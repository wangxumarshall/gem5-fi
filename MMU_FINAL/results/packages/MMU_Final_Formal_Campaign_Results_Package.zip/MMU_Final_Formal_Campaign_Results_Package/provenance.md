# Provenance

```json
{
 "campaign_id": "MMU-FORMAL-20261113",
 "repo_root": "/home/sdc/gem5-fi-mmu-impl-v2",
 "git_head": "872953c22e041f191555e1a29da188da86a18467",
 "source_closure_commit": "60f1a8760410288128061d85582e5395b24c0106",
 "binary": {
  "path": "/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt",
  "sha256": "b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185"
 },
 "source_sha256": {
  "CHAOS/gem5/src/arch/arm/mmu.cc": "bba49e65398f80aaf58b3ce5a954f4ffbd68278dd0b5c888124d249e28dd1c1b",
  "CHAOS/gem5/src/arch/arm/table_walker.cc": "54dbeeff2e40891eb018c4bf891a5446ab2b8c4fe88f69c40647c26923595985",
  "CHAOS/gem5/src/arch/arm/table_walker.hh": "89110e2081da62743e4c2325aa656976e945f086959bcd29f18882412e44b611",
  "CHAOS/gem5/src/arch/arm/tlb.cc": "b81b7b4cc9eee2c7ba0b592775587dcc7610c8d18c237ba412d2c69ba80d52f4",
  "CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.cc": "38c0942ab5d2c4c73b7ee3763c1d7503b708ba9ba4f73c2fd051db6836052dc4",
  "CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.hh": "90ea1b55a9a7e51db04fad4a23ceee3107ebc2d375c3d5c5902b9ffb6b2d3336"
 },
 "authority": {
  "gem5-fi-MMU-Final-Paper-Experiment-Plan.xlsx": {
   "path": "/home/sdc/gem5-fi-mmu-impl-v2/phase3/final/MMU_Final_Formal_Readiness_Package_v3.0.2/gem5-fi-MMU-Final-Paper-Experiment-Plan.xlsx",
   "sha256": "82dc67e34869260b77cf781042550ec6fd9d6257b0231ad11a3000d526dd9cc3"
  },
  "MMU_40_Sample_Matrix.csv": {
   "path": "/home/sdc/gem5-fi-mmu-impl-v2/phase3/final/MMU_Final_Formal_Readiness_Package_v3.0.2/MMU_40_Sample_Matrix.csv",
   "sha256": "34dc41f5e2f67dedf1b0890469539e4f5bf6c3ba2baa97a6021d68543c3a2906"
  },
  "MMU_Parameter_Authority_v3.0.2.json": {
   "path": "/home/sdc/gem5-fi-mmu-impl-v2/phase3/final/MMU_Final_Formal_Readiness_Package_v3.0.2/MMU_Parameter_Authority_v3.0.2.json",
   "sha256": "d015e054d39acf554dafa529db306f73b8c2295047654b73803cb95f2197c177"
  }
 },
 "runner": {
  "path": "/home/sdc/gem5-fi-mmu-impl-v2/tools/mmu_formal_runner.py",
  "sha256": "730e8d3bdd424e94464d42f1bd76fd26a4f2a1701790af03d530bb985491a0ea"
 },
 "workloads": {
  "W9": "4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98",
  "W10": "733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae",
  "W10S": "fede5f3ea4c3224f34ef9768a8cbb0fe49b071cab86306e67e7a73610f11b0a3",
  "W11": "1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4",
  "W12": "8fa269fd88eaf9126f67cf80d5d77f13600e211948db5cd7f4b89f42c147fdbc",
  "W13": "6e7d926e863c15433b3887e3ac069169e510751190d4b0de5dae0e7aa886ec70",
  "W14": "f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36"
 },
 "kernel": {
  "path": "/home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux",
  "sha256": "9b9b9ce70bc6fb831461b527ccf36f124f1af8f3dc717d7ef13e62060aecfa7e"
 },
 "bootloader": {
  "path": "/home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64",
  "sha256": "37ca07b55da2c0843d6670bb0693d21159236e0c6b74526f531abaeeaab51bfd"
 },
 "checkpoint": "/home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609",
 "disk_template": {
  "path": "/home/sdc/gem5-fi-mmu-impl-v2/runs/disks/mmu_template.img",
  "sha256": "bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759"
 },
 "started_utc": "2026-11-13T06:38:35Z",
 "finished_utc": "2026-11-13T15:48:24Z"
}
```
