# Independent Trace Sampling Verification

Seven original traces were copied byte-for-byte (SHA256 verified) and causal slices were extracted from the copied originals with `scripts/extract_slice.py`. No event was synthesized.

| Sample | Trace events | Slice events | Missing | Chain mismatches | Fabricated | Verdict |
|---|---|---|---|---|---|---|
| M01-F0-W9-S01-R01 | 1429 | 25 | none | 0 | 0 | PASS |
| M03-F0-W11-S01-R01 | 535 | 10 | none | 0 | 0 | PASS |
| M03-F0-W11-S01-R05 | 337 | 45 | none | 0 | 0 | PASS |
| M05-F0-W13-S01-R05 | 297 | 81 | none | 0 | 0 | PASS |
| M06-F0-W10-S01-R02 | 8607 | 25 | none | 0 | 0 | PASS |
| M07-F0-W14-S01-R02 | 491 | 29 | none | 0 | 0 | PASS |
| M07-F0-W14-S01-R05 | 413 | 73 | none | 0 | 0 | PASS |

## Slice roles

### M01-F0-W9-S01-R01

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M01-F0-W9-S01-R01/Trace/prop_evt.txt.gz`
- Source SHA256: `039f72b44cf2b6eed3e4b30ff441c79aa031a01bc22b0cb6580fa5ed0320cc0a`
- Copied SHA256: `039f72b44cf2b6eed3e4b30ff441c79aa031a01bc22b0cb6580fa5ed0320cc0a` (identical=True)
- Requested/slice: 25/25; missing: none; chain mismatches: 0; fabricated: 0

### M03-F0-W11-S01-R01

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M03-F0-W11-S01-R01/Trace/prop_evt.txt.gz`
- Source SHA256: `f57622313144ee17df1f33306283e28e07b3795e00de111c12985cddfdce279d`
- Copied SHA256: `f57622313144ee17df1f33306283e28e07b3795e00de111c12985cddfdce279d` (identical=True)
- Requested/slice: 10/10; missing: none; chain mismatches: 0; fabricated: 0

### M03-F0-W11-S01-R05

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M03-F0-W11-S01-R05/Trace/prop_evt.txt.gz`
- Source SHA256: `3ee7f576aaff072c475be2a796d2634b02333f912f82e80d70d9f177f9617787`
- Copied SHA256: `3ee7f576aaff072c475be2a796d2634b02333f912f82e80d70d9f177f9617787` (identical=True)
- Requested/slice: 45/45; missing: none; chain mismatches: 0; fabricated: 0

### M05-F0-W13-S01-R05

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M05-F0-W13-S01-R05/Trace/prop_evt.txt.gz`
- Source SHA256: `9a5e6d7ba2e7af713324f2af7704fd33a4dee1f17d982696e4a45ef11186098e`
- Copied SHA256: `9a5e6d7ba2e7af713324f2af7704fd33a4dee1f17d982696e4a45ef11186098e` (identical=True)
- Requested/slice: 81/81; missing: none; chain mismatches: 0; fabricated: 0

### M06-F0-W10-S01-R02

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M06-F0-W10-S01-R02/Trace/prop_evt.txt.gz`
- Source SHA256: `efcf8e11c5b78901e89d4690f62fcab3d1a73bdbd0cbd3070f156243bff8a3db`
- Copied SHA256: `efcf8e11c5b78901e89d4690f62fcab3d1a73bdbd0cbd3070f156243bff8a3db` (identical=True)
- Requested/slice: 25/25; missing: none; chain mismatches: 0; fabricated: 0

### M07-F0-W14-S01-R02

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M07-F0-W14-S01-R02/Trace/prop_evt.txt.gz`
- Source SHA256: `82c1989f8af1ab88444a8077298f28e86bb5419f8a7297ea5424bc1f0a3128d9`
- Copied SHA256: `82c1989f8af1ab88444a8077298f28e86bb5419f8a7297ea5424bc1f0a3128d9` (identical=True)
- Requested/slice: 29/29; missing: none; chain mismatches: 0; fabricated: 0

### M07-F0-W14-S01-R05

- Source trace: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/attempt_A01/M07-F0-W14-S01-R05/Trace/prop_evt.txt.gz`
- Source SHA256: `e39266c85d5b40438fd7cd9d49c546fbf3c1822d971240b1bce9496be26db72d`
- Copied SHA256: `e39266c85d5b40438fd7cd9d49c546fbf3c1822d971240b1bce9496be26db72d` (identical=True)
- Requested/slice: 73/73; missing: none; chain mismatches: 0; fabricated: 0

## Verdict

`TRACE_SAMPLE_VERIFICATION = PASS` (7/7 PASS).
