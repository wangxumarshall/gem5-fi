"""Fault consumption semantics.

Distinguishes:
  FaultInjected
  FaultActivated
  FaultStateConsumed
  DownstreamArchitecturalConsumption
  ExplicitFaultStateConsumedEventObserved

Consumption evidence must be a real event in the original trace.  The verdict
supplies the expected event ID/kind; this module verifies it rather than
inventing one.
"""

CONSUMER_KINDS = ('lsu_request', 'commit', 'exception_delivery')


def _x(e):
    return e.get('ExtraFields') or {}


def _find(events, eid):
    for e in events:
        try:
            if int(e.get('EventID', e.get('event_id', -1))) == int(eid):
                return e
        except (TypeError, ValueError):
            continue
    return None


def evaluate(verdict, events, guest):
    """Return consumption semantics for one sample.

    `events` must include the frozen chain events and, where available, the
    selected raw-trace events.  `guest` carries the software-visible oracle
    symptoms.
    """
    status = verdict.get('ActivationStatus', '')
    cons_status = verdict.get('FaultConsumptionStatus', '')
    act_id = verdict.get('activation_event_id')
    cons_id = verdict.get('consumption_event_id')
    details = verdict.get('Details') or {}
    ev = _find(events, cons_id)
    act = _find(events, act_id)
    explicit = [e for e in events
                if e.get('Kind') == 'fault_state_consumed']
    kinds = [e.get('Kind', '') for e in events]
    term = verdict.get('TerminalState', '')
    consumed = (cons_status == 'CONSUMED' and ev is not None)
    downstream_kind = ''
    if consumed and term != 'SQUASHED':
        for e in events:
            eid = e.get('EventID', e.get('event_id', -1))
            try:
                after = int(eid) >= int(cons_id)
            except (TypeError, ValueError):
                after = False
            if after and e.get('Kind') in CONSUMER_KINDS:
                downstream_kind = e.get('Kind')
                break
    downstream = bool(consumed and term != 'SQUASHED' and
                      (downstream_kind or 'exception_delivery' in kinds))
    share = guest.get('GuestSharedChanged', '')
    arch_data = bool(
        consumed and term != 'SQUASHED' and
        (guest.get('GuestValueMismatch') is True or str(share) == '1'))
    conf = 'HIGH'
    if ev is None:
        conf = 'LOW'
    elif _x(ev).get('permission_result') is not None and \
            verdict.get('consumption_kind') not in (
                '', None, 'permission_eval'):
        conf = 'MEDIUM'
    join = {}
    if ev is not None:
        for k in ('TranslationID', 'EntryID', 'EntryGeneration',
                  'UniqueRequestID', 'VA', 'PA'):
            if ev.get(k) not in (None, ''):
                join[k] = ev[k]
        for k in ('translation_id', 'tlb_entry_id', 'entry_generation',
                  'unique_request_id', 'va', 'pa'):
            if _x(ev).get(k) not in (None, ''):
                join[k] = _x(ev)[k]
    return {
        'FaultInjected': bool(act is not None and status == 'ACTIVATED'),
        'FaultActivated': status == 'ACTIVATED',
        'FaultStateConsumed': consumed,
        'ExplicitFaultStateConsumedEventObserved': bool(explicit),
        'ExplicitFaultStateConsumedEventIDs': ';'.join(
            str(e.get('EventID', e.get('event_id', ''))) for e in explicit),
        'ConsumptionEvidenceEventID': cons_id if ev is not None else '',
        'ConsumptionEvidenceKind': ev.get('Kind', '') if ev else '',
        'ConsumptionEvidenceSource': (
            'verdict.consumption_kind=%s; consumption_basis=%s; verified in '
            'original trace' % (verdict.get('consumption_kind'),
                                details.get('consumption_basis', ''))),
        'ConsumptionJoinKeys': join,
        'ConsumptionEvidenceConfidence': conf,
        'DownstreamArchitecturalConsumption': downstream,
        'DownstreamConsumptionKind': downstream_kind,
        'ArchitecturalDataCorruption': arch_data,
        'PropagationStatus': verdict.get('PropagationStatus', ''),
        'TerminalState': term,
        'ConsumptionEvidencePresent': ev is not None,
        'ConsumptionEvidenceNote': (
            '' if ev is not None else
            'verdict reports CONSUMED but the consumption event was not '
            'located in the frozen trace'),
    }
