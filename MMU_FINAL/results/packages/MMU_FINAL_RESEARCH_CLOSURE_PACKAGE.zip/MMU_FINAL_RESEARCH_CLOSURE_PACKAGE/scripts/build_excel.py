#!/usr/bin/env python3
"""Build the single authoritative final Excel workbook from structured data."""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

import openpyxl
from openpyxl.styles import Font


def load_csv(path):
    return list(csv.DictReader(open(path))) if Path(path).is_file() else []


def add_sheet(wb, title, rows, columns=None):
    ws = wb.create_sheet(title)
    if not rows:
        ws.append(['(empty)'])
        return ws
    cols = columns or list(rows[0].keys())
    ws.append(cols)
    ws['A1'].font = Font(bold=True)
    for r in rows:
        ws.append([json.dumps(r.get(c, ''), sort_keys=True)
                   if isinstance(r.get(c), (dict, list))
                   else r.get(c, '') for c in cols])
    ws.freeze_panes = 'B2'
    return ws


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    samples = data['samples']
    gt_rows, orig_rows, sim_rows, blind_rows, cons_rows, term_rows = (
        [], [], [], [], [], [])
    for r in samples:
        g, o, s, b, c, t = (r['GroundTruth'], r['OriginalResult'],
                            r['SimulatorAssisted'], r['BlindedObservation'],
                            r['Consumption'], r['TerminalSemantics'])
        gt_rows.append(dict(g, OpaqueSampleID=r['OpaqueSampleID']))
        orig_rows.append(dict(o, SampleRunID=r['SampleRunID'],
                              OpaqueSampleID=r['OpaqueSampleID']))
        sim_rows.append(dict(s, OpaqueSampleID=r['OpaqueSampleID']))
        blind_rows.append(dict(b, OpaqueSampleID=r['OpaqueSampleID']))
        cons_rows.append(dict(c, SampleRunID=r['SampleRunID'],
                              OpaqueSampleID=r['OpaqueSampleID']))
        term_rows.append(dict(t, SampleRunID=r['SampleRunID'],
                              OpaqueSampleID=r['OpaqueSampleID']))
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Readme'
    for line in [
        ['MMU FINAL Research Feature Library'],
        ['Campaign', 'MMU-FORMAL-20261113'],
        ['Frozen binary', data['metadata']['frozen_binary_sha256']],
        ['Source closure', data['metadata']['source_closure']],
        ['Samples', len(samples)],
        ['Views', 'Ground Truth / Simulator-Assisted / Blinded'],
        ['Blind view', 'No FaultModelID/FaultOrigin/InjectionLocation/'
                       'TraceFaultSite/FaultField inputs'],
        ['Consumption', 'FaultInjected/FaultActivated/FaultStateConsumed/'
                        'DownstreamArchitecturalConsumption separated'],
        ['Repeatability', '10 fully expanded isolated commands; not executed'],
        ['Status', 'See reports/Final_Research_Closure_Report.md'],
    ]:
        ws.append(line)
    ws['A1'].font = Font(bold=True, size=14)
    add_sheet(wb, 'Ground_Truth', gt_rows)
    add_sheet(wb, 'Original_40_Results', orig_rows)
    add_sheet(wb, 'Simulator_Features', sim_rows)
    add_sheet(wb, 'Blinded_Observations', blind_rows)
    add_sheet(wb, 'Consumption_Evidence', cons_rows)
    add_sheet(wb, 'Manifestation_Types', term_rows)
    add_sheet(wb, 'Model_Signatures', load_csv(
        FINAL / 'discriminability' / 'MMU_Model_Signatures.csv'))
    add_sheet(wb, 'Cross_Model_Discriminability', load_csv(
        FINAL / 'discriminability' / 'MMU_Cross_Model_Discriminability.csv'))
    add_sheet(wb, 'Observability_Classification', load_csv(
        FINAL / 'leakage' / 'MMU_Feature_Observability_Matrix.csv'))
    add_sheet(wb, 'Repeatability_Samples', load_csv(
        FINAL / 'repeatability' / 'MMU_Repeatability_Launch_Matrix.csv'))
    add_sheet(wb, 'Repeatability_Parity', load_csv(
        FINAL / 'repeatability' / 'Repeatability_Parameter_Parity.csv'))
    add_sheet(wb, 'Research_Limitations', [
        {'Limitation': x} for x in [
            'Blinded observation cannot separate M04 vs M08; requires '
            'simulator-only entry/request-PA evidence.',
            'M02/M04/M08 share final wrong-value symptoms; trace events are '
            'needed for separation.',
            'M01/M03 final wrong value alone is ambiguous; maintenance/ASID/'
            'permission evidence is required.',
            'Production availability of TLB/PTW/PFN/entry-generation signals '
            'is UNKNOWN and must not be assumed.',
            'M03 R01-R04 are SQUASHED/PARTIAL/COMPLETE, not detected '
            'exceptions.',
            'M06 R01-R05 are DETECTED_CONTAINED, not generic MASKED.',
            'M07 R02 has no permission_eval joined to the activation '
            'TranslationID; nearest same-VA deny is event 345/tid 5.',
            'No classifier accuracy or cross-workload generalization is '
            'claimed.',
            '10 repeatability runs are prepared but not executed.',
        ]])
    add_sheet(wb, 'Provenance', load_csv(
        FINAL / 'provenance' / 'Provenance_Table.csv')
        if (FINAL / 'provenance' / 'Provenance_Table.csv').is_file()
        else [{'Note': 'See provenance/Provenance.md'}])
    add_sheet(wb, 'Change_Log', [
        {'Change': x} for x in [
            'Created three strictly separated data views.',
            'Removed GT-derived UpstreamPathClass from blind view; replaced '
            'with event-derived observed path class.',
            'Separated consumption semantics into four stages.',
            'Prepared 10 fully expanded, hash-pinned repeat commands.',
            'Versioned terminal semantic corrections.',
            'No frozen data, binary, workload or trace was modified.',
        ]])
    out = FINAL / 'excel' / 'MMU_FINAL_Research_Feature_Library.xlsx'
    wb.save(out)
    print(json.dumps({'xlsx': str(out), 'sheets': wb.sheetnames,
                      'size_bytes': out.stat().st_size}, indent=1))


if __name__ == '__main__':
    main()
