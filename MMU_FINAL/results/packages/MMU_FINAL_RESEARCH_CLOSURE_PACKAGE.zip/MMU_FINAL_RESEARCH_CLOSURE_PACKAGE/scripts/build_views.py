#!/usr/bin/env python3
"""Build Ground Truth, Simulator-Assisted and Blinded views + leakage audit."""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

FINAL = C.OUT / 'final_closure'
VIEWS = FINAL / 'views'
LEAK = FINAL / 'leakage'


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    samples = data['samples']

    gt_rows, sim_rows, blind_rows = [], [], []
    for r in samples:
        g = r['GroundTruth']; o = r['OriginalResult']; s = r['SimulatorAssisted']
        b = r['BlindedObservation']
        gt_rows.append({
            'SampleRunID': r['SampleRunID'],
            'OpaqueSampleID': r['OpaqueSampleID'],
            'FaultModelID': g['FaultModelID'],
            'FaultOrigin': g['FaultOrigin'],
            'FaultType': g['FaultType'],
            'SourceFile': g['FaultLocation'].get('SourceFile', ''),
            'SourceFunction': g['FaultLocation'].get('SourceFunction', ''),
            'TraceFaultSite': g['TraceFaultSite'],
            'InjectionLocation': g['InjectionLocation'],
            'FaultField': g['FaultField'],
            'TargetVA': g['TargetVA'],
            'AccessMode': g['AccessMode'],
            'FaultStateBefore': g['FaultStateBefore'],
            'FaultStateAfter': g['FaultStateAfter'],
            'FaultParameters': g['FaultParameters'],
            'OriginalTerminalState': g['OriginalTerminalState'],
            'OriginalOracleResult': g['OriginalOracleResult'],
            'OriginalPropagationStatus': g['OriginalPropagationStatus'],
            'OriginalTraceCompleteness': g['OriginalTraceCompleteness'],
        })
        sim_rows.append(dict(s, **{
            'ContextID': o['ContextID'],
            'WorkloadID': o['WorkloadID'],
            'TerminalState': o['TerminalState'],
            'OracleResult': o['OracleResult'],
            'PropagationStatus': o['PropagationStatus'],
        }))
        blind_rows.append(dict(b, **{
            'OpaqueSampleID': r['OpaqueSampleID'],
        }))
    C.write_csv(VIEWS / 'MMU_Ground_Truth.csv', gt_rows)
    C.write_json(VIEWS / 'MMU_Ground_Truth.json', gt_rows)
    C.write_csv(VIEWS / 'MMU_Simulator_Assisted_Features.csv', sim_rows)
    C.write_json(VIEWS / 'MMU_Simulator_Assisted_Features.json', sim_rows)
    C.write_csv(VIEWS / 'MMU_Blinded_Diagnostic_Features.csv', blind_rows)
    C.write_json(VIEWS / 'MMU_Blinded_Diagnostic_Features.json', blind_rows)

    # ---- field-level leakage audit ---------------------------------------
    def row(feature, source_file, source_func, fields, gt, obs, risk,
            allowed, reason):
        return {
            'FeatureName': feature, 'SourceFile': source_file,
            'SourceFunction': source_func, 'SourceFields': fields,
            'DerivedFromGroundTruth': gt, 'ObservabilityClass': obs,
            'LeakageRisk': risk, 'AllowedInBlindView': allowed,
            'Reason': reason,
        }
    audit = [
        row('FaultModelID', 'MMU_Final_Dataset.json',
            'build_final_dataset.GroundTruth', 'manifest.model', True,
            'GROUND_TRUTH', 'CRITICAL', 'NO',
            'direct model identity'),
        row('FaultOrigin', 'MMU_Final_Dataset.json',
            'build_final_dataset.GroundTruth', 'feature_library.ModelMechanism',
            True, 'GROUND_TRUTH', 'CRITICAL', 'NO',
            'direct model mechanism'),
        row('InjectionLocation', 'MMU_Final_Dataset.json',
            'build_final_dataset.GroundTruth',
            'feature_library.InjectionLocation', True, 'GROUND_TRUTH',
            'CRITICAL', 'NO', 'injector source/site'),
        row('TraceFaultSite', 'MMU_Final_Dataset.json',
            'build_final_dataset.GroundTruth',
            'feature_library.InjectionLocation.TraceFaultSite', True,
            'GROUND_TRUTH_DERIVED', 'CRITICAL', 'NO',
            'old UpstreamPathClass used this field; now forbidden'),
        row('FaultField', 'MMU_Final_Dataset.json',
            'build_final_dataset.GroundTruth',
            'feature_library.TargetField', True, 'GROUND_TRUTH_DERIVED',
            'CRITICAL', 'NO', 'mutated field known only to the injector'),
        row('UpstreamPathClass_SIM (addendum v1)', 'addendum/observable_features/'
            'build_observable_features.py', 'build_observable_features.main',
            'InjectionLocation.TraceFaultSite', True,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'HIGH', 'NO',
            'legacy field used TraceFaultSite; replaced by '
            'ObservedPathClass_BLIND'),
        row('ObservedPathClass', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind',
            'non-injector event kinds only', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'derived from observed events; no GT argument in signature'),
        row('ObservedEventKinds', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind',
            'non-injector event kinds only', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'injector-only kinds are filtered out'),
        row('ObservedMaintenanceEvents', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'tlbi_match/tlbi_invalidate',
            False, 'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'real maintenance events, not injector labels'),
        row('ObservedPTW', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'ptw_start/pte_read', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'real walker events'),
        row('ObservedPartialEntry', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'partial_entry_insert', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'real walk-cache event'),
        row('ObservedPermissionResults', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'permission_eval result', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'real permission evaluation event'),
        row('ObservedSquash', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'squash', False,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'NONE', 'YES',
            'real pipeline event'),
        row('ObservedExceptionDelivery', 'final_closure/scripts/blind_features.py',
            'blind_features.derive_blind', 'exception_delivery', False,
            'POTENTIALLY_SOFTWARE_OBSERVABLE', 'NONE', 'YES',
            'architectural exception event; real hardware observability '
            'not proven'),
        row('GuestSignal', 'final_closure/scripts/build_final_dataset.py',
            'guest_from_verdict', 'verdict.oracle.line.signal', False,
            'PRODUCTION_OBSERVABLE', 'NONE', 'YES',
            'software-visible process signal'),
        row('GuestValueMismatch', 'final_closure/scripts/build_final_dataset.py',
            'guest_from_verdict', 'verdict.oracle.line observed/expected',
            False, 'PRODUCTION_OBSERVABLE', 'NONE', 'YES',
            'requires an application-level oracle'),
        row('GuestUnexpectedSuccess', 'final_closure/scripts/build_final_dataset.py',
            'guest_from_verdict',
            'verdict.oracle.line signal/control signal', False,
            'PRODUCTION_OBSERVABLE', 'NONE', 'YES',
            'software sees an access succeed without fault'),
        row('OpaqueSampleID', 'MMU_Opaque_ID_Map.csv',
            'build_final_dataset.main', 'sorted index S001..S040', False,
            'INDEX_ONLY', 'NONE', 'INDEX_ONLY',
            'external index; carries no model identity'),
        row('ChainEventKinds', 'MMU_Final_Dataset.json',
            'build_final_dataset.SimulatorAssisted', 'chain events', True,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'HIGH', 'NO',
            'chain includes injector-only event kinds and is not blinded'),
        row('FaultStateBefore/After', 'MMU_Final_Dataset.json',
            'build_final_dataset.SimulatorAssisted', 'activation state', True,
            'SIMULATOR_INSTRUMENTATION_ONLY', 'HIGH', 'NO',
            'activation state is injector-authored'),
        row('ConsumptionEvidenceEventID', 'MMU_Final_Dataset.json',
            'consumption_semantics.evaluate', 'verdict consumption event',
            False, 'SIMULATOR_INSTRUMENTATION_ONLY', 'MEDIUM', 'NO',
            'event-level consumption evidence is for simulator-assisted '
            'analysis; not a blind production input'),
    ]
    C.write_csv(LEAK / 'MMU_Feature_Leakage_Audit.csv', audit)
    C.write_json(LEAK / 'MMU_Feature_Leakage_Audit.json', audit)

    # ---- observability matrix --------------------------------------------
    obs = [
        ('ObservedPathClass', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'event-kind derived; no production '
         'equivalent proven'),
        ('ObservedEventKinds', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'gem5 trace instrumentation'),
        ('ObservedTLBHits/Misses', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'TLB internals'),
        ('ObservedPTW/PartialEntry', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'walker internals'),
        ('ObservedPermissionResults', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'internal permission decision'),
        ('ObservedSquash', 'SIMULATOR_INSTRUMENTATION_ONLY',
         'blind_features.derive_blind', 'pipeline squash'),
        ('ObservedExceptionDelivery', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'blind_features.derive_blind', 'architectural exception may be '
         'visible; exact hardware path unproven'),
        ('GuestSignal/SICode', 'PRODUCTION_OBSERVABLE',
         'guest oracle', 'process-visible signal'),
        ('GuestValueMismatch', 'PRODUCTION_OBSERVABLE',
         'guest oracle + application oracle', 'needs an expected value'),
        ('GuestUnexpectedSuccess', 'PRODUCTION_OBSERVABLE',
         'guest oracle + control', 'software sees missing fault'),
        ('TLBEntryID/Generation', 'UNKNOWN',
         'simulator-assisted only', 'no proven real-hardware interface'),
        ('ModifiedPFN/InternalPTE', 'UNKNOWN',
         'simulator-assisted only', 'requires internal inspection'),
        ('PermissionGrantDecision', 'UNKNOWN',
         'simulator-assisted only', 'internal decision not exposed'),
        ('Per-instruction IFU Fetch/Decode/Commit', 'UNKNOWN',
         'not emitted by frozen binary', 'cannot be reconstructed'),
    ]
    C.write_csv(LEAK / 'MMU_Feature_Observability_Matrix.csv',
                [{'Feature': a, 'ObservabilityClass': b, 'Source': c,
                  'EvidenceBasis': d} for a, b, c, d in obs])
    C.write_json(LEAK / 'MMU_Feature_Observability_Matrix.json',
                 [{'Feature': a, 'ObservabilityClass': b, 'Source': c,
                   'EvidenceBasis': d} for a, b, c, d in obs])

    # ---- provenance -------------------------------------------------------
    prov = []
    for f in blind_rows[0].keys():
        prov.append({
            'Feature': f,
            'View': 'Blinded',
            'Source': 'blind_features.derive_blind / guest_from_verdict',
            'GroundTruthSource': 'NONE',
            'Note': 'generated without model/fault-site/fault-field inputs',
        })
    for f in sim_rows[0].keys():
        prov.append({
            'Feature': f,
            'View': 'SimulatorAssisted',
            'Source': 'build_final_dataset.SimulatorAssisted',
            'GroundTruthSource': (
                'YES' if f in ('FaultModelID', 'FaultOrigin',
                               'TraceFaultSite', 'FaultField',
                               'StateTransitionValues') else 'NO'),
            'Note': 'simulator-assisted analysis only',
        })
    C.write_csv(LEAK / 'MMU_Feature_Provenance.csv', prov)

    md = ['# Blinded Diagnostic View Generation\n\n',
          '`blind_features.derive_blind(events, guest, access_mode, '
          'target_va)` has **no ground-truth parameter**. It filters '
          'injector-only event kinds and derives path classes only from '
          'non-injector microarchitectural events.\n\n',
          '## Guarantees\n\n',
          '- No `FaultModelID`, `FaultOrigin`, `InjectionLocation`, '
          '`TraceFaultSite` or `FaultField` input.\n',
          '- `SampleRunID` is replaced by `OpaqueSampleID` (S001..S040); the '
          'mapping is in the Ground Truth view only.\n',
          '- Injector-only kinds (`mmu_fault_*`, `refill_pfn_corrupt`, '
          '`tlbi_suppressed`, `tlb_entry_lineage`, `fault_state_consumed`, '
          '`fault_result_propagated`, `fault_entry_*`, `chain_end`) are '
          'removed before deriving observations.\n',
          '- `ObservedPathClass` is deliberately ambiguous where the '
          'remaining events are ambiguous (e.g. `RESIDENT_HIT` covers M04/M08; '
          '`PERMISSION_DENIED_SQUASHED` covers M03 R01-R04).\n',
          '- `TerminalState`, `OracleResult` and `ManifestationType` are not '
          'in the blinded input; guest symptoms are software-visible '
          'observations, not origin labels.\n\n',
          '## Leakage finding\n\n',
          'The old `UpstreamPathClass_SIM` used '
          '`InjectionLocation.TraceFaultSite` and was effectively a model '
          'label. It is retained only in the legacy addendum and marked '
          '`LeakageRisk=HIGH`, `AllowedInBlindView=NO`.\n\n',
          'No classifier is trained and no accuracy is claimed.\n']
    (LEAK / 'Blinded_View_Generation.md').write_text(''.join(md))
    print(json.dumps({
        'ground_truth_rows': len(gt_rows),
        'simulator_rows': len(sim_rows),
        'blinded_rows': len(blind_rows),
        'blind_columns': list(blind_rows[0].keys()),
        'leakage_rows': len(audit),
        'path_classes': sorted({r['ObservedPathClass']
                                for r in blind_rows}),
    }, indent=1))


if __name__ == '__main__':
    main()
