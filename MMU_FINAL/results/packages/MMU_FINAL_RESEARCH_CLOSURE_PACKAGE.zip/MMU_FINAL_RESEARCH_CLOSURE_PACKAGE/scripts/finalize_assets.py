#!/usr/bin/env python3
"""Copy describe/trace evidence and write per-repeat launch manifests."""
import csv
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'


def main():
    desc_out = FINAL / 'repeatability' / 'describe'
    desc_out.mkdir(parents=True, exist_ok=True)
    for p in (ADD / 'describe' / 'raw').glob('*.json'):
        shutil.copy2(p, desc_out / p.name)
    for p in desc_out.glob('M*.md'):
        p.unlink()
    for name in ('Describe_Parity_Check.csv', 'Describe_Parity_Check.json'):
        p = ADD / 'describe' / name
        if p.is_file():
            shutil.copy2(p, desc_out / name)
    parity_all = json.load(open(ADD / 'describe' /
                                'Describe_Parity_Check.json'))
    tr_out = FINAL / 'evidence' / 'trace_samples'
    tr_out.mkdir(parents=True, exist_ok=True)
    for p in (ADD / 'trace_samples').iterdir():
        dst = tr_out / p.name
        if p.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(p, dst)
        else:
            shutil.copy2(p, dst)
    rows = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'MMU_Repeatability_Launch_Matrix.csv')))
    parity = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'Repeatability_Parameter_Parity.csv')))
    pdir = FINAL / 'repeatability' / 'parity'
    pdir.mkdir(parents=True, exist_ok=True)
    for r in rows:
        base = Path(r['Outdir']).parent
        man = dict(r)
        man['ExpectedExecutionIsolationDifferences'] = [
            'outdir', 'readfile', 'disk', 'prop_run_id',
            'prop_sample_run_id']
        man['NoGem5Started'] = True
        man['LaunchCommandScript'] = r['CommandScript']
        (base / 'launch_manifest.json').write_text(
            json.dumps(man, indent=2, sort_keys=True) + '\n')
        checks = [p for p in parity if p['RepeatID'] == r['RepeatID']]
        (pdir / ('%s.json' % r['RepeatID'])).write_text(
            json.dumps(checks, indent=2, sort_keys=True) + '\n')
    # Generate describe markdown with the fully expanded command (no
    # template placeholders).
    for r in rows:
        sid = r['RepeatOfSampleRunID']
        raw = json.load(open(desc_out / ('%s.json' % sid)))
        plan = raw['plan']
        checks = [p for p in parity_all if p['SampleRunID'] == sid]
        d = ['# Read-Only Describe: %s\n\n' % sid,
             'Status: `%s`; would_run=`%s`; parity_ok=`%s`.\n\n' % (
                 raw.get('status'), raw.get('would_run'),
                 raw.get('parity_ok')),
             '| Field | Value |\n|---|---|\n',
             '| Model label | `%s` |\n' % r['ModelID'],
             '| Context | `%s` |\n' % r['ContextID'],
             '| Target VA | `%s` |\n' % ('0x%x' % plan['target_va']),
             '| Mode / n / ordinal | %s / %s / %s |\n' % (
                 plan.get('target_mode'), plan.get('target_n'),
                 plan.get('eligible_event_index')),
             '| Executed guest | `%s` |\n' % r['ExecutedGuestBinarySHA256'],
             '| Disk copy | `%s` |\n' % r['DiskCopy'],
             '| rcS copy | `%s` |\n\n' % r['RcsCopy'],
             '## Fully expanded command\n\n```bash\n%s\n```\n\n' %
             r['FullCommand'],
             '## Parity checks\n\n| Check | Status |\n|---|---|\n']
        for c in checks:
            d.append('| %s | %s |\n' % (c['CheckID'], c['Status']))
        (desc_out / ('%s.md' % sid)).write_text(''.join(d))
    md = ['# Fully Expanded Repeatability Commands\n\n',
          'All commands use absolute paths, isolated output dirs, byte-copied '
          'rcS and hash-pinned sparse disk copies. No gem5 run was started.\n\n']
    for r in rows:
        md.append('## %s (repeat of %s)\n\n' % (
            r['RepeatID'], r['RepeatOfSampleRunID']))
        md.append('```bash\n%s\n```\n\n' % r['FullCommand'])
        md.append('- Outdir: `%s`\n' % r['Outdir'])
        md.append('- rcS: `%s` (`%s`)\n' % (r['RcsCopy'],
                                            r['RcsCopySHA256']))
        md.append('- Disk: `%s` (`%s`)\n' % (r['DiskCopy'],
                                             r['DiskCopySHA256']))
        md.append('- Executed guest: `%s`\n\n' %
                  r['ExecutedGuestBinarySHA256'])
    (FINAL / 'repeatability' / 'RepeatCommands.md').write_text(''.join(md))
    iso = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'Repeatability_Output_Isolation_Audit.csv')))
    imd = ['# Repeatability Output Isolation Audit\n\n',
           '| RepeatID | Formal Run | Collision | Expected differences |\n'
           '|---|---|---|---|\n']
    for r in iso:
        imd.append('| %s | %s | %s | %s |\n' % (
            r['RepeatID'], r['FormalSampleRunID'], r['Collision'],
            r['ExpectedDifferences']))
    imd.append('\nAll outdirs are under the final closure repeatability tree; '
               'no formal, pilot or failed-attempt path is written. Disk '
               'copies are separate inodes and are excluded from the ZIP.\n')
    (FINAL / 'repeatability' /
     'Repeatability_Output_Isolation_Audit.md').write_text(''.join(imd))
    print(json.dumps({
        'describe_json': len(list(desc_out.glob('*.json'))),
        'describe_md': len(list(desc_out.glob('M*.md'))),
        'trace_sample_dirs': len([p for p in tr_out.iterdir()
                                  if p.is_dir()]),
        'launch_manifests': len(rows),
        'parity_reports': len(rows),
    }, indent=1))


if __name__ == '__main__':
    main()
