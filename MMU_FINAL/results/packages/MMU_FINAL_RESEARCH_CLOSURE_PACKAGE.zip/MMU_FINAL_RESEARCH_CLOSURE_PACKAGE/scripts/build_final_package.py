#!/usr/bin/env python3
"""Build the final closure ZIP and SHA256 manifest (disk images excluded)."""
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ZIP = C.CAMP / 'MMU_FINAL_RESEARCH_CLOSURE_PACKAGE.zip'


def sha(p):
    return C.sha256_file(p)


def walk(root):
    out = []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x != '__pycache__']
        for f in sorted(files):
            p = Path(d) / f
            if p.name in ('SHA256_MANIFEST.txt',):
                continue
            if p.suffix in ('.img', '.pyc'):
                continue
            out.append(p)
    return sorted(out, key=lambda p: str(p.relative_to(root)))


def main():
    # vendor common.py so the tests are self-contained after extraction
    src_common = C.OUT / 'scripts' / 'common.py'
    dst_common = FINAL / 'scripts' / 'common.py'
    if src_common.is_file() and src_common.resolve() != dst_common.resolve():
        shutil.copy2(src_common, dst_common)
    status = json.load(open(FINAL / 'statuses' / 'STATUS.json'))
    readme = '''# MMU FINAL RESEARCH CLOSURE PACKAGE

Campaign: `MMU-FORMAL-20261113`

```text
FORMAL_DATA_INTEGRITY              = %s
DIAGNOSTIC_FEATURE_INTEGRITY       = %s
REPEATABILITY_EXECUTION_READINESS  = %s
INDEPENDENT_ACCEPTANCE             = %s
MMU_FINAL_RESEARCH_CLOSURE         = %s
MMU_DIAGNOSTIC_FEATURE_GATE        = %s
MMU_REPEATABILITY_LAUNCH_GATE      = %s
```

No gem5 experiment was started. No frozen C++ hook, binary, workload,
SampleRunID, trace, manifest, verdict or original result was modified.
The 10 repeatability runs are prepared for researcher approval only.

## Contents

| Path | Content |
|---|---|
| `reports/Final_Research_Closure_Report.md` | final closure report |
| `reports/Original_40_Sample_Integrity_Audit.{md,json,csv}` | original data audit |
| `views/MMU_Ground_Truth.{csv,json}` | Ground Truth view |
| `views/MMU_Simulator_Assisted_Features.{csv,json}` | simulator-assisted view |
| `views/MMU_Blinded_Diagnostic_Features.{csv,json}` | blinded diagnostic view |
| `leakage/MMU_Feature_Leakage_Audit.{csv,json}` | field-level leakage audit |
| `leakage/MMU_Feature_Observability_Matrix.{csv,json}` | observability tiers |
| `consumption/MMU_Fault_Consumption_Semantics_Report.md` | consumption semantics |
| `consumption/MMU_40_Sample_Consumption_Evidence.{csv,json}` | 40-sample evidence |
| `discriminability/MMU_Model_Discriminability_Report.md` | model-ID-free analysis |
| `terminal_semantics/MMU_Terminal_Semantic_Classification_Report.md` | terminal labels |
| `repeatability/MMU_10_Sample_Repeatability_Matrix.{csv,xlsx}` | 10-sample matrix |
| `repeatability/Repeatability_Parameter_Parity.csv` | 10-sample parity |
| `repeatability/describe/` | 10 read-only describe JSON + MD |
| `repeatability/parity/` | 10 per-repeat parity reports |
| `repeatability/launch/` | isolated command.sh, rcS copy, launch manifest per repeat |
| `repeatability/Disk_Copy_Manifest.csv` | independent disk copies (excluded from ZIP) |
| `repeatability/Repeatability_Output_Isolation_Audit.md` | isolation audit |
| `evidence/trace_samples/` | 7 original trace copies + verified slices |
| `excel/MMU_FINAL_Research_Feature_Library.xlsx` | authoritative workbook |
| `scripts/` | feature/consumption/repeatability generators |
| `tests/` | automated tests, logs and independent acceptance |
| `provenance/Provenance.md` | binary/source/workload/disk provenance |
| `reports/Change_Log.md`, `reports/Changed_Files.csv` | change record |
| `SHA256_MANIFEST.txt` | every file hash |

Disk images under `repeatability/launch/*/disk.img` (~1.5 GiB each) exist on
the server and are intentionally excluded from the ZIP; their absolute paths,
sizes and SHA256 are in `Disk_Copy_Manifest.csv`.

## Stop condition

Await researcher approval before executing any of the 10 repeats.
''' % (status['FORMAL_DATA_INTEGRITY'],
       status['DIAGNOSTIC_FEATURE_INTEGRITY'],
       status['REPEATABILITY_EXECUTION_READINESS'],
       status['INDEPENDENT_ACCEPTANCE'],
       status['MMU_FINAL_RESEARCH_CLOSURE'],
       status['MMU_DIAGNOSTIC_FEATURE_GATE'],
       status['MMU_REPEATABILITY_LAUNCH_GATE'])
    (FINAL / 'README.md').write_text(readme)
    # change/diff records
    changed = list(__import__('csv').DictReader(open(
        FINAL / 'reports' / 'Changed_Files.csv')))
    (FINAL / 'reports' / 'Modified_Files.md').write_text(
        '# Modified / New Files\n\nAll %d files are new artifacts under '
        '`final_closure/`. No frozen file is listed as modified.\n\n'
        'See `Changed_Files.csv` for path, size and SHA256.\n' % len(changed))
    git_diff = subprocess.run(
        ['git', 'diff', '--', 'runs/MMU_FORMAL_CAMPAIGN_20261113'],
        cwd=str(C.REPO), capture_output=True, text=True).stdout
    (FINAL / 'reports' / 'Git_Diff.patch').write_text(
        git_diff or '# (empty: no tracked change under the campaign path)\n')
    (FINAL / 'reports' / 'Package_Verification_Procedure.md').write_text(
        '# Package Verification\n\n'
        '1. `sha256sum -c SHA256_MANIFEST.txt` inside the package.\n'
        '2. `sha256sum -c MMU_FINAL_RESEARCH_CLOSURE_PACKAGE.zip.sha256` '
        'next to the ZIP.\n'
        '3. `unzip -t MMU_FINAL_RESEARCH_CLOSURE_PACKAGE.zip`.\n\n'
        'The final ZIP hash is recorded externally because a file cannot '
        'contain its own hash.\n')

    files = walk(FINAL)
    manifest = FINAL / 'SHA256_MANIFEST.txt'
    manifest.write_text(''.join(
        '%s  %s\n' % (sha(p), p.relative_to(FINAL)) for p in files))
    if ZIP.exists():
        ZIP.unlink()
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for p in files:
            zf.write(p, arcname='MMU_FINAL_RESEARCH_CLOSURE_PACKAGE/' +
                     str(p.relative_to(FINAL)))
        zf.write(manifest, arcname='MMU_FINAL_RESEARCH_CLOSURE_PACKAGE/'
                              'SHA256_MANIFEST.txt')
    digest = sha(ZIP)
    (C.CAMP / (ZIP.name + '.sha256')).write_text(
        '%s  %s\n' % (digest, ZIP.name))
    print(json.dumps({
        'zip': str(ZIP),
        'zip_sha256': digest,
        'zip_size_bytes': ZIP.stat().st_size,
        'files_manifested': len(files),
        'zip_entries': len(files) + 1,
    }, indent=1))


if __name__ == '__main__':
    main()
