"""Common loaders for the MMU post-campaign closure audit.

Read-only over the frozen campaign. All writes go under post_campaign_closure/.
"""
import csv
import gzip
import hashlib
import json
import os
import re
from pathlib import Path

REPO = Path('/home/sdc/gem5-fi-mmu-impl-v2')
CAMP = REPO / 'runs' / 'MMU_FORMAL_CAMPAIGN_20261113'
PKG = CAMP / 'MMU_Final_Formal_Campaign_Results_Package'
ANALYSIS = CAMP / 'analysis'
OUT = CAMP / 'post_campaign_closure'
AUDIT = OUT / 'audit'
FEAT = OUT / 'feature_library'
REALCASE = OUT / 'real_case'
REPEAT = OUT / 'repeatability'
SCHEMA = OUT / 'schema'
EVID = OUT / 'evidence'
CACHE = OUT / 'cache'

MODELS = ['M01', 'M02', 'M03', 'M04', 'M05', 'M06', 'M07', 'M08']
CONTEXTS = ['R01', 'R02', 'R03', 'R04', 'R05']
MODEL_WORKLOAD = {
    'M01': 'W9', 'M02': 'W10', 'M03': 'W11', 'M04': 'W12',
    'M05': 'W13', 'M06': 'W10', 'M07': 'W14', 'M08': 'W10',
}
MODEL_MECHANISM = {
    'M01': 'L2/Unified TLB invalidation suppression (stale translation)',
    'M02': 'PTW refill PFN corruption',
    'M03': 'Foreign-ASID false match',
    'M04': 'Resident TLB entry PFN substitution',
    'M05': 'Partial walk-cache next-table pointer substitution',
    'M06': 'Invalid leaf descriptor (Translation Fault detection)',
    'M07': 'Permission grant inversion',
    'M08': 'Final physical-address materialization corruption',
}


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for block in iter(lambda: fh.read(chunk), b''):
            h.update(block)
    return h.hexdigest()


def load_json(path):
    with open(path) as fh:
        return json.load(fh)


def write_json(path, obj, indent=2):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w') as fh:
        json.dump(obj, fh, indent=indent, sort_keys=False, default=str)
        fh.write('\n')


def write_csv(path, rows, fields=None):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        for row in rows:
            for key in row:
                if key not in fields:
                    fields.append(key)
    with open(path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        for row in rows:
            w.writerow({k: _csv_val(row.get(k, '')) for k in fields})


def _csv_val(v):
    if isinstance(v, (list, dict)):
        return json.dumps(v, separators=(',', ':'), default=str)
    if v is None:
        return ''
    return v


def _read_csv(path):
    with open(path, newline='') as fh:
        return list(csv.DictReader(fh))


# ---- frozen campaign sources -------------------------------------------------
def matrix_rows():
    """40-row frozen sample matrix (CSV)."""
    return _read_csv(PKG / '40_Sample_Matrix_Completed.csv')


def samples_csv_rows():
    return _read_csv(ANALYSIS / 'samples.csv')


def samples_json_rows():
    return load_json(ANALYSIS / 'samples.json')


def xlsx_matrix_rows():
    import openpyxl
    wb = openpyxl.load_workbook(
        PKG / 'MMU_Final_Formal_Campaign_Results.xlsx', read_only=True,
        data_only=True)
    ws = wb['40_Sample_Matrix']
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    header = list(rows[0])
    return [dict(zip(header, r)) for r in rows[1:] if r and r[0]]


def xlsx_sheet_rows(sheet):
    import openpyxl
    wb = openpyxl.load_workbook(
        PKG / 'MMU_Final_Formal_Campaign_Results.xlsx', read_only=True,
        data_only=True)
    ws = wb[sheet]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    header = list(rows[0])
    return [dict(zip(header, r)) for r in rows[1:] if r and r[0]]


def authority_matrix_rows():
    return _read_csv(PKG / 'authority' / 'MMU_40_Sample_Matrix.csv')


def fault_control_pairs():
    return _read_csv(PKG / 'fault_control_pairs.csv')


def control_zero_proof():
    return load_json(ANALYSIS / 'control_zero_proof.json')


def final_summary():
    return load_json(ANALYSIS / 'final_summary.json')


def campaign_summary():
    return load_json(ANALYSIS / 'campaign_summary.json')


def provenance():
    return load_json(PKG / 'provenance.json')


def model_validation():
    return load_json(PKG / 'model_specific_validation.json')


def evidence_index_rows():
    return _read_csv(PKG / 'evidence_index' / 'raw_trace_and_evidence_index.csv')


def sample_dir(sid):
    for row in matrix_rows():
        if row['SampleRunID'] == sid:
            return Path(row['RunDir'])
    raise KeyError(sid)


def repr_path(path):
    """Manifest paths may be absolute or repo-relative."""
    p = Path(str(path))
    if p.is_absolute():
        return p
    return REPO / p


def manifest(sid):
    return load_json(sample_dir(sid) / 'sample_manifest.json')


def verdict(sid):
    return load_json(sample_dir(sid) / 'Validation' / 'verdict.json')


def verdict_md(sid):
    p = sample_dir(sid) / 'Validation' / 'verdict.md'
    return p.read_text() if p.exists() else ''


def chain(sid):
    return load_json(ANALYSIS / 'propagation_chains' / ('%s.json' % sid))


def chain_csv_path(sid):
    return ANALYSIS / 'propagation_chains' / ('%s.csv' % sid)


def result_json(sid):
    return load_json(CAMP / 'logs' / ('%s.result.json' % sid))


def observed_output(sid):
    return (sample_dir(sid) / 'Run_Log' / 'observed_output.txt').read_text()


def parse_evt_line(line):
    """Parse one PROP-EVT line into a dict of string fields."""
    body = line[len('PROP-EVT: '):].rstrip('\n')
    out = {}
    for token in body.split(' '):
        if '=' in token:
            k, v = token.split('=', 1)
            out[k] = v
    return out


def scan_cache(sid):
    return load_json(CACHE / 'trace_scan' / ('%s.json' % sid))


# ---- derived helpers ---------------------------------------------------------
def parse_kv_line(line):
    """Parse a workload oracle line 'K=1 K2=0x.. msg=...'."""
    out = {}
    for token in line.strip().split(' '):
        if '=' in token:
            k, v = token.split('=', 1)
            out[k] = v
    return out


def verdict_oracle(ver):
    return (ver.get('Details') or {}).get('oracle') or {}


def verdict_control_oracle(ver):
    return (ver.get('Details') or {}).get('control_oracle') or {}


def fault_tagged(events):
    return [e for e in events if e.get('fault_id') not in ('', '0', None)]


def event_by_id(events, eid):
    for e in events:
        if e.get('event_id') == str(eid):
            return e
    return None


def ensure_dirs():
    for d in (AUDIT, FEAT, REALCASE, REPEAT, SCHEMA, EVID,
              CACHE / 'trace_scan'):
        d.mkdir(parents=True, exist_ok=True)
