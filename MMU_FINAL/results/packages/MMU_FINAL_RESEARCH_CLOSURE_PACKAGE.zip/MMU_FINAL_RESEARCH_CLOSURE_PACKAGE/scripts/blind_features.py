"""Pure, ground-truth-independent blinded observation derivation.

This module never accepts a model ID, fault origin, injection location,
trace fault site or injector-only event label.  It only accepts observed trace
events, the software-visible guest oracle fields, access mode and VA.
"""

INJECTOR_ONLY_KINDS = {
    'mmu_fault_activate', 'mmu_fault_arm', 'mmu_fault_disarm',
    'mmu_fault_summary', 'fault_state_consumed',
    'fault_result_propagated', 'fault_entry_consume', 'fault_entry_reuse',
    'fault_entry_end', 'fault_entry_promote', 'refill_pfn_corrupt',
    'tlbi_suppressed', 'tlb_entry_lineage', 'chain_end',
}

MICROARCH_KINDS = {
    'translation_start', 'tlbi_issue', 'tlbi_match', 'tlbi_invalidate',
    'tlb_lookup_hit', 'tlb_lookup_miss', 'ptw_start', 'pte_read',
    'pte_decode', 'ptw_request', 'ptw_response', 'partial_entry_insert',
    'tlb_fill', 'tlb_entry_insert', 'permission_eval',
    'translation_result', 'lsu_request', 'cache_request', 'cache_lookup',
    'mshr_alloc', 'cache_response', 'memory_response', 'rf_writeback',
    'consumer', 'commit', 'squash', 'exception_delivery',
}

CONSUMER_KINDS = ('lsu_request', 'commit', 'exception_delivery', 'squash')


def _x(e):
    return e.get('ExtraFields') or {}


def _kind(e):
    return e.get('Kind', '')


def _same_page_va(e, target_va):
    """Keep events for the software-known target page or without a VA.

    The target VA/access are software-known inputs, not ground-truth fault
    metadata.  This removes unrelated translations from the propagation chain.
    """
    va = e.get('VA') or _x(e).get('va')
    if va in (None, ''):
        return True
    try:
        if isinstance(target_va, str):
            tva = int(target_va, 0)
        else:
            tva = int(target_va)
        eva = int(str(va), 16)
        return (eva & ~0xFFF) == (tva & ~0xFFF)
    except (TypeError, ValueError):
        return True


def derive_blind(events, guest, access_mode, target_va):
    """Return blinded observations.

    Ground Truth is intentionally absent from this signature.  The caller
    cannot pass a model ID, fault site or injection location.
    """
    observed = [e for e in events
                if _kind(e) not in INJECTOR_ONLY_KINDS and
                _same_page_va(e, target_va)]
    kinds = [_kind(e) for e in observed]
    kset = set(kinds)
    perm = [(_x(e).get('permission_result') or '')
            for e in observed if _kind(e) == 'permission_eval']
    perm = [p for p in perm if p]
    mode = access_mode or ''
    squash = 'squash' in kset
    exception = 'exception_delivery' in kset
    ptw = 'ptw_start' in kset or 'pte_read' in kset
    partial = 'partial_entry_insert' in kset
    maintenance = bool({'tlbi_match', 'tlbi_invalidate'} & kset)
    hit = 'tlb_lookup_hit' in kset
    consumer = next((k for k in kinds if k in CONSUMER_KINDS), '')
    # Path class is derived only from non-injector event kinds.  It is
    # deliberately ambiguous where the observations are ambiguous.
    if exception:
        path = 'EXCEPTION_DETECTION'
    elif ptw:
        # partial_entry_insert is a normal walk event in several models; it is
        # not M05-specific, so the blinded class stays deliberately broad.
        path = 'PTW_WALK'
    elif 'deny' in perm and squash:
        path = 'PERMISSION_DENIED_SQUASHED'
    elif 'deny' in perm:
        path = 'PERMISSION_DENIED_CONSUMED'
    elif 'grant' in perm and mode == 'Execute':
        path = 'PERMISSION_GRANTED_EXECUTE'
    elif maintenance and hit:
        path = 'MAINTENANCE_THEN_REUSE'
    elif hit:
        path = 'RESIDENT_HIT'
    else:
        path = 'OTHER'
    pa_values = []
    va_values = []
    for e in observed:
        if _kind(e) == 'translation_result':
            if e.get('PA'):
                pa_values.append(e['PA'])
            if e.get('VA'):
                va_values.append(e['VA'])
        if _kind(e) == 'lsu_request' and e.get('PA'):
            pa_values.append(e['PA'])
    return {
        'ObservedEventKinds': '|'.join(sorted(kset & MICROARCH_KINDS)),
        'ObservedPathClass': path,
        'ObservedPathAmbiguity': (
            'AMBIGUOUS_ACROSS_PTW_PATHS' if path == 'PTW_WALK'
            else 'AMBIGUOUS_WITH_RESIDENT_HIT' if path == 'RESIDENT_HIT'
            else 'AMBIGUOUS_WITH_PERMISSION_DENIED_CONSUMED'
            if path == 'PERMISSION_DENIED_SQUASHED' else ''),
        'ObservedMaintenanceEvents': maintenance,
        'ObservedPTW': ptw,
        'ObservedPartialEntry': partial,
        'ObservedTLBHits': kinds.count('tlb_lookup_hit'),
        'ObservedTLBMisses': kinds.count('tlb_lookup_miss'),
        'ObservedPermissionResults': '|'.join(sorted(set(perm))),
        'ObservedSquash': squash,
        'ObservedExceptionDelivery': exception,
        'ObservedConsumerKind': consumer,
        'ObservedTranslationVAs': '|'.join(sorted(set(va_values))),
        'ObservedTranslationPAs': '|'.join(sorted(set(pa_values))),
        'ObservedAccessMode_SW': mode,
        'ObservedTargetVA_SW': target_va,
        'GuestSignal_SW': guest.get('GuestSignal', ''),
        'GuestSICode_SW': guest.get('GuestSICode', ''),
        'GuestFaultClass_SW': guest.get('GuestFaultClass', ''),
        'GuestObservedValue_SW': guest.get('GuestObservedValue', ''),
        'GuestExpectedValue_SW': guest.get('GuestExpectedValue', ''),
        'GuestValueMismatch_SW': guest.get('GuestValueMismatch'),
        'GuestUnexpectedSuccess_SW': guest.get('GuestUnexpectedSuccess'),
    }
