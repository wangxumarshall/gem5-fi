"""Pure repeatability launch-row validation used by tests."""

FORBIDDEN_PLACEHOLDERS = ('<REPEAT', 'REPEAT_OUTDIR', 'REPEAT_RCS',
                          'FROZEN_DISK_COPY', 'REPEAT_RUN_ID',
                          'REPEAT_SAMPLE_RUN_ID')


def validate_row(row, formal_paths, formal_sids):
    """Return a list of failure strings for one launch row."""
    fail = []
    cmd = row.get('FullCommand', '')
    outdir = row.get('Outdir', '')
    if row.get('Status') != 'READY_FOR_RESEARCHER_APPROVAL':
        fail.append('status=%s' % row.get('Status'))
    for p in FORBIDDEN_PLACEHOLDERS:
        if p in cmd:
            fail.append('placeholder:%s' % p)
    if any('seed' in x.lower() for x in cmd.split()):
        fail.append('seed_flag_present')
    if row.get('ModelID') == 'M05':
        if '--mmu_m05_decoy_va 0x4010200000' not in cmd:
            fail.append('m05_decoy_va_missing')
        if '--mmu_m05_decoy_table_base 0' not in cmd:
            fail.append('m05_decoy_table_base_missing')
    if row.get('ModelID') == 'M01':
        if row.get('ExecutedGuestBinarySHA256') != (
                '4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104'
                'ee6508c98'):
            fail.append('m01_executed_guest_wrong')
    if row.get('RepeatID') in formal_sids:
        fail.append('repeat_id_collides_with_formal')
    if any(outdir == p or outdir.startswith(p + '/') for p in formal_paths):
        fail.append('outdir_collides_with_formal')
    if '--mmu_fault_model' not in cmd:
        fail.append('missing_fault_model_flag')
    if row.get('DiskCopySHA256') != (
            'bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff0321'
            '6425759'):
        fail.append('disk_hash_wrong')
    return fail
