#!/usr/bin/env python3
"""Original data integrity audit, provenance, limitations and change log."""
import csv
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

BINARY = C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt'
SOURCES = [
    'CHAOS/gem5/src/arch/arm/mmu.cc',
    'CHAOS/gem5/src/arch/arm/table_walker.cc',
    'CHAOS/gem5/src/arch/arm/table_walker.hh',
    'CHAOS/gem5/src/arch/arm/tlb.cc',
    'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.cc',
    'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.hh',
]


def sha(p):
    return C.sha256_file(p)


def main():
    for d in ('provenance', 'reports'):
        (FINAL / d).mkdir(parents=True, exist_ok=True)
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    samples = data['samples']
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    audit = []
    trace_ok = 0
    manifest_ok = 0
    verdict_ok = 0
    for r in samples:
        sid = r['SampleRunID']
        o = r['OriginalResult']
        rdir = Path(o['RunDir'])
        actual_trace = sha(Path(o['TraceAbsolutePath']))
        actual_man = sha(rdir / 'sample_manifest.json')
        actual_ver = sha(rdir / 'Validation/verdict.json')
        t = actual_trace == o['TraceSHA256']
        m = actual_man == o['ManifestSHA256']
        v = actual_ver == o['VerdictSHA256']
        trace_ok += int(t); manifest_ok += int(m); verdict_ok += int(v)
        audit.append({
            'SampleRunID': sid,
            'OpaqueSampleID': r['OpaqueSampleID'],
            'InMatrix': sid in matrix,
            'RunDirExists': rdir.is_dir(),
            'TraceSHA256Recorded': o['TraceSHA256'],
            'TraceSHA256Actual': actual_trace,
            'TraceUnchanged': t,
            'ManifestUnchanged': m,
            'VerdictUnchanged': v,
            'TerminalState': o['TerminalState'],
            'OracleResult': o['OracleResult'],
            'PropagationStatus': o['PropagationStatus'],
            'BinarySHA256': o['BinarySHA256'],
        })
    C.write_csv(FINAL / 'reports' /
                'Original_40_Sample_Integrity_Audit.csv', audit)
    terminal = {}
    for r in samples:
        t = r['OriginalResult']['TerminalState']
        terminal[t] = terminal.get(t, 0) + 1
    original_zip = C.CAMP / 'MMU_Final_Formal_Campaign_Results_Package.zip'
    binary_ok = sha(BINARY) == data['metadata']['frozen_binary_sha256']
    source_rows = []
    recorded = {}
    for line in (C.sample_dir('M01-F0-W9-S01-R01') / 'SHA256' /
                 'SHA256SUMS.txt').read_text().splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2 and parts[1].startswith('source:'):
            recorded[parts[1][7:]] = parts[0]
    for rel in SOURCES:
        p = C.REPO / rel
        source_rows.append({
            'Path': rel,
            'ActualSHA256': sha(p),
            'RecordedSHA256': recorded.get(rel, ''),
            'Match': sha(p) == recorded.get(rel),
        })
    closure_ok = subprocess.run(
        ['git', 'cat-file', '-e', data['metadata']['source_closure']],
        cwd=str(C.REPO), capture_output=True).returncode == 0
    summary = {
        'FORMAL_DATA_INTEGRITY': (
            'PASS' if (len(samples) == 40 and set(r['SampleRunID']
                                                 for r in samples) ==
                       set(matrix) and trace_ok == 40 and
                       manifest_ok == 40 and verdict_ok == 40 and
                       terminal == {'SDC': 31, 'SQUASHED': 4,
                                    'DETECTED_CONTAINED': 5} and
                       binary_ok and closure_ok and
                       sha(original_zip) ==
                       'caeaf6506495ed119a06a12075f5193276e2e1279286ddc5'
                       '6610016f39caa151') else 'FAIL'),
        'samples': len(samples),
        'sample_id_set_matches_matrix': set(r['SampleRunID']
                                            for r in samples) ==
                                        set(matrix),
        'trace_unchanged': '%d/40' % trace_ok,
        'manifest_unchanged': '%d/40' % manifest_ok,
        'verdict_unchanged': '%d/40' % verdict_ok,
        'terminal_distribution': terminal,
        'frozen_binary_sha256': sha(BINARY),
        'binary_matches_frozen': binary_ok,
        'source_files_match': all(s['Match'] for s in source_rows),
        'source_closure_commit_exists': closure_ok,
        'original_results_zip_sha256': sha(original_zip),
        'original_results_zip_unchanged':
            sha(original_zip) == 'caeaf6506495ed119a06a12075f5193276e2e12792'
                                 '86ddc56610016f39caa151',
    }
    C.write_json(FINAL / 'reports' /
                 'Original_40_Sample_Integrity_Audit.json', summary)
    md = ['# Original 40-Sample Integrity Audit\n\n',
          '| Check | Result |\n|---|---|\n']
    for k in ('FORMAL_DATA_INTEGRITY', 'samples',
              'sample_id_set_matches_matrix', 'trace_unchanged',
              'manifest_unchanged', 'verdict_unchanged',
              'terminal_distribution', 'frozen_binary_sha256',
              'binary_matches_frozen', 'source_files_match',
              'source_closure_commit_exists',
              'original_results_zip_sha256',
              'original_results_zip_unchanged'):
        md.append('| %s | `%s` |\n' % (k, summary[k]))
    md.append('\nNo frozen file was modified. Each trace, manifest and '
              'verdict hash was recomputed from the server files.\n')
    (FINAL / 'reports' / 'Original_40_Sample_Integrity_Audit.md').write_text(
        ''.join(md))

    # provenance
    prov = [{
        'Artifact': 'gem5 binary',
        'Path': str(BINARY),
        'SizeBytes': BINARY.stat().st_size,
        'SHA256': sha(BINARY),
        'Role': 'frozen simulator binary',
    }]
    for s in source_rows:
        prov.append({
            'Artifact': 'gem5 source', 'Path': str(C.REPO / s['Path']),
            'SizeBytes': (C.REPO / s['Path']).stat().st_size,
            'SHA256': s['ActualSHA256'], 'Role': 'frozen source closure',
        })
    for p, role in [(C.REPO / 'gem5-fs/vmlinux', 'kernel'),
                    (C.REPO / 'gem5-fs/boot.arm64', 'bootloader')]:
        prov.append({'Artifact': role, 'Path': str(p),
                     'SizeBytes': p.stat().st_size, 'SHA256': sha(p),
                     'Role': role})
    prov.append({'Artifact': 'original results zip',
                 'Path': str(original_zip),
                 'SizeBytes': original_zip.stat().st_size,
                 'SHA256': sha(original_zip),
                 'Role': 'frozen campaign result package'})
    # workload identities
    add = C.OUT / 'addendum' / 'Workload_Hash_Identity.csv'
    if add.is_file():
        for r in csv.DictReader(open(add)):
            prov.append({
                'Artifact': 'workload/%s' % r.get('FileRole', ''),
                'Path': r.get('Path', ''),
                'SizeBytes': r.get('SizeBytes', ''),
                'SHA256': r.get('SHA256', ''),
                'Role': 'workload %s' % r.get('VariantIdentity', ''),
            })
    # disk copies
    dm = FINAL / 'repeatability' / 'Disk_Copy_Manifest.csv'
    if dm.is_file():
        for r in csv.DictReader(open(dm)):
            prov.append({
                'Artifact': 'repeat disk copy',
                'Path': r['Path'], 'SizeBytes': r['SizeBytes'],
                'SHA256': r['SHA256'], 'Role': r['RepeatID'],
            })
    C.write_csv(FINAL / 'provenance' / 'Provenance_Table.csv', prov)
    C.write_json(FINAL / 'provenance' / 'Provenance_Table.json', prov)
    pmd = ['# Provenance\n\n', '| Artifact | Path | SHA256 | Role |\n'
           '|---|---|---|---|\n']
    for r in prov:
        pmd.append('| %s | `%s` | `%s` | %s |\n' % (
            r['Artifact'], r['Path'], r['SHA256'], r['Role']))
    (FINAL / 'provenance' / 'Provenance.md').write_text(''.join(pmd))

    # limitations
    lim = ['# Research Limitations\n\n',
           'These are research-observability boundaries, not hidden '
           'engineering failures.\n\n',
           '1. The blinded observation set cannot separate M04 vs M08; both '
           'can present resident-hit + wrong value. Entry lineage/request-PA '
           'are simulator-only.\n',
           '2. M02/M04/M08 share the final wrong-value symptom; trace events '
           'are required for more than a generic "wrong data" diagnosis.\n',
           '3. M01/M03 final wrong value alone is ambiguous; TLB maintenance '
           'history, ASID relation and squash/permission evidence are needed.\n',
           '4. Production availability of TLB entry ID/generation, modified '
           'PFN, PTW partial entries and permission-grant internals is '
           'UNKNOWN; no real-hardware interface is proven here.\n',
           '5. M03 R01-R04 are SQUASHED/PARTIAL/COMPLETE; they are not '
           'detected exceptions.\n',
           '6. M06 R01-R05 are DETECTED_CONTAINED, not generic MASKED; the '
           'exception is delivered and the guest value is correct.\n',
           '7. M07 R02 has no permission_eval joined to the activation '
           'TranslationID; nearest same-VA deny is event 345 / tid 5.\n',
           '8. Per-instruction IFU fetch/decode/commit nodes are not emitted '
           'by the frozen binary; they are not fabricated.\n',
           '9. No classifier is trained and no accuracy or cross-workload '
           'generalization is claimed.\n',
           '10. The 10 repeatability runs are prepared but not executed.\n']
    (FINAL / 'reports' / 'Research_Limitations.md').write_text(''.join(lim))

    # change log / git
    files = []
    for p in sorted(FINAL.rglob('*')):
        if p.is_file() and p.name not in (
                'SHA256_MANIFEST.txt', 'disk.img', 'Changed_Files.csv',
                'Modified_Files.md', 'Git_Diff.patch', 'Git_Status.txt',
                'Package_Verification_Procedure.md') and \
                '__pycache__' not in p.parts and p.suffix != '.pyc':
            files.append({'Path': str(p.relative_to(FINAL)),
                          'SizeBytes': p.stat().st_size,
                          'SHA256': sha(p)})
    C.write_csv(FINAL / 'reports' / 'Changed_Files.csv', files)
    git_status = subprocess.run(
        ['git', 'status', '--porcelain',
         'runs/MMU_FORMAL_CAMPAIGN_20261113'], cwd=str(C.REPO),
        capture_output=True, text=True).stdout
    git_diff = subprocess.run(
        ['git', 'diff', '--', 'runs/MMU_FORMAL_CAMPAIGN_20261113'],
        cwd=str(C.REPO), capture_output=True, text=True).stdout
    (FINAL / 'reports' / 'Git_Status.txt').write_text(
        'campaign path status:\n%s\ncampaign path diff:\n%s' %
        (git_status or '(empty)', git_diff or '(empty)'))
    cl = ['# Change Log / Modification Record\n\n',
          'All changes are new Python/data artifacts under '
          '`post_campaign_closure/final_closure/`. No frozen C++, binary, '
          'workload, trace, manifest, verdict or original result was '
          'modified.\n\n',
          '- Created three separated views: Ground Truth, Simulator-Assisted, '
          'Blinded.\n',
          '- Replaced GT-derived `UpstreamPathClass_SIM` with event-derived '
          '`ObservedPathClass` in the blind view.\n',
          '- Separated FaultInjected / FaultActivated / FaultStateConsumed / '
          'DownstreamArchitecturalConsumption; 40/40 consumption evidence '
          'with 5 literal explicit events.\n',
          '- Prepared 10 fully expanded, hash-pinned repeat commands with '
          'independent sparse disk copies and rcS copies.\n',
          '- Versioned M03/M06/M07 terminal semantic corrections.\n',
          '- Added leakage, consumption, repeatability and data-integrity '
          'tests.\n\n',
          '## Git state\n\n```\n%s\n```\n\n' % (
              git_status or '(no changes under the campaign path)'),
          '## File list\n\nSee `reports/Changed_Files.csv`.\n']
    (FINAL / 'reports' / 'Change_Log.md').write_text(''.join(cl))
    print(json.dumps(summary, indent=1))


if __name__ == '__main__':
    main()
