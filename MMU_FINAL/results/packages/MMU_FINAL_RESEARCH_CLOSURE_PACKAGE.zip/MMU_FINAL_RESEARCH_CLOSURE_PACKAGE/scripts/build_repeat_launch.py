#!/usr/bin/env python3
"""Prepare the 10 repeatability runs: assets, expanded commands, parity.

No gem5 run is started.  Disk copies are sparse, independent, writable copies
of the frozen template; they are excluded from the final ZIP but their paths
and SHA256 are recorded.
"""
import base64
import csv
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'
LAUNCH = FINAL / 'repeatability' / 'launch'
PAYLOAD_RE = __import__('re').compile(
    r"base64 -d > \S+ <<'([A-Za-z0-9_]+)'")


def sha(p):
    return C.sha256_file(p)


def payload_hash(rcs_path):
    p = Path(rcs_path)
    if not p.is_file():
        return None
    lines = p.read_text(errors='replace').splitlines()
    marker = start = None
    for i, line in enumerate(lines):
        m = PAYLOAD_RE.search(line)
        if m:
            marker, start = m.group(1), i + 1
            break
    if marker is None:
        return None
    blob = []
    for line in lines[start:]:
        if line.strip() == marker:
            break
        blob.append(line.strip())
    try:
        return hashlib.sha256(
            gzip.decompress(base64.b64decode(''.join(blob)))).hexdigest()
    except Exception:
        return None


def resolve(p):
    p = Path(str(p))
    return p if p.is_absolute() else C.REPO / p


def cmd_map(cmd):
    out = {}
    i = 0
    while i < len(cmd):
        if str(cmd[i]).startswith('--'):
            if i + 1 < len(cmd) and not str(cmd[i + 1]).startswith('--'):
                out[cmd[i]] = cmd[i + 1]
                i += 2
            else:
                out[cmd[i]] = 'true'
                i += 1
        else:
            i += 1
    return out


def main():
    LAUNCH.mkdir(parents=True, exist_ok=True)
    add = list(csv.DictReader(open(
        ADD / 'repeatability_v2' / 'MMU_Repeatability_Matrix_v2.csv')))
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    formal_paths = [str(C.sample_dir(sid)) for sid in matrix]
    formal_paths += [str(C.CAMP / 'attempt_A01' / sid) for sid in matrix]
    formal_paths += [str(C.CAMP / 'attempt_A02' / sid) for sid in matrix]
    formal_paths += [str(p) for p in (C.REPO / 'runs').glob('TEST-F1-*')]
    formal_sids = set(matrix)
    rows = []
    parity_rows = []
    disk_manifest = []
    isolation = []
    m07_rows = []
    for r in add:
        sid = r['RepeatOfSampleRunID']
        model = r['ModelID']
        ctx = r['ContextID']
        rep_id = 'REP-FINAL-MMU-%s-%s-01' % (model, ctx)
        base = LAUNCH / rep_id
        outdir = base / 'outdir'
        base.mkdir(parents=True, exist_ok=True)
        outdir.mkdir(exist_ok=True)
        man = C.manifest(sid)
        orig_cmd = man['command']
        # copy rcS actually used
        orig_rcs = resolve(cmd_map(orig_cmd).get('--readfile', ''))
        rcs_copy = base / 'rcS.scoped'
        if not rcs_copy.exists() or sha(rcs_copy) != sha(orig_rcs):
            shutil.copy2(orig_rcs, rcs_copy)
        # independent sparse disk copy
        orig_disk = resolve(cmd_map(orig_cmd).get('--disk', ''))
        disk_copy = base / 'disk.img'
        if not disk_copy.exists():
            subprocess.run(['cp', '--sparse=always', str(orig_disk),
                            str(disk_copy)], check=True)
        disk_ok = sha(disk_copy) == sha(orig_disk)
        # expanded command: replace isolation paths and trace IDs only
        cmd = []
        skip = False
        for tok in orig_cmd:
            if skip:
                skip = False
                continue
            if tok == '--outdir':
                cmd += [tok, str(outdir)]; skip = True
            elif tok == '--readfile':
                cmd += [tok, str(rcs_copy)]; skip = True
            elif tok == '--disk':
                cmd += [tok, str(disk_copy)]; skip = True
            elif tok == '--prop_run_id':
                cmd += [tok, rep_id]; skip = True
            elif tok == '--prop_sample_run_id':
                cmd += [tok, rep_id]; skip = True
            else:
                cmd.append(tok)
        cmd = [str(C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt')
               if i == 0 else tok for i, tok in enumerate(cmd)]
        # absolute paths for asset flags (they were already absolute in most)
        for flag in ('--kernel', '--bootloader', '--restore-checkpoint'):
            if flag in cmd:
                i = cmd.index(flag) + 1
                cmd[i] = str(resolve(cmd[i]))
        # positional config script after --outdir value
        try:
            oi = cmd.index('--outdir')
            cfg_i = oi + 2
            if cfg_i < len(cmd) and not str(cmd[cfg_i]).startswith('--'):
                cmd[cfg_i] = str(resolve(cmd[cfg_i]))
        except (ValueError, IndexError):
            pass
        # write command.sh
        sh = base / 'command.sh'
        sh.write_text('#!/bin/bash\nset -euo pipefail\nexec ' +
                      ' '.join("'%s'" % x if ' ' in str(x) else str(x)
                               for x in cmd) + '\n')
        sh.chmod(0o755)
        bash_ok = subprocess.run(['bash', '-n', str(sh)],
                                 capture_output=True, text=True).returncode == 0
        # parity: compare semantic flags
        orig = cmd_map(orig_cmd)
        new = cmd_map(cmd)
        semantic = [k for k in orig
                    if k.startswith('--mmu_') or
                    (k.startswith('--prop_') and k not in (
                        '--prop_run_id', '--prop_sample_run_id'))]
        mismatch = {k: (orig[k], new.get(k)) for k in semantic
                    if orig[k] != new.get(k)}
        expected_diff = {
            '--outdir': (orig.get('--outdir'), new.get('--outdir')),
            '--readfile': (orig.get('--readfile'), new.get('--readfile')),
            '--disk': (orig.get('--disk'), new.get('--disk')),
            '--prop_run_id': (orig.get('--prop_run_id'),
                              new.get('--prop_run_id')),
            '--prop_sample_run_id': (orig.get('--prop_sample_run_id'),
                                     new.get('--prop_sample_run_id')),
        }
        placeholder = any('<REPEAT' in str(x) or 'REPEAT_' in str(x)
                          for x in cmd)
        collision = any(str(outdir) == p or str(outdir).startswith(p + os.sep)
                        for p in formal_paths)
        # asset checks
        executed = payload_hash(orig_rcs)
        if model == 'M01':
            executed = payload_hash(C.REPO / 'configs/fs/mmu_w9.rcS')
        m05_ok = True
        if model == 'M05':
            m05_ok = (new.get('--mmu_m05_decoy_va') == '0x4010200000' and
                      new.get('--mmu_m05_decoy_table_base') == '0')
        seed_ok = all('seed' not in k.lower() for k in new)
        assets_ok = (rcs_copy.is_file() and disk_copy.is_file() and
                     disk_ok and Path(cmd[0]).is_file() and bash_ok)
        ready = (not mismatch and not placeholder and not collision and
                 m05_ok and seed_ok and assets_ok and
                 rep_id not in formal_sids)
        row = {
            'RepeatID': rep_id,
            'RepeatOfSampleRunID': sid,
            'ModelID': model,
            'ContextID': ctx,
            'Outdir': str(outdir),
            'RcsCopy': str(rcs_copy),
            'RcsCopySHA256': sha(rcs_copy),
            'DiskCopy': str(disk_copy),
            'DiskCopySHA256': sha(disk_copy),
            'DiskCopySizeBytes': disk_copy.stat().st_size,
            'ExecutedGuestBinarySHA256': executed or '',
            'CanonicalWorkloadSHA256': man.get('workload_sha256'),
            'FrozenBinarySHA256': sha(Path(cmd[0])),
            'FullCommand': ' '.join(cmd),
            'CommandScript': str(sh),
            'BashSyntaxOK': bash_ok,
            'SemanticFlagMismatches': json.dumps(mismatch, sort_keys=True),
            'PlaceholderPresent': placeholder,
            'PathCollision': collision,
            'M05DecoyExplicitOK': m05_ok,
            'NoSeedFlag': seed_ok,
            'AssetsOK': assets_ok,
            'Status': 'READY_FOR_RESEARCHER_APPROVAL' if ready else 'BLOCKED',
        }
        rows.append(row)
        isolation.append({
            'RepeatID': rep_id,
            'FormalSampleRunID': sid,
            'FormalRunDir': str(C.sample_dir(sid)),
            'RepeatOutdir': str(outdir),
            'Collision': collision,
            'ExpectedDifferences': json.dumps(expected_diff, sort_keys=True),
            'Note': 'outdir/readfile/disk/trace IDs are isolated; all fault '
                    'semantic flags are identical',
        })
        disk_manifest.append({
            'RepeatID': rep_id,
            'Path': str(disk_copy),
            'SizeBytes': disk_copy.stat().st_size,
            'SHA256': sha(disk_copy),
            'SourceDisk': str(orig_disk),
            'SourceSHA256': sha(orig_disk),
            'IndependentInode': disk_copy.stat().st_ino !=
                                orig_disk.stat().st_ino,
            'ExcludedFromZip': True,
        })
        for cid, status, expected, actual in [
            ('status', 'PASS' if ready else 'FAIL',
             'READY_FOR_RESEARCHER_APPROVAL', row['Status']),
            ('semantic_flags', 'PASS' if not mismatch else 'FAIL',
             '{}', json.dumps(mismatch, sort_keys=True)),
            ('placeholders', 'PASS' if not placeholder else 'FAIL',
             False, placeholder),
            ('collision', 'PASS' if not collision else 'FAIL',
             False, collision),
            ('m05_decoy',
             ('PASS' if m05_ok else 'FAIL') if model == 'M05' else 'N/A',
             '0x4010200000/0' if model == 'M05' else 'N/A',
             ('%s/%s' % (new.get('--mmu_m05_decoy_va'),
                        new.get('--mmu_m05_decoy_table_base')))
             if model == 'M05' else 'N/A'),
            ('seed', 'PASS' if seed_ok else 'FAIL', 'no seed flag', seed_ok),
            ('assets', 'PASS' if assets_ok else 'FAIL', True, assets_ok),
            ('bash_syntax', 'PASS' if bash_ok else 'FAIL', True, bash_ok),
        ]:
            parity_rows.append({
                'RepeatID': rep_id,
                'CheckID': cid,
                'Status': status,
                'Expected': expected,
                'Actual': actual,
            })
    C.write_csv(FINAL / 'repeatability' / 'MMU_Repeatability_Launch_Matrix.csv',
                rows)
    C.write_json(FINAL / 'repeatability' /
                 'MMU_Repeatability_Launch_Matrix.json', rows)
    C.write_csv(FINAL / 'repeatability' /
                'Repeatability_Parameter_Parity.csv', parity_rows)
    C.write_csv(FINAL / 'repeatability' / 'Disk_Copy_Manifest.csv',
                disk_manifest)
    C.write_csv(FINAL / 'repeatability' /
                'Repeatability_Output_Isolation_Audit.csv', isolation)
    md = ['# Repeatability Launch Assets\n\n',
          'Status: `%s`. No gem5 run was started.\n\n' %
          ('READY_FOR_RESEARCHER_APPROVAL'
           if all(r['Status'] == 'READY_FOR_RESEARCHER_APPROVAL'
                  for r in rows) else 'BLOCKED'),
          '## Fully expanded commands\n\n']
    for r in rows:
        md.append('### %s (repeat of %s)\n\n' % (
            r['RepeatID'], r['RepeatOfSampleRunID']))
        md.append('```bash\n%s\n```\n\n' % r['FullCommand'])
        md.append('- rcS copy: `%s` (`%s`)\n' % (
            r['RcsCopy'], r['RcsCopySHA256']))
        md.append('- Disk copy: `%s` (`%s`, %d bytes)\n' % (
            r['DiskCopy'], r['DiskCopySHA256'], r['DiskCopySizeBytes']))
        md.append('- Executed guest: `%s`; canonical field: `%s`\n' % (
            r['ExecutedGuestBinarySHA256'], r['CanonicalWorkloadSHA256']))
        md.append('- Status: **%s**\n\n' % r['Status'])
    md.append('## M07 exact target VATs\n\n')
    for sid in ['M07-F0-W14-S01-R03', 'M07-F0-W14-S01-R04',
                'M07-F0-W14-S01-R05']:
        m = C.manifest(sid)
        m07_rows.append({
            'SampleRunID': sid,
            'ContextID': m['context'],
            'TargetVA': '0x%x' % m['target_va'],
            'AccessMode': m['target_mode'],
            'PageBase': '0x%x' % (m['target_va'] & ~0xFFF),
            'ExactVAUsed': True,
        })
    C.write_csv(FINAL / 'repeatability' / 'M07_Target_VA_Audit.csv',
                m07_rows)
    for m in m07_rows:
        md.append('| %s | %s | `%s` | `%s` |\n' % (
            m['SampleRunID'], m['AccessMode'], m['TargetVA'],
            m['PageBase']))
    md.append('\n## Safety\n\n')
    md.append('- No placeholders remain in any command.\n')
    md.append('- No RepeatID equals a formal SampleRunID.\n')
    md.append('- No output path collides with a formal/pilot/failed path.\n')
    md.append('- Each disk copy is a separate inode and hash-pinned; disk '
              'copies are excluded from the ZIP.\n')
    md.append('- No seed flag is present; SeedPolicy remains deterministic.\n')
    md.append('- `bash -n` passes for every command; gem5 is not executed.\n')
    (FINAL / 'repeatability' / 'Repeatability_Launch_Plan.md').write_text(
        ''.join(md))
    blocked = [r for r in rows if r['Status'] !=
               'READY_FOR_RESEARCHER_APPROVAL']
    print(json.dumps({
        'repeats': len(rows),
        'ready': len(rows) - len(blocked),
        'blocked': [r['RepeatID'] for r in blocked],
        'disk_free_after': subprocess.run(
            ['df', '-h', '/home/sdc'], capture_output=True,
            text=True).stdout.strip().splitlines()[-1],
    }, indent=1))
    return 0 if not blocked else 1


if __name__ == '__main__':
    sys.exit(main())
