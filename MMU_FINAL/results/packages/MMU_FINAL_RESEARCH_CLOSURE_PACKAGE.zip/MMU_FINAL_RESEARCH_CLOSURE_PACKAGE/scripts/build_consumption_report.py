#!/usr/bin/env python3
"""Build the 40-sample consumption semantics report from the final dataset."""
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    rows = []
    for r in data['samples']:
        g = r['GroundTruth']; c = r['Consumption']; t = r['TerminalSemantics']
        rows.append({
            'SampleRunID': r['SampleRunID'],
            'OpaqueSampleID': r['OpaqueSampleID'],
            'FaultModelID': g['FaultModelID'],
            'ContextID': r['OriginalResult']['ContextID'],
            'FaultInjected': c['FaultInjected'],
            'FaultActivated': c['FaultActivated'],
            'FaultStateConsumed': c['FaultStateConsumed'],
            'ExplicitFaultStateConsumedEventObserved':
                c['ExplicitFaultStateConsumedEventObserved'],
            'ExplicitFaultStateConsumedEventIDs':
                c['ExplicitFaultStateConsumedEventIDs'],
            'ConsumptionEvidenceEventID': c['ConsumptionEvidenceEventID'],
            'ConsumptionEvidenceKind': c['ConsumptionEvidenceKind'],
            'ConsumptionEvidenceSource': c['ConsumptionEvidenceSource'],
            'ConsumptionJoinKeys': c['ConsumptionJoinKeys'],
            'ConsumptionEvidenceConfidence':
                c['ConsumptionEvidenceConfidence'],
            'DownstreamArchitecturalConsumption':
                c['DownstreamArchitecturalConsumption'],
            'DownstreamConsumptionKind': c['DownstreamConsumptionKind'],
            'ArchitecturalDataCorruption':
                c['ArchitecturalDataCorruption'],
            'PropagationStatus': c['PropagationStatus'],
            'TerminalState': c['TerminalState'],
            'Primary_v2': t['Primary_v2'],
            'Secondary_v2': t['Secondary_v2'],
        })
    out = FINAL / 'consumption'
    import common as C
    C.write_csv(out / 'MMU_40_Sample_Consumption_Evidence.csv', rows)
    C.write_json(out / 'MMU_40_Sample_Consumption_Evidence.json', rows)
    by_model = defaultdict(Counter)
    for r in rows:
        by_model[r['FaultModelID']]['consumed'] += int(r['FaultStateConsumed'])
        by_model[r['FaultModelID']]['downstream'] += int(
            r['DownstreamArchitecturalConsumption'])
        by_model[r['FaultModelID']]['explicit'] += int(
            r['ExplicitFaultStateConsumedEventObserved'])
    summary = {
        'samples': len(rows),
        'fault_injected': sum(1 for r in rows if r['FaultInjected']),
        'fault_activated': sum(1 for r in rows if r['FaultActivated']),
        'fault_state_consumed': sum(1 for r in rows
                                    if r['FaultStateConsumed']),
        'explicit_fault_state_consumed_event':
            sum(1 for r in rows if r['ExplicitFaultStateConsumedEventObserved']),
        'downstream_architectural_consumption':
            sum(1 for r in rows
                if r['DownstreamArchitecturalConsumption']),
        'architectural_data_corruption':
            sum(1 for r in rows if r['ArchitecturalDataCorruption']),
        'terminal_distribution': dict(Counter(r['TerminalState']
                                              for r in rows)),
        'propagation_distribution': dict(Counter(r['PropagationStatus']
                                                 for r in rows)),
        'per_model': {m: dict(c) for m, c in by_model.items()},
        'low_confidence': [r['SampleRunID'] for r in rows
                           if r['ConsumptionEvidenceConfidence'] == 'LOW'],
    }
    C.write_json(out / 'MMU_Fault_Consumption_Semantics.json', summary)
    md = ['# Fault Consumption Semantics Report\n\n',
          'Semantics are separated into FaultInjected, FaultActivated, '
          'FaultStateConsumed and DownstreamArchitecturalConsumption. '
          '`ExplicitFaultStateConsumedEventObserved` is only the literal '
          '`fault_state_consumed` event; it does not replace '
          'FaultStateConsumed.\n\n',
          '## Counts\n\n',
          '| Metric | Value |\n|---|---|\n']
    for k in ('samples', 'fault_injected', 'fault_activated',
              'fault_state_consumed',
              'explicit_fault_state_consumed_event',
              'downstream_architectural_consumption',
              'architectural_data_corruption'):
        md.append('| %s | %s |\n' % (k, summary[k]))
    md.append('| terminal distribution | %s |\n' %
              json.dumps(summary['terminal_distribution']))
    md.append('| propagation distribution | %s |\n\n' %
              json.dumps(summary['propagation_distribution']))
    md.append('## Per-model consumption evidence\n\n')
    md.append('| Model | Consumed | Downstream | Explicit literal event |\n'
              '|---|---|---|---|\n')
    for m in sorted(by_model):
        c = by_model[m]
        md.append('| %s | %d/5 | %d/5 | %d/5 |\n' % (
            m, c['consumed'], c['downstream'], c['explicit']))
    md.append('\n## Important distinctions\n\n')
    md.append('- **M03 R01-R04**: FaultStateConsumed=true (the false-ASID '
              'hit is used by translation), but '
              'DownstreamArchitecturalConsumption=false because the result is '
              'squashed before architectural update. Terminal SQUASHED / '
              'Propagation PARTIAL / Trace COMPLETE.\n')
    md.append('- **M06 R01-R05**: the literal `fault_state_consumed` event is '
              'present (5/5), but consumption is also proven by `pte_decode` '
              'and the Translation-Fault path. This is detection/containment, '
              'not generic masking.\n')
    md.append('- **M07 R02**: permission denial is recorded by '
              '`mmu_fault_activate(permission_before=false)`; no '
              'permission_eval with the same TranslationID is joined. This '
              'limitation remains.\n')
    md.append('- For M01/M02/M04/M05/M08, the consumption event is the '
              'model-specific TLB hit / request / translation result shown in '
              'the table; `fault_state_consumed` is not emitted.\n\n')
    md.append('## Verdict comparison\n\n')
    md.append('The recomputed counts match the frozen formal verdicts: '
              'FaultActivated=40, FaultStateConsumed=40, Propagation '
              'FULL=36/PARTIAL=4, Terminal SDC=31/SQUASHED=4/'
              'DETECTED_CONTAINED=5. No event was synthesized.\n')
    (out / 'MMU_Fault_Consumption_Semantics_Report.md').write_text(''.join(md))
    print(json.dumps(summary, indent=1))


if __name__ == '__main__':
    main()
