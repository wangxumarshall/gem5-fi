#!/usr/bin/env python3
"""Write final status, closure report and repeatability workbook."""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

import openpyxl
from openpyxl.styles import Font


def load(p):
    return json.load(open(p))


def main():
    (FINAL / 'statuses').mkdir(exist_ok=True)
    (FINAL / 'reports').mkdir(exist_ok=True)
    acc = load(FINAL / 'tests' / 'Independent_Acceptance.json')
    audit = load(FINAL / 'reports' /
                 'Original_40_Sample_Integrity_Audit.json')
    cons = load(FINAL / 'consumption' /
                'MMU_Fault_Consumption_Semantics.json')
    launch = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'MMU_Repeatability_Launch_Matrix.csv')))
    parity = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'Repeatability_Parameter_Parity.csv')))
    # authoritative repeatability CSV + workbook
    import shutil
    shutil.copy2(FINAL / 'repeatability' /
                 'MMU_Repeatability_Launch_Matrix.csv',
                 FINAL / 'repeatability' /
                 'MMU_10_Sample_Repeatability_Matrix.csv')
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Matrix'
    headers = list(launch[0].keys())
    ws.append(headers); ws['A1'].font = Font(bold=True)
    for r in launch:
        ws.append([r.get(h, '') for h in headers])
    ws.freeze_panes = 'B2'
    ws2 = wb.create_sheet('Parity')
    ws2.append(list(parity[0].keys()))
    for r in parity:
        ws2.append([r.get(h, '') for h in parity[0].keys()])
    ws3 = wb.create_sheet('M07_Target_VA')
    m07 = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'M07_Target_VA_Audit.csv')))
    ws3.append(list(m07[0].keys()))
    for r in m07:
        ws3.append([r.get(h, '') for h in m07[0].keys()])
    wb.save(FINAL / 'repeatability' /
            'MMU_10_Sample_Repeatability_Matrix.xlsx')

    status = {
        'generated_utc': __import__('datetime').datetime.utcnow()
        .isoformat() + 'Z',
        'FORMAL_DATA_INTEGRITY': acc['FORMAL_DATA_INTEGRITY'],
        'DIAGNOSTIC_FEATURE_INTEGRITY':
            acc['DIAGNOSTIC_FEATURE_INTEGRITY'],
        'REPEATABILITY_EXECUTION_READINESS':
            acc['REPEATABILITY_EXECUTION_READINESS'],
        'INDEPENDENT_ACCEPTANCE': acc['INDEPENDENT_ACCEPTANCE'],
        'MMU_FINAL_RESEARCH_CLOSURE': acc['MMU_FINAL_RESEARCH_CLOSURE'],
        'MMU_DIAGNOSTIC_FEATURE_GATE':
            acc['MMU_DIAGNOSTIC_FEATURE_GATE'],
        'MMU_REPEATABILITY_LAUNCH_GATE':
            acc['MMU_REPEATABILITY_LAUNCH_GATE'],
        'no_new_gem5_experiment': True,
        'original_artifacts_modified': False,
    }
    (FINAL / 'statuses' / 'STATUS.json').write_text(
        json.dumps(status, indent=2) + '\n')
    smd = ['# Final Status\n\n', '| Status | Value |\n|---|---|\n']
    for k in ('FORMAL_DATA_INTEGRITY', 'DIAGNOSTIC_FEATURE_INTEGRITY',
              'REPEATABILITY_EXECUTION_READINESS', 'INDEPENDENT_ACCEPTANCE',
              'MMU_FINAL_RESEARCH_CLOSURE',
              'MMU_DIAGNOSTIC_FEATURE_GATE',
              'MMU_REPEATABILITY_LAUNCH_GATE',
              'no_new_gem5_experiment', 'original_artifacts_modified'):
        smd.append('| `%s` | `%s` |\n' % (k, status[k]))
    (FINAL / 'statuses' / 'STATUS.md').write_text(''.join(smd))

    md = ['# MMU Final Research Closure Report\n\n',
          'Campaign: `MMU-FORMAL-20261113`\n\n',
          '## Final status\n\n',
          '- **MMU_FINAL_RESEARCH_CLOSURE = %s**\n' %
          status['MMU_FINAL_RESEARCH_CLOSURE'],
          '- MMU_DIAGNOSTIC_FEATURE_GATE = `%s`\n' %
          status['MMU_DIAGNOSTIC_FEATURE_GATE'],
          '- MMU_REPEATABILITY_LAUNCH_GATE = `%s`\n\n' %
          status['MMU_REPEATABILITY_LAUNCH_GATE'],
          'All four engineering gates pass. The final closure carries '
          'documented research limitations (observability and model '
          'separability), not hidden data failures.\n\n',
          '## Gate 1 — Formal data integrity\n\n',
          '`FORMAL_DATA_INTEGRITY = %s`\n\n' % status['FORMAL_DATA_INTEGRITY'],
          '- 40/40 SampleRunIDs present; terminal distribution `%s`.\n' %
          json.dumps(audit['terminal_distribution']),
          '- 40/40 trace, manifest and verdict hashes unchanged.\n',
          '- Frozen binary `%s`; source closure commit present; original '
          'results ZIP `%s` unchanged.\n\n' % (
              audit['frozen_binary_sha256'],
              audit['original_results_zip_sha256']),
          '## Gate 2 — Diagnostic feature integrity\n\n',
          '`DIAGNOSTIC_FEATURE_INTEGRITY = %s`\n\n' %
          status['DIAGNOSTIC_FEATURE_INTEGRITY'],
          '- Three views are separated: Ground Truth, Simulator-Assisted and '
          'Blinded.\n',
          '- The old `UpstreamPathClass_SIM` used `TraceFaultSite` and is '
          'marked critical leakage; the blind view uses event-derived '
          '`ObservedPathClass` only.\n',
          '- Fault consumption is separated into FaultInjected / '
          'FaultActivated / FaultStateConsumed / '
          'DownstreamArchitecturalConsumption.\n',
          '- Recomputed consumption: **%d/40 consumed**, **%d/40 downstream**, '
          'only **%d** literal `fault_state_consumed` events (M06).\n' % (
              cons['fault_state_consumed'],
              cons['downstream_architectural_consumption'],
              cons['explicit_fault_state_consumed_event']),
          '- M03 R01-R04: consumed but squashed before architectural update. '
          'M06: detected and contained; not generic masked. M07: '
          'permission-policy manifestations.\n\n',
          '## Gate 3 — Repeatability execution readiness\n\n',
          '`REPEATABILITY_EXECUTION_READINESS = %s`\n\n' %
          status['REPEATABILITY_EXECUTION_READINESS'],
          '- 10/10 launch rows READY; 10/10 read-only describes READY; '
          '%d parity checks with no semantic mismatch.\n' % len(parity),
          '- M01 uses executed guest `4f3ddbf2...`, not the canonical '
          '`ec525687...` field; the original matrix is untouched.\n',
          '- M05 R05 uses explicit `--mmu_m05_decoy_va 0x4010200000` and '
          '`--mmu_m05_decoy_table_base 0`; no live-scan fallback.\n',
          '- M07 R04/R05 exact target VAs are `0x400d400100` / '
          '`0x400d600180`.\n',
          '- All commands are fully expanded; isolated outdirs, byte-copied '
          'rcS and independent hash-pinned disk copies exist. No placeholders, '
          'no collisions, no seed flag.\n\n',
          '## Gate 4 — Independent acceptance\n\n',
          '`INDEPENDENT_ACCEPTANCE = %s`\n\n' %
          status['INDEPENDENT_ACCEPTANCE'],
          '- 33 automated tests pass; negative tests cover missing M05 '
          'decoy, wrong W9 guest, unresolved placeholders, output collision, '
          'missing consumption evidence, unsupported M03 exception labels and '
          'GT leakage.\n',
          '- No gem5 process was started; no repeatability run was executed.\n',
          '- The package SHA256 manifest is verified externally after zip '
          'creation (sibling `.sha256` file).\n\n',
          '## Key research findings\n\n',
          '1. The blinded view cannot distinguish M04 vs M08, and cannot '
          'reliably separate M02/M04/M08 from final wrong-value symptoms '
          'alone. Simulator-assisted entry/request-PA evidence is required.\n',
          '2. M01 vs M03 is separable only when maintenance/ASID/permission '
          'or squash observations are available.\n',
          '3. M06 vs M07 is separable when exception delivery or unexpected '
          'success is visible.\n',
          '4. No classifier accuracy or cross-workload generalization is '
          'claimed for 40 contexts.\n\n',
          '## Independent packaging review\n\n',
          'An independent read-only review found a non-blocking ZIP '
          'self-containment gap: `common.py` was not vendored and '
          '`__pycache__` files were present. Both were fixed; the describe '
          'markdown was regenerated with fully expanded commands. A fresh '
          'extraction now passes `sha256sum -c` and all 33 tests. The review '
          'confirmed no new gem5 process, no disk-image entry in the ZIP, '
          'and no semantic parity failure.\n\n',
          '## Stop condition\n\n',
          'No new gem5 experiment was started. The 10 repeatability runs are '
          'prepared and await researcher approval.\n']
    (FINAL / 'reports' / 'Final_Research_Closure_Report.md').write_text(
        ''.join(md))
    print(json.dumps(status, indent=1))


if __name__ == '__main__':
    main()
