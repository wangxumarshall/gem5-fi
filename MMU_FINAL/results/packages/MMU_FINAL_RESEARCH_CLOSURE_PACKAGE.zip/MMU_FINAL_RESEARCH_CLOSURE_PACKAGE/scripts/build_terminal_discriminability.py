#!/usr/bin/env python3
"""Terminal semantic report and model-ID-free discriminability analysis."""
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    samples = data['samples']
    gt = {r['OpaqueSampleID']: r['GroundTruth'] for r in samples}
    blind = [dict(r['BlindedObservation'], OpaqueSampleID=r['OpaqueSampleID'])
             for r in samples]
    # terminal table
    term_rows = []
    for r in samples:
        t = r['TerminalSemantics']
        term_rows.append({
            'SampleRunID': r['SampleRunID'],
            'OpaqueSampleID': r['OpaqueSampleID'],
            'FaultModelID_LABEL': r['GroundTruth']['FaultModelID'],
            'ContextID': r['OriginalResult']['ContextID'],
            'TerminalState_ORIGINAL': t['TerminalState_ORIGINAL'],
            'OracleResult_ORIGINAL': t['OracleResult_ORIGINAL'],
            'Primary_v2': t['Primary_v2'],
            'Secondary_v2': t['Secondary_v2'],
            'DetectionStatus_v2': t['DetectionStatus_v2'],
            'MaskingStatus_v2': t['MaskingStatus_v2'],
            'ExceptionDelivered_TraceEvidence':
                t['ExceptionDelivered_TraceEvidence'],
            'Correction': t['Correction'],
            'EvidenceLimitation': t['EvidenceLimitation'],
        })
    ot = FINAL / 'terminal_semantics'
    C.write_csv(ot / 'MMU_Terminal_Semantic_Classification.csv', term_rows)
    C.write_json(ot / 'MMU_Terminal_Semantic_Classification.json', term_rows)
    dist = Counter(r['TerminalState_ORIGINAL'] for r in term_rows)
    md = ['# Terminal Semantic Classification\n\n',
          'Original frozen distribution: `%s`.\n\n' % json.dumps(dict(dist)),
          '## M03\n\n']
    for r in term_rows:
        if r['FaultModelID_LABEL'] == 'M03':
            md.append('- %s: Terminal=%s, Propagation=%s, Trace=%s, '
                      'Primary=%s, Secondary=%s. No `exception_delivery` / '
                      '`fault_result_propagated`; squash-only. Detection '
                      'status=%s, masking=%s.\n' % (
                          r['SampleRunID'], r['TerminalState_ORIGINAL'],
                          next(x['OriginalResult']['PropagationStatus']
                               for x in samples
                               if x['SampleRunID'] == r['SampleRunID']),
                          next(x['OriginalResult']['TraceCompleteness']
                               for x in samples
                               if x['SampleRunID'] == r['SampleRunID']),
                          r['Primary_v2'], r['Secondary_v2'],
                          r['DetectionStatus_v2'], r['MaskingStatus_v2']))
    md.append('\n## M06\n\n')
    for r in term_rows:
        if r['FaultModelID_LABEL'] == 'M06':
            md.append('- %s: Terminal=%s, Primary=%s, Secondary=%s, '
                      'Detection=%s, Masking=%s; exception evidence=%s.\n' % (
                          r['SampleRunID'], r['TerminalState_ORIGINAL'],
                          r['Primary_v2'], r['Secondary_v2'],
                          r['DetectionStatus_v2'], r['MaskingStatus_v2'],
                          r['ExceptionDelivered_TraceEvidence']))
    md.append('\n## M07\n\n')
    for r in term_rows:
        if r['FaultModelID_LABEL'] == 'M07':
            md.append('- %s: Terminal=%s, Primary=%s, Secondary=%s. %s\n' % (
                r['SampleRunID'], r['TerminalState_ORIGINAL'],
                r['Primary_v2'], r['Secondary_v2'],
                r['EvidenceLimitation']))
    md.append('\n## Invariant\n\nOriginal `TerminalState` and `OracleResult` '
              'are unchanged; v2 labels are a separate versioned semantic '
              'dimension.\n')
    (ot / 'MMU_Terminal_Semantic_Classification_Report.md').write_text(
        ''.join(md))

    # discriminability
    def vals(model, key):
        return [r for r in blind
                if gt[r['OpaqueSampleID']]['FaultModelID'] == model]

    def sig(model, key):
        c = Counter(str(r[key]) for r in vals(model, key))
        return ','.join('%s:%d' % (k, v) for k, v in sorted(c.items()))

    pairs = [
        ('M02/M04/M08', ['M02', 'M04', 'M08'],
         'all can produce a wrong PA or wrong data value',
         'ObservedPTW, ObservedPartialEntry, ObservedTLBHits, '
         'ObservedConsumerKind, GuestValueMismatch_SW',
         'M02 has PTW; M04 has resident TLB hit in some contexts; M08 has '
         'final request PA corruption (simulator-only).',
         'Blinded observation cannot separate M02/M04/M08 reliably: all '
         'show PTW and/or resident-hit signals and the same wrong-value '
         'symptom. M04 vs M08 is not separable without internal entry/'
         'request-PA instrumentation.',
         'Simulator-assisted: refill-PFN event, entry lineage, request-PA '
         'delta. Production: page-table/PMU evidence not proven.'),
        ('M01/M03', ['M01', 'M03'],
         'stale vs foreign-ASID translation',
         'ObservedMaintenanceEvents, ObservedTLBHits, '
         'ObservedPermissionResults, ObservedSquash, GuestValueMismatch_SW',
         'M01 shows maintenance events followed by reuse; M03 shows '
         'permission-eval categories (deny+squash or grant+execute).',
         'If only the final wrong value is available, both are ambiguous. '
         'The observation must include maintenance history and permission/'
         'squash events.',
         'Simulator-assisted: TLBI match/suppression, candidate ASID. '
         'Production: TLB maintenance history + ASID correlation may be '
         'indirectly testable but is not proven.'),
        ('M06/M07', ['M06', 'M07'],
         'detection vs permission inversion',
         'ObservedExceptionDelivery, ObservedPermissionResults, '
         'ObservedSquash, GuestSignal_SW, GuestValueMismatch_SW, '
         'GuestUnexpectedSuccess_SW',
         'M06 has exception delivery/containment; M07 has permission '
         'denial followed by a successful consumer or unexpected success.',
         'If exception delivery is not observed, M06 vs M07 can be '
         'ambiguous; guest unexpected-success is a software-visible separator '
         'when present.',
         'Simulator-assisted: fault_state_consumed / exception class. '
         'Production: SIGSEGV/ESR and policy test are available, but exact '
         'internal cause is not.'),
    ]
    disc_rows = []
    for name, models, why, features, evidence, ambiguous, additional in pairs:
        disc_rows.append({
            'Pair': name, 'ModelsForAnalysisOnly': ','.join(models),
            'WhySimilar': why, 'ObservableFeatureSet': features,
            'DistinguishingEvidence': evidence,
            'AmbiguousCases': ambiguous,
            'RequiredAdditionalObservability': additional,
        })
    od = FINAL / 'discriminability'
    C.write_csv(od / 'MMU_Cross_Model_Discriminability.csv', disc_rows)
    C.write_json(od / 'MMU_Cross_Model_Discriminability.json', disc_rows)
    md = ['# Cross-Model Discriminability (model-ID-free)\n\n',
          'This is not a trained classifier and no accuracy is claimed. '
          'Ground-truth model IDs are used only to group the evaluation.\n\n',
          '## Blind feature distributions\n\n',
          '| Feature | M02 | M04 | M08 | M01 | M03 | M06 | M07 |\n'
          '|---|---|---|---|---|---|---|---|\n']
    for key in ('ObservedPathClass', 'ObservedMaintenanceEvents',
                'ObservedPTW', 'ObservedPermissionResults',
                'ObservedSquash', 'ObservedExceptionDelivery',
                'ObservedConsumerKind', 'GuestValueMismatch_SW',
                'GuestUnexpectedSuccess_SW'):
        md.append('| %s | %s | %s | %s | %s | %s | %s | %s |\n' % (
            key, sig('M02', key), sig('M04', key), sig('M08', key),
            sig('M01', key), sig('M03', key), sig('M06', key),
            sig('M07', key)))
    md.append('\n## Pair conclusions\n\n')
    for d in disc_rows:
        md.append('### %s\n\n' % d['Pair'])
        md.append('- Observable feature set: %s\n' %
                  d['ObservableFeatureSet'])
        md.append('- Distinguishing evidence: %s\n' %
                  d['DistinguishingEvidence'])
        md.append('- Ambiguous cases: %s\n' % d['AmbiguousCases'])
        md.append('- Required additional observability: %s\n\n' %
                  d['RequiredAdditionalObservability'])
    md.append('## Boundaries\n\n')
    md.append('- M04 vs M08 is not separable from the blinded observation '
              'set; both can present resident TLB hit + wrong value. '
              'Simulator-assisted entry/request-PA evidence is needed.\n')
    md.append('- M02 vs M04/M08 cannot be separated by final software '
              'symptom alone; PTW presence helps only if the trace is '
              'available.\n')
    md.append('- M01 vs M03 require maintenance/ASID/permission/squash '
              'observations; final wrong value alone is ambiguous.\n')
    md.append('- M06 vs M07 is separable when exception delivery or '
              'unexpected-success is visible.\n')
    md.append('- No claim is made about generalization to new faults or '
              'workloads; the dataset has 40 contexts.\n')
    (od / 'MMU_Model_Discriminability_Report.md').write_text(''.join(md))

    # model signature table from the existing feature library
    fl = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    sig_rows = []
    for m in fl['model_signatures']:
        sig_rows.append({
            'ModelID_LABEL': m['ModelID'],
            'SignatureName': m['SignatureName'],
            'Mechanism_LABEL': m['Mechanism'],
            'StableSignatureCount': m['DistinctStableSignatures'],
            'StableEventKinds': '|'.join(m['StableEventKinds']),
            'TerminalDistribution': m['TerminalDistribution'],
            'StableFields': m['StableFields'],
            'VariableFields': m['VariableFields'],
        })
    C.write_csv(od / 'MMU_Model_Signatures.csv', sig_rows)
    C.write_json(od / 'MMU_Model_Signatures.json', sig_rows)
    print(json.dumps({
        'terminal_distribution': dict(dist),
        'terminal_rows': len(term_rows),
        'discriminability_rows': len(disc_rows),
        'model_signature_rows': len(sig_rows),
    }, indent=1))


if __name__ == '__main__':
    main()
