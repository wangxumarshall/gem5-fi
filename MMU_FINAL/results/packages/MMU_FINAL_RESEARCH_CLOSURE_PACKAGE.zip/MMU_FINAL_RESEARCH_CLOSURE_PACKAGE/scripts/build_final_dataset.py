#!/usr/bin/env python3
"""Build the single authoritative final dataset from frozen artifacts.

This does not rerun gem5 and does not modify any frozen file.  The blinded
observations are produced by a function that has no ground-truth parameter.
"""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
sys.path.insert(0, str(HERE))
import common as C
import blind_features
import consumption_semantics

FINAL = C.OUT / 'final_closure'
ADD = C.OUT / 'addendum'


def parse_line(line):
    return C.parse_kv_line(line)


def guest_from_verdict(ver):
    o = parse_line((ver.get('Details', {}).get('oracle') or {}).get('line', ''))
    c = parse_line((ver.get('Details', {}).get('control_oracle') or {})
                   .get('line', ''))
    expected = None
    if 'new_marker' in o:
        expected = o.get('new_marker')
    elif 'target_after' in o:
        expected = o.get('target_after')
    elif 'sentinel' in o:
        expected = o.get('sentinel')
    elif 'expect' in o:
        expected = o.get('expect')
    elif 'expected' in o:
        expected = o.get('expected')
    observed = o.get('observed') or o.get('target_observed')
    mismatch = None
    if expected is not None and observed is not None:
        mismatch = str(expected).lower() != str(observed).lower()
    if 'neighbor_alias_observed' in o and 'neighbor_before' in o:
        mismatch = bool(mismatch) or (
            o.get('neighbor_alias_observed') != o.get('neighbor_before'))
    unexpected = (c.get('signal') not in (None, '', '0') and
                  o.get('signal') in ('0', '') and o.get('result') == 'FAIL')
    return {
        'GuestSignal': o.get('signal', ''),
        'GuestSICode': o.get('si_code', ''),
        'GuestFaultClass': o.get('fault_class', ''),
        'GuestObservedValue': observed or '',
        'GuestExpectedValue': expected or '',
        'GuestValueMismatch': mismatch,
        'GuestUnexpectedSuccess': unexpected,
        'GuestSharedChanged': o.get('shared_changed', ''),
        'GuestResult': o.get('result', ''),
    }


def cmd_map(cmd):
    out = {}
    i = 0
    while i < len(cmd):
        if str(cmd[i]).startswith('--'):
            if i + 1 < len(cmd) and not str(cmd[i + 1]).startswith('--'):
                out[cmd[i]] = cmd[i + 1]
                i += 2
            else:
                out[cmd[i]] = 'true'
                i += 1
        else:
            i += 1
    return out


def main():
    for d in ('data', 'views', 'consumption', 'leakage', 'repeatability',
              'discriminability', 'terminal_semantics', 'provenance',
              'reports', 'tests', 'excel'):
        (FINAL / d).mkdir(parents=True, exist_ok=True)
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    auth = {r['SampleRunID']: r for r in C.authority_matrix_rows()}
    pairs = {r['SampleRunID']: r for r in C.fault_control_pairs()}
    v1 = {f['identity']['SampleRunID']: f
          for f in json.load(open(C.FEAT /
                                  'MMU_Diagnostic_Feature_Library.json'))[
                                      'samples']}
    v2 = {r['SampleRunID']: r for r in csv.DictReader(
        open(ADD / 'semantic_labels' / 'MMU_Manifestation_Labels_v2.csv'))}
    sids = sorted(matrix)
    opaque = {sid: 'S%03d' % i for i, sid in enumerate(sids, 1)}
    records = []
    for sid in sids:
        man = C.manifest(sid)
        ver = C.verdict(sid)
        ch = C.chain(sid)
        scan = C.scan_cache(sid)
        rdir = C.sample_dir(sid)
        guest = guest_from_verdict(ver)
        chain_events = ch.get('Events', [])
        combined = {}
        for e in chain_events:
            combined[int(e['EventID'])] = e
        for e in scan['SelectedEvents']:
            try:
                eid = int(e['event_id'])
            except (TypeError, ValueError):
                continue
            combined.setdefault(eid, e)
        events_for_consumption = [combined[k] for k in sorted(combined)]
        cons = consumption_semantics.evaluate(ver, events_for_consumption,
                                              guest)
        cons_ev = next((e for e in chain_events
                        if str(e.get('EventID')) ==
                        str(ver.get('consumption_event_id'))), {})
        f = v1[sid]
        blind = blind_features.derive_blind(
            chain_events, guest, man.get('target_mode', ''),
            '0x%x' % man['target_va'])
        model = man['model']
        gt = {
            'SampleRunID': sid,
            'OpaqueSampleID': opaque[sid],
            'FaultModelID': model,
            'FaultOrigin': f['fault_origin']['ModelMechanism'],
            'FaultType': f['fault_origin']['FaultType'],
            'FaultLocation': f['fault_origin']['InjectionLocation'],
            'FaultOriginSite': f['fault_origin']['InjectionLocation'][
                'SourceFile'],
            'InjectionLocation': f['fault_origin']['InjectionLocation'][
                'TraceFaultSite'],
            'TraceFaultSite': f['fault_origin']['InjectionLocation'][
                'TraceFaultSite'],
            'FaultField': f['fault_origin']['TargetField'],
            'FaultStateBefore': f['activation']['FaultStateBefore'],
            'FaultStateAfter': f['activation']['FaultStateAfter'],
            'FaultParameters': {
                k: v for k, v in cmd_map(man['command']).items()
                if str(k).startswith('--mmu_')},
            'TargetVA': '0x%x' % man['target_va'],
            'AccessMode': man['target_mode'],
            'OriginalTerminalState': ver['TerminalState'],
            'OriginalOracleResult': ver['OracleResult'],
            'OriginalPropagationStatus': ver['PropagationStatus'],
            'OriginalTraceCompleteness': ver['TraceCompleteness'],
        }
        original = {
            'ModelID': model,
            'ContextID': man['context'],
            'WorkloadID': matrix[sid]['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'AttemptID': matrix[sid]['AttemptID'],
            'RunDir': str(rdir),
            'ActivationStatus': ver['ActivationStatus'],
            'FaultConsumptionStatus': ver['FaultConsumptionStatus'],
            'PropagationStatus': ver['PropagationStatus'],
            'TerminalState': ver['TerminalState'],
            'OracleResult': ver['OracleResult'],
            'TraceCompleteness': ver['TraceCompleteness'],
            'RecordIntegrity': ver['RecordIntegrity'],
            'BinarySHA256': man.get('gem5_sha256'),
            'WorkloadSHA256': man.get('workload_sha256'),
            'ConfigSHA256': C.sha256_file(rdir / 'Config' / 'config.ini'),
            'ManifestSHA256': C.sha256_file(rdir / 'sample_manifest.json'),
            'VerdictSHA256': C.sha256_file(rdir / 'Validation/verdict.json'),
            'TraceAbsolutePath': scan['TraceAbsolutePath'],
            'TraceSHA256': scan['TraceSHA256'],
            'TraceEventCount': scan['EventCount'],
            'ChainEventCount': len(chain_events),
            'ChainJoinMismatches': len(scan['ChainJoinMismatches']),
            'ControlRunDir': pairs[sid]['ControlRunDir'],
            'ControlOraclePath': pairs[sid]['ControlOraclePath'],
            'ControlOracleSHA256': pairs[sid]['ControlOracleSHA256'],
        }
        sim = {
            'SampleRunID': sid,
            'OpaqueSampleID': opaque[sid],
            'ChainEventKinds': '|'.join(e['Kind'] for e in chain_events),
            'ChainEventIDs': ';'.join(str(e['EventID'])
                                      for e in chain_events),
            'ActivationEventID': f['activation']['ActivationEventID'],
            'ActivationKind': f['activation']['ActivationKind'],
            'ConsumptionEventID': ver['consumption_event_id'],
            'ConsumptionKind': ver.get('consumption_kind', ''),
            'TranslationID': cons_ev.get('TranslationID', ''),
            'TraceFaultSite': f['fault_origin']['InjectionLocation'][
                'TraceFaultSite'],
            'FaultField': f['fault_origin']['TargetField'],
            'FaultModelID': model,
            'FaultOrigin': f['fault_origin']['ModelMechanism'],
            'StateTransitionFields': '|'.join(
                sorted(set(f['activation']['FaultStateBefore']) |
                       set(f['activation']['FaultStateAfter']))),
            'StateTransitionValues': json.dumps({
                'before': f['activation']['FaultStateBefore'],
                'after': f['activation']['FaultStateAfter']},
                sort_keys=True),
            'DownstreamKinds': '|'.join(
                f['propagation_path']['DownstreamKinds']),
            'NodeCount': len(chain_events),
            'ProvenanceClasses': json.dumps({
                'FaultModelID': 'GROUND_TRUTH',
                'FaultOrigin': 'GROUND_TRUTH',
                'TraceFaultSite': 'GROUND_TRUTH_DERIVED',
                'FaultField': 'GROUND_TRUTH_DERIVED',
                'translation_result': 'MICROARCH_EVENT',
                'tlb_lookup_hit': 'MICROARCH_EVENT',
                'ptw_start': 'MICROARCH_EVENT',
                'pte_read': 'MICROARCH_EVENT',
                'permission_eval': 'MICROARCH_EVENT',
                'lsu_request': 'MICROARCH_EVENT',
                'mmu_fault_activate': 'INJECTOR_EVENT',
                'mmu_fault_arm': 'INJECTOR_EVENT',
                'refill_pfn_corrupt': 'INJECTOR_EVENT',
                'tlbi_suppressed': 'INJECTOR_EVENT',
                'tlb_entry_lineage': 'INJECTOR_EVENT',
                'fault_state_consumed': 'INJECTOR_EVENT',
                'fault_result_propagated': 'INJECTOR_EVENT',
            }, sort_keys=True),
        }
        terminal = {
            'TerminalState_ORIGINAL': ver['TerminalState'],
            'OracleResult_ORIGINAL': ver['OracleResult'],
            'Primary_v2': v2[sid]['Primary_v2'],
            'Secondary_v2': v2[sid]['Secondary_v2'],
            'DetectionStatus_v2': v2[sid]['DetectionStatus_v2'],
            'MaskingStatus_v2': v2[sid]['MaskingStatus_v2'],
            'ExceptionDelivered_TraceEvidence':
                str(v2[sid]['ExceptionDelivered_TraceEvidence']).lower() ==
                'true',
            'Correction': v2[sid]['Correction'],
            'EvidenceLimitation': v2[sid]['EvidenceLimitation'],
        }
        records.append({
            'SampleRunID': sid,
            'OpaqueSampleID': opaque[sid],
            'GroundTruth': gt,
            'OriginalResult': original,
            'SimulatorAssisted': sim,
            'BlindedObservation': blind,
            'Consumption': cons,
            'TerminalSemantics': terminal,
            'GuestSymptoms': guest,
        })
    meta = {
        'campaign_id': 'MMU-FORMAL-20261113',
        'campaign_status': C.final_summary().get('status'),
        'frozen_binary_sha256':
            'b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185',
        'source_closure': '60f1a8760410288128061d85582e5395b24c0106',
        'sample_count': len(records),
        'terminal_distribution': {
            'SDC': sum(1 for r in records
                       if r['OriginalResult']['TerminalState'] == 'SDC'),
            'SQUASHED': sum(1 for r in records
                            if r['OriginalResult']['TerminalState'] ==
                            'SQUASHED'),
            'DETECTED_CONTAINED': sum(
                1 for r in records if r['OriginalResult']['TerminalState'] ==
                'DETECTED_CONTAINED'),
        },
        'views': {
            'ground_truth': 'MMU_Ground_Truth.csv/json',
            'simulator_assisted': 'MMU_Simulator_Assisted_Features.csv/json',
            'blinded': 'MMU_Blinded_Diagnostic_Features.csv/json',
        },
    }
    C.write_json(FINAL / 'data' / 'MMU_Final_Dataset.json',
                 {'metadata': meta, 'samples': records})
    C.write_json(FINAL / 'data' / 'MMU_Opaque_ID_Map.json', opaque)
    C.write_csv(FINAL / 'data' / 'MMU_Opaque_ID_Map.csv',
                [{'SampleRunID': s, 'OpaqueSampleID': o}
                 for s, o in sorted(opaque.items())])
    rows = []
    for r in records:
        g = r['GroundTruth']; o = r['OriginalResult']
        c = r['Consumption']; t = r['TerminalSemantics']
        rows.append({
            'SampleRunID': r['SampleRunID'],
            'OpaqueSampleID': r['OpaqueSampleID'],
            'ModelID': g['FaultModelID'],
            'ContextID': o['ContextID'],
            'WorkloadID': o['WorkloadID'],
            'TerminalState': o['TerminalState'],
            'OracleResult': o['OracleResult'],
            'PropagationStatus': o['PropagationStatus'],
            'FaultStateConsumed': c['FaultStateConsumed'],
            'DownstreamArchitecturalConsumption':
                c['DownstreamArchitecturalConsumption'],
            'Primary_v2': t['Primary_v2'],
            'Secondary_v2': t['Secondary_v2'],
            'ExecutionControls': o['RunDir'],
        })
    C.write_csv(FINAL / 'data' / 'MMU_Final_Dataset.csv', rows)
    print(json.dumps({
        'samples': len(records),
        'terminal': meta['terminal_distribution'],
        'consumed': sum(1 for r in records
                        if r['Consumption']['FaultStateConsumed']),
        'explicit_consumed_events': sum(
            1 for r in records if r['Consumption'][
                'ExplicitFaultStateConsumedEventObserved']),
        'consumption_missing': [r['SampleRunID'] for r in records
                                if not r['Consumption'][
                                    'ConsumptionEvidencePresent']],
        'downstream': sum(1 for r in records
                          if r['Consumption'][
                              'DownstreamArchitecturalConsumption']),
    }, indent=1))


if __name__ == '__main__':
    main()
