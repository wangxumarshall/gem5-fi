# Independent Acceptance

| Gate | Check | Status | Detail |
|---|---|---|---|
| G1 | FORMAL_DATA_INTEGRITY | PASS | PASS |
| G1 | 40_sample_ids | PASS | 40 |
| G1 | terminal_distribution | PASS | {'SDC': 31, 'SQUASHED': 4, 'DETECTED_CONTAINED': 5} |
| G1 | trace_manifest_verdict_unchanged | PASS | {'FORMAL_DATA_INTEGRITY': 'PASS', 'samples': 40, 'sample_id_set_matches_matrix': True, 'trace_unchanged': '40/40', 'manifest_unchanged': '40/40', 'verdict_uncha |
| G1 | binary_source_zip | PASS | {'FORMAL_DATA_INTEGRITY': 'PASS', 'samples': 40, 'sample_id_set_matches_matrix': True, 'trace_unchanged': '40/40', 'manifest_unchanged': '40/40', 'verdict_uncha |
| G2 | blind_no_forbidden_columns | PASS | [] |
| G2 | blind_opaque_ids | PASS | 40 |
| G2 | high_risk_not_allowed | PASS | 21 |
| G2 | consumption_40 | PASS | 40 |
| G2 | explicit_event_5 | PASS |  |
| G2 | downstream_36 | PASS |  |
| G2 | m03_no_detected_exception | PASS |  |
| G2 | m06_contained | PASS |  |
| G3 | 10_ready | PASS | 10 |
| G3 | no_placeholders | PASS |  |
| G3 | m01_executed | PASS |  |
| G3 | m05_decoy | PASS |  |
| G3 | m07_exact_va | PASS |  |
| G3 | 10_describe_ready | PASS | 10 |
| G3 | parity_no_fail | PASS | 80 |
| G3 | disk_independent | PASS | 10 |
| G3 | no_collision | PASS |  |
| G4 | automated_tests | PASS | {'tests_run': 33, 'failures': 0, 'errors': 0, 'skipped': 0, 'success': True, 'log': '/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campai |
| G4 | no_new_gem5 | PASS |  |
| G4 | excel_sheets | PASS | [] |

## Gate status

- **FORMAL_DATA_INTEGRITY = PASS**
- **DIAGNOSTIC_FEATURE_INTEGRITY = PASS**
- **REPEATABILITY_EXECUTION_READINESS = PASS**
- **INDEPENDENT_ACCEPTANCE = PASS**
- **MMU_FINAL_RESEARCH_CLOSURE = PASS_WITH_DOCUMENTED_RESEARCH_LIMITATIONS**
- **MMU_DIAGNOSTIC_FEATURE_GATE = PASS**
- **MMU_REPEATABILITY_LAUNCH_GATE = READY_FOR_RESEARCHER_APPROVAL**
