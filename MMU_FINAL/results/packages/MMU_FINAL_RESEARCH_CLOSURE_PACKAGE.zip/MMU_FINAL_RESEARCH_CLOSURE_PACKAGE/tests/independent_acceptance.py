#!/usr/bin/env python3
"""Independent acceptance: reads deliverables only, no generator imports."""
import csv
import json
import subprocess
import sys
from pathlib import Path

FINAL = Path(__file__).resolve().parent.parent
PC = FINAL.parent
CAMP = PC.parent


def load(p):
    return json.load(open(p))


def csvrows(p):
    return list(csv.DictReader(open(p)))


def main():
    checks = []

    def check(gate, name, ok, detail=''):
        checks.append({'Gate': gate, 'Check': name,
                       'Status': 'PASS' if ok else 'FAIL',
                       'Detail': str(detail)})

    audit = load(FINAL / 'reports' /
                 'Original_40_Sample_Integrity_Audit.json')
    check('G1', 'FORMAL_DATA_INTEGRITY', audit['FORMAL_DATA_INTEGRITY'] ==
          'PASS', audit['FORMAL_DATA_INTEGRITY'])
    check('G1', '40_sample_ids', audit['samples'] == 40, audit['samples'])
    check('G1', 'terminal_distribution',
          audit['terminal_distribution'] ==
          {'SDC': 31, 'SQUASHED': 4, 'DETECTED_CONTAINED': 5},
          audit['terminal_distribution'])
    check('G1', 'trace_manifest_verdict_unchanged',
          audit['trace_unchanged'] == '40/40' and
          audit['manifest_unchanged'] == '40/40' and
          audit['verdict_unchanged'] == '40/40', audit)
    check('G1', 'binary_source_zip',
          audit['binary_matches_frozen'] and
          audit['source_files_match'] and
          audit['source_closure_commit_exists'] and
          audit['original_results_zip_unchanged'], audit)

    blind = csvrows(FINAL / 'views' / 'MMU_Blinded_Diagnostic_Features.csv')
    forbidden = {'FaultModelID', 'FaultOrigin', 'InjectionLocation',
                 'TraceFaultSite', 'FaultField', 'SampleRunID'}
    check('G2', 'blind_no_forbidden_columns',
          not (set(blind[0]) & forbidden), sorted(set(blind[0]) & forbidden))
    check('G2', 'blind_opaque_ids',
          all(r['OpaqueSampleID'].startswith('S') and
              'M0' not in r['OpaqueSampleID'] for r in blind), len(blind))
    leak = csvrows(FINAL / 'leakage' / 'MMU_Feature_Leakage_Audit.csv')
    check('G2', 'high_risk_not_allowed',
          all(r['AllowedInBlindView'] != 'YES'
              for r in leak if r['LeakageRisk'] in ('CRITICAL', 'HIGH')),
          len(leak))
    cons = csvrows(FINAL / 'consumption' /
                   'MMU_40_Sample_Consumption_Evidence.csv')
    check('G2', 'consumption_40', sum(
        1 for r in cons if r['FaultStateConsumed'] == 'True') == 40, len(cons))
    check('G2', 'explicit_event_5', sum(
        1 for r in cons
        if r['ExplicitFaultStateConsumedEventObserved'] == 'True') == 5, '')
    check('G2', 'downstream_36', sum(
        1 for r in cons
        if r['DownstreamArchitecturalConsumption'] == 'True') == 36, '')
    term = csvrows(FINAL / 'terminal_semantics' /
                   'MMU_Terminal_Semantic_Classification.csv')
    check('G2', 'm03_no_detected_exception',
          all('DETECTED_EXCEPTION' not in r['Secondary_v2']
              for r in term if r['FaultModelID_LABEL'] == 'M03'), '')
    check('G2', 'm06_contained',
          all(r['Primary_v2'] == 'DETECTED_CONTAINED' and
              r['MaskingStatus_v2'] == 'CONTAINED_BY_EXCEPTION_DELIVERY'
              for r in term if r['FaultModelID_LABEL'] == 'M06'), '')

    launch = csvrows(FINAL / 'repeatability' /
                     'MMU_Repeatability_Launch_Matrix.csv')
    check('G3', '10_ready', len(launch) == 10 and all(
        r['Status'] == 'READY_FOR_RESEARCHER_APPROVAL' for r in launch),
        len(launch))
    check('G3', 'no_placeholders', all(
        r['PlaceholderPresent'] == 'False' for r in launch), '')
    check('G3', 'm01_executed', next(
        r['ExecutedGuestBinarySHA256'] for r in launch
        if r['ModelID'] == 'M01') ==
        '4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98', '')
    m05 = next(r for r in launch if r['ModelID'] == 'M05')
    check('G3', 'm05_decoy',
          '--mmu_m05_decoy_va 0x4010200000' in m05['FullCommand'] and
          '--mmu_m05_decoy_table_base 0' in m05['FullCommand'], '')
    check('G3', 'm07_exact_va',
          (lambda d: d['R04'] == '0x400d400100' and
           d['R05'] == '0x400d600180')(
              {r['SampleRunID'].split('-')[-1]: r['TargetVA']
               for r in csvrows(FINAL / 'repeatability' /
                                'M07_Target_VA_Audit.csv')}), '')
    desc = [p for p in (FINAL / 'repeatability' / 'describe').glob('M*.json')
            if load(p).get('status') == 'READY']
    check('G3', '10_describe_ready', len(desc) == 10, len(desc))
    parity = csvrows(FINAL / 'repeatability' /
                     'Repeatability_Parameter_Parity.csv')
    check('G3', 'parity_no_fail', all(
        r['Status'] in ('PASS', 'N/A') for r in parity), len(parity))
    disk = csvrows(FINAL / 'repeatability' / 'Disk_Copy_Manifest.csv')
    check('G3', 'disk_independent', all(
        r['IndependentInode'] == 'True' and
        r['SHA256'] ==
        'bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759'
        for r in disk) and len({r['Path'] for r in disk}) == 10, len(disk))
    check('G3', 'no_collision', all(
        r['Collision'] == 'False' for r in csvrows(
            FINAL / 'repeatability' /
            'Repeatability_Output_Isolation_Audit.csv')), '')

    tests = load(FINAL / 'tests' / 'TEST_RESULTS.json')
    check('G4', 'automated_tests', tests['success'] and
          tests['failures'] == 0 and tests['errors'] == 0,
          tests)
    proc = subprocess.run(['pgrep', '-x', 'gem5.opt'],
                          capture_output=True, text=True)
    check('G4', 'no_new_gem5', proc.stdout.strip() == '', proc.stdout)
    import openpyxl
    wb = openpyxl.load_workbook(
        FINAL / 'excel' / 'MMU_FINAL_Research_Feature_Library.xlsx',
        read_only=True)
    required = {'Readme', 'Ground_Truth', 'Original_40_Results',
                'Simulator_Features', 'Blinded_Observations',
                'Consumption_Evidence', 'Manifestation_Types',
                'Model_Signatures', 'Cross_Model_Discriminability',
                'Observability_Classification', 'Repeatability_Samples',
                'Repeatability_Parity', 'Research_Limitations',
                'Provenance', 'Change_Log'}
    check('G4', 'excel_sheets', required.issubset(set(wb.sheetnames)),
          sorted(required - set(wb.sheetnames)))

    gates = {}
    for g in ('G1', 'G2', 'G3', 'G4'):
        gates[g] = all(c['Status'] == 'PASS' for c in checks
                       if c['Gate'] == g)
    status = {
        'FORMAL_DATA_INTEGRITY': 'PASS' if gates['G1'] else 'FAIL',
        'DIAGNOSTIC_FEATURE_INTEGRITY': 'PASS' if gates['G2'] else 'FAIL',
        'REPEATABILITY_EXECUTION_READINESS': 'PASS' if gates['G3'] else 'FAIL',
        'INDEPENDENT_ACCEPTANCE': 'PASS' if gates['G4'] else 'FAIL',
        'MMU_FINAL_RESEARCH_CLOSURE': (
            'PASS_WITH_DOCUMENTED_RESEARCH_LIMITATIONS'
            if all(gates.values()) else 'BLOCKED'),
        'MMU_DIAGNOSTIC_FEATURE_GATE': 'PASS' if gates['G2'] else 'FAIL',
        'MMU_REPEATABILITY_LAUNCH_GATE': (
            'READY_FOR_RESEARCHER_APPROVAL' if gates['G3'] else 'BLOCKED'),
        'checks': checks,
        'gates': gates,
    }
    out = FINAL / 'tests' / 'Independent_Acceptance.json'
    out.write_text(json.dumps(status, indent=2) + '\n')
    md = ['# Independent Acceptance\n\n',
          '| Gate | Check | Status | Detail |\n|---|---|---|---|\n']
    for c in checks:
        md.append('| %s | %s | %s | %s |\n' % (
            c['Gate'], c['Check'], c['Status'], c['Detail'][:160]))
    md.append('\n## Gate status\n\n')
    for k in ('FORMAL_DATA_INTEGRITY', 'DIAGNOSTIC_FEATURE_INTEGRITY',
              'REPEATABILITY_EXECUTION_READINESS', 'INDEPENDENT_ACCEPTANCE',
              'MMU_FINAL_RESEARCH_CLOSURE',
              'MMU_DIAGNOSTIC_FEATURE_GATE',
              'MMU_REPEATABILITY_LAUNCH_GATE'):
        md.append('- **%s = %s**\n' % (k, status[k]))
    (FINAL / 'tests' / 'Independent_Acceptance.md').write_text(''.join(md))
    print(json.dumps({k: v for k, v in status.items()
                      if k not in ('checks', 'gates')}, indent=1))
    return 0 if all(gates.values()) else 1


if __name__ == '__main__':
    sys.exit(main())
