#!/usr/bin/env python3
"""Independent automated tests for the final MMU closure artifacts."""
import csv
import hashlib
import json
import os
import subprocess
import sys
import unittest
from collections import Counter
from pathlib import Path

FINAL = Path(__file__).resolve().parent.parent
PC = FINAL.parent
for _cand in (PC / 'scripts', FINAL / 'scripts'):
    if (_cand / 'common.py').is_file():
        sys.path.insert(0, str(_cand))
sys.path.insert(0, str(FINAL / 'scripts'))
import common as C
import blind_features
import consumption_semantics
import repeat_validate


def sha(p):
    return C.sha256_file(p)


def load_json(p):
    return json.load(open(p))


class TestFormalData(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_json(FINAL / 'data' / 'MMU_Final_Dataset.json')
        cls.samples = cls.data['samples']
        cls.audit = load_json(FINAL / 'reports' /
                              'Original_40_Sample_Integrity_Audit.json')

    def test_01_40_samples(self):
        self.assertEqual(len(self.samples), 40)
        self.assertEqual(len({r['SampleRunID'] for r in self.samples}), 40)

    def test_02_terminal_distribution(self):
        c = Counter(r['OriginalResult']['TerminalState']
                    for r in self.samples)
        self.assertEqual(dict(c), {'SDC': 31, 'SQUASHED': 4,
                                   'DETECTED_CONTAINED': 5})

    def test_03_original_audit(self):
        self.assertEqual(self.audit['FORMAL_DATA_INTEGRITY'], 'PASS')
        self.assertEqual(self.audit['trace_unchanged'], '40/40')
        self.assertEqual(self.audit['manifest_unchanged'], '40/40')
        self.assertEqual(self.audit['verdict_unchanged'], '40/40')

    def test_04_binary_and_source_closure(self):
        self.assertTrue(self.audit['binary_matches_frozen'])
        self.assertEqual(
            self.audit['frozen_binary_sha256'],
            'b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f'
            '7185')
        self.assertTrue(self.audit['source_files_match'])
        self.assertTrue(self.audit['source_closure_commit_exists'])

    def test_05_original_zip(self):
        self.assertEqual(
            self.audit['original_results_zip_sha256'],
            'caeaf6506495ed119a06a12075f5193276e2e1279286ddc56610016f39c'
            'aa151')


class TestBlindLeakage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_json(FINAL / 'data' / 'MMU_Final_Dataset.json')
        cls.samples = cls.data['samples']
        cls.blind = list(csv.DictReader(open(
            FINAL / 'views' / 'MMU_Blinded_Diagnostic_Features.csv')))
        cls.audit = list(csv.DictReader(open(
            FINAL / 'leakage' / 'MMU_Feature_Leakage_Audit.csv')))

    def test_01_no_forbidden_columns(self):
        cols = set(self.blind[0].keys())
        forbidden = {'FaultModelID', 'FaultOrigin', 'InjectionLocation',
                     'TraceFaultSite', 'FaultField', 'SampleRunID'}
        self.assertFalse(cols & forbidden)

    def test_02_opaque_ids(self):
        for r in self.blind:
            self.assertRegex(r['OpaqueSampleID'], r'^S\d{3}$')
            self.assertNotIn('M0', r['OpaqueSampleID'])

    def test_03_derive_is_reproducible_and_gt_free(self):
        for r in self.samples:
            events = C.chain(r['SampleRunID'])['Events']
            guest = r['GuestSymptoms']
            out = blind_features.derive_blind(
                events, guest, r['GroundTruth']['AccessMode'],
                r['GroundTruth']['TargetVA'])
            stored = r['BlindedObservation']
            for k, v in out.items():
                self.assertEqual(str(stored[k]), str(v), (r['SampleRunID'], k))
        import inspect
        params = list(inspect.signature(
            blind_features.derive_blind).parameters)
        self.assertEqual(params, ['events', 'guest', 'access_mode',
                                  'target_va'])

    def test_04_removing_injector_events_does_not_change(self):
        for r in self.samples:
            events = C.chain(r['SampleRunID'])['Events']
            filtered = [e for e in events
                        if e.get('Kind') not in
                        blind_features.INJECTOR_ONLY_KINDS]
            a = blind_features.derive_blind(
                events, r['GuestSymptoms'],
                r['GroundTruth']['AccessMode'], r['GroundTruth']['TargetVA'])
            b = blind_features.derive_blind(
                filtered, r['GuestSymptoms'],
                r['GroundTruth']['AccessMode'], r['GroundTruth']['TargetVA'])
            self.assertEqual(a, b)

    def test_05_leakage_audit(self):
        for r in self.audit:
            if r['LeakageRisk'] in ('CRITICAL', 'HIGH'):
                self.assertNotEqual(r['AllowedInBlindView'], 'YES', r)

    def test_06_no_high_risk_allowed(self):
        allowed = [r for r in self.audit
                   if r['AllowedInBlindView'] == 'YES']
        names = {r['FeatureName'] for r in allowed}
        self.assertNotIn('FaultModelID', names)
        self.assertNotIn('TraceFaultSite', names)
        self.assertNotIn('UpstreamPathClass_SIM (addendum v1)', names)


class TestConsumption(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_json(FINAL / 'data' / 'MMU_Final_Dataset.json')
        cls.rows = cls.data['samples']

    def test_01_40_consumed(self):
        self.assertEqual(sum(1 for r in self.rows
                             if r['Consumption']['FaultStateConsumed']), 40)

    def test_02_explicit_event_only_m06(self):
        explicit = [r['SampleRunID'] for r in self.rows
                    if r['Consumption'][
                        'ExplicitFaultStateConsumedEventObserved']]
        self.assertEqual(len(explicit), 5)
        self.assertTrue(all(x.startswith('M06-') for x in explicit))

    def test_03_m03_squash_not_arch(self):
        for r in self.rows:
            if r['GroundTruth']['FaultModelID'] == 'M03' and \
                    r['OriginalResult']['TerminalState'] == 'SQUASHED':
                self.assertTrue(r['Consumption']['FaultStateConsumed'])
                self.assertFalse(r['Consumption'][
                    'DownstreamArchitecturalConsumption'])

    def test_04_missing_evidence_is_not_consumed(self):
        ver = {'ActivationStatus': 'ACTIVATED',
               'FaultConsumptionStatus': 'CONSUMED',
               'activation_event_id': 1, 'consumption_event_id': 99,
               'consumption_kind': 'lsu_request',
               'PropagationStatus': 'FULL', 'TerminalState': 'SDC'}
        out = consumption_semantics.evaluate(ver, [{'EventID': 1,
                                                    'Kind': 'mmu_fault_activate'}],
                                             {'GuestValueMismatch': True})
        self.assertFalse(out['FaultStateConsumed'])

    def test_05_counts(self):
        self.assertEqual(sum(
            1 for r in self.rows if r['Consumption'][
                'DownstreamArchitecturalConsumption']), 36)


class TestTerminal(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = load_json(FINAL / 'data' /
                             'MMU_Final_Dataset.json')['samples']

    def test_01_m03_no_exception(self):
        for r in self.rows:
            if r['GroundTruth']['FaultModelID'] == 'M03' and \
                    r['OriginalResult']['TerminalState'] == 'SQUASHED':
                self.assertFalse(r['TerminalSemantics'][
                    'ExceptionDelivered_TraceEvidence'])
                self.assertNotIn('DETECTED_EXCEPTION',
                                 r['TerminalSemantics']['Secondary_v2'])

    def test_02_m06_contained(self):
        for r in self.rows:
            if r['GroundTruth']['FaultModelID'] == 'M06':
                self.assertEqual(r['TerminalSemantics']['Primary_v2'],
                                 'DETECTED_CONTAINED')
                self.assertEqual(r['TerminalSemantics']['MaskingStatus_v2'],
                                 'CONTAINED_BY_EXCEPTION_DELIVERY')
                self.assertTrue(r['TerminalSemantics'][
                    'ExceptionDelivered_TraceEvidence'])

    def test_03_m07_permission(self):
        m07 = [r for r in self.rows
               if r['GroundTruth']['FaultModelID'] == 'M07']
        self.assertEqual(Counter(r['TerminalSemantics']['Primary_v2']
                                 for r in m07),
                         Counter({'UNAUTHORIZED_WRITE': 2,
                                  'UNAUTHORIZED_READ': 1,
                                  'UNAUTHORIZED_EXECUTION': 2}))
        r02 = next(r for r in m07 if r['OriginalResult']['ContextID'] == 'R02')
        self.assertIn('translation_id=5',
                      r02['TerminalSemantics']['EvidenceLimitation'])


class TestRepeatability(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = list(csv.DictReader(open(
            FINAL / 'repeatability' /
            'MMU_Repeatability_Launch_Matrix.csv')))
        cls.formal = [r['RunDir'] for r in C.matrix_rows()]

    def test_01_all_ready(self):
        self.assertEqual(len(self.rows), 10)
        for r in self.rows:
            self.assertEqual(r['Status'],
                             'READY_FOR_RESEARCHER_APPROVAL', r['RepeatID'])

    def test_02_no_placeholders(self):
        for r in self.rows:
            self.assertIn(str(r['PlaceholderPresent']).lower(),
                          ('false', '0', ''), r['RepeatID'])
            for p in repeat_validate.FORBIDDEN_PLACEHOLDERS:
                self.assertNotIn(p, r['FullCommand'])

    def test_03_m01_actual_guest(self):
        r = next(x for x in self.rows if x['ModelID'] == 'M01')
        self.assertEqual(r['ExecutedGuestBinarySHA256'],
                         '4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09'
                         'dda9104ee6508c98')
        self.assertEqual(r['DiskCopySHA256'],
                         'bb872707d6bae3885688556908536d4f92e07da68aae0401'
                         'd27ff03216425759')

    def test_04_m05_decoy(self):
        r = next(x for x in self.rows if x['ModelID'] == 'M05')
        self.assertIn('--mmu_m05_decoy_va 0x4010200000', r['FullCommand'])
        self.assertIn('--mmu_m05_decoy_table_base 0', r['FullCommand'])
        self.assertTrue(r['M05DecoyExplicitOK'])

    def test_05_m07_exact_va(self):
        rows = list(csv.DictReader(open(
            FINAL / 'repeatability' / 'M07_Target_VA_Audit.csv')))
        d = {r['SampleRunID'].split('-')[-1]: r['TargetVA'] for r in rows}
        self.assertEqual(d['R04'], '0x400d400100')
        self.assertEqual(d['R05'], '0x400d600180')

    def test_06_negative_missing_decoy(self):
        r = dict(next(x for x in self.rows if x['ModelID'] == 'M05'))
        r['FullCommand'] = r['FullCommand'].replace(
            '--mmu_m05_decoy_va 0x4010200000', '')
        self.assertIn('m05_decoy_va_missing',
                      repeat_validate.validate_row(r, self.formal,
                                                   set()))

    def test_07_negative_wrong_w9(self):
        r = dict(next(x for x in self.rows if x['ModelID'] == 'M01'))
        r['ExecutedGuestBinarySHA256'] = 'ec525687'
        self.assertIn('m01_executed_guest_wrong',
                      repeat_validate.validate_row(r, self.formal, set()))

    def test_08_negative_placeholder(self):
        r = dict(next(x for x in self.rows))
        r['FullCommand'] += ' <REPEAT_OUTDIR>'
        self.assertTrue(any('placeholder' in x for x in
                            repeat_validate.validate_row(r, self.formal,
                                                         set())))

    def test_09_negative_collision(self):
        r = dict(next(x for x in self.rows))
        r['Outdir'] = self.formal[0] + '/outdir'
        self.assertIn('outdir_collides_with_formal',
                      repeat_validate.validate_row(r, self.formal, set()))

    def test_10_disk_independence(self):
        rows = list(csv.DictReader(open(
            FINAL / 'repeatability' / 'Disk_Copy_Manifest.csv')))
        inodes = set()
        for r in rows:
            self.assertTrue(r['IndependentInode'] == 'True')
            inodes.add(os.stat(r['Path']).st_ino)
        self.assertEqual(len(inodes), len(rows))


class TestObservabilityAndExcel(unittest.TestCase):
    def test_01_unknown_marked(self):
        rows = list(csv.DictReader(open(
            FINAL / 'leakage' / 'MMU_Feature_Observability_Matrix.csv')))
        cats = {r['ObservabilityClass'] for r in rows}
        self.assertIn('UNKNOWN', cats)
        self.assertIn('SIMULATOR_INSTRUMENTATION_ONLY', cats)
        self.assertIn('PRODUCTION_OBSERVABLE', cats)

    def test_02_no_classifier_claim(self):
        text = (FINAL / 'discriminability' /
                'MMU_Model_Discriminability_Report.md').read_text()
        self.assertIn('no accuracy is claimed', text)
        self.assertIn('not separable', text.lower())

    def test_03_excel_sheets(self):
        import openpyxl
        wb = openpyxl.load_workbook(
            FINAL / 'excel' / 'MMU_FINAL_Research_Feature_Library.xlsx',
            read_only=True)
        expected = {'Readme', 'Ground_Truth', 'Original_40_Results',
                    'Simulator_Features', 'Blinded_Observations',
                    'Consumption_Evidence', 'Manifestation_Types',
                    'Model_Signatures', 'Cross_Model_Discriminability',
                    'Observability_Classification', 'Repeatability_Samples',
                    'Repeatability_Parity', 'Research_Limitations',
                    'Provenance', 'Change_Log'}
        self.assertTrue(expected.issubset(set(wb.sheetnames)))

    def test_04_no_gem5_running(self):
        proc = subprocess.run(['pgrep', '-x', 'gem5.opt'],
                              capture_output=True, text=True)
        self.assertEqual(proc.stdout.strip(), '')


if __name__ == '__main__':
    unittest.main(verbosity=2)
