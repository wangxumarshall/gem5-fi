#!/usr/bin/env python3
"""Run the closure test suite and persist the log + result summary."""
import io
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
loader = unittest.TestLoader()
suite = loader.discover(str(HERE), pattern='test_*.py')
buf = io.StringIO()
runner = unittest.TextTestRunner(stream=buf, verbosity=2)
result = runner.run(suite)
log = buf.getvalue()
print(log)
(HERE / 'TEST_LOG.txt').write_text(log)
summary = {
    'tests_run': result.testsRun,
    'failures': len(result.failures),
    'errors': len(result.errors),
    'skipped': len(result.skipped),
    'success': result.wasSuccessful(),
    'log': str(HERE / 'TEST_LOG.txt'),
}
(HERE / 'TEST_RESULTS.json').write_text(
    json.dumps(summary, indent=2) + '\n')
sys.exit(0 if result.wasSuccessful() else 1)
