# Change Log / Modification Record

All changes are new Python/data artifacts under `post_campaign_closure/final_closure/`. No frozen C++, binary, workload, trace, manifest, verdict or original result was modified.

- Created three separated views: Ground Truth, Simulator-Assisted, Blinded.
- Replaced GT-derived `UpstreamPathClass_SIM` with event-derived `ObservedPathClass` in the blind view.
- Separated FaultInjected / FaultActivated / FaultStateConsumed / DownstreamArchitecturalConsumption; 40/40 consumption evidence with 5 literal explicit events.
- Prepared 10 fully expanded, hash-pinned repeat commands with independent sparse disk copies and rcS copies.
- Versioned M03/M06/M07 terminal semantic corrections.
- Added leakage, consumption, repeatability and data-integrity tests.

## Git state

```
(no changes under the campaign path)
```

## File list

See `reports/Changed_Files.csv`.
