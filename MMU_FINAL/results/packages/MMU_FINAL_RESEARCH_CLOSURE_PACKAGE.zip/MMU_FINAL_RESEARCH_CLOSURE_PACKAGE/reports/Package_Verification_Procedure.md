# Package Verification

1. `sha256sum -c SHA256_MANIFEST.txt` inside the package.
2. `sha256sum -c MMU_FINAL_RESEARCH_CLOSURE_PACKAGE.zip.sha256` next to the ZIP.
3. `unzip -t MMU_FINAL_RESEARCH_CLOSURE_PACKAGE.zip`.

The final ZIP hash is recorded externally because a file cannot contain its own hash.
