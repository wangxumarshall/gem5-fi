# Original 40-Sample Integrity Audit

| Check | Result |
|---|---|
| FORMAL_DATA_INTEGRITY | `PASS` |
| samples | `40` |
| sample_id_set_matches_matrix | `True` |
| trace_unchanged | `40/40` |
| manifest_unchanged | `40/40` |
| verdict_unchanged | `40/40` |
| terminal_distribution | `{'SDC': 31, 'SQUASHED': 4, 'DETECTED_CONTAINED': 5}` |
| frozen_binary_sha256 | `b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185` |
| binary_matches_frozen | `True` |
| source_files_match | `True` |
| source_closure_commit_exists | `True` |
| original_results_zip_sha256 | `caeaf6506495ed119a06a12075f5193276e2e1279286ddc56610016f39caa151` |
| original_results_zip_unchanged | `True` |

No frozen file was modified. Each trace, manifest and verdict hash was recomputed from the server files.
