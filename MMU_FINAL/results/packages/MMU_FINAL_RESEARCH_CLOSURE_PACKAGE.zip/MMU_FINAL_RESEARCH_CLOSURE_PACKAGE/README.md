# MMU FINAL RESEARCH CLOSURE PACKAGE

Campaign: `MMU-FORMAL-20261113`

```text
FORMAL_DATA_INTEGRITY              = PASS
DIAGNOSTIC_FEATURE_INTEGRITY       = PASS
REPEATABILITY_EXECUTION_READINESS  = PASS
INDEPENDENT_ACCEPTANCE             = PASS
MMU_FINAL_RESEARCH_CLOSURE         = PASS_WITH_DOCUMENTED_RESEARCH_LIMITATIONS
MMU_DIAGNOSTIC_FEATURE_GATE        = PASS
MMU_REPEATABILITY_LAUNCH_GATE      = READY_FOR_RESEARCHER_APPROVAL
```

No gem5 experiment was started. No frozen C++ hook, binary, workload,
SampleRunID, trace, manifest, verdict or original result was modified.
The 10 repeatability runs are prepared for researcher approval only.

## Contents

| Path | Content |
|---|---|
| `reports/Final_Research_Closure_Report.md` | final closure report |
| `reports/Original_40_Sample_Integrity_Audit.{md,json,csv}` | original data audit |
| `views/MMU_Ground_Truth.{csv,json}` | Ground Truth view |
| `views/MMU_Simulator_Assisted_Features.{csv,json}` | simulator-assisted view |
| `views/MMU_Blinded_Diagnostic_Features.{csv,json}` | blinded diagnostic view |
| `leakage/MMU_Feature_Leakage_Audit.{csv,json}` | field-level leakage audit |
| `leakage/MMU_Feature_Observability_Matrix.{csv,json}` | observability tiers |
| `consumption/MMU_Fault_Consumption_Semantics_Report.md` | consumption semantics |
| `consumption/MMU_40_Sample_Consumption_Evidence.{csv,json}` | 40-sample evidence |
| `discriminability/MMU_Model_Discriminability_Report.md` | model-ID-free analysis |
| `terminal_semantics/MMU_Terminal_Semantic_Classification_Report.md` | terminal labels |
| `repeatability/MMU_10_Sample_Repeatability_Matrix.{csv,xlsx}` | 10-sample matrix |
| `repeatability/Repeatability_Parameter_Parity.csv` | 10-sample parity |
| `repeatability/describe/` | 10 read-only describe JSON + MD |
| `repeatability/parity/` | 10 per-repeat parity reports |
| `repeatability/launch/` | isolated command.sh, rcS copy, launch manifest per repeat |
| `repeatability/Disk_Copy_Manifest.csv` | independent disk copies (excluded from ZIP) |
| `repeatability/Repeatability_Output_Isolation_Audit.md` | isolation audit |
| `evidence/trace_samples/` | 7 original trace copies + verified slices |
| `excel/MMU_FINAL_Research_Feature_Library.xlsx` | authoritative workbook |
| `scripts/` | feature/consumption/repeatability generators |
| `tests/` | automated tests, logs and independent acceptance |
| `provenance/Provenance.md` | binary/source/workload/disk provenance |
| `reports/Change_Log.md`, `reports/Changed_Files.csv` | change record |
| `SHA256_MANIFEST.txt` | every file hash |

Disk images under `repeatability/launch/*/disk.img` (~1.5 GiB each) exist on
the server and are intentionally excluded from the ZIP; their absolute paths,
sizes and SHA256 are in `Disk_Copy_Manifest.csv`.

## Stop condition

Await researcher approval before executing any of the 10 repeats.
