# Repeatability Launch Assets

Status: `READY_FOR_RESEARCHER_APPROVAL`. No gem5 run was started.

## Fully expanded commands

### REP-FINAL-MMU-M01-R01-01 (repeat of M01-F0-W9-S01-R01)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M01-R01-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M01-R01-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M01-R01-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4000000000 --prop_mmu_va_hi 0x4000100000 --prop_run_id REP-FINAL-MMU-M01-R01-01 --prop_sample_run_id REP-FINAL-MMU-M01-R01-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M01 --mmu_fault_enable true --mmu_m01_va 0x4000000000 --mmu_m01_asid 220 --mmu_m01_vmid 0 --mmu_m01_regime 0 --mmu_m01_security_state 0 --mmu_m01_n 12
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M01-R01-01/rcS.scoped` (`cb2df4cb47147fd7958a2f2f03e2459dd8f3f5c594cfdb0f99a854d2081ddf60`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M01-R01-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98`; canonical field: `ec525687a757fd0f3865294481c687e754c06dc6a073dd2aa80306b04621732b`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M02-R02-01 (repeat of M02-F0-W10-S01-R02)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M02-R02-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M02-R02-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M02-R02-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4001000000 --prop_mmu_va_hi 0x4001500000 --prop_run_id REP-FINAL-MMU-M02-R02-01 --prop_sample_run_id REP-FINAL-MMU-M02-R02-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M02 --mmu_fault_enable true --mmu_m02_va 0x4001100000 --mmu_m02_old_pfn 0x834b2 --mmu_m02_xor_mask 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M02-R02-01/rcS.scoped` (`fd36b4a21b3b2130e5210e9769162d7cf09811d6888076b1849a7afba355cb09`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M02-R02-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae`; canonical field: `733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M03-R01-01 (repeat of M03-F0-W11-S01-R01)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R01-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R01-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R01-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4004000000 --prop_mmu_va_hi 0x4007000000 --prop_run_id REP-FINAL-MMU-M03-R01-01 --prop_sample_run_id REP-FINAL-MMU-M03-R01-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M03 --mmu_fault_enable true --mmu_target_va 0x4004000000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Read --mmu_m03_candidate_asid -1
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R01-01/rcS.scoped` (`89122633ce009de0977b6f25cc31511a10b2b6a58a9251bcd902fc4f8696dff2`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R01-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4`; canonical field: `1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M03-R05-01 (repeat of M03-F0-W11-S01-R05)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R05-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R05-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R05-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4004000000 --prop_mmu_va_hi 0x4007000000 --prop_run_id REP-FINAL-MMU-M03-R05-01 --prop_sample_run_id REP-FINAL-MMU-M03-R05-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M03 --mmu_fault_enable true --mmu_target_va 0x4005000000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Execute --mmu_m03_candidate_asid -1
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R05-01/rcS.scoped` (`4fb5bb1cca11e765b1b405398cf71c21245ceb97fe316eb63b95f09725630355`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M03-R05-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4`; canonical field: `1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M04-R05-01 (repeat of M04-F0-W12-S01-R05)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M04-R05-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M04-R05-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M04-R05-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4008000000 --prop_mmu_va_hi 0x400b000000 --prop_run_id REP-FINAL-MMU-M04-R05-01 --prop_sample_run_id REP-FINAL-MMU-M04-R05-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M04 --mmu_fault_enable true --mmu_target_va 0x4008000000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Execute --mmu_target_instance itb --mmu_m04_decoy_pfn 0x8353c
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M04-R05-01/rcS.scoped` (`49d45147ae1a8a3634f6ecd8be20c4da9f14001257dedbdc4c6460ab3115b622`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M04-R05-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `8fa269fd88eaf9126f67cf80d5d77f13600e211948db5cd7f4b89f42c147fdbc`; canonical field: `8fa269fd88eaf9126f67cf80d5d77f13600e211948db5cd7f4b89f42c147fdbc`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M05-R05-01 (repeat of M05-F0-W13-S01-R05)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M05-R05-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M05-R05-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M05-R05-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4010000000 --prop_mmu_va_hi 0x4010400000 --prop_run_id REP-FINAL-MMU-M05-R05-01 --prop_sample_run_id REP-FINAL-MMU-M05-R05-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M05 --mmu_fault_enable true --mmu_target_va 0x4010000000 --mmu_target_n 21 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Execute --mmu_target_instance l2_shared --mmu_target_walk_level 2 --mmu_fault_persistence entry_lifetime --mmu_m05_decoy_table_base 0 --mmu_m05_decoy_va 0x4010200000
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M05-R05-01/rcS.scoped` (`8e4b4fa0656340793787acd6cebfda41d40c748b7d9e86b8bf54af43a2f44bf8`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M05-R05-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `6e7d926e863c15433b3887e3ac069169e510751190d4b0de5dae0e7aa886ec70`; canonical field: `6e7d926e863c15433b3887e3ac069169e510751190d4b0de5dae0e7aa886ec70`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M06-R02-01 (repeat of M06-F0-W10-S01-R02)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M06-R02-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M06-R02-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M06-R02-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4001100000 --prop_mmu_va_hi 0x4001700000 --prop_run_id REP-FINAL-MMU-M06-R02-01 --prop_sample_run_id REP-FINAL-MMU-M06-R02-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M06 --mmu_fault_enable true --mmu_target_va 0x4001100000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Write --mmu_target_walk_level 3
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M06-R02-01/rcS.scoped` (`c3b949057eef196b63b53a58c89ae533b1c27028c7a82f82ee293255ad47359e`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M06-R02-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `fede5f3ea4c3224f34ef9768a8cbb0fe49b071cab86306e67e7a73610f11b0a3`; canonical field: `fede5f3ea4c3224f34ef9768a8cbb0fe49b071cab86306e67e7a73610f11b0a3`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M07-R01-01 (repeat of M07-F0-W14-S01-R01)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R01-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R01-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R01-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x400c000000 --prop_mmu_va_hi 0x400e000000 --prop_run_id REP-FINAL-MMU-M07-R01-01 --prop_sample_run_id REP-FINAL-MMU-M07-R01-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M07 --mmu_fault_enable true --mmu_target_va 0x400d000000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Write --mmu_fault_persistence one_shot
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R01-01/rcS.scoped` (`8d1a401bfef1fd5ccebbf0ac4ad75361e76d2d6978fcc16a778e9d7febaa5d98`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R01-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36`; canonical field: `f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M07-R05-01 (repeat of M07-F0-W14-S01-R05)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R05-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R05-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R05-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x400c000000 --prop_mmu_va_hi 0x400e000000 --prop_run_id REP-FINAL-MMU-M07-R05-01 --prop_sample_run_id REP-FINAL-MMU-M07-R05-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M07 --mmu_fault_enable true --mmu_target_va 0x400d600180 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Execute --mmu_fault_persistence one_shot
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R05-01/rcS.scoped` (`c317505d95c161a6ac4dd045d8dbcfcd0b34bad7bab8bbced1614be85566eb48`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M07-R05-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36`; canonical field: `f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

### REP-FINAL-MMU-M08-R01-01 (repeat of M08-F0-W10-S01-R01)

```bash
/home/sdc/gem5-fi-mmu-impl-v2/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M08-R01-01/outdir /home/sdc/gem5-fi-mmu-impl-v2/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M08-R01-01/disk.img --bootloader /home/sdc/gem5-fi-mmu-impl-v2/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-impl-v2/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M08-R01-01/rcS.scoped --chaos_propagation --prop_mmu_va_lo 0x4001000000 --prop_mmu_va_hi 0x4001500000 --prop_run_id REP-FINAL-MMU-M08-R01-01 --prop_sample_run_id REP-FINAL-MMU-M08-R01-01 --prop_mmu_trace --prop_write_log on --mmu_fault_model M08 --mmu_fault_enable true --mmu_target_va 0x4001000000 --mmu_target_n 12 --mmu_eligible_event_index 1 --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_mode Read --mmu_m08_pa_xor_mask 0x1000
```

- rcS copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M08-R01-01/rcS.scoped` (`573243f11c2815a0a7c0b7ca0e4a98c29126ce4097996f2b18cbff05113e3712`)
- Disk copy: `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/final_closure/repeatability/launch/REP-FINAL-MMU-M08-R01-01/disk.img` (`bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff03216425759`, 2361393152 bytes)
- Executed guest: `733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae`; canonical field: `733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae`
- Status: **READY_FOR_RESEARCHER_APPROVAL**

## M07 exact target VATs

| M07-F0-W14-S01-R03 | Read | `0x400d200000` | `0x400d200000` |
| M07-F0-W14-S01-R04 | Execute | `0x400d400100` | `0x400d400000` |
| M07-F0-W14-S01-R05 | Execute | `0x400d600180` | `0x400d600000` |

## Safety

- No placeholders remain in any command.
- No RepeatID equals a formal SampleRunID.
- No output path collides with a formal/pilot/failed path.
- Each disk copy is a separate inode and hash-pinned; disk copies are excluded from the ZIP.
- No seed flag is present; SeedPolicy remains deterministic.
- `bash -n` passes for every command; gem5 is not executed.
