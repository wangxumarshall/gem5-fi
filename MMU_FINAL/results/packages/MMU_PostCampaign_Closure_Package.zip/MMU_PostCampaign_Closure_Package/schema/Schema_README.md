# ARM CPU-SDC Propagation Schema v1

File: `ARM_CPU_SDC_Propagation_Schema_v1.json` (JSON Schema draft 2020-12).

## Design

- Two record types share one field dictionary: `PropagationEvent` (one observed node) and `SampleRecord` (identity + terminal + an `events` array). The root uses `anyOf` because the two intentionally overlap; validate a known record type against `$defs/SampleRecord` or `$defs/PropagationEvent` directly.
- The 27 cross-unit fields requested for MMU/LSU unification are in both definitions.
- `additionalProperties: true` is deliberate: MMU-only fields (ASID, VMID, TLB entry/generation, PTW/PTE, permission, candidate/decoy, request-PA) and LSU-only fields (LQ/SQ, cache line/set/way, MSHR, arch/phys reg, replay) are retained, never dropped to force uniformity.
- Hex values are carried as strings to preserve width and leading zeros; numeric values are allowed where unambiguous.
- `TerminalState` keeps the frozen vocabulary; `ManifestationType` is a separate diagnostic dimension.

## MMU mapping

See `MMU_to_Unified_Schema_Mapping.csv`: 27 unified fields mapped to manifest/verdict/trace sources plus 46 MMU-only extension fields.

## LSU mapping

See `LSU_to_Unified_Schema_Mapping.csv`: the shared registry in `CHAOSPropagation.hh` already provides the 27-field core for LSU plus 17 LSU-only extension fields. `TranslationID` is the explicit cross-unit link from LSU requests to MMU translations.
## Validation

`validate_schema.py` validates the schema itself and checks a representative MMU feature record against `PropagationEvent`.
