# MMU Post-Campaign Closure Package

Campaign: `MMU-FORMAL-20261113`
Source status: `FORMAL_CAMPAIGN_COMPLETE_WITH_LIMITATIONS`
Closure status: `POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`

No gem5 experiment was started, no C++ hook, frozen binary, workload,
SampleRunID, trace, control or original result was modified.

## Contents

| Path | Deliverable |
|---|---|
| `audit/MMU_40_Sample_Final_Audit.{csv,json,md}` | 40-sample final audit |
| `audit/MMU_40_Sample_Final_Result_Matrix.{csv,xlsx}` | recomputed 40-sample result matrix |
| `audit/Workload_SHA256_Consistency_Report.md` | W9/W10/W10S hash analysis |
| `audit/Workload_Hash_Identity.csv` / `Workload_Sample_Identity_Chain.csv` | hash-to-file mapping |
| `audit/Control_Sharing_Audit.md` / `Control_Map.csv` / `Control_Sharing_Summary.csv` | 28-control sharing + zero-injection audit |
| `audit/Attempt_History.csv` / `Attempt_Audit.md` | A01/A02 history |
| `audit/M07_Terminal_Semantics_Audit.md` / `M07_Sample_Evidence.csv` | M07 semantics |
| `audit/SDC_Semantic_Audit.csv` | 31-SDC semantic audit |
| `feature_library/MMU_Diagnostic_Feature_Library.{xlsx,csv,json}` | diagnostic feature library |
| `feature_library/Model_Propagation_Signatures.md` | model-level signatures + discriminators |
| `feature_library/propagation_chains/<sid>.{json,csv}` | event-level propagation chains |
| `feature_library/Propagation_Chain_Events.csv` | all chain events combined |
| `real_case/RealCase_Mapping.{csv,md,json}` | real ARM DTLB case mapping |
| `repeatability/MMU_Repeatability_Validation_Plan.{xlsx,md}` | repeat design (not executed) |
| `schema/ARM_CPU_SDC_Propagation_Schema_v1.json` | unified MMU/LSU schema |
| `schema/MMU_to_Unified_Schema_Mapping.csv` / `LSU_to_Unified_Schema_Mapping.csv` | mappings |
| `schema/SCHEMA_VALIDATION.json` | schema validation evidence |
| `evidence/Trace_Index.csv` | absolute trace path, size, SHA256 |
| `evidence/Provenance_Binary_Source_Workload.{json,md}` | binary/source/workload provenance |
| `evidence/SHA256_MANIFEST.txt` | hash of every package file |
| `scripts/` | all generators (read-only over the frozen campaign) |
| `ACCEPTANCE_ANSWERS.md` | answers to the 12 acceptance questions |
| `FINAL_STATUS.md` | final status + limitations |

## Regeneration

Run in this order from this directory:

```
python3 scripts/scan_traces.py
python3 scripts/audit_samples.py
python3 scripts/audit_workload_hash.py
python3 scripts/audit_controls.py
python3 scripts/audit_attempts.py
python3 scripts/audit_m07.py
python3 scripts/build_features.py
python3 scripts/build_realcase_repeat.py
python3 scripts/build_schema.py
python3 scripts/validate_schema.py
python3 scripts/build_package.py
```

The scripts only read `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113`
and its frozen siblings, and write under `post_campaign_closure/` (plus the
final ZIP at the campaign root).
