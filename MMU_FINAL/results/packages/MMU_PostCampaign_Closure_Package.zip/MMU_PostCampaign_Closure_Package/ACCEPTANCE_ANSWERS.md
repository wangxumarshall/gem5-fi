# Acceptance Answers

## 1. Are all 40 formal samples retained?

Yes. 40 unique SampleRunIDs, 5 contexts for each of M01-M08, zero missing. The A02 retries are the adopted records for M06-R04 and M08-R04; the interrupted A01 directories are preserved. See `audit/MMU_40_Sample_Final_Audit.csv` and `audit/Attempt_History.csv`.

## 2. Were the 31 SDC terminal classifications semantically audited?

Yes. 31/31 are `CONFIRMED_SDC` by a software-visible oracle difference (wrong value or permission bypass), a control difference, complete trace and `wrong_value_proven`. Primary manifestations: {"UNAUTHORIZED_EXECUTION": 2, "UNAUTHORIZED_READ": 1, "UNAUTHORIZED_WRITE": 2, "WRONG_CODE_PAGE_EXECUTION": 3, "WRONG_DATA_VALUE": 23}. Original TerminalState values were not overwritten. See `audit/SDC_Semantic_Audit.csv`.

## 3. Does M07 distinguish data corruption from permission bypass?

Yes. R01/R02 = UNAUTHORIZED_WRITE (+ permission bypass, + shared-memory mutation), R03 = UNAUTHORIZED_READ, R04/R05 = UNAUTHORIZED_EXECUTION. There is no WRONG_DATA_VALUE in M07: `value_ok=1` and observed == expected in all five. The control gets SIGSEGV + permission fault; the faulted run has no exception. R02 has no permission_eval joined to its activation (`translation_id=7`); the nearest same-VA deny is event 345 on `translation_id=5`, reported explicitly rather than hidden. See `audit/M07_Terminal_Semantics_Audit.md`.

## 4. Is the basis for the 28 shared controls explicit?

Yes. 40 fault references -> 28 distinct oracle files; 34 control run directories exist, 6 are duplicate/superseded and unreferenced. All 40 references pass oracle-hash, workload, context and zero-injection checks. The frozen approval evidence is `/home/sdc/gem5-fi-mmu-impl-v2/phase3/final/MMU_Final_Formal_Readiness_Package_v3.0.1/MMU_Control_Inventory_Reconciliation.md` (`CONTROL_INVENTORY_VERDICT = RECONCILED`). See `audit/Control_Sharing_Audit.md`.

## 5. Are the W9/W10/W10S hash differences explained?

Yes. W9 matrix `ec525687...` is the `mmu_rev` build; the executed guest is the live build `4f3ddbf2...`. The two `.c` sources differ (the rev adds `consumer_result`); the disk image contains the live format string and not the rev one; the guest output has no `consumer_result`. W10S `fede5f3e...` is the executed payload and matches the matrix; W10S-COLD-STORE / W10S-WARM-STORE are documented internal variants while the authoritative WorkloadID stays W10. See `audit/Workload_SHA256_Consistency_Report.md`.

## 6. Are both interrupted attempts fully preserved?

Yes. `attempt_A01/M06-F0-W10-S01-R04` and `attempt_A01/M08-F0-W10-S01-R04` are intact partial directories (no manifest/verdict/SHA256SUMS, truncated traces with 308 and 174 events, 0-byte stats). A02 is the completed adopted attempt in both cases. Verified counts: 40 unique samples, 40 completed final attempts, 2 interrupted attempts, 42 attempt directories. See `audit/Attempt_Audit.md`.

## 7. Are the 40 propagation chains traceable to the raw traces?

Yes. Every chain EventID was re-read from the raw `prop_evt.txt.gz`; 0/40 samples have a join mismatch. The evidence index records absolute path, size and SHA256 for every trace and supporting file. See `evidence/Trace_Index.csv`.

## 8. Does every model have a diagnostic signature?

Yes. The feature library has per-sample origin, activation, state-transition, translation, propagation and terminal features plus a context-independent StableModelSignature. Stable-signature counts: {"M01": 1, "M02": 1, "M03": 2, "M04": 2, "M05": 2, "M06": 1, "M07": 3, "M08": 1}. See `feature_library/Model_Propagation_Signatures.md`.

## 9. Which features distinguish the models?

The discriminators are fault site + activation kind + the state-transition fields, not the shared downstream event kinds: M01 `tlbi_match`+`tlbi_suppressed`; M02 `refill_pfn_corrupt`; M03 foreign `candidate_asid`+`false_hit`; M04 resident `tlb_entry_lineage` with no PTW; M05 `partial_entry_insert`+`next_table_pa_before/after`; M06 `fault_state_consumed`+`fault_result_propagated`+`exception_delivery`; M07 `permission_before=false`->`permission_after=true`; M08 `request_pa_before/after` with PFN unchanged. Confusable pairs and separators are in `feature_library/Model_Propagation_Signatures.md`.

## 10. Is the M01 vs real DTLB stale-translation boundary clear?

Yes. Functional semantics = HIGH, propagation path = HIGH, diagnostic feature match = MEDIUM_TO_HIGH, but microarchitectural structure = LOW_TO_MEDIUM: gem5 M01 targets the `l2_shared` (unified L2) TLB, not the DTB. The mapping explicitly does not claim L2/unified == DTLB. No external erratum/CVE citation exists in the repository. See `real_case/RealCase_Mapping.md`.

## 11. Is the repeatability matrix designed?

Yes: 10 independent repeats covering M01-R01, M02-R02, M03-R01/R05, M04-R05, M05-R05, M06-R02, M07-R01/R05, M08-R01, each checked against the actual trace before selection. The plan is design-only; no new gem5 run was started. See `repeatability/MMU_Repeatability_Validation_Plan.md`.

## 12. Can LSU and MMU map to the unified schema?

Yes. 27 common fields, 63 retained MMU extension fields and 19 LSU extension fields; `TranslationID` is the cross-unit link. Schema meta-validation and representative MMU/LSU records all PASS. See `schema/ARM_CPU_SDC_Propagation_Schema_v1.json` and `schema/SCHEMA_VALIDATION.json`.

## Final state

`POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`
