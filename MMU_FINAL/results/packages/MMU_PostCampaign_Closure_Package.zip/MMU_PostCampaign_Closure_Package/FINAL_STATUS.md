# Final Status

`POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`

## Closed

- 40/40 samples retained, 40/40 activated, 40/40 consumed, 40/40 trace
  COMPLETE, 40/40 record integrity PASS.
- 31 SDC, 4 SQUASHED, 5 DETECTED_CONTAINED confirmed from raw evidence.
- 28/28 controls zero-proven; 40/40 control references pass hash/workload/
  context checks; sharing approval documented.
- 40/40 propagation chains verified against raw traces with zero join
  mismatches.
- Diagnostic feature library, model signatures, discriminators and confusable
  pairs built.
- Real-case mapping, 10-repeat design and unified MMU/LSU schema delivered.

## Documented limitations (do not alter the counts)

1. **W9 `WorkloadSHA256` semantics**: the matrix records the canonical
   `mmu_rev` build `ec525687...`, while the executed guest is the live build
   `4f3ddbf2...`. The two sources differ. This is a provenance-field
   limitation, not an M01 result change. The field is split into
   WorkloadSourceSHA256 / WorkloadBinarySHA256 / RuntimeScriptSHA256 /
   WorkloadVariant.
2. **Real case**: researcher-supplied; no external erratum/CVE/trace
   citation exists. Functional/propagation match is high, but the gem5 target
   is `l2_shared`, not the DTB.
3. **M07 R02**: no `permission_eval` is joined to the activation
   (`translation_id=7`). The nearest same-VA deny is event 345 on
   `translation_id=5` (tick delta -2331), which the frozen validator does not
   associate. The deny is proven by
   `mmu_fault_activate(permission_before=false)` and the control SIGSEGV
   permission fault.
4. **M07 R04/R05**: fetch activation carries `translation_id=0`; downstream
   consumption is joined co-temporally by the frozen strict chain, never by
   event order.
5. **M04 trace tagging**: nearly all post-arm events carry `fault_id=1`.
   Feature extraction anchors on the activation translation/VA and the frozen
   chain; non-chain selection is capped at 5000 events (R01-R04). Chain joins
   remain 0-mismatch.
6. **IFU nodes**: per the campaign report, some per-instruction IFU
   fetch/decode nodes are not emitted by the frozen binary; they are listed
   as `NodesNotEmittedByFrozenBinary`, not fabricated.
7. **A01 retries**: the interrupted A01 directories are preserved but are not
   independent repeats and contain truncated traces.
8. **ManifestationType** is a diagnostic dimension added by this audit; the
   original `TerminalState` remains authoritative and unchanged.

## Stop condition

No new gem5 experiment was started. Repeatability runs require researcher
approval.
