#!/usr/bin/env python3
"""Task 2 - MMU Diagnostic Feature Library.

Builds per-sample origin / activation / state-transition / propagation /
terminal features and a canonical diagnostic signature from the raw traces
(via the verified chain events) plus the manifest/verdict/authority records.
Every state transition keeps its real EventID. Read-only over the campaign.
"""
import json
import sys
from collections import Counter, OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C
import audit_m07

SOURCE_SITE = {
    'M01': ('CHAOS/gem5/src/arch/arm/tlb.cc',
            'TLB::flush / TLBI suppression (tlb.cc:1295-1342)',
            'TLB invalidation comparator'),
    'M02': ('CHAOS/gem5/src/arch/arm/table_walker.cc',
            'insertTableEntry refill PFN XOR (table_walker.cc:3237-3267)',
            'completed leaf PFN'),
    'M03': ('CHAOS/gem5/src/arch/arm/tlb.cc',
            'lookup miss -> foreign-ASID candidate (tlb.cc:328-437)',
            'ASID comparator / tag match'),
    'M04': ('CHAOS/gem5/src/arch/arm/tlb.cc',
            'resident entry PFN substitution (function-level site)',
            'resident TLB entry PFN'),
    'M05': ('CHAOS/gem5/src/arch/arm/table_walker.cc',
            'insertPartialTableEntry next-table pointer (function-level site)',
            'partial walk-cache next-table base'),
    'M06': ('CHAOS/gem5/src/arch/arm/table_walker.cc',
            'doLongDescriptor bit0 clear (table_walker.cc:2140-2191)',
            'L3 leaf descriptor bits[1:0]'),
    'M07': ('CHAOS/gem5/src/arch/arm/mmu.cc',
            'checkPermissions64 deny -> grant (mmu.cc:735-791)',
            'permission grant decision'),
    'M08': ('CHAOS/gem5/src/arch/arm/mmu.cc',
            'translateMmuOn setPaddr XOR (function-level site)',
            'final Request physical address'),
}

MODEL_SIGNATURE_NAME = {
    'M01': 'Stale Translation Signature',
    'M02': 'PTW Refill PFN Corruption Signature',
    'M03': 'Foreign-ASID False Match Signature',
    'M04': 'Resident Entry PFN Substitution Signature',
    'M05': 'Partial Walk-Cache Pointer Substitution Signature',
    'M06': 'Invalid Leaf Descriptor Detection Signature',
    'M07': 'Permission Grant Inversion Signature',
    'M08': 'Final PA Materialization Corruption Signature',
}

STATE_KEYS = [
    'field', 'before', 'after', 'state_before', 'state_after',
    'entry_valid', 'entry_partial', 'entry_generation_after',
    'permission_result', 'permission_before', 'permission_after',
    'memory_attribute', 'fault_status', 'old_pfn', 'new_pfn', 'old_pa',
    'new_pa', 'pte_address', 'pte_value_before', 'pte_value_after',
    'descriptor_before', 'descriptor_after', 'descriptor_type',
    'request_pa_before', 'request_pa_after', 'candidate_asid',
    'candidate_entry_id', 'candidate_generation', 'candidate_pfn',
    'candidate_pa', 'candidate_valid', 'candidate_partial',
    'lookup_outcome', 'decoy_pfn', 'decoy_va', 'next_table_pa_before',
    'next_table_pa_after', 'commit_status', 'squash_status', 'outcome',
    'contained', 'regime', 'security_state', 'is_write', 'is_fetch',
    'pte_memory_written', 'state_consumed', 'result_propagated',
    'exception_delivered', 'fault_site', 'fault_field', 'fault_reason',
    'fault_persistence', 'tlb_instance', 'walk_level', 'asid', 'vmid',
]


def ev_map(scan):
    return {e.get('event_id'): e for e in scan['SelectedEvents']}


def merged(e, raw_map):
    """Chain event + raw trace fields (raw wins for shared keys)."""
    x = dict(e.get('ExtraFields') or {})
    raw = raw_map.get(str(e.get('EventID')), {})
    x.update(raw)
    return x


def first_kind(events, kinds):
    for e in events:
        if e.get('Kind') in kinds:
            return e
    return None


def state_delta(actx):
    keys = STATE_KEYS
    return {k: actx.get(k, '') for k in keys if actx.get(k, '') != ''}


def build_sample(sid, matrix, authority, diag_map):
    man = C.manifest(sid)
    ver = C.verdict(sid)
    ch = C.chain(sid)
    scan = C.scan_cache(sid)
    raw = ev_map(scan)
    model = man['model']
    act_id = int(ver['activation_event_id'])
    chain_events = ch.get('Events', [])
    act_e = next((e for e in chain_events
                  if int(e['EventID']) == act_id), None)
    actx = merged(act_e, raw) if act_e else dict(
        raw.get(str(act_id), {}))
    kinds = [e['Kind'] for e in chain_events]
    after = [e for e in chain_events if int(e['EventID']) > act_id]
    after_kinds = [e['Kind'] for e in after]
    tr = next((e for e in after if e['Kind'] == 'translation_result'), None)
    trx = merged(tr, raw) if tr else {}
    lsu = next((e for e in after if e['Kind'] == 'lsu_request'), None)
    lsux = merged(lsu, raw) if lsu else {}
    lookup_hits = [e for e in chain_events
                   if e['Kind'] in ('tlb_lookup_hit', 'tlb_lookup_miss')]
    tlbi = [e for e in chain_events if e['Kind'].startswith('tlbi_')]
    up = [e['Kind'] for e in chain_events
          if int(e['EventID']) < act_id][-8:]
    arow = authority.get(sid, {})
    o = C.parse_kv_line((ver['Details'].get('oracle') or {}).get('line', ''))
    primary, secondary, mismatch, permission, basis = audit_m07.classify(
        model, man['context'], man['target_mode'],
        (ver['Details'].get('oracle') or {}).get('line', ''),
        ver['TerminalState'])
    src_file, src_func, target_field_class = SOURCE_SITE[model]
    upstream_tlb = ''
    for e in chain_events:
        if int(e['EventID']) >= act_id:
            break
        x = merged(e, raw)
        if x.get('tlb_instance'):
            upstream_tlb = x['tlb_instance']
    tlb_level = (actx.get('walk_level') or actx.get('tlb_instance') or
                 upstream_tlb or '')
    target_asid = (man.get('target_asid')
                   if man.get('target_asid') is not None
                   else actx.get('asid', ''))
    fault_duration = actx.get('fault_persistence', '')
    if not fault_duration and model == 'M01':
        fault_duration = ('entry_lifetime_until_tlbi_suppression_disarmed'
                          if any(k == 'mmu_fault_disarm' for k in kinds)
                          else 'entry_lifetime')
    lookup_outcome = actx.get('lookup_outcome', '')
    if not lookup_outcome:
        if model == 'M01':
            lookup_outcome = 'stale_l2_hit_after_suppressed_invalidation'
        elif model in ('M02', 'M05', 'M06'):
            lookup_outcome = 'ptw_refill_path'
        elif model == 'M08':
            lookup_outcome = 'completed_translation_then_pa_corruption'
        elif model == 'M07':
            lookup_outcome = 'translation_then_permission_bypass'
        else:
            lookup_outcome = ','.join(up[-2:])
    if 'pages' in o:
        page_size = '4 KiB (pages=%s)' % o.get('pages')
    elif 'page_size' in o:
        page_size = o.get('page_size')
    else:
        page_size = '4 KiB (manifest.target_n=12)'

    origin = {
        'FaultModelID': model,
        'ModelMechanism': C.MODEL_MECHANISM[model],
        'TargetUnit': 'MMU/TLB',
        'TargetSubUnit': arow.get('TargetSubUnit', ''),
        'FaultType': arow.get('FaultType', ''),
        'InjectionMode': arow.get('InjectionMode', 'F0'),
        'InjectionLocation': {
            'SourceFile': src_file,
            'SourceFunction': src_func,
            'TraceFaultSite': actx.get('fault_site', ''),
        },
        'TargetField': actx.get('fault_field') or actx.get('field') or '',
        'TargetFieldClass': target_field_class,
        'TargetVA': '0x%x' % man['target_va'],
        'TargetASID': target_asid,
        'ManifestTargetASID': man.get('target_asid'),
        'ActivationASID': actx.get('asid', ''),
        'TargetVMID': actx.get('vmid', ''),
        'TLBInstance': actx.get('tlb_instance', '') or upstream_tlb,
        'TLBLevel': tlb_level,
        'FaultDuration': fault_duration,
        'FaultReason': actx.get('fault_reason', ''),
    }
    activation = {
        'EligibleEventCondition': arow.get('EligibleEventCondition', ''),
        'ActualEligibleEvent': man.get('target_event', ''),
        'EventOrdinal': man.get('eligible_event_index', ''),
        'ActivationEventID': act_id,
        'ActivationKind': act_e['Kind'] if act_e else '',
        'ActivationTick': actx.get('tick', ''),
        'DynamicInstSeqNum': actx.get('dyn_inst_seq', ''),
        'AccessMode': actx.get('mode') or man.get('target_mode', ''),
        'WalkLevel': actx.get('walk_level') or man.get('walk_level', ''),
        'PageSize': page_size,
        'ASID': actx.get('asid', ''),
        'VMID': actx.get('vmid', ''),
        'Regime': actx.get('regime', ''),
        'SecurityState': actx.get('security_state', ''),
        'TLBLookupOutcome': lookup_outcome,
        'UpstreamNodeKinds': up,
        'FaultStateBefore': state_delta(actx),
        'FaultStateAfter': {k: actx.get(k, '') for k in
                            ('entry_generation_after', 'permission_after',
                             'new_pfn', 'new_pa', 'request_pa_after',
                             'descriptor_after', 'next_table_pa_after')
                            if actx.get(k, '') != ''},
    }
    transitions = []
    for e in chain_events:
        x = merged(e, raw)
        row = {
            'EventID': e['EventID'],
            'ParentEventID': e.get('ParentEventID', ''),
            'Kind': e['Kind'],
            'Tick': e.get('Tick', ''),
            'TranslationID': e.get('TranslationID', ''),
            'LookupID': e.get('LookupID', ''),
            'WalkID': e.get('WalkID', ''),
            'EntryID': e.get('EntryID', ''),
            'EntryGeneration': e.get('EntryGeneration', ''),
            'DynamicInstSeqNum': e.get('DynamicInstSeqNum', ''),
            'VA': e.get('VA', ''),
            'PA': e.get('PA', ''),
            'CommitSeq': e.get('CommitSeq', ''),
            'SquashStatus': e.get('SquashStatus', ''),
            'Field': e.get('Field', ''),
            'Before': e.get('Before', ''),
            'After': e.get('After', ''),
            'StateBefore': e.get('StateBefore', ''),
            'StateAfter': e.get('StateAfter', ''),
            'Outcome': e.get('Outcome', ''),
        }
        for k in ('asid', 'vmid', 'tlb_instance', 'permission_result',
                  'permission_before', 'permission_after',
                  'memory_attribute', 'old_pfn', 'new_pfn', 'old_pa',
                  'new_pa', 'pte_address', 'pte_value_before',
                  'pte_value_after', 'descriptor_before',
                  'descriptor_after', 'request_pa_before',
                  'request_pa_after', 'candidate_asid', 'candidate_entry_id',
                  'candidate_generation', 'candidate_pfn', 'candidate_pa',
                  'lookup_outcome', 'decoy_pfn', 'decoy_va',
                  'next_table_pa_before', 'next_table_pa_after',
                  'fault_site', 'fault_field', 'fault_persistence',
                  'regime', 'security_state', 'fault_status',
                  'pte_memory_written'):
            if x.get(k, '') != '':
                row[k] = x.get(k)
        transitions.append(row)
    old_pfn = actx.get('old_pfn') or actx.get('candidate_pfn') or ''
    new_pfn = actx.get('new_pfn') or ''
    old_pa = actx.get('old_pa') or actx.get('candidate_pa') or ''
    new_pa = actx.get('new_pa') or actx.get('request_pa_after') or ''
    if model == 'M01':
        hit = next((e for e in chain_events
                    if e['Kind'] == 'tlb_lookup_hit'), None)
        hx = merged(hit, raw) if hit else {}
        old_pa = hx.get('pa', '') or old_pa
        new_pa = trx.get('pa', '') or new_pa
    if not new_pa and trx.get('pa'):
        new_pa = trx['pa']
    translation = {
        'TranslationResultEventID': tr['EventID'] if tr else '',
        'TranslationVA': trx.get('va', ''),
        'TranslationPA': trx.get('pa', ''),
        'MemoryAttribute': trx.get('memory_attribute', ''),
        'FaultStatus': trx.get('fault_status', ''),
        'OldPFN': old_pfn,
        'NewPFN': new_pfn,
        'OldPA': old_pa,
        'NewPA': new_pa,
        'PTEAddress': actx.get('pte_address', ''),
        'PTEValueBefore': actx.get('pte_value_before', ''),
        'PTEValueAfter': actx.get('pte_value_after', ''),
        'DescriptorBefore': actx.get('descriptor_before', ''),
        'DescriptorAfter': actx.get('descriptor_after', ''),
        'CandidateASID': actx.get('candidate_asid', ''),
        'CandidateEntryID': actx.get('candidate_entry_id', ''),
        'CandidateGeneration': actx.get('candidate_generation', ''),
        'LookupOutcome': lookup_outcome,
        'DecoyPFN': actx.get('decoy_pfn', ''),
        'DecoyVA': actx.get('decoy_va', ''),
        'NextTablePABefore': actx.get('next_table_pa_before', ''),
        'NextTablePAAfter': actx.get('next_table_pa_after', ''),
        'RequestPABefore': actx.get('request_pa_before', ''),
        'RequestPAAfter': actx.get('request_pa_after', ''),
        'PermissionBefore': actx.get('permission_before', ''),
        'PermissionAfter': actx.get('permission_after', ''),
        'PermissionResultAtActivation': actx.get('permission_result', ''),
    }
    consumed = [e for e in after if e['Kind'] not in (
        'mmu_fault_summary', 'chain_end')]
    propagation = {
        'Nodes': [{
            'EventID': e['EventID'],
            'ParentEventID': e.get('ParentEventID', ''),
            'Kind': e['Kind'],
            'Tick': e.get('Tick', ''),
            'TranslationID': e.get('TranslationID', ''),
            'EntryID': e.get('EntryID', ''),
            'EntryGeneration': e.get('EntryGeneration', ''),
            'DynamicInstSeqNum': e.get('DynamicInstSeqNum', ''),
            'VA': e.get('VA', ''),
            'PA': e.get('PA', ''),
            'CommitSeq': e.get('CommitSeq', ''),
            'SquashStatus': e.get('SquashStatus', ''),
        } for e in chain_events],
        'ObservedNodeKinds': kinds,
        'DownstreamKinds': after_kinds,
        'DownstreamConsumptionNodes': [{
            'EventID': e['EventID'], 'Kind': e['Kind'],
            'VA': e.get('VA', ''), 'PA': e.get('PA', ''),
            'Mode': (merged(e, raw) or {}).get('mode', ''),
        } for e in consumed],
        'UpstreamKinds': up,
        'MissingExpectedKinds': ver['Details'].get('missing_kinds', []),
        'NodesNotEmittedByFrozenBinary':
            ch.get('DownstreamNotObservedByFrozenBinary', []),
        'StrictChainOK': (ch.get('StrictChain') or {}).get('ok'),
        'StrictChainJoinBasis': (ch.get('StrictChain') or {}).get(
            'activation_basis', ''),
        'ConsumerMode': lsux.get('mode', ''),
        'ChainEventCount': len(chain_events),
        'ChainJoinMismatches': scan['ChainJoinMismatches'],
    }
    delta = {
        'M01': 'entry_valid->valid_retained;invalidation_suppressed',
        'M02': 'pfn %s->%s' % (old_pfn, new_pfn),
        'M03': 'candidate entry %s/%s asid %s;false_hit' % (
            actx.get('candidate_entry_id', ''), actx.get('candidate_generation',
                                                       ''),
            actx.get('candidate_asid', '')),
        'M04': 'resident entry %s/%s pfn %s->%s' % (
            actx.get('tlb_entry_id', ''), actx.get('entry_generation', ''),
            old_pfn, new_pfn),
        'M05': 'next_table_pa %s->%s;decoy_va=%s' % (
            actx.get('next_table_pa_before', ''),
            actx.get('next_table_pa_after', ''), actx.get('decoy_va', '')),
        'M06': 'descriptor %s->%s;invalid' % (
            actx.get('descriptor_before', ''),
            actx.get('descriptor_after', '')),
        'M07': 'permission %s->%s' % (
            actx.get('permission_before', ''),
            actx.get('permission_after', '')),
        'M08': 'request_pa %s->%s;pfn_unchanged' % (
            actx.get('request_pa_before', ''),
            actx.get('request_pa_after', '')),
    }[model]
    if model == 'M06':
        effect = 'descriptor %s->%s (invalid);Translation Fault' % (
            actx.get('descriptor_before', ''), actx.get('descriptor_after', ''))
    elif model == 'M05':
        effect = 'next_table_pa %s->%s;decoy_va=%s' % (
            actx.get('next_table_pa_before', ''),
            actx.get('next_table_pa_after', ''), actx.get('decoy_va', ''))
    elif model == 'M07':
        effect = 'VA/PA unchanged (PA %s);permission bypass' % (
            trx.get('pa', '') or 'n/a')
    else:
        effect = '%s->%s' % (old_pa or 'n/a', new_pa or 'n/a')
    core = OrderedDict([
        ('FaultOrigin', '%s@%s' % (model, actx.get('fault_site', '') or
                                   actx.get('fault_field', ''))),
        ('ActivationCondition', '%s:%s:%s' % (
            act_e['Kind'] if act_e else '',
            actx.get('lookup_outcome', lookup_outcome),
            actx.get('walk_level', ''))),
        ('StateTransition', delta),
        ('TranslationEffect', effect),
        ('DownstreamConsumption', ','.join(
            k for k in after_kinds if k not in (
                'mmu_fault_summary', 'chain_end'))),
        ('TerminalOutcome', '%s/%s/%s' % (
            ver['TerminalState'], ver['OracleResult'], primary)),
    ])
    signature = ' | '.join('%s=%s' % (k, v) for k, v in core.items())
    # Context-independent model signature: literal VA/PA/PFN/entry IDs/ticks
    # are replaced by their model-level relation class.
    state_class = {
        'M01': 'entry_valid->valid_retained;invalidation_suppressed',
        'M02': 'refill_pfn_changed;pte_memory_unchanged',
        'M03': 'foreign_asid_candidate;false_hit',
        'M04': 'resident_entry_pfn_substituted',
        'M05': 'next_table_pa_substituted;decoy_l3',
        'M06': 'leaf_descriptor_invalid',
        'M07': 'permission_false_to_true',
        'M08': 'final_request_pa_corrupted;pfn_unchanged',
    }[model]
    stable_signature = '%s|activation=%s|lookup=%s|state=%s|terminal=%s|' \
        'manifestation=%s' % (
            model, act_e['Kind'] if act_e else '',
            lookup_outcome, state_class,
            ver['TerminalState'], primary)
    existing = diag_map.get(sid)
    sig_matches = (existing is not None and
                   existing.get('PropagationSignature') == kinds)
    terminal = {
        'TerminalState': ver['TerminalState'],
        'ManifestationTypePrimary': primary,
        'ManifestationTypeSecondary': secondary,
        'OracleResult': ver['OracleResult'],
        'TraceCompleteness': ver['TraceCompleteness'],
        'PropagationCoverage': ver['PropagationStatus'],
        'DetectionStatus': {
            'DETECTED_CONTAINED': 'DETECTED_AND_CONTAINED',
            'SQUASHED': 'SQUASHED_BEFORE_ARCH_UPDATE',
            'SDC': 'NOT_DETECTED',
        }.get(ver['TerminalState'], 'UNKNOWN'),
        'SquashStatus': ('SQUASHED'
                         if ver['TerminalState'] == 'SQUASHED' or any(
                             e.get('SquashStatus') == 'SQUASH'
                             for e in chain_events) else 'NOT_SQUASHED'),
        'MaskingStatus': {
            'DETECTED_CONTAINED': 'MASKED_BY_EXCEPTION_DELIVERY',
            'SQUASHED': 'SQUASHED_BEFORE_COMMIT',
        }.get(ver['TerminalState'], 'NOT_MASKED'),
        'WrongValueProven': ver['Details'].get('wrong_value_proven'),
        'DataValueMismatch': bool(mismatch),
        'PermissionPolicyViolation': permission,
        'OriginalTerminalStatePreserved': True,
    }
    checks = Counter(t['Kind'] for t in transitions)
    fmap = [
        ('M01', {'tlbi_match', 'mmu_fault_arm', 'tlbi_suppressed',
                 'mmu_fault_disarm'}),
        ('M02', {'refill_pfn_corrupt', 'ptw_start', 'pte_read'}),
        ('M03', {'mmu_fault_activate', 'tlb_lookup_hit', 'squash'}),
        ('M04', {'tlb_entry_lineage', 'fault_entry_consume'}),
        ('M05', {'partial_entry_insert', 'next_table_pa_after'}),
        ('M06', {'fault_state_consumed', 'fault_result_propagated',
                 'exception_delivery'}),
        ('M07', {'permission_eval', 'permission_after'}),
        ('M08', {'request_pa_after', 'mmu_fault_activate'}),
    ]
    return {
        'identity': {
            'SampleRunID': sid,
            'ModelID': model,
            'ContextID': man['context'],
            'WorkloadID': matrix[sid]['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'RunWorkload': man.get('run_workload', ''),
            'AttemptID': matrix[sid]['AttemptID'],
            'FaultID': ver.get('fault_id'),
            'CampaignID': matrix[sid]['CampaignID'],
        },
        'fault_origin': origin,
        'activation': activation,
        'microarchitectural_state_transitions': transitions,
        'translation_effect': translation,
        'propagation_path': propagation,
        'terminal': terminal,
        'diagnostic_signature': {
            'Components': core,
            'CanonicalString': signature,
            'StableModelSignature': stable_signature,
            'EventKindSequence': kinds,
            'SignatureMatchesFrozenArtifact': sig_matches,
            'FrozenArtifactSignatureLength': (len(existing[
                'PropagationSignature']) if existing else None),
        },
        'evidence': {
            'TracePath': scan['TraceAbsolutePath'],
            'TraceSHA256': scan['TraceSHA256'],
            'TraceEventCount': scan['EventCount'],
            'FaultTaggedEventCount': scan['FaultTaggedEventCount'],
            'SelectionCapped': scan['SelectionCapped'],
            'ManifestPath': str(C.sample_dir(sid) / 'sample_manifest.json'),
            'VerdictPath': str(C.sample_dir(sid) / 'Validation/verdict.json'),
            'ChainPath': str(C.ANALYSIS / 'propagation_chains' /
                             ('%s.json' % sid)),
            'ActivationEventID': act_id,
            'ConsumptionEventID': ver.get('consumption_event_id'),
            'ChainJoinMismatches': scan['ChainJoinMismatches'],
        },
    }


def model_summary(features):
    out = []
    for model in C.MODELS:
        feats = [f for f in features if f['identity']['ModelID'] == model]
        kind_sets = [set(f['diagnostic_signature']['EventKindSequence'])
                     for f in feats]
        stable_kinds = sorted(set.intersection(*kind_sets)) if kind_sets \
            else []
        all_kinds = sorted(set.union(*kind_sets)) if kind_sets else []
        sigs = Counter(f['diagnostic_signature']['CanonicalString']
                       for f in feats)
        stable_sigs = Counter(
            f['diagnostic_signature']['StableModelSignature'] for f in feats)
        terminals = Counter(f['terminal']['TerminalState'] for f in feats)
        manifestations = Counter(
            f['terminal']['ManifestationTypePrimary'] for f in feats)
        out.append({
            'ModelID': model,
            'SignatureName': MODEL_SIGNATURE_NAME[model],
            'Mechanism': C.MODEL_MECHANISM[model],
            'Samples': [f['identity']['SampleRunID'] for f in feats],
            'StableEventKinds': stable_kinds,
            'VariableEventKinds': sorted(set(all_kinds) - set(stable_kinds)),
            'DistinctSignatures': len(sigs),
            'DistinctStableSignatures': len(stable_sigs),
            'StableSignatureVariants': [{'signature': s, 'count': n}
                                        for s, n in stable_sigs.items()],
            'SignatureVariants': [{'signature': s, 'count': n}
                                  for s, n in sigs.items()],
            'TerminalDistribution': dict(terminals),
            'ManifestationDistribution': dict(manifestations),
            'StableFields': _stable_fields(feats),
            'VariableFields': _variable_fields(feats),
        })
    return out


def _flat(f):
    tc = f['translation_effect']
    return {
        'fault_site': f['fault_origin']['InjectionLocation'][
            'TraceFaultSite'],
        'fault_field': f['fault_origin']['TargetField'],
        'tlb_instance': f['fault_origin']['TLBInstance'],
        'walk_level': f['fault_origin']['TLBLevel'],
        'access_mode': f['activation']['AccessMode'],
        'activation_kind': f['activation']['ActivationKind'],
        'terminal': f['terminal']['TerminalState'],
        'manifestation': f['terminal']['ManifestationTypePrimary'],
        'lookup_outcome': f['activation']['TLBLookupOutcome'],
        # context-varying values, to separate stable diagnostic features from
        # dynamic-context values
        'target_va': f['fault_origin']['TargetVA'],
        'activation_event_id': f['activation']['ActivationEventID'],
        'fault_state_before': json.dumps(
            f['activation']['FaultStateBefore'], sort_keys=True),
        'old_pfn': tc['OldPFN'],
        'new_pfn': tc['NewPFN'],
        'old_pa': tc['OldPA'],
        'new_pa': tc['NewPA'],
        'translation_pa': tc['TranslationPA'],
    }


def _stable_fields(feats):
    keys = list(_flat(feats[0]).keys())
    out = {}
    for k in keys:
        vals = {str(_flat(f).get(k, '')) for f in feats}
        if len(vals) == 1:
            out[k] = vals.pop()
    return out


def _variable_fields(feats):
    keys = list(_flat(feats[0]).keys())
    out = {}
    for k in keys:
        vals = sorted({str(_flat(f).get(k, '')) for f in feats})
        if len(vals) > 1:
            out[k] = vals
    return out


DISCRIMINATORS = {
    'M01': ['tlbi_match', 'tlbi_suppressed', 'mmu_fault_arm',
            'mmu_fault_disarm', 'fault_site=tlb flush suppression'],
    'M02': ['refill_pfn_corrupt', 'old_pfn!=new_pfn at refill',
            'PTE memory value unchanged'],
    'M03': ['candidate_asid (foreign)', 'lookup_outcome=false_hit',
            'candidate_entry_id/generation'],
    'M04': ['tlb_entry_lineage', 'fault_entry_consume on resident entry',
            'no PTW before activation'],
    'M05': ['partial_entry_insert', 'next_table_pa_before/after',
            'decoy_va'],
    'M06': ['fault_state_consumed', 'fault_result_propagated',
            'exception_delivery', 'pte_memory_written=0'],
    'M07': ['permission_before=false', 'permission_after=true',
            'permission_eval deny', 'no address corruption'],
    'M08': ['request_pa_before/after', 'old_pfn==new_pfn',
            'translation_result correct before final PA'],
}

CONFUSABLE = [
    {'Models': 'M02 vs M08',
     'Why': 'both W10 read contexts end in a wrong PA/sentinel 0x60',
     'Separator': 'M02 has refill_pfn_corrupt with old_pfn 0x834b2 -> '
                  '0x834b3; M08 keeps PFN and changes Request PA at '
                  'setPaddr (request_pa_before 0x834b2000 -> 0x834b3000).'},
    {'Models': 'M01 vs M03',
     'Why': 'both consume a stale/foreign TLB entry without a fresh walk',
     'Separator': 'M01 has tlbi_match + tlbi_suppressed + mmu_fault_disarm '
                  'and a retained L2 entry; M03 has candidate_asid != request '
                  'ASID and lookup_outcome=false_hit, with no suppression.'},
    {'Models': 'M02 vs M04',
     'Why': 'both substitute a PFN in a TLB entry',
     'Separator': 'M02 activates at refill after ptw_start/pte_read; M04 '
                  'activates on a real resident hit (tlb_entry_lineage, '
                  'fault_entry_consume) with no PTW.'},
    {'Models': 'M03 vs M04',
     'Why': 'both redirect a translation to another allocated page',
     'Separator': 'M03 candidate ASID differs from the request ASID; M04 '
                  'candidate/decoy PFN has the same ASID and a lineage join.'},
    {'Models': 'M05 vs M02',
     'Why': 'both reach a wrong leaf PFN through the walker',
     'Separator': 'M05 corrupts the intermediate next-table base '
                  '(next_table_pa_before/after, decoy_va) at L2; M02 '
                  'corrupts the completed leaf PFN at refill.'},
    {'Models': 'M06 vs all',
     'Why': 'M06 is a detection signature, not a silent wrong value',
     'Separator': 'fault_state_consumed + fault_result_propagated + '
                  'exception_delivery; terminal DETECTED_CONTAINED.'},
    {'Models': 'M07 vs all',
     'Why': 'M07 changes only the permission decision',
     'Separator': 'permission_before=false -> permission_after=true with an '
                  'unchanged VA/PA/PFN; control SIGSEGV permission fault.'},
]


def main():
    C.ensure_dirs()
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    authority = {r['SampleRunID']: r for r in C.authority_matrix_rows()}
    diag = C.load_json(C.PKG / 'diagnostic_features.json')
    diag_map = {d['SampleRunID']: d for d in diag}
    features = []
    for sid in sorted(matrix):
        features.append(build_sample(sid, matrix, authority, diag_map))
    lib = {
        'library_version': 'MMU-DIAG-FEATURE-LIB-v1',
        'campaign_id': 'MMU-FORMAL-20261113',
        'source_campaign_status': C.final_summary().get('status'),
        'feature_categories': [
            'fault_origin', 'activation', 'microarchitectural_state_transitions',
            'translation_effect', 'propagation_path', 'terminal',
            'diagnostic_signature'],
        'samples': features,
        'model_signatures': model_summary(features),
        'key_discriminators': DISCRIMINATORS,
        'confusable_pairs': CONFUSABLE,
    }
    C.write_json(C.FEAT / 'MMU_Diagnostic_Feature_Library.json', lib)
    # event-level chains
    cdir = C.FEAT / 'propagation_chains'
    cdir.mkdir(parents=True, exist_ok=True)
    for f in features:
        sid = f['identity']['SampleRunID']
        C.write_json(cdir / ('%s.json' % sid), {
            'SampleRunID': sid,
            'ModelID': f['identity']['ModelID'],
            'ContextID': f['identity']['ContextID'],
            'FaultOrigin': f['fault_origin'],
            'Activation': f['activation'],
            'StateTransitions': f['microarchitectural_state_transitions'],
            'TranslationEffect': f['translation_effect'],
            'PropagationPath': f['propagation_path'],
            'Terminal': f['terminal'],
            'DiagnosticSignature': f['diagnostic_signature'],
            'Evidence': f['evidence'],
        })
        C.write_csv(cdir / ('%s.csv' % sid),
                    f['microarchitectural_state_transitions'])

    # flat CSV
    rows = []
    for f in features:
        i, o, a, t, tc = (f['identity'], f['fault_origin'], f['activation'],
                          f['terminal'], f['translation_effect'])
        p = f['propagation_path']
        rows.append({
            'SampleRunID': i['SampleRunID'], 'ModelID': i['ModelID'],
            'ContextID': i['ContextID'], 'WorkloadID': i['WorkloadID'],
            'WorkloadVariant': i['WorkloadVariant'],
            'AttemptID': i['AttemptID'], 'FaultID': i['FaultID'],
            'FaultModelID': o['FaultModelID'],
            'TargetUnit': o['TargetUnit'], 'TargetSubUnit': o['TargetSubUnit'],
            'FaultType': o['FaultType'],
            'InjectionLocationSourceFile': o['InjectionLocation']['SourceFile'],
            'InjectionLocationSourceFunction':
                o['InjectionLocation']['SourceFunction'],
            'TraceFaultSite': o['InjectionLocation']['TraceFaultSite'],
            'TargetField': o['TargetField'], 'TargetVA': o['TargetVA'],
            'TargetASID': o['TargetASID'],
            'ManifestTargetASID': o['ManifestTargetASID'],
            'ActivationASID': o['ActivationASID'],
            'TargetVMID': o['TargetVMID'], 'TLBInstance': o['TLBInstance'],
            'TLBLevel': o['TLBLevel'], 'InjectionMode': o['InjectionMode'],
            'FaultDuration': o['FaultDuration'],
            'EligibleEventCondition': a['EligibleEventCondition'],
            'ActualEligibleEvent': a['ActualEligibleEvent'],
            'EventOrdinal': a['EventOrdinal'],
            'ActivationEventID': a['ActivationEventID'],
            'ActivationKind': a['ActivationKind'],
            'ActivationTick': a['ActivationTick'],
            'DynamicInstSeqNum': a['DynamicInstSeqNum'],
            'AccessMode': a['AccessMode'], 'WalkLevel': a['WalkLevel'],
            'PageSize': a['PageSize'], 'TLBLookupOutcome':
                a['TLBLookupOutcome'],
            'FaultStateBefore': a['FaultStateBefore'],
            'FaultStateAfter': a['FaultStateAfter'],
            'TranslationResultEventID': tc['TranslationResultEventID'],
            'TranslationVA': tc['TranslationVA'],
            'TranslationPA': tc['TranslationPA'],
            'OldPFN': tc['OldPFN'], 'NewPFN': tc['NewPFN'],
            'OldPA': tc['OldPA'], 'NewPA': tc['NewPA'],
            'PTEAddress': tc['PTEAddress'],
            'PTEValueBefore': tc['PTEValueBefore'],
            'PTEValueAfter': tc['PTEValueAfter'],
            'DescriptorBefore': tc['DescriptorBefore'],
            'DescriptorAfter': tc['DescriptorAfter'],
            'CandidateASID': tc['CandidateASID'],
            'CandidateEntryID': tc['CandidateEntryID'],
            'CandidateGeneration': tc['CandidateGeneration'],
            'DecoyPFN': tc['DecoyPFN'], 'DecoyVA': tc['DecoyVA'],
            'NextTablePABefore': tc['NextTablePABefore'],
            'NextTablePAAfter': tc['NextTablePAAfter'],
            'RequestPABefore': tc['RequestPABefore'],
            'RequestPAAfter': tc['RequestPAAfter'],
            'PermissionBefore': tc['PermissionBefore'],
            'PermissionAfter': tc['PermissionAfter'],
            'MemoryAttribute': tc['MemoryAttribute'],
            'DownstreamKinds': p['DownstreamKinds'],
            'MissingExpectedKinds': p['MissingExpectedKinds'],
            'NodesNotEmittedByFrozenBinary':
                p['NodesNotEmittedByFrozenBinary'],
            'ConsumerMode': p['ConsumerMode'],
            'StrictChainOK': p['StrictChainOK'],
            'ChainEventCount': p['ChainEventCount'],
            'ChainJoinMismatches': p['ChainJoinMismatches'],
            'TerminalState': t['TerminalState'],
            'ManifestationTypePrimary': t['ManifestationTypePrimary'],
            'ManifestationTypeSecondary': t['ManifestationTypeSecondary'],
            'OracleResult': t['OracleResult'],
            'TraceCompleteness': t['TraceCompleteness'],
            'PropagationCoverage': t['PropagationCoverage'],
            'DetectionStatus': t['DetectionStatus'],
            'SquashStatus': t['SquashStatus'],
            'MaskingStatus': t['MaskingStatus'],
            'DiagnosticSignature':
                f['diagnostic_signature']['CanonicalString'],
            'EventKindSequence':
                f['diagnostic_signature']['EventKindSequence'],
            'SignatureMatchesFrozenArtifact':
                f['diagnostic_signature']['SignatureMatchesFrozenArtifact'],
            'TraceSHA256': f['evidence']['TraceSHA256'],
        })
    C.write_csv(C.FEAT / 'MMU_Diagnostic_Feature_Library.csv', rows)

    _xlsx(lib, features)
    _md(lib, features)
    print(json.dumps({
        'samples': len(features),
        'models': [{'ModelID': m['ModelID'],
                    'distinct_signatures': m['DistinctSignatures'],
                    'stable_kinds': len(m['StableEventKinds']),
                    'terminals': m['TerminalDistribution']}
                   for m in lib['model_signatures']],
        'signature_matches_frozen': sum(
            1 for f in features if f['diagnostic_signature'][
                'SignatureMatchesFrozenArtifact']),
        'chain_join_mismatch_samples': [
            f['identity']['SampleRunID'] for f in features
            if f['evidence']['ChainJoinMismatches']],
        'selection_capped': [f['identity']['SampleRunID'] for f in features
                             if f['evidence']['SelectionCapped']],
    }, indent=1))


def _xlsx(lib, features):
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'README'
    for line in [
        ['MMU Diagnostic Feature Library'],
        ['Campaign', lib['campaign_id']],
        ['Status', lib['source_campaign_status']],
        ['Samples', len(features)],
        ['Source', '40 frozen formal samples; raw traces + verdicts + '
                   'propagation chain JSON'],
        ['State transitions', 'Every row carries the real EventID from '
                              'prop_evt.txt.gz; chain joins verified with '
                              'zero mismatches'],
        ['ManifestationType', 'Diagnostic dimension added by this audit; '
                              'original TerminalState is preserved'],
        ['Limitation', 'M04 trace tags nearly every post-arm event with '
                       'fault_id=1; relevance is anchored on the activation '
                       'translation/VA and the frozen chain, and selection '
                       'is capped at 5000 non-chain events'],
    ]:
        ws.append(line)
    ws['A1'].font = Font(bold=True, size=14)

    flat_fields = list(lib['samples'][0]['identity'].keys())
    ws2 = wb.create_sheet('Sample_Features')
    headers = ['SampleRunID', 'ModelID', 'ContextID', 'WorkloadID',
               'Variant', 'FaultModelID', 'TargetSubUnit', 'FaultType',
               'TraceFaultSite', 'TargetField', 'TargetVA', 'TargetASID',
               'ActivationASID', 'TLBInstance', 'TLBLevel', 'FaultDuration',
               'ActualEligibleEvent',
               'ActivationEventID', 'ActivationKind', 'AccessMode',
               'WalkLevel', 'TLBLookupOutcome', 'OldPFN', 'NewPFN',
               'OldPA', 'NewPA', 'DescriptorBefore', 'DescriptorAfter',
               'PermissionBefore', 'PermissionAfter', 'DownstreamKinds',
               'TerminalState', 'ManifestationTypePrimary',
               'ManifestationTypeSecondary', 'OracleResult',
               'TraceCompleteness', 'PropagationCoverage', 'DetectionStatus',
               'SquashStatus', 'MaskingStatus', 'DiagnosticSignature']
    ws2.append(headers)
    for f in features:
        i, o, a, t, tc, p = (f['identity'], f['fault_origin'],
                             f['activation'], f['terminal'],
                             f['translation_effect'], f['propagation_path'])
        ws2.append([
            i['SampleRunID'], i['ModelID'], i['ContextID'], i['WorkloadID'],
            i['WorkloadVariant'], o['FaultModelID'], o['TargetSubUnit'],
            o['FaultType'], o['InjectionLocation']['TraceFaultSite'],
            o['TargetField'], o['TargetVA'], o['TargetASID'],
            o['ActivationASID'], o['TLBInstance'], o['TLBLevel'],
            o['FaultDuration'],
            a['ActualEligibleEvent'], a['ActivationEventID'],
            a['ActivationKind'], a['AccessMode'], a['WalkLevel'],
            a['TLBLookupOutcome'], tc['OldPFN'], tc['NewPFN'], tc['OldPA'],
            tc['NewPA'], tc['DescriptorBefore'], tc['DescriptorAfter'],
            tc['PermissionBefore'], tc['PermissionAfter'],
            ', '.join(p['DownstreamKinds']), t['TerminalState'],
            t['ManifestationTypePrimary'], t['ManifestationTypeSecondary'],
            t['OracleResult'], t['TraceCompleteness'],
            t['PropagationCoverage'], t['DetectionStatus'],
            t['SquashStatus'], t['MaskingStatus'],
            f['diagnostic_signature']['CanonicalString'],
        ])
    ws2.freeze_panes = 'B2'

    ws3 = wb.create_sheet('State_Transitions')
    keys = ['SampleRunID', 'EventID', 'ParentEventID', 'Kind', 'Tick',
            'TranslationID', 'EntryID', 'EntryGeneration',
            'DynamicInstSeqNum', 'VA', 'PA', 'Field', 'Before', 'After',
            'StateBefore', 'StateAfter', 'Outcome', 'asid', 'vmid',
            'tlb_instance', 'permission_result', 'permission_before',
            'permission_after', 'memory_attribute', 'old_pfn', 'new_pfn',
            'old_pa', 'new_pa', 'pte_address', 'pte_value_before',
            'pte_value_after', 'descriptor_before', 'descriptor_after',
            'request_pa_before', 'request_pa_after', 'candidate_asid',
            'candidate_entry_id', 'candidate_generation', 'candidate_pfn',
            'candidate_pa', 'lookup_outcome', 'decoy_pfn', 'decoy_va',
            'next_table_pa_before', 'next_table_pa_after', 'fault_site',
            'fault_field', 'fault_persistence', 'regime', 'security_state',
            'fault_status', 'pte_memory_written', 'SquashStatus']
    ws3.append(keys)
    for f in features:
        sid = f['identity']['SampleRunID']
        for tr in f['microarchitectural_state_transitions']:
            row = dict(tr)
            row['SampleRunID'] = sid
            ws3.append([row.get(k, '') for k in keys])
    ws3.freeze_panes = 'B2'

    ws4 = wb.create_sheet('Model_Signatures')
    ws4.append(['ModelID', 'SignatureName', 'Mechanism', 'Samples',
                'DistinctSignatures',
                'DistinctStableSignatures', 'StableSignatureVariants',
                'StableEventKinds', 'VariableEventKinds',
                'TerminalDistribution', 'ManifestationDistribution',
                'StableFields', 'VariableFields'])
    for m in lib['model_signatures']:
        ws4.append([m['ModelID'], m['SignatureName'], m['Mechanism'],
                    ', '.join(m['Samples']), m['DistinctSignatures'],
                    m['DistinctStableSignatures'],
                    json.dumps(m['StableSignatureVariants']),
                    ', '.join(m['StableEventKinds']),
                    ', '.join(m['VariableEventKinds']),
                    json.dumps(m['TerminalDistribution']),
                    json.dumps(m['ManifestationDistribution']),
                    json.dumps(m['StableFields']),
                    json.dumps(m['VariableFields'])])

    ws5 = wb.create_sheet('Discriminators')
    ws5.append(['ModelID', 'KeyDiscriminators'])
    for model, vals in lib['key_discriminators'].items():
        ws5.append([model, '; '.join(vals)])
    ws5.append([])
    ws5.append(['Confusable pair', 'Why', 'Separator'])
    for c in lib['confusable_pairs']:
        ws5.append([c['Models'], c['Why'], c['Separator']])
    wb.save(C.FEAT / 'MMU_Diagnostic_Feature_Library.xlsx')


def _md(lib, features):
    md = ['# MMU Diagnostic Feature Library\n\n',
          'Campaign: `%s` (source status `%s`). Built from the 40 frozen '
          'formal samples; every state transition is anchored to a real '
          '`EventID` in `Trace/prop_evt.txt.gz`.\n\n' % (
              lib['campaign_id'], lib['source_campaign_status']),
          '## Feature categories\n\n']
    for c in lib['feature_categories']:
        md.append('- `%s`\n' % c)
    md.append('\n## Model-level signatures\n\n')
    md.append('| Model | Signature name | Mechanism | Samples | Full '
              'signatures | Stable signatures | Stable event kinds | '
              'Terminals |\n|---|---|---|---|---|---|---|---|\n')
    for m in lib['model_signatures']:
        md.append('| %s | %s | %s | %d | %d | %d | %s | %s |\n' % (
            m['ModelID'], m['SignatureName'], m['Mechanism'],
            len(m['Samples']),
            m['DistinctSignatures'], m['DistinctStableSignatures'],
            ', '.join(m['StableEventKinds'][:8]) +
            ('...' if len(m['StableEventKinds']) > 8 else ''),
            json.dumps(m['TerminalDistribution'])))
    md.append('\n`StableModelSignature` deliberately excludes literal '
              'VA/PA/PFN/entry IDs/ticks, so it expresses the model-level '
              'diagnostic class rather than one dynamic context. Full '
              'signatures retain context-specific values and downstream '
              'ordering.\n')
    md.append('\n## Stable vs variable features\n\n')
    for m in lib['model_signatures']:
        md.append('### %s\n\n' % m['ModelID'])
        md.append('- Stable fields: `%s`\n' % json.dumps(m['StableFields']))
        md.append('- Variable fields: `%s`\n' % json.dumps(m['VariableFields']))
        if m['DistinctSignatures'] > 1:
            md.append('- Signature variants: %s\n' % json.dumps(
                [{'count': v['count'], 'signature': v['signature'][:300]}
                 for v in m['SignatureVariants']]))
        md.append('\n')
    md.append('## Key discriminators\n\n')
    for model, vals in lib['key_discriminators'].items():
        md.append('- **%s**: %s\n' % (model, '; '.join(vals)))
    md.append('\n## Confusable propagation paths\n\n')
    for c in lib['confusable_pairs']:
        md.append('- **%s** — %s  \n  Separator: %s\n' % (
            c['Models'], c['Why'], c['Separator']))
    md.append('\n## Similar features across models (low specificity)\n\n')
    md.append('These are shared by many models and must **not** be used '
              'alone for root-cause diagnosis: `translation_result`, '
              '`lsu_request`, `cache_request/lookup/response`, '
              '`memory_response`, `rf_writeback`, `commit`, `consumer`, '
              '`chain_end`. The W10/W10S oracle sentinel pattern is also '
              'shared by M02, M06 and M08. The wrong-PFN outcome is shared '
              'by M02, M04 and M05; the foreign/stale entry consumption is '
              'shared by M01 and M03.\n')
    md.append('\n## Features suitable for root-cause diagnosis (ranked)\n\n')
    md.append('1. **Trace fault site + activation kind** — highest '
              'specificity (`mmu_fault_arm`, `refill_pfn_corrupt`, '
              '`tlb_lookup_miss_false_hit`, `tlb_lookup_hit_pfn_subst`, '
              '`ptw_insertPartialTableEntry`, '
              '`ptw_doLongDescriptor_valid_clear`, '
              '`mmu_checkPermissions64`, `mmu_translate_set_paddr`).\n')
    md.append('2. **Activation state delta** — the old/new PFN, descriptor, '
              'permission, next-table-PA or request-PA fields and the '
              'entry/ASID relations; these separate M02/M08, M03/M04, '
              'M05/M02 and M07.\n')
    md.append('3. **Upstream path** — PTW before activation (M02/M05/M06) '
              'vs resident hit (M04) vs TLBI suppression (M01) vs '
              'permission eval (M07).\n')
    md.append('4. **Terminal/containment pattern** — DETECTED_CONTAINED + '
              'exception_delivery (M06), SQUASHED before arch update '
              '(M03 R01-R04), silent SDC (the rest).\n')
    md.append('5. **Downstream event kinds** — lowest specificity; useful '
              'only after the origin is anchored. Literal VA/PA/PFN/entry '
              'IDs/ticks are context values, not stable diagnostic '
              'features.\n')
    md.append('\n## TraceCompleteness is not PropagationStatus\n\n')
    md.append('M03 R01-R04 are `TraceCompleteness=COMPLETE` with '
              '`PropagationStatus=PARTIAL` and `TerminalState=SQUASHED`; '
              'their real squash is preserved. M06 R01-R05 are COMPLETE + '
              'FULL + DETECTED_CONTAINED. The library keeps both dimensions '
              'separate.\n\n')
    md.append('## Honesty notes\n\n')
    md.append('- `ManifestationType` is an added diagnostic dimension; the '
              'original `TerminalState` is never overwritten.\n')
    md.append('- M04 tags almost every post-arm event with `fault_id=1`; the '
              'library therefore anchors relevance on the activation '
              'translation/VA and the frozen chain, and caps non-chain '
              'selection. The chain join still has zero mismatches.\n')
    md.append('- M07 R04/R05 require a co-temporal join (`translation_id=0` '
              'on the fetch activation); the strict chain supplies it and '
              'the join is not inferred from event order.\n')
    md.append('- Nodes not emitted by the frozen binary are listed per '
              'sample in `NodesNotEmittedByFrozenBinary`; they are not '
              'fabricated.\n')
    (C.FEAT / 'Model_Propagation_Signatures.md').write_text(''.join(md))


if __name__ == '__main__':
    main()
