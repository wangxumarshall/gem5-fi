#!/usr/bin/env python3
"""Task 1.3 - control sharing and zero-injection audit.

Verifies the 40 fault->control references, the 28 distinct oracles, the
zero-injection proof of every control, workload/context compatibility, and the
documented approval basis. Read-only.
"""
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

APPROVAL_DOC = (C.REPO / 'phase3/final/'
                'MMU_Final_Formal_Readiness_Package_v3.0.1/'
                'MMU_Control_Inventory_Reconciliation.md')
CTX_RE = re.compile(r'\bctx=(R\d+)')
TVA_RE = re.compile(r'\btarget_va=(0x[0-9a-fA-F]+)')
PREFIX_RE = re.compile(r'^(W\d+S?)_RESULT\b')
INI_RE = re.compile(r'^mmuFaultEnable=(.*)$', re.M)
INI_MODEL_RE = re.compile(r'^mmuFaultModel=(.*)$', re.M)


def read_config(control_dir):
    p = Path(control_dir) / 'Config' / 'config.ini'
    if not p.exists():
        return {}
    txt = p.read_text(errors='replace')
    return {'mmuFaultEnable': (INI_RE.search(txt).group(1).strip()
                               if INI_RE.search(txt) else ''),
            'mmuFaultModel': (INI_MODEL_RE.search(txt).group(1).strip()
                              if INI_MODEL_RE.search(txt) else ''),
            'path': str(p)}


def approval_lines():
    if not APPROVAL_DOC.exists():
        return {'exists': False}
    lines = APPROVAL_DOC.read_text(errors='replace').splitlines()
    hits = [i + 1 for i, ln in enumerate(lines)
            if 'CONTROL_INVENTORY_VERDICT' in ln or
            'Sharing is intentional and valid' in ln or
            '34 run dirs' in ln]
    verdict = next((ln.strip() for ln in lines
                    if 'CONTROL_INVENTORY_VERDICT' in ln), '')
    return {'exists': True, 'path': str(APPROVAL_DOC),
            'sha256': C.sha256_file(APPROVAL_DOC),
            'line_numbers': hits, 'verdict': verdict,
            'approved': 'RECONCILED' in verdict}


def main():
    C.ensure_dirs()
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    pairs = C.fault_control_pairs()
    zero = C.control_zero_proof()
    approval = approval_lines()

    rows = []
    groups = OrderedDict()
    for p in pairs:
        sid = p['SampleRunID']
        m = matrix[sid]
        man = C.manifest(sid)
        ver = C.verdict(sid)
        ctl_dir = Path(p['ControlRunDir'])
        oracle = Path(p['ControlOraclePath'])
        ctl_line = (ver.get('Details', {}).get('control_oracle', {})
                    .get('line', ''))
        actual_hash = C.sha256_file(oracle) if oracle.is_file() else ''
        cfg = read_config(ctl_dir)
        cmd_path = ctl_dir / 'Run_Log' / 'command.txt'
        cmd = cmd_path.read_text(errors='replace') if cmd_path.exists() else ''
        fault_flags = re.findall(r'--mmu_fault_\w+(?:[ =]\S+)?', cmd)
        z = zero.get(str(ctl_dir), {})
        text = oracle.read_text(errors='replace') if oracle.is_file() else ''
        line_present = bool(ctl_line) and ctl_line.strip() in text
        prefix = PREFIX_RE.search(ctl_line)
        oracle_workload = prefix.group(1) if prefix else ''
        ctx_m = CTX_RE.search(ctl_line)
        tva_m = TVA_RE.search(ctl_line)
        sample_workload = man.get('run_workload', '')
        if ctx_m:
            context_match = ctx_m.group(1) == m['ContextID']
            context_basis = 'ctx token %s' % ctx_m.group(1)
        elif tva_m:
            target_va = man.get('target_va')
            context_match = (isinstance(target_va, int) and
                             int(tva_m.group(1), 16) == target_va)
            context_basis = 'target_va %s vs manifest %s' % (
                tva_m.group(1), target_va)
        else:
            context_match = False
            context_basis = 'no ctx/target_va token'
        workload_match = (oracle_workload == sample_workload)
        zero_ok = (z.get('status') == 'ZERO_PROVEN' and
                   int(z.get('injection_applied_count', -1)) == 0 and
                   cfg.get('mmuFaultEnable', '').lower() == 'true' and
                   cfg.get('mmuFaultModel', '') == '' and
                   str(z.get('gem5_exit_code', '')) == '0')
        oracle_hash_match = (actual_hash.lower() ==
                             p['ControlOracleSHA256'].lower())
        shared = sum(1 for q in pairs
                     if q['ControlRunDir'] == p['ControlRunDir']) > 1
        issues = []
        if not ctl_dir.is_dir():
            issues.append('control dir missing')
        if not oracle.is_file():
            issues.append('oracle file missing')
        if not oracle_hash_match:
            issues.append('oracle sha mismatch')
        if not line_present:
            issues.append('control oracle line not found verbatim')
        if not workload_match:
            issues.append('workload mismatch oracle=%s sample=%s' % (
                oracle_workload, sample_workload))
        if not context_match:
            issues.append('context mismatch (%s)' % context_basis)
        if not zero_ok:
            issues.append('zero-injection proof failed')
        if fault_flags:
            issues.append('fault flags in command: %s' % fault_flags)
        verdict = 'PASS' if not issues else 'NEEDS_REVIEW'
        row = {
            'SampleRunID': sid,
            'ModelID': m['ModelID'],
            'ContextID': m['ContextID'],
            'WorkloadID': m['WorkloadID'],
            'RunWorkload': sample_workload,
            'ControlRunDir': str(ctl_dir),
            'ControlOraclePath': str(oracle),
            'ControlOracleSHA256Recorded': p['ControlOracleSHA256'],
            'ControlOracleSHA256Actual': actual_hash,
            'OracleHashMatch': oracle_hash_match,
            'ControlExists': ctl_dir.is_dir(),
            'ControlOracleExists': oracle.is_file(),
            'ControlOracleLineVerbatim': line_present,
            'OracleWorkloadPrefix': oracle_workload,
            'WorkloadCompatible': workload_match,
            'TargetContextCompatible': context_match,
            'ContextMatchBasis': context_basis,
            'ControlConfigFaultEnable': cfg.get('mmuFaultEnable', ''),
            'ControlConfigFaultModel': cfg.get('mmuFaultModel', ''),
            'ControlCommandFaultFlags': ';'.join(fault_flags),
            'ControlGem5ExitCode': z.get('gem5_exit_code', ''),
            'InjectionAppliedCount': z.get('injection_applied_count', ''),
            'ZeroProofStatus': z.get('status', ''),
            'ZeroProofBasis': z.get('basis', ''),
            'SharedControl': shared,
            'PairingBasis': p.get('PairingBasis', ''),
            'ApprovalEvidence': ('%s lines %s' % (
                approval.get('path', 'MISSING'),
                ','.join(str(x) for x in approval.get('line_numbers', [])))),
            'ApprovalStatus': ('APPROVED_BY_INVENTORY_RECONCILIATION'
                               if approval.get('approved')
                               else 'NEEDS_REVIEW'),
            'AuditVerdict': verdict,
            'Notes': '; '.join(issues),
        }
        rows.append(row)
        g = groups.setdefault(str(ctl_dir), {
            'ControlRunDir': str(ctl_dir),
            'ControlOraclePath': str(oracle),
            'OracleSHA256': actual_hash,
            'Workload': oracle_workload,
            'SampleRunIDs': [],
            'Contexts': [],
            'ZeroProofStatus': z.get('status', ''),
            'InjectionAppliedCount': z.get('injection_applied_count', ''),
            'Gem5ExitCode': z.get('gem5_exit_code', ''),
            'ConfigFaultEnable': cfg.get('mmuFaultEnable', ''),
            'ConfigFaultModel': cfg.get('mmuFaultModel', ''),
            'OracleHashMatch': oracle_hash_match,
            'Approved': approval.get('approved', False),
        })
        g['SampleRunIDs'].append(sid)
        g['Contexts'].append(m['ContextID'])

    group_rows = []
    for ctl, g in groups.items():
        group_rows.append({
            'ControlRunDir': g['ControlRunDir'],
            'ControlOraclePath': g['ControlOraclePath'],
            'OracleSHA256': g['OracleSHA256'],
            'Workload': g['Workload'],
            'SamplesReferenced': len(g['SampleRunIDs']),
            'SampleRunIDs': ','.join(g['SampleRunIDs']),
            'Contexts': ','.join(g['Contexts']),
            'SharedByModels': ','.join(sorted(set(
                s.split('-')[0] for s in g['SampleRunIDs']))),
            'ZeroProofStatus': g['ZeroProofStatus'],
            'InjectionAppliedCount': g['InjectionAppliedCount'],
            'Gem5ExitCode': g['Gem5ExitCode'],
            'ConfigFaultEnable': g['ConfigFaultEnable'],
            'ConfigFaultModel': g['ConfigFaultModel'],
            'OracleHashMatch': g['OracleHashMatch'],
            'Approved': g['Approved'],
        })

    C.write_csv(C.AUDIT / 'Control_Map.csv', rows)
    C.write_csv(C.AUDIT / 'Control_Sharing_Summary.csv', group_rows)

    summary = {
        'fault_control_references': len(rows),
        'distinct_control_oracles': len(groups),
        'control_dirs_existing': sum(1 for g in groups.values()
                                     if Path(g['ControlRunDir']).is_dir()),
        'zero_proven': sum(1 for g in groups.values()
                           if g['ZeroProofStatus'] == 'ZERO_PROVEN'),
        'oracle_hash_match': sum(1 for r in rows if r['OracleHashMatch']),
        'workload_compatible': sum(1 for r in rows if r['WorkloadCompatible']),
        'context_compatible': sum(1 for r in rows
                                  if r['TargetContextCompatible']),
        'zero_proof_rows': sum(1 for r in rows
                               if r['ZeroProofStatus'] == 'ZERO_PROVEN' and
                               int(r['InjectionAppliedCount']) == 0),
        'audit_pass': sum(1 for r in rows if r['AuditVerdict'] == 'PASS'),
        'audit_review': [r for r in rows if r['AuditVerdict'] != 'PASS'],
        'approval': approval,
        'unreferenced_control_dirs': [],
    }
    existing = sorted(p.name for p in (C.REPO / 'runs').glob('TEST-F1-CTRL*')
                      if p.is_dir())
    referenced = set(Path(g['ControlRunDir']).name for g in groups.values())
    summary['unreferenced_control_dirs'] = [
        x for x in existing if x not in referenced]
    C.write_json(C.AUDIT / 'Control_Audit.json', summary)
    print(json.dumps(summary, indent=1))

    # ---- report -----------------------------------------------------------
    md = []
    md.append('# Control Sharing and Zero-Injection Audit\n')
    md.append('Sources: `fault_control_pairs.csv`, each sample '
              '`Validation/verdict.json` (`Details.control_oracle`), each '
              'control `Config/config.ini` and `Run_Log/command.txt`, '
              '`analysis/control_zero_proof.json`.\n')
    md.append('## Result\n')
    md.append('| Check | Result |\n|---|---|\n')
    md.append('| Fault->control references | %d |\n' % len(rows))
    md.append('| Distinct referenced oracles | %d |\n' % len(groups))
    md.append('| Oracle SHA256 match | %d/%d |\n' % (
        summary['oracle_hash_match'], len(rows)))
    md.append('| Zero-injection proven | %d/%d oracles |\n' % (
        summary['zero_proven'], len(groups)))
    md.append('| Workload compatible | %d/%d |\n' % (
        summary['workload_compatible'], len(rows)))
    md.append('| Context compatible | %d/%d |\n' % (
        summary['context_compatible'], len(rows)))
    md.append('| Row-level PASS | %d/%d |\n\n' % (
        summary['audit_pass'], len(rows)))
    md.append('## Why 40 samples use 28 controls\n\n')
    md.append('The counting units differ: 40 fault samples reference 28 '
              'distinct oracle files; 34 `TEST-F1-CTRL*` run directories '
              'exist, of which 6 are duplicate/superseded copies not '
              'referenced by this campaign. A shared control is one '
              'independent execution whose per-context oracle line is '
              'distinct. This is documented and approved in '
              '`%s` (lines %s):\n\n' % (
                  approval.get('path'),
                  ','.join(str(x) for x in approval.get('line_numbers', []))))
    md.append('> %s\n\n' % approval.get('verdict', ''))
    md.append('| Control | Samples | Models | Contexts |\n|---|---|---|---|\n')
    for g in group_rows:
        md.append('| `%s` | %d | %s | %s |\n' % (
            Path(g['ControlRunDir']).name, g['SamplesReferenced'],
            g['SharedByModels'], g['Contexts']))
    md.append('\nUnreferenced control directories (historical duplicates): '
              '%s\n\n' % ', '.join(
                  '`%s`' % x for x in summary['unreferenced_control_dirs']))
    md.append('## Zero-injection basis\n\n')
    md.append('Every control was executed with `mmuFaultEnable=true` but an '
              'empty `mmuFaultModel`; `CHAOSPropagation` arms injection only '
              'when both are set. `control_zero_proof.json` records '
              '`injection_applied_count=0` and gem5 exit 0 for all 28 '
              'oracles, and the control `Config/config.ini` / command line '
              'were re-read here. No `--mmu_fault_model` flag is present in '
              'any control command.\n\n')
    md.append('## W10S oracle substitution\n\n')
    md.append('The two W10S variant controls (`TEST-F1-CTRL-W10S-COLD`, '
              '`TEST-F1-CTRL-W10S-WARM`) use the guest serial transcript '
              '(`board.terminal`) as the oracle because their '
              '`golden_output.txt` is empty; this is documented in the '
              'inventory reconciliation. Both are context-exact by the '
              'generated rcS named in their command.\n\n')
    md.append('## Verdict\n\n')
    if summary['audit_review']:
        md.append('`CONTROL_AUDIT = NEEDS_REVIEW` for %d row(s): %s\n' % (
            len(summary['audit_review']),
            json.dumps(summary['audit_review'], indent=1)))
    else:
        md.append('`CONTROL_AUDIT = PASS` — all 40 references, 28 oracles, '
                  'hash, workload, context and zero-injection checks agree, '
                  'with the frozen approval evidence above. No control was '
                  're-run or modified.\n')
    (C.AUDIT / 'Control_Sharing_Audit.md').write_text(''.join(md))


if __name__ == '__main__':
    main()
