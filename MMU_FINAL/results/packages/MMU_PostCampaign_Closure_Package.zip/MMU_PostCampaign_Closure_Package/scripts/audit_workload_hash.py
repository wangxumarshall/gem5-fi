#!/usr/bin/env python3
"""Task 1.2 - reconcile the WorkloadSHA256 fields.

Resolves every recorded hash to a real file, extracts the gzip+base64 payload
embedded in each rcS, and reports the W9 (ec5256.. vs 4f3ddb..) and
W10S/W10 questions separately. Read-only.
"""
import base64
import gzip
import hashlib
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

W9_MATRIX = 'ec525687a757fd0f3865294481c687e754c06dc6a073dd2aa80306b04621732b'
W9_LIVE = '4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98'
W10S_HASH = 'fede5f3ea4c3224f34ef9768a8cbb0fe49b071cab86306e67e7a73610f11b0a3'
PAYLOAD_RE = re.compile(r"base64 -d > \S+ <<'([A-Za-z0-9_]+)'")


def extract_payload_hash(rcs_path):
    """Return (sha256, decompressed_size) of the gzip+base64 payload."""
    lines = Path(rcs_path).read_text(errors='replace').splitlines()
    marker = None
    start = None
    for i, line in enumerate(lines):
        m = PAYLOAD_RE.search(line)
        if m:
            marker, start = m.group(1), i + 1
            break
    if marker is None:
        return None, None
    blob = []
    for line in lines[start:]:
        if line.strip() == marker:
            break
        blob.append(line.strip())
    raw = base64.b64decode(''.join(blob))
    payload = gzip.decompress(raw)
    return hashlib.sha256(payload).hexdigest(), len(payload)


def contains_bytes(path, needle, chunk=8 << 20):
    """Streaming byte containment check (no shell grep memory blow-up)."""
    n = len(needle)
    with open(path, 'rb') as fh:
        prev = b''
        while True:
            block = fh.read(chunk)
            if not block:
                return False
            buf = prev + block
            if needle in buf:
                return True
            prev = buf[-n:]
    return False


def file_info(path, role, notes=''):
    p = Path(path)
    return {
        'Role': role,
        'Path': str(p),
        'Exists': p.is_file(),
        'SizeBytes': p.stat().st_size if p.is_file() else '',
        'SHA256': C.sha256_file(p) if p.is_file() else '',
        'Notes': notes,
    }


def main():
    C.ensure_dirs()
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    sids = sorted(matrix)

    # --- physical identity of every binary/source/rcS in play ---------------
    workloads = OrderedDict()
    for wid, variant in [('W9', 'canonical-rev'), ('W9', 'live-executed'),
                         ('W10', 'canonical'), ('W10S', 'variant'),
                         ('W11', 'canonical'), ('W12', 'canonical'),
                         ('W13', 'canonical'), ('W14', 'canonical')]:
        if wid == 'W9' and variant == 'canonical-rev':
            binary = C.REPO / 'workloads/mmu_rev/W9/Binary/mmu_w9'
            source = C.REPO / 'workloads/mmu_rev/W9/mmu_w9.c'
            rcS = C.REPO / 'configs/fs/mmu_w9_run.rcS'
        elif wid == 'W9':
            binary = C.REPO / 'workloads/mmu/W9/mmu_w9'
            source = C.REPO / 'workloads/mmu/W9/mmu_w9.c'
            rcS = C.REPO / 'configs/fs/mmu_w9.rcS'
        else:
            binary = C.REPO / ('workloads/mmu/%s/mmu_%s' % (wid, wid.lower()))
            source = C.REPO / ('workloads/mmu/%s/mmu_%s.c' % (wid, wid.lower()))
            rcS = C.REPO / ('configs/fs/mmu_%s_run.rcS' % wid.lower())
        key = '%s/%s' % (wid, variant)
        wl = {'WorkloadID': wid, 'VariantIdentity': variant,
              'Binary': file_info(binary, 'workload ELF'),
              'Source': file_info(source, 'workload C source')}
        emb, emb_size = extract_payload_hash(rcS)
        wl['RuntimeScript'] = file_info(rcS, 'rcS script')
        wl['RuntimeScriptEmbeddedPayloadSHA256'] = emb or ''
        wl['RuntimeScriptEmbeddedPayloadSize'] = emb_size or ''
        workloads[key] = wl

    # generated W10S rcS (the two actually used)
    for sid in ('M06-F0-W10-S01-R02', 'M08-F0-W10-S01-R05'):
        rcs = C.repr_path(C.manifest(sid)['rcs_source'])
        emb, size = extract_payload_hash(rcs)
        workloads['rcS/%s' % sid] = {
            'WorkloadID': 'W10S', 'VariantIdentity': 'generated rcS used',
            'Binary': file_info(C.REPO / 'workloads/mmu/W10S/mmu_w10s',
                                'workload ELF'),
            'Source': file_info(C.REPO / 'workloads/mmu/W10S/mmu_w10s.c',
                                'workload C source'),
            'RuntimeScript': file_info(rcs, 'generated rcS'),
            'RuntimeScriptEmbeddedPayloadSHA256': emb or '',
            'RuntimeScriptEmbeddedPayloadSize': size or '',
        }

    # --- per-sample identity chain ------------------------------------------
    sample_rows = []
    for sid in sids:
        m = matrix[sid]
        man = C.manifest(sid)
        rcs_source = C.repr_path(man['rcs_source'])
        emb, emb_size = extract_payload_hash(rcs_source)
        wb = C.repr_path(man['workload_binary'])
        row = {
            'SampleRunID': sid,
            'ModelID': m['ModelID'],
            'ContextID': m['ContextID'],
            'MatrixWorkloadID': m['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'RunWorkload': man.get('run_workload', ''),
            'MatrixWorkloadSHA256': m['WorkloadSHA256'],
            'ManifestWorkloadBinary': str(wb),
            'ManifestWorkloadSHA256': man.get('workload_sha256', ''),
            'ManifestHashEqualsFile': (C.sha256_file(wb)
                                       if wb.is_file() else '') ==
                                      man.get('workload_sha256', ''),
            'RcsSource': str(rcs_source),
            'RcsSourceSHA256': (C.sha256_file(rcs_source)
                                if rcs_source.is_file() else ''),
            'RcsEmbeddedPayloadSHA256': emb or '',
            'RcsEmbeddedPayloadSize': emb_size or '',
            'MatrixHashEqualsEmbedded': (m['WorkloadSHA256'] == emb) if emb
                                        else None,
            'ExecutedGuestBinarySHA256': '',
            'ExecutedGuestIdentitySource': '',
            'SemanticConsistency': '',
            'Disposition': '',
            'Notes': '',
        }
        if sid.startswith('M01'):
            # mmu_w9_run.rcS executes /root/mmu_w9 from the disk image.
            install = C.REPO / 'configs/fs/mmu_w9.rcS'
            install_hash, _ = extract_payload_hash(install)
            row['ExecutedGuestBinarySHA256'] = install_hash
            row['ExecutedGuestIdentitySource'] = (
                'disk-image /root/mmu_w9; install payload %s = %s' %
                (install, install_hash))
            row['SemanticConsistency'] = (
                'MATRIX_HASH_IDENTIFIES_A_DIFFERENT_BUILD')
            row['Disposition'] = 'FIELD_SEMANTICS_MISMATCH'
            row['Notes'] = ('matrix WorkloadSHA256=%s is the mmu_rev build; '
                            'executed guest is the live build %s'
                            % (m['WorkloadSHA256'], install_hash))
        else:
            row['ExecutedGuestBinarySHA256'] = emb or ''
            row['ExecutedGuestIdentitySource'] = (
                'rcS embedded payload %s' % rcs_source)
            match = (row['ExecutedGuestBinarySHA256'] ==
                     m['WorkloadSHA256'])
            row['SemanticConsistency'] = ('MATCH' if match
                                          else 'MISMATCH')
            row['Disposition'] = ('OK' if match
                                  else 'NEEDS_REVIEW')
        sample_rows.append(row)

    # --- direct evidence for the W9 executed binary -------------------------
    disk = C.sample_dir('M01-F0-W9-S01-R01') / 'disk.img'
    live_fmt = b'vec0=0x%02x result=%s'
    rev_fmt = b'vec0=0x%02x consumer_result=0x%02x result=%s'
    w9_c_notes = []
    for label, p in [('live', C.REPO / 'workloads/mmu/W9/mmu_w9.c'),
                     ('rev', C.REPO / 'workloads/mmu_rev/W9/mmu_w9.c')]:
        src = p.read_text(errors='replace')
        w9_c_notes.append({
            'source': str(p), 'sha256': C.sha256_file(p),
            'contains_consumer_result': 'consumer_result' in src,
            'format_line': next((ln.strip() for ln in src.splitlines()
                                 if 'result=' in ln and 'printf' in ln), ''),
        })
    evidence = {
        'w9_golden_output_has_consumer_result': any(
            'consumer_result' in C.observed_output(sid)
            for sid in sids if sid.startswith('M01')),
        'disk_image': str(disk),
        'disk_contains_live_format_string': contains_bytes(disk, live_fmt),
        'disk_contains_rev_format_string': contains_bytes(disk, rev_fmt),
        'live_format_string': live_fmt.decode(),
        'rev_format_string': rev_fmt.decode(),
        'w9_sources': w9_c_notes,
    }

    # --- W10S legality -----------------------------------------------------
    freeze_json = C.REPO / 'phase3/freeze/authority/MMU_Formal_Config.json'
    freeze_yaml = C.REPO / 'phase3/freeze/authority/MMU_Formal_Config.yaml'
    w10s = {
        'freeze_config_json': str(freeze_json),
        'freeze_config_json_sha256': (C.sha256_file(freeze_json)
                                      if freeze_json.exists() else ''),
        'freeze_config_yaml': str(freeze_yaml),
        'freeze_config_yaml_sha256': (C.sha256_file(freeze_yaml)
                                      if freeze_yaml.exists() else ''),
        'documented_variants': {},
        'formal_workloads': [],
        'matrix_rows': [],
        'source_diff': {},
    }
    if freeze_json.exists():
        fj = C.load_json(freeze_json)
        w10s['documented_variants'] = fj.get('workload_variant', {})
        w10s['formal_workloads'] = fj.get('workloads', [])
        w10s['workload_sha256'] = fj.get('workload_sha256', {})
        w10s['w9_executed_install_sha256'] = fj.get(
            'W9_executed_install_sha256')
        w10s['w9_note'] = fj.get('W9_note', '')
    for sid in ('M06-F0-W10-S01-R02', 'M08-F0-W10-S01-R05'):
        m = matrix[sid]
        man = C.manifest(sid)
        w10s['matrix_rows'].append({
            'SampleRunID': sid, 'WorkloadID': m['WorkloadID'],
            'AccessMode': m['AccessMode'], 'TargetVA': m['TargetVA'],
            'Variant': man.get('workload_variant'),
            'WorkloadSHA256': m['WorkloadSHA256'],
            'ControlOracle': man.get('control_run', ''),
        })
    w10_c = C.REPO / 'workloads/mmu/W10/mmu_w10.c'
    w10s_c = C.REPO / 'workloads/mmu/W10S/mmu_w10s.c'
    w10s['source_diff'] = {
        'W10_source': file_info(w10_c, 'W10 C source'),
        'W10S_source': file_info(w10s_c, 'W10S C source'),
        'differ': (C.sha256_file(w10_c) != C.sha256_file(w10s_c)),
    }

    report = {
        'workload_identities': workloads,
        'sample_identity_chain': sample_rows,
        'w9_execution_evidence': evidence,
        'w10s_variant_legality': w10s,
        'field_definitions': [
            {'Field': 'WorkloadSourceSHA256',
             'Definition': 'SHA256 of the frozen workload C source',
             'CurrentSource': 'not recorded per sample (computable)',
             'ExampleW9': (C.sha256_file(C.REPO /
                                         'workloads/mmu/W9/mmu_w9.c'))},
            {'Field': 'WorkloadBinarySHA256',
             'Definition': ('SHA256 of the preflight-selected canonical ELF '
                            '(what the current WorkloadSHA256 records)'),
             'CurrentSource': 'sample_manifest.workload_sha256',
             'ExampleW9': W9_MATRIX},
            {'Field': 'RuntimeScriptSHA256',
             'Definition': 'SHA256 of the rcS actually supplied to gem5',
             'CurrentSource': 'computable from rcs_source / rcS.scoped',
             'ExampleW9': C.sha256_file(
                 C.REPO / 'configs/fs/mmu_w9_run.rcS')},
            {'Field': 'WorkloadVariant',
             'Definition': ('Internal variant that keeps the authoritative '
                            'WorkloadID unchanged (W10S-COLD-STORE, ...)'),
             'CurrentSource': 'sample_manifest.workload_variant',
             'ExampleW9': 'W9'},
            {'Field': 'ExecutedGuestBinarySHA256',
             'Definition': ('SHA256 of the ELF actually executed inside the '
                            'guest (disk /root binary or rcS payload)'),
             'CurrentSource': 'computable: rcS embedded payload / W9 install',
             'ExampleW9': W9_LIVE},
        ],
        'documentation_defects': [
            {'path': str(C.REPO / 'phase3/final/'
                         'MMU_Final_40_Sample_Runner_Describe_Audit_Package_v2/'
                         'MMU_Final_Provenance.txt'),
             'defect': ('labels ec5256.. with the live workloads/mmu/W9 path; '
                        'the file at that path hashes to 4f3ddb..'),
             'correct_path_for_ec5256': str(C.REPO /
                 'workloads/mmu_rev/W9/Binary/mmu_w9')},
            {'path': str(freeze_json),
             'defect': ('W9_note states both builds are "the same W9 '
                        'source"; the two .c files and ELFs differ'),
             'quote': w10s.get('w9_note', '')},
        ],
    }
    C.write_json(C.AUDIT / 'Workload_SHA256_Reconciliation.json', report)

    rows = []
    for r in sample_rows:
        rows.append(r)
    C.write_csv(C.AUDIT / 'Workload_Sample_Identity_Chain.csv', rows)

    id_rows = []
    for key, wl in workloads.items():
        for role in ('Binary', 'Source', 'RuntimeScript'):
            fi = wl[role]
            if not fi['Exists']:
                continue
            id_rows.append({
                'WorkloadID': wl['WorkloadID'],
                'VariantIdentity': wl['VariantIdentity'],
                'FileRole': role,
                'Path': fi['Path'],
                'SizeBytes': fi['SizeBytes'],
                'SHA256': fi['SHA256'],
                'EmbeddedPayloadSHA256':
                    wl.get('RuntimeScriptEmbeddedPayloadSHA256', ''),
                'Notes': fi['Notes'],
            })
    C.write_csv(C.AUDIT / 'Workload_Hash_Identity.csv', id_rows)

    md = ['# Workload SHA256 Consistency Report\n\n',
          'All hashes below were recomputed with `sha256sum` / Python '
          '`hashlib` on the real files; rcS payloads were base64-decoded and '
          'gunzipped.\n\n',
          '## Bottom line\n\n',
          '| Hash | Physical identity | Not |\n|---|---|---|\n',
          '| `%s` | `workloads/mmu_rev/W9/Binary/mmu_w9` (canonical rev '
          'build, what the matrix records) | not the executed guest binary; '
          'not the rcS file hash |\n' % W9_MATRIX,
          '| `%s` | `workloads/mmu/W9/mmu_w9` (live build; embedded in '
          '`configs/fs/mmu_w9.rcS` and installed at `/root/mmu_w9`) | not '
          'the hash recorded in the matrix |\n' % W9_LIVE,
          '| `%s` | `workloads/mmu/W10S/mmu_w10s` (embedded in both '
          'generated W10S rcS) | not the rcS file hash |\n\n' % W10S_HASH,
          '## W9: both hashes are real, but they are different builds\n\n',
          '- Matrix/manifest `WorkloadSHA256` = `%s` = the preflight-selected '
          'canonical rev build (`workloads/mmu_rev/W9/Binary/mmu_w9`).\n' %
          W9_MATRIX,
          '- Frozen campaign provenance (`provenance.json/md`) = `%s` = the '
          'live build (`workloads/mmu/W9/mmu_w9`), path-correct.\n' %
          W9_LIVE,
          '- The two `.c` sources differ: live `%s` (no `consumer_result`) '
          'vs rev `%s` (adds `consumer_result`). The two ELFs differ.\n' % (
              evidence['w9_sources'][0]['sha256'],
              evidence['w9_sources'][1]['sha256']),
          '- Executed guest evidence: `configs/fs/mmu_w9.rcS` embeds `%s`; '
          'the frozen guest output has no `consumer_result` field; a direct '
          'byte scan of a formal `disk.img` contains the live format string '
          '`%s` and does **not** contain the rev format string `%s`.\n' % (
              W9_LIVE, evidence['live_format_string'],
              evidence['rev_format_string']),
          '- Therefore `WorkloadSHA256` in the frozen matrix means '
          '*"preflight-selected canonical ELF"*, **not** *"executed guest '
          'binary"*. For the five M01 samples it does not identify the ELF '
          'that produced the observed output.\n',
          '- This is a provenance-field limitation, not an execution '
          'divergence: the M01 fault targets the TLB, and the oracle '
          'comparison uses the output of the executed live build against '
          'the independent control. No result is reclassified here.\n\n',
          '## W10S is a legal internal variant of W10\n\n',
          '- Authority WorkloadID stays `W10`; the two samples are '
          '`W10S-COLD-STORE` (M06/R02) and `W10S-WARM-STORE` (M08/R05), '
          'access mode Write, documented in '
          '`phase3/freeze/authority/MMU_Formal_Config.json` and in '
          '`mmu_formal_preflight.py` `W10S_VARIANTS`.\n',
          '- The executed rcS embeds `%s`, which matches the matrix '
          '`WorkloadSHA256` exactly; the two W10S sample records are '
          'semantically consistent.\n' % W10S_HASH,
          '- The formal workload list contains six IDs (W9-W14); W10S is '
          'deliberately not a formal WorkloadID.\n\n',
          '## Recommended field split (no original field modified)\n\n',
          '| Proposed field | Definition |\n|---|---|\n']
    for fd in report['field_definitions']:
        md.append('| `%s` | %s; currently: %s |\n' % (
            fd['Field'], fd['Definition'], fd['CurrentSource']))
    md.append('\n## Documentation defects found\n\n')
    for d in report['documentation_defects']:
        md.append('- `%s`: %s\n' % (d['path'], d['defect']))
    md.append('\n## Sample dispositions\n\n')
    dispo = {}
    for r in sample_rows:
        dispo[r['Disposition']] = dispo.get(r['Disposition'], 0) + 1
    md.append('`%s`\n\n' % json.dumps(dispo))
    md.append('The 5 `FIELD_SEMANTICS_MISMATCH` rows are exactly the five '
              'M01/W9 samples; the other 35 rows match the executed rcS '
              'payload. `mmu_formal_validate.py` does not verify '
              '`workload_sha256`; the runner does via its frozen table, '
              'which is why the matrix is internally consistent while '
              'still naming a different W9 build from the executed one.\n\n')
    md.append('## Verdict\n\n')
    md.append('`WORKLOAD_HASH_AUDIT = EXPLAINED_WITH_DOCUMENTED_LIMITATION`. '
              'W9 field semantics are now split into '
              'WorkloadSourceSHA256 / WorkloadBinarySHA256 / '
              'RuntimeScriptSHA256 / WorkloadVariant; W10S is a documented '
              'legal variant. Original SampleRunID and WorkloadID values are '
              'unchanged.\n')
    (C.AUDIT / 'Workload_SHA256_Consistency_Report.md').write_text(''.join(md))

    print(json.dumps({
        'w9_matrix_hash': W9_MATRIX,
        'w9_executed_hash': W9_LIVE,
        'w9_executed_evidence': evidence,
        'w9_sources': w9_c_notes,
        'sample_dispositions': dict(
            (r['SampleRunID'], r['Disposition']) for r in sample_rows),
        'w10s_documented_variants': w10s.get('documented_variants'),
        'w10s_formal_workloads': w10s.get('formal_workloads'),
        'w10s_rows': w10s['matrix_rows'],
    }, indent=1))


if __name__ == '__main__':
    main()
