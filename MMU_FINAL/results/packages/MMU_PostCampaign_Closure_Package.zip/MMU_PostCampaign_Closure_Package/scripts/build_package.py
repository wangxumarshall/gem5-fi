#!/usr/bin/env python3
"""Build the evidence index, provenance, SHA256 manifest and final ZIP.

Writes only under post_campaign_closure/ (plus the ZIP at the campaign root).
"""
import csv
import datetime
import gzip
import hashlib
import json
import os
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

ZIP_NAME = 'MMU_PostCampaign_Closure_Package.zip'


def sha(p):
    return C.sha256_file(p)


def walk_files(root, exclude_dirs=(), exclude_names=()):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root)
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for fn in sorted(filenames):
            if fn in exclude_names:
                continue
            p = Path(dirpath) / fn
            out.append((p, str(rel_dir / fn)))
    return sorted(out, key=lambda x: x[1])


def build_result_matrix():
    audit = json.load(open(C.AUDIT / 'MMU_40_Sample_Final_Audit.json'))
    fd = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    feat = {f['identity']['SampleRunID']: f for f in fd['samples']}
    rows = []
    for s in audit['samples']:
        sid = s['SampleRunID']
        f = feat[sid]
        rows.append({
            'SampleRunID': sid,
            'ModelID': s['ModelID'],
            'ContextID': s['ContextID'],
            'WorkloadID': s['WorkloadID'],
            'WorkloadVariant': s['WorkloadVariant'],
            'AttemptID': s['AttemptID'],
            'FaultID': s['fields']['FaultID']['values'].get('matrix_csv'),
            'ActivationStatus': s['fields']['InjectionStatus']['values'].get(
                'matrix_csv'),
            'FaultConsumptionStatus': s['fields'][
                'FaultConsumptionStatus']['values'].get('matrix_csv'),
            'PropagationStatus': s['fields']['PropagationStatus']['values'].get(
                'matrix_csv'),
            'TerminalState': s['fields']['TerminalState']['values'].get(
                'matrix_csv'),
            'OracleResult': s['fields']['OracleResult']['values'].get(
                'matrix_csv'),
            'TraceCompleteness': s['fields']['TraceCompleteness']['values'].get(
                'matrix_csv'),
            'RecordIntegrity': s['fields']['RecordIntegrity']['values'].get(
                'matrix_csv'),
            'ManifestationTypePrimary':
                f['terminal']['ManifestationTypePrimary'],
            'ManifestationTypeSecondary':
                f['terminal']['ManifestationTypeSecondary'],
            'DetectionStatus': f['terminal']['DetectionStatus'],
            'SquashStatus': f['terminal']['SquashStatus'],
            'MaskingStatus': f['terminal']['MaskingStatus'],
            'TargetVA': f['fault_origin']['TargetVA'],
            'AccessMode': f['activation']['AccessMode'],
            'ActivationEventID': f['activation']['ActivationEventID'],
            'ConsumptionEventID': f['evidence']['ConsumptionEventID'],
            'ChainEventCount': f['propagation_path']['ChainEventCount'],
            'StableModelSignature':
                f['diagnostic_signature']['StableModelSignature'],
            'TraceSHA256': f['evidence']['TraceSHA256'],
            'AuditVerdict': s['sample_audit_verdict'],
        })
    C.write_csv(C.AUDIT / 'MMU_40_Sample_Final_Result_Matrix.csv', rows)
    # workbook form of the same matrix
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Result_Matrix'
    ws.append(list(rows[0].keys()))
    ws['A1'].font = Font(bold=True)
    for r in rows:
        ws.append([r.get(k, '') for k in rows[0].keys()])
    ws.freeze_panes = 'B2'
    wb.save(C.AUDIT / 'MMU_40_Sample_Final_Result_Matrix.xlsx')
    return rows


def build_combined_events():
    fd = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    rows = []
    for f in fd['samples']:
        sid = f['identity']['SampleRunID']
        for tr in f['microarchitectural_state_transitions']:
            row = dict(tr)
            row['SampleRunID'] = sid
            row['ModelID'] = f['identity']['ModelID']
            row['ContextID'] = f['identity']['ContextID']
            rows.append(row)
    fields = ['SampleRunID', 'ModelID', 'ContextID', 'EventID',
              'ParentEventID', 'Kind', 'Tick', 'TranslationID', 'EntryID',
              'EntryGeneration', 'DynamicInstSeqNum', 'VA', 'PA',
              'Field', 'Before', 'After', 'StateBefore', 'StateAfter',
              'Outcome', 'SquashStatus']
    extra = []
    for r in rows:
        for k in r:
            if k not in fields and k not in extra:
                extra.append(k)
    C.write_csv(C.FEAT / 'Propagation_Chain_Events.csv', rows,
                fields + sorted(extra))
    return len(rows)


def build_trace_index(attempt_rows):
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    chain_d = C.ANALYSIS / 'propagation_chains'
    rows = []
    disk_hash = None
    for sid in sorted(matrix):
        rdir = C.sample_dir(sid)
        scan = C.scan_cache(sid)
        ver = C.verdict(sid)
        if disk_hash is None:
            disk_hash = C.sha256_file(rdir / 'disk.img')
        files = {
            'Trace': rdir / 'Trace/prop_evt.txt.gz',
            'Verdict': rdir / 'Validation/verdict.json',
            'Manifest': rdir / 'sample_manifest.json',
            'ObservedOutput': rdir / 'Run_Log/observed_output.txt',
            'GameOutput': rdir / 'Run_Log/board.terminal',
            'ChainJSON': chain_d / ('%s.json' % sid),
            'DiskImage': rdir / 'disk.img',
        }
        row = {
            'SampleRunID': sid,
            'AttemptID': matrix[sid]['AttemptID'],
            'ModelID': matrix[sid]['ModelID'],
            'ContextID': matrix[sid]['ContextID'],
            'TraceAbsolutePath': scan['TraceAbsolutePath'],
            'TraceSizeBytes': scan['TraceSizeBytes'],
            'TraceSHA256': scan['TraceSHA256'],
            'TraceEventCount': scan['EventCount'],
            'FaultTaggedEventCount': scan['FaultTaggedEventCount'],
            'SelectionCapped': scan['SelectionCapped'],
            'ChainEventCount': scan['ChainEventCount'],
            'ChainJoinMismatches': len(scan['ChainJoinMismatches']),
            'TraceCompleteness': ver['TraceCompleteness'],
            'RecordIntegrity': ver['RecordIntegrity'],
            'VerdictAbsolutePath': str(files['Verdict']),
            'VerdictSHA256': sha(files['Verdict']),
            'ManifestAbsolutePath': str(files['Manifest']),
            'ManifestSHA256': sha(files['Manifest']),
            'ObservedOutputAbsolutePath': str(files['ObservedOutput']),
            'ObservedOutputSHA256': sha(files['ObservedOutput']),
            'BoardTerminalAbsolutePath': str(files['GameOutput']),
            'BoardTerminalSHA256': sha(files['GameOutput']),
            'ChainJSONAbsolutePath': str(files['ChainJSON']),
            'ChainJSONSHA256': sha(files['ChainJSON']),
            'DiskImageAbsolutePath': str(files['DiskImage']),
            'DiskImageSizeBytes': files['DiskImage'].stat().st_size,
            'DiskImageSHA256': disk_hash,
            'AttemptStatus': 'COMPLETED_FINAL',
        }
        rows.append(row)
    # interrupted A01 traces
    for r in attempt_rows:
        if r['Status'] == 'INTERRUPTED_PARTIAL':
            rows.append({
                'SampleRunID': r['SampleRunID'],
                'AttemptID': r['AttemptID'],
                'ModelID': r['SampleRunID'].split('-')[0],
                'ContextID': r['SampleRunID'].split('-')[-1],
                'TraceAbsolutePath': r['TracePath'],
                'TraceSizeBytes': r['TraceBytes'],
                'TraceSHA256': r['TraceSHA256'],
                'TraceEventCount': r['TraceEventCount'],
                'FaultTaggedEventCount': '',
                'SelectionCapped': '',
                'ChainEventCount': '',
                'ChainJoinMismatches': '',
                'TraceCompleteness': 'INCOMPLETE',
                'RecordIntegrity': 'INTERRUPTED',
                'VerdictAbsolutePath': '',
                'VerdictSHA256': '',
                'ManifestAbsolutePath': '',
                'ManifestSHA256': '',
                'ObservedOutputAbsolutePath': '',
                'ObservedOutputSHA256': '',
                'BoardTerminalAbsolutePath': '',
                'BoardTerminalSHA256': '',
                'ChainJSONAbsolutePath': '',
                'ChainJSONSHA256': '',
                'DiskImageAbsolutePath': '',
                'DiskImageSizeBytes': '',
                'DiskImageSHA256': '',
                'AttemptStatus': 'INTERRUPTED_PARTIAL',
                'TraceTruncated': r['TraceTruncated'],
            })
    fields = list(rows[0].keys())
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    C.write_csv(C.EVID / 'Trace_Index.csv', rows, fields)
    return rows


def build_provenance():
    man = C.manifest('M01-F0-W9-S01-R01')
    source_files = [
        'CHAOS/gem5/src/arch/arm/mmu.cc',
        'CHAOS/gem5/src/arch/arm/table_walker.cc',
        'CHAOS/gem5/src/arch/arm/table_walker.hh',
        'CHAOS/gem5/src/arch/arm/tlb.cc',
        'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.cc',
        'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.hh',
    ]
    recorded = {}
    sums = (C.sample_dir('M01-F0-W9-S01-R01') / 'SHA256' /
            'SHA256SUMS.txt').read_text().splitlines()
    for line in sums:
        parts = line.split(None, 1)
        if len(parts) == 2 and parts[1].startswith('source:'):
            recorded[parts[1][len('source:'):]] = parts[0]
    sources = []
    for rel in source_files:
        p = C.REPO / rel
        sources.append({'Path': rel, 'AbsolutePath': str(p),
                        'SizeBytes': p.stat().st_size if p.exists() else '',
                        'SHA256': sha(p) if p.exists() else '',
                        'RecordedSHA256': recorded.get(rel, ''),
                        'Match': (sha(p) == recorded.get(rel)) if p.exists()
                                 else False})
    checkpoint = Path(man['checkpoint'])
    ckpt_files = []
    if checkpoint.is_dir():
        for p in sorted(checkpoint.rglob('*')):
            if p.is_file():
                ckpt_files.append({'RelativePath': str(p.relative_to(
                    checkpoint)), 'SizeBytes': p.stat().st_size,
                    'SHA256': sha(p)})
    kernel = C.REPO / 'gem5-fs/vmlinux'
    boot = C.REPO / 'gem5-fs/boot.arm64'
    authority = C.PKG / 'authority'
    runner_dir = C.PKG / 'runner'
    wl = list(csv.DictReader(open(C.AUDIT / 'Workload_Hash_Identity.csv')))
    rec = json.load(open(C.AUDIT / 'Workload_SHA256_Reconciliation.json'))
    prov = {
        'generated_utc': datetime.datetime.utcnow().isoformat() + 'Z',
        'campaign_id': 'MMU-FORMAL-20261113',
        'frozen_binary': {
            'AbsolutePath': str(C.REPO /
                                'CHAOS/gem5/build/ARM/gem5.opt'),
            'SizeBytes': (C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt'
                          ).stat().st_size,
            'SHA256': sha(C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt'),
            'RecordedInAll40Samples': man.get('gem5_sha256'),
            'Match': (sha(C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt') ==
                      man.get('gem5_sha256')),
        },
        'gem5_source_files': sources,
        'kernel': {'AbsolutePath': str(kernel),
                   'SizeBytes': kernel.stat().st_size,
                   'SHA256': sha(kernel)} if kernel.exists() else {},
        'bootloader': {'AbsolutePath': str(boot),
                       'SizeBytes': boot.stat().st_size,
                       'SHA256': sha(boot)} if boot.exists() else {},
        'checkpoint': {'AbsolutePath': str(checkpoint),
                       'Exists': checkpoint.is_dir(),
                       'FileCount': len(ckpt_files),
                       'TotalBytes': sum(f['SizeBytes'] for f in ckpt_files),
                       'Files': ckpt_files},
        'disk_image_template': {
            'AbsolutePath': str(C.sample_dir('M01-F0-W9-S01-R01') /
                                'disk.img'),
            'SizeBytes': (C.sample_dir('M01-F0-W9-S01-R01') /
                          'disk.img').stat().st_size,
            'SHA256': sha(C.sample_dir('M01-F0-W9-S01-R01') / 'disk.img'),
            'Note': 'identical recorded hash in all 40 SHA256SUMS'},
        'runtime_scripts': [{'Path': r['Path'], 'SHA256': r['SHA256'],
                             'WorkloadID': r['WorkloadID'],
                             'Variant': r['VariantIdentity']} for r in wl
                            if r['FileRole'] == 'RuntimeScript'],
        'workload_binaries_and_sources': wl,
        'executed_guest_identity': {
            'W9_matrix_hash': rec['sample_identity_chain'][0][
                'MatrixWorkloadSHA256'],
            'W9_executed_hash': rec['sample_identity_chain'][0][
                'ExecutedGuestBinarySHA256'],
            'W9_evidence': rec['w9_execution_evidence'],
            'W10S_hash': rec['sample_identity_chain'][-1][
                'MatrixWorkloadSHA256'],
        },
        'authority': [{
            'AbsolutePath': str(p), 'SizeBytes': p.stat().st_size,
            'SHA256': sha(p)} for p in sorted(authority.rglob('*'))
            if p.is_file()],
        'campaign_runner': [{
            'AbsolutePath': str(p), 'SizeBytes': p.stat().st_size,
            'SHA256': sha(p)} for p in sorted(runner_dir.rglob('*'))
            if p.is_file()],
        'original_results_zip': {
            'AbsolutePath': str(C.CAMP / ZIP_NAME.replace(
                'MMU_PostCampaign', 'MMU_Final_Formal_Campaign_Results')),
            'SHA256': sha(C.CAMP /
                          'MMU_Final_Formal_Campaign_Results_Package.zip'),
            'Note': 'original frozen results package; unchanged by this work',
        },
        'original_campaign_summary_sha256': sha(
            C.ANALYSIS / 'final_summary.json'),
    }
    C.write_json(C.EVID / 'Provenance_Binary_Source_Workload.json', prov)

    md = ['# Binary / Source / Workload Provenance\n\n',
          '## Frozen gem5 binary\n\n',
          '- Path: `%s`\n' % prov['frozen_binary']['AbsolutePath'],
          '- Size: %s bytes\n' % prov['frozen_binary']['SizeBytes'],
          '- SHA256: `%s`\n' % prov['frozen_binary']['SHA256'],
          '- Equals all 40 sample `BinarySHA256`: **%s**\n\n' %
          prov['frozen_binary']['Match'],
          '## Source files (verified against the per-sample SHA256SUMS)\n\n',
          '| File | SHA256 | Recorded | Match |\n|---|---|---|---|\n']
    for s in sources:
        md.append('| `%s` | `%s` | `%s` | %s |\n' % (
            s['Path'], s['SHA256'], s['RecordedSHA256'], s['Match']))
    md.append('\n## Checkpoint / kernel / bootloader\n\n')
    md.append('- Checkpoint: `%s` (%d files, %d bytes)\n' % (
        prov['checkpoint']['AbsolutePath'], prov['checkpoint']['FileCount'],
        prov['checkpoint']['TotalBytes']))
    if prov.get('kernel'):
        md.append('- Kernel `%s`: `%s`\n' % (
            prov['kernel']['AbsolutePath'], prov['kernel']['SHA256']))
    if prov.get('bootloader'):
        md.append('- Bootloader `%s`: `%s`\n' % (
            prov['bootloader']['AbsolutePath'],
            prov['bootloader']['SHA256']))
    md.append('\nFull per-file checkpoint hashes are in the JSON.\n\n')
    md.append('## Workload identities\n\n')
    md.append('| Workload | Variant | Role | Path | SHA256 |\n'
              '|---|---|---|---|---|\n')
    for r in wl:
        md.append('| %s | %s | %s | `%s` | `%s` |\n' % (
            r['WorkloadID'], r['VariantIdentity'], r['FileRole'],
            r['Path'], r['SHA256']))
    md.append('\n## Executed guest identity\n\n')
    md.append('- W9 matrix hash `%s` identifies the mmu_rev build; the '
              'executed guest is the live build `%s` (rcS payload, disk '
              'image bytes, and output format all agree).\n' % (
                  prov['executed_guest_identity']['W9_matrix_hash'],
                  prov['executed_guest_identity']['W9_executed_hash']))
    md.append('- W10S executed hash matches the matrix: `%s`.\n\n' %
              prov['executed_guest_identity']['W10S_hash'])
    md.append('## Original frozen artifacts (unchanged)\n\n')
    md.append('- Original results ZIP: `%s`\n' % (
        prov['original_results_zip']['AbsolutePath']))
    md.append('  SHA256 `%s`\n' % prov['original_results_zip']['SHA256'])
    md.append('- Original `analysis/final_summary.json` SHA256 `%s`\n' %
              prov['original_campaign_summary_sha256'])
    md.append('\nNo original campaign file was modified by this work.\n')
    (C.EVID / 'Provenance_Binary_Source_Workload.md').write_text(''.join(md))
    return prov


def build_acceptance():
    audit = json.load(open(C.AUDIT / 'MMU_40_Sample_Final_Audit.json'))
    m07 = json.load(open(C.AUDIT / 'M07_Terminal_Semantics_Audit.json'))
    ctl = json.load(open(C.AUDIT / 'Control_Audit.json'))
    att = json.load(open(C.AUDIT / 'Attempt_Audit.json'))
    wl = json.load(open(C.AUDIT / 'Workload_SHA256_Reconciliation.json'))
    fl = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    sdc = m07['sdc_audit']
    lines = ['# Acceptance Answers\n\n',
             '## 1. Are all 40 formal samples retained?\n\n',
             'Yes. 40 unique SampleRunIDs, 5 contexts for each of M01-M08, '
             'zero missing. The A02 retries are the adopted records for '
             'M06-R04 and M08-R04; the interrupted A01 directories are '
             'preserved. See `audit/MMU_40_Sample_Final_Audit.csv` and '
             '`audit/Attempt_History.csv`.\n\n',
             '## 2. Were the 31 SDC terminal classifications semantically '
             'audited?\n\n',
             'Yes. 31/31 are `CONFIRMED_SDC` by a software-visible oracle '
             'difference (wrong value or permission bypass), a control '
             'difference, complete trace and `wrong_value_proven`. Primary '
             'manifestations: %s. Original TerminalState values were not '
             'overwritten. See `audit/SDC_Semantic_Audit.csv`.\n\n' %
             json.dumps({k: sum(1 for r in sdc
                                if r['ManifestationTypePrimary'] == k)
                         for k in sorted({r['ManifestationTypePrimary']
                                          for r in sdc})}),
             '## 3. Does M07 distinguish data corruption from permission '
             'bypass?\n\n',
             'Yes. R01/R02 = UNAUTHORIZED_WRITE (+ permission bypass, + '
             'shared-memory mutation), R03 = UNAUTHORIZED_READ, R04/R05 = '
             'UNAUTHORIZED_EXECUTION. There is no WRONG_DATA_VALUE in M07: '
             '`value_ok=1` and observed == expected in all five. The control '
             'gets SIGSEGV + permission fault; the faulted run has no '
             'exception. R02 has no permission_eval joined to its activation '
             '(`translation_id=7`); the nearest same-VA deny is event 345 on '
             '`translation_id=5`, reported explicitly rather than hidden. '
             'See `audit/M07_Terminal_Semantics_Audit.md`.\n\n',
             '## 4. Is the basis for the 28 shared controls explicit?\n\n',
             'Yes. 40 fault references -> 28 distinct oracle files; 34 '
             'control run directories exist, 6 are duplicate/superseded and '
             'unreferenced. All 40 references pass oracle-hash, workload, '
             'context and zero-injection checks. The frozen approval evidence '
             'is `%s` (`CONTROL_INVENTORY_VERDICT = RECONCILED`). See '
             '`audit/Control_Sharing_Audit.md`.\n\n' %
             ctl['approval']['path'],
             '## 5. Are the W9/W10/W10S hash differences explained?\n\n',
             'Yes. W9 matrix `ec525687...` is the `mmu_rev` build; the '
             'executed guest is the live build `4f3ddbf2...`. The two `.c` '
             'sources differ (the rev adds `consumer_result`); the disk image '
             'contains the live format string and not the rev one; the guest '
             'output has no `consumer_result`. W10S `fede5f3e...` is the '
             'executed payload and matches the matrix; W10S-COLD-STORE / '
             'W10S-WARM-STORE are documented internal variants while the '
             'authoritative WorkloadID stays W10. See '
             '`audit/Workload_SHA256_Consistency_Report.md`.\n\n',
             '## 6. Are both interrupted attempts fully preserved?\n\n',
             'Yes. `attempt_A01/M06-F0-W10-S01-R04` and '
             '`attempt_A01/M08-F0-W10-S01-R04` are intact partial directories '
             '(no manifest/verdict/SHA256SUMS, truncated traces with 308 and '
             '174 events, 0-byte stats). A02 is the completed adopted attempt '
             'in both cases. Verified counts: 40 unique samples, 40 completed '
             'final attempts, 2 interrupted attempts, 42 attempt directories. '
             'See `audit/Attempt_Audit.md`.\n\n',
             '## 7. Are the 40 propagation chains traceable to the raw '
             'traces?\n\n',
             'Yes. Every chain EventID was re-read from the raw '
             '`prop_evt.txt.gz`; 0/40 samples have a join mismatch. The '
             'evidence index records absolute path, size and SHA256 for every '
             'trace and supporting file. See `evidence/Trace_Index.csv`.\n\n',
             '## 8. Does every model have a diagnostic signature?\n\n',
             'Yes. The feature library has per-sample origin, activation, '
             'state-transition, translation, propagation and terminal '
             'features plus a context-independent StableModelSignature. '
             'Stable-signature counts: %s. See '
             '`feature_library/Model_Propagation_Signatures.md`.\n\n' %
             json.dumps({m['ModelID']: m['DistinctStableSignatures']
                         for m in fl['model_signatures']}),
             '## 9. Which features distinguish the models?\n\n',
             'The discriminators are fault site + activation kind + the '
             'state-transition fields, not the shared downstream event kinds: '
             'M01 `tlbi_match`+`tlbi_suppressed`; M02 `refill_pfn_corrupt`; '
             'M03 foreign `candidate_asid`+`false_hit`; M04 resident '
             '`tlb_entry_lineage` with no PTW; M05 `partial_entry_insert`+'
             '`next_table_pa_before/after`; M06 `fault_state_consumed`+'
             '`fault_result_propagated`+`exception_delivery`; M07 '
             '`permission_before=false`->`permission_after=true`; M08 '
             '`request_pa_before/after` with PFN unchanged. Confusable pairs '
             'and separators are in `feature_library/'
             'Model_Propagation_Signatures.md`.\n\n',
             '## 10. Is the M01 vs real DTLB stale-translation boundary '
             'clear?\n\n',
             'Yes. Functional semantics = HIGH, propagation path = HIGH, '
             'diagnostic feature match = MEDIUM_TO_HIGH, but '
             'microarchitectural structure = LOW_TO_MEDIUM: gem5 M01 targets '
             'the `l2_shared` (unified L2) TLB, not the DTB. The mapping '
             'explicitly does not claim L2/unified == DTLB. No external '
             'erratum/CVE citation exists in the repository. See '
             '`real_case/RealCase_Mapping.md`.\n\n',
             '## 11. Is the repeatability matrix designed?\n\n',
             'Yes: 10 independent repeats covering M01-R01, M02-R02, '
             'M03-R01/R05, M04-R05, M05-R05, M06-R02, M07-R01/R05, M08-R01, '
             'each checked against the actual trace before selection. The '
             'plan is design-only; no new gem5 run was started. See '
             '`repeatability/MMU_Repeatability_Validation_Plan.md`.\n\n',
             '## 12. Can LSU and MMU map to the unified schema?\n\n',
             'Yes. 27 common fields, 63 retained MMU extension fields and 19 '
             'LSU extension fields; `TranslationID` is the cross-unit link. '
             'Schema meta-validation and representative MMU/LSU records all '
             'PASS. See `schema/ARM_CPU_SDC_Propagation_Schema_v1.json` and '
             '`schema/SCHEMA_VALIDATION.json`.\n\n',
             '## Final state\n\n',
             '`POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`\n']
    (C.OUT / 'ACCEPTANCE_ANSWERS.md').write_text(''.join(lines))


def build_readme_and_status():
    readme = '''# MMU Post-Campaign Closure Package

Campaign: `MMU-FORMAL-20261113`
Source status: `FORMAL_CAMPAIGN_COMPLETE_WITH_LIMITATIONS`
Closure status: `POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`

No gem5 experiment was started, no C++ hook, frozen binary, workload,
SampleRunID, trace, control or original result was modified.

## Contents

| Path | Deliverable |
|---|---|
| `audit/MMU_40_Sample_Final_Audit.{csv,json,md}` | 40-sample final audit |
| `audit/MMU_40_Sample_Final_Result_Matrix.{csv,xlsx}` | recomputed 40-sample result matrix |
| `audit/Workload_SHA256_Consistency_Report.md` | W9/W10/W10S hash analysis |
| `audit/Workload_Hash_Identity.csv` / `Workload_Sample_Identity_Chain.csv` | hash-to-file mapping |
| `audit/Control_Sharing_Audit.md` / `Control_Map.csv` / `Control_Sharing_Summary.csv` | 28-control sharing + zero-injection audit |
| `audit/Attempt_History.csv` / `Attempt_Audit.md` | A01/A02 history |
| `audit/M07_Terminal_Semantics_Audit.md` / `M07_Sample_Evidence.csv` | M07 semantics |
| `audit/SDC_Semantic_Audit.csv` | 31-SDC semantic audit |
| `feature_library/MMU_Diagnostic_Feature_Library.{xlsx,csv,json}` | diagnostic feature library |
| `feature_library/Model_Propagation_Signatures.md` | model-level signatures + discriminators |
| `feature_library/propagation_chains/<sid>.{json,csv}` | event-level propagation chains |
| `feature_library/Propagation_Chain_Events.csv` | all chain events combined |
| `real_case/RealCase_Mapping.{csv,md,json}` | real ARM DTLB case mapping |
| `repeatability/MMU_Repeatability_Validation_Plan.{xlsx,md}` | repeat design (not executed) |
| `schema/ARM_CPU_SDC_Propagation_Schema_v1.json` | unified MMU/LSU schema |
| `schema/MMU_to_Unified_Schema_Mapping.csv` / `LSU_to_Unified_Schema_Mapping.csv` | mappings |
| `schema/SCHEMA_VALIDATION.json` | schema validation evidence |
| `evidence/Trace_Index.csv` | absolute trace path, size, SHA256 |
| `evidence/Provenance_Binary_Source_Workload.{json,md}` | binary/source/workload provenance |
| `evidence/SHA256_MANIFEST.txt` | hash of every package file |
| `scripts/` | all generators (read-only over the frozen campaign) |
| `ACCEPTANCE_ANSWERS.md` | answers to the 12 acceptance questions |
| `FINAL_STATUS.md` | final status + limitations |

## Regeneration

Run in this order from this directory:

```
python3 scripts/scan_traces.py
python3 scripts/audit_samples.py
python3 scripts/audit_workload_hash.py
python3 scripts/audit_controls.py
python3 scripts/audit_attempts.py
python3 scripts/audit_m07.py
python3 scripts/build_features.py
python3 scripts/build_realcase_repeat.py
python3 scripts/build_schema.py
python3 scripts/validate_schema.py
python3 scripts/build_package.py
```

The scripts only read `/home/sdc/gem5-fi-mmu-impl-v2/runs/MMU_FORMAL_CAMPAIGN_20261113`
and its frozen siblings, and write under `post_campaign_closure/` (plus the
final ZIP at the campaign root).
'''
    (C.OUT / 'README.md').write_text(readme)

    status = '''# Final Status

`POST_CAMPAIGN_CLOSED_WITH_DOCUMENTED_LIMITATIONS`

## Closed

- 40/40 samples retained, 40/40 activated, 40/40 consumed, 40/40 trace
  COMPLETE, 40/40 record integrity PASS.
- 31 SDC, 4 SQUASHED, 5 DETECTED_CONTAINED confirmed from raw evidence.
- 28/28 controls zero-proven; 40/40 control references pass hash/workload/
  context checks; sharing approval documented.
- 40/40 propagation chains verified against raw traces with zero join
  mismatches.
- Diagnostic feature library, model signatures, discriminators and confusable
  pairs built.
- Real-case mapping, 10-repeat design and unified MMU/LSU schema delivered.

## Documented limitations (do not alter the counts)

1. **W9 `WorkloadSHA256` semantics**: the matrix records the canonical
   `mmu_rev` build `ec525687...`, while the executed guest is the live build
   `4f3ddbf2...`. The two sources differ. This is a provenance-field
   limitation, not an M01 result change. The field is split into
   WorkloadSourceSHA256 / WorkloadBinarySHA256 / RuntimeScriptSHA256 /
   WorkloadVariant.
2. **Real case**: researcher-supplied; no external erratum/CVE/trace
   citation exists. Functional/propagation match is high, but the gem5 target
   is `l2_shared`, not the DTB.
3. **M07 R02**: no `permission_eval` is joined to the activation
   (`translation_id=7`). The nearest same-VA deny is event 345 on
   `translation_id=5` (tick delta -2331), which the frozen validator does not
   associate. The deny is proven by
   `mmu_fault_activate(permission_before=false)` and the control SIGSEGV
   permission fault.
4. **M07 R04/R05**: fetch activation carries `translation_id=0`; downstream
   consumption is joined co-temporally by the frozen strict chain, never by
   event order.
5. **M04 trace tagging**: nearly all post-arm events carry `fault_id=1`.
   Feature extraction anchors on the activation translation/VA and the frozen
   chain; non-chain selection is capped at 5000 events (R01-R04). Chain joins
   remain 0-mismatch.
6. **IFU nodes**: per the campaign report, some per-instruction IFU
   fetch/decode nodes are not emitted by the frozen binary; they are listed
   as `NodesNotEmittedByFrozenBinary`, not fabricated.
7. **A01 retries**: the interrupted A01 directories are preserved but are not
   independent repeats and contain truncated traces.
8. **ManifestationType** is a diagnostic dimension added by this audit; the
   original `TerminalState` remains authoritative and unchanged.

## Stop condition

No new gem5 experiment was started. Repeatability runs require researcher
approval.
'''
    (C.OUT / 'FINAL_STATUS.md').write_text(status)


def write_manifest_and_zip():
    manifest_path = C.EVID / 'SHA256_MANIFEST.txt'
    files = walk_files(C.OUT, exclude_dirs={'cache'},
                       exclude_names={'SHA256_MANIFEST.txt'})
    lines = ['%s  %s\n' % (sha(p), rel) for p, rel in files]
    manifest_path.write_text(''.join(lines))
    zip_path = C.CAMP / ZIP_NAME
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for p, rel in files:
            zf.write(p, arcname='MMU_PostCampaign_Closure_Package/' + rel)
        zf.write(manifest_path,
                 arcname='MMU_PostCampaign_Closure_Package/'
                         'evidence/SHA256_MANIFEST.txt')
    digest = sha(zip_path)
    (C.CAMP / (ZIP_NAME + '.sha256')).write_text(
        '%s  %s\n' % (digest, ZIP_NAME))
    return zip_path, digest, len(files)


def main():
    C.ensure_dirs()
    att = json.load(open(C.AUDIT / 'Attempt_Audit.json'))['attempts']
    build_result_matrix()
    events = build_combined_events()
    build_trace_index(att)
    build_provenance()
    build_acceptance()
    build_readme_and_status()
    zip_path, digest, n = write_manifest_and_zip()
    print(json.dumps({
        'zip': str(zip_path),
        'zip_sha256': digest,
        'zip_size_bytes': zip_path.stat().st_size,
        'files_manifested': n,
        'combined_chain_events': events,
        'sha256_file': str(C.CAMP / (ZIP_NAME + '.sha256')),
    }, indent=1))


if __name__ == '__main__':
    main()
