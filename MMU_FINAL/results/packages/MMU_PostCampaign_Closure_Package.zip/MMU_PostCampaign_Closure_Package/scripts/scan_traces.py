#!/usr/bin/env python3
"""One-pass, read-only scan of all 40 frozen trace files.

Writes a compact per-sample cache containing:
  - trace identity (abs path, size, sha256, event/line counts)
  - full event-kind histogram
  - the header field list
  - every fault-tagged event, every event referenced by the frozen
    propagation-chain JSON / strict chain, and events within +/-2 IDs of
    those (immediate ordering context)
  - a join check proving each chain EventID exists in the raw trace

Unrelated translations in the ROI are NOT retained: the frozen chain JSON
already enumerates the actual propagation nodes. Only non-empty fields are
stored, keeping the cache small for the 260k-event W12 traces.
"""
import gzip
import json
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C


def collect_ids(obj, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if (k.lower().endswith('event_id') or k.lower() in
                    ('eventid', 'activationeventid', 'consumptioneventid')):
                try:
                    out.add(int(v))
                except (TypeError, ValueError):
                    pass
            collect_ids(v, out)
    elif isinstance(obj, list):
        for v in obj:
            collect_ids(v, out)


def main():
    C.ensure_dirs()
    t0 = time.time()
    sids = [r['SampleRunID'] for r in C.matrix_rows()]
    summary = []
    for idx, sid in enumerate(sids, 1):
        rdir = C.sample_dir(sid)
        trace = rdir / 'Trace' / 'prop_evt.txt.gz'
        ver = C.verdict(sid)
        ch = C.chain(sid)
        wanted = set()
        for v in (ver.get('activation_event_id'),
                  ver.get('consumption_event_id')):
            try:
                wanted.add(int(v))
            except (TypeError, ValueError):
                pass
        collect_ids(ch, wanted)

        kinds = Counter()
        events = []
        added_ids = set()
        buffer = []
        pending_after = 0
        seeds = set()
        header = ''
        total = 0
        chain_ev = {}
        for e in ch.get('Events', []):
            try:
                chain_ev[int(e.get('EventID'))] = e
            except (TypeError, ValueError):
                pass
        # Fault identity for relevance filtering.  M04 (and any model whose
        # trace tags every post-arm event with fault_id=1) makes fault_id
        # useless as a selector, so relevance is anchored on the activation
        # translation/VA and on lifecycle kinds.
        act_tid, act_va = '', ''
        try:
            act_eid = int(ver.get('activation_event_id'))
        except (TypeError, ValueError):
            act_eid = -1
        if act_eid in chain_ev:
            act_tid = str(chain_ev[act_eid].get('TranslationID') or '')
            act_va = str(chain_ev[act_eid].get('VA') or '')
        if not act_va and ver.get('target_va'):
            act_va = format(int(ver['target_va']), 'x')
        lifecycle = {'refill_pfn_corrupt', 'tlbi_match', 'tlbi_invalidate',
                     'tlbi_suppressed', 'tlb_entry_insert',
                     'tlb_entry_lineage', 'partial_entry_insert',
                     'tlb_fill', 'exception_delivery'}
        max_selected = 5000
        capped = False
        fault_tagged_total = 0

        with gzip.open(trace, 'rt', errors='replace') as fh:
            for line in fh:
                if line.startswith('# prop-evt v1:'):
                    header = line[len('# prop-evt v1:'):].strip()
                    continue
                if not line.startswith('PROP-EVT: '):
                    continue
                ev = C.parse_evt_line(line)
                total += 1
                kind = ev.get('kind', '')
                kinds[kind] += 1
                try:
                    eid = int(ev.get('event_id', '-1'))
                except ValueError:
                    eid = -1
                fault_tag = ev.get('fault_id') not in ('', '0', None)
                if fault_tag:
                    fault_tagged_total += 1
                relevant = fault_tag and (
                    (act_tid and ev.get('translation_id') == act_tid) or
                    (act_va and ev.get('va') == act_va) or
                    kind.startswith('mmu_fault') or
                    kind.startswith('fault_') or
                    kind in lifecycle)
                if eid in wanted:
                    is_seed = True
                elif relevant:
                    if len(events) >= max_selected:
                        capped = True
                        is_seed = False
                    else:
                        is_seed = True
                else:
                    is_seed = False
                if is_seed:
                    seeds.add(eid)
                    for prev_eid, prev_ev in buffer[-2:]:
                        if prev_eid not in added_ids and prev_eid >= 0:
                            events.append({k: v for k, v in prev_ev.items()
                                           if v != ''})
                            added_ids.add(prev_eid)
                    if eid not in added_ids and eid >= 0:
                        events.append({k: v for k, v in ev.items() if v != ''})
                        added_ids.add(eid)
                    pending_after = 2
                elif pending_after > 0 and eid >= 0:
                    events.append({k: v for k, v in ev.items() if v != ''})
                    added_ids.add(eid)
                    pending_after -= 1
                buffer.append((eid, ev))
                if len(buffer) > 3:
                    buffer.pop(0)
        events.sort(key=lambda e: int(e.get('event_id', -1)))

        # join check against the frozen chain artifact
        by_id = {}
        for ev in events:
            by_id[ev.get('event_id')] = ev
        mismatches = []
        for eid, ce in chain_ev.items():
            ev = by_id.get(str(eid))
            if ev is None:
                mismatches.append({'EventID': eid, 'problem': 'not_found'})
                continue
            for raw_key, chain_key in (('kind', 'Kind'),
                                       ('tick', 'Tick'),
                                       ('parent_event_id', 'ParentEventID')):
                want = str(ce.get(chain_key, ''))
                got = str(ev.get(raw_key, ''))
                if want not in ('', 'None') and got != want:
                    mismatches.append({'EventID': eid, 'field': raw_key,
                                       'chain': want, 'trace': got})

        rec = {
            'SampleRunID': sid,
            'ModelID': ch.get('ModelID'),
            'ContextID': ch.get('ContextID'),
            'TraceAbsolutePath': str(trace),
            'TraceSizeBytes': trace.stat().st_size,
            'TraceSHA256': C.sha256_file(trace),
            'HeaderFields': header.split(),
            'EventCount': total,
            'KindCounts': dict(sorted(kinds.items())),
            'ChainEventCount': len(chain_ev),
            'ChainJoinMismatches': mismatches,
            'WantedEventIDs': sorted(wanted),
            'SeedEventIDs': sorted(seeds),
            'FaultTaggedEventCount': fault_tagged_total,
            'SelectionCapped': capped,
            'SelectedEventCount': len(events),
            'SelectedEvents': events,
        }
        C.write_json(C.CACHE / 'trace_scan' / ('%s.json' % sid), rec)
        summary.append({
            'SampleRunID': sid,
            'events': total,
            'selected': len(events),
            'kinds': len(kinds),
            'chain_events': len(chain_ev),
            'join_mismatches': len(mismatches),
            'trace_bytes': rec['TraceSizeBytes'],
        })
        print('[%2d/%d] %s events=%d tagged=%d selected=%d kinds=%d '
              'chain=%d mismatch=%d capped=%s' % (
                  idx, len(sids), sid, total, fault_tagged_total,
                  len(events), len(kinds), len(chain_ev), len(mismatches),
                  capped), flush=True)

    C.write_json(C.OUT / 'cache' / 'scan_summary.json', summary)
    print('done in %.1fs; total events=%d; total mismatches=%d' % (
        time.time() - t0, sum(s['events'] for s in summary),
        sum(s['join_mismatches'] for s in summary)))


if __name__ == '__main__':
    main()
