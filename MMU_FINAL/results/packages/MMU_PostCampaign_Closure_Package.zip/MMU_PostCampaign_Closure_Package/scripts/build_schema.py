#!/usr/bin/env python3
"""Task 7 - unified ARM CPU-SDC propagation schema + MMU/LSU mappings."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

UNIFIED_FIELDS = [
    ('Unit', 'enum', 'MMU | LSU | CACHE | MEMORY | PRF | ROB | IQ | BPU | OTHER'),
    ('SubUnit', 'string', 'unit-specific subunit'),
    ('FaultModelID', 'string', 'model identifier (M01..M08 for MMU)'),
    ('FaultLocation', 'object', 'source file/function/site + target field'),
    ('FaultID', 'string|integer|null', 'fault instance id'),
    ('SampleRunID', 'string', 'frozen sample id'),
    ('ContextID', 'string', 'dynamic context id'),
    ('WorkloadID', 'string', 'authoritative workload id'),
    ('ActivationCondition', 'object', 'eligible event/ordinal/tick/mode/...'),
    ('StateTransition', 'object', 'old/new value and state before/after'),
    ('EventID', 'string|integer|null', 'trace event id'),
    ('ParentEventID', 'string|integer|null', 'causal parent event id'),
    ('DynamicInstSeqNum', 'string|integer|null', 'dynamic instruction sequence'),
    ('TranslationID', 'string|integer|null', 'translation transaction id'),
    ('RequestID', 'string|integer|null', 'request id'),
    ('ResponseID', 'string|integer|null', 'response id'),
    ('OldValue', 'string|null', 'pre-fault value (hex preserved)'),
    ('NewValue', 'string|null', 'post-fault value (hex preserved)'),
    ('VA', 'string|null', 'virtual address (hex preserved)'),
    ('PA', 'string|null', 'physical address (hex preserved)'),
    ('CommitStatus', 'string|null', 'COMMITTED | NOT_COMMITTED | UNKNOWN'),
    ('SquashStatus', 'string|null', 'SQUASHED | NOT_SQUASHED | UNKNOWN'),
    ('DetectionStatus', 'string|null', 'DETECTED... | NOT_DETECTED | UNKNOWN'),
    ('TerminalState', 'string|null', 'frozen terminal vocabulary'),
    ('ManifestationType', 'string|null', 'diagnostic manifestation'),
    ('OracleResult', 'string|null', 'FAIL | PASS | PASS_EXPECTED_DETECTION'),
    ('TraceCompleteness', 'string|null', 'COMPLETE | PARTIAL | INCOMPLETE'),
]

MMU_EXTENSIONS = [
    'asid', 'vmid', 'regime', 'security_state', 'stage', 'mode',
    'tlb_instance', 'tlb_level', 'tlb_entry_id', 'entry_generation',
    'entry_generation_after', 'entry_valid', 'entry_partial', 'lookup_id',
    'walk_id', 'walk_level', 'pte_address', 'pte_value_before',
    'pte_value_after', 'descriptor_before', 'descriptor_after',
    'descriptor_type', 'permission_before', 'permission_after',
    'permission_result', 'memory_attribute', 'pfn', 'old_pfn', 'new_pfn',
    'old_pa', 'new_pa', 'candidate_asid', 'candidate_entry_id',
    'candidate_generation', 'candidate_pfn', 'candidate_pa',
    'candidate_valid', 'candidate_partial', 'lookup_outcome',
    'decoy_pfn', 'decoy_pa', 'decoy_va', 'next_table_pa_before',
    'next_table_pa_after', 'request_pa_before', 'request_pa_after',
    'fault_site', 'fault_field', 'fault_reason', 'fault_persistence',
    'exception_class', 'squash_status', 'commit_status', 'data_fnv',
    'trace_integrity', 'trace_completeness', 'propagation_coverage',
    'missing_edges', 'retained_entry_id', 'retained_entry_generation',
    'suppress_count', 'is_write', 'is_fetch',
]

LSU_EXTENSIONS = [
    'lq_idx', 'sq_idx', 'store_dyn_inst_seq', 'commit_seq', 'pc', 'opcode',
    'cache_line', 'set', 'way', 'cache_name', 'mshr_id', 'fill_id',
    'arch_reg', 'phys_reg', 'request_fragment_id', 'replay_generation',
    'execution_attempt_id', 'hit', 'latency',
]


def build_schema():
    nullable = lambda t: {'type': [t, 'null']}
    common = {
        'Unit': {'type': 'string', 'enum': [
            'MMU', 'LSU', 'CACHE', 'MEMORY', 'PRF', 'ROB', 'IQ', 'BPU',
            'OTHER']},
        'SubUnit': nullable('string'),
        'FaultModelID': nullable('string'),
        'FaultLocation': {'oneOf': [
            {'type': 'string'}, {'$ref': '#/$defs/FaultLocation'},
            {'type': 'null'}]},
        'FaultID': {'type': ['string', 'integer', 'null']},
        'SampleRunID': nullable('string'),
        'ContextID': nullable('string'),
        'WorkloadID': nullable('string'),
        'ActivationCondition': {'oneOf': [
            {'$ref': '#/$defs/ActivationCondition'}, {'type': 'null'}]},
        'StateTransition': {'oneOf': [
            {'$ref': '#/$defs/StateTransition'}, {'type': 'null'}]},
        'EventID': {'type': ['string', 'integer', 'null']},
        'ParentEventID': {'type': ['string', 'integer', 'null']},
        'DynamicInstSeqNum': {'type': ['string', 'integer', 'null']},
        'TranslationID': {'type': ['string', 'integer', 'null']},
        'RequestID': {'type': ['string', 'integer', 'null']},
        'ResponseID': {'type': ['string', 'integer', 'null']},
        'OldValue': {'type': ['string', 'number', 'null']},
        'NewValue': {'type': ['string', 'number', 'null']},
        'VA': {'type': ['string', 'integer', 'null']},
        'PA': {'type': ['string', 'integer', 'null']},
        'CommitStatus': {'type': ['string', 'null'], 'enum': [
            'COMMITTED', 'NOT_COMMITTED', 'UNKNOWN', None]},
        'SquashStatus': {'type': ['string', 'null'], 'enum': [
            'SQUASHED', 'NOT_SQUASHED', 'UNKNOWN', None]},
        'DetectionStatus': {'type': ['string', 'null']},
        'TerminalState': {'type': ['string', 'null'], 'enum': [
            'SDC', 'SQUASHED', 'DETECTED_CONTAINED', 'ACTIVATED_MASKED',
            'ARCH_STATE_CORRUPTION', 'CRASH', 'HANG/TIMEOUT',
            'TRACE_INCOMPLETE', 'INJECTION_NOT_ACTIVATED',
            'NO_ELIGIBLE_EVENT', None]},
        'ManifestationType': {'type': ['string', 'null'], 'enum': [
            'WRONG_DATA_VALUE', 'UNAUTHORIZED_WRITE', 'UNAUTHORIZED_READ',
            'UNAUTHORIZED_EXECUTION', 'WRONG_TRANSLATION',
            'WRONG_CODE_PAGE_EXECUTION', 'PERMISSION_BYPASS',
            'DETECTED_EXCEPTION', 'SQUASHED', 'MASKED', None]},
        'OracleResult': {'type': ['string', 'null'], 'enum': [
            'FAIL', 'PASS', 'PASS_EXPECTED_DETECTION', None]},
        'TraceCompleteness': {'type': ['string', 'null'], 'enum': [
            'COMPLETE', 'PARTIAL', 'INCOMPLETE', 'NOT_OBSERVED',
            'TRACE_INCOMPLETE', None]},
    }
    schema = {
        '$schema': 'https://json-schema.org/draft/2020-12/schema',
        '$id': 'https://example.org/arm-cpu-sdc-propagation-schema-v1.json',
        'title': 'ARM CPU-SDC Propagation Schema v1',
        'description': (
            'Unit-neutral event/sample schema for ARM CPU silent-data-'
            'corruption propagation. MMU-specific fields (ASID, VMID, TLB '
            'entry, PTW, PTE) and LSU-specific fields are retained as '
            'extensions; they are never dropped to force uniformity.'),
        'schema_version': '1.0.0',
        'type': 'object',
        '$defs': {
            'FaultLocation': {
                'type': 'object',
                'properties': {
                    'unit': {'type': 'string'},
                    'sub_unit': {'type': 'string'},
                    'source_file': {'type': 'string'},
                    'source_function': {'type': 'string'},
                    'trace_fault_site': {'type': 'string'},
                    'target_field': {'type': 'string'},
                },
                'additionalProperties': True,
            },
            'ActivationCondition': {
                'type': 'object',
                'properties': {
                    'eligible_event_condition': {'type': 'string'},
                    'actual_eligible_event': {'type': 'string'},
                    'event_ordinal': {'type': ['integer', 'string', 'null']},
                    'activation_tick': {'type': ['integer', 'string',
                                                 'null']},
                    'access_mode': {'type': ['string', 'null']},
                    'walk_level': {'type': ['string', 'null']},
                    'asid': {'type': ['string', 'integer', 'null']},
                    'vmid': {'type': ['string', 'integer', 'null']},
                    'tlb_lookup_outcome': {'type': ['string', 'null']},
                },
                'additionalProperties': True,
            },
            'StateTransition': {
                'type': 'object',
                'properties': {
                    'event_id': {'type': ['string', 'integer', 'null']},
                    'field': {'type': ['string', 'null']},
                    'before': {'type': ['string', 'number', 'null']},
                    'after': {'type': ['string', 'number', 'null']},
                    'state_before': {'type': ['string', 'null']},
                    'state_after': {'type': ['string', 'null']},
                    'old_value': {'type': ['string', 'number', 'null']},
                    'new_value': {'type': ['string', 'number', 'null']},
                },
                'additionalProperties': True,
            },
            'PropagationEvent': {
                'type': 'object',
                'properties': common,
                'required': ['Unit', 'EventID', 'SampleRunID',
                             'FaultModelID', 'StateTransition'],
                'additionalProperties': True,
                'description': (
                    'One observed propagation node. MMU extensions: asid, '
                    'vmid, tlb_instance, tlb_entry_id, entry_generation, '
                    'walk_level, pte_*, descriptor_*, permission_*, '
                    'candidate_*, decoy_*, request_pa_*, next_table_pa_*. '
                    'LSU extensions: lq_idx, sq_idx, cache_line, mshr_id, '
                    'arch_reg, phys_reg, ...'),
            },
            'SampleRecord': {
                'type': 'object',
                'properties': dict(common, **{
                    'events': {'type': 'array',
                               'items': {'$ref':
                                         '#/$defs/PropagationEvent'}},
                    'WorkloadVariant': {'type': ['string', 'null']},
                    'TraceSHA256': {'type': ['string', 'null']},
                }),
                'required': ['Unit', 'SampleRunID', 'FaultModelID',
                             'TerminalState', 'OracleResult',
                             'TraceCompleteness', 'events'],
                'additionalProperties': True,
            },
        },
        # anyOf, not oneOf: PropagationEvent and SampleRecord deliberately
        # overlap on the shared 27-field core, and every record allows
        # unit-specific additionalProperties.  Consumers that need a strict
        # record type validate against the corresponding $defs entry directly.
        'anyOf': [
            {'$ref': '#/$defs/PropagationEvent'},
            {'$ref': '#/$defs/SampleRecord'},
        ],
        'x-mmu-extensions': MMU_EXTENSIONS,
        'x-lsu-extensions': LSU_EXTENSIONS,
        'x-field-dictionary': [
            {'field': f, 'type': t, 'description': d}
            for f, t, d in UNIFIED_FIELDS],
    }
    return schema


MMU_MAPPING = [
    ('Unit', 'constant', 'MMU', 'unit of the injection'),
    ('SubUnit', 'authority.TargetSubUnit', 'TLB Invalidation; L2/Unified TLB',
     'frozen authority matrix'),
    ('FaultModelID', 'manifest.model', 'M01', 'frozen sample manifest'),
    ('FaultLocation', 'manifest + authority + trace',
     '{source_file,source_function,trace_fault_site,target_field}',
     'trace fault_site merged with verified source site'),
    ('FaultID', 'verdict.fault_id', '1', 'fault instance'),
    ('SampleRunID', 'manifest.sample_run_id', 'M01-F0-W9-S01-R01',
     'never rewritten'),
    ('ContextID', 'manifest.context', 'R01', 'dynamic context'),
    ('WorkloadID', 'matrix.WorkloadID', 'W9',
     'authoritative WorkloadID; variant kept separately'),
    ('ActivationCondition', 'manifest + activation event',
     'eligible condition, ordinal, tick, mode, walk_level, asid/vmid, '
     'tlb_lookup_outcome', 'per-sample activation feature'),
    ('StateTransition', 'trace event fields',
     'field/before/after/state_before/state_after + old/new pfn/pa/'
     'descriptor/permission/request_pa', 'EventID preserved'),
    ('EventID', 'trace event_id', '293', 'real raw-trace id'),
    ('ParentEventID', 'trace parent_event_id', '292', 'parent edge'),
    ('DynamicInstSeqNum', 'trace dyn_inst_seq', '106305715',
     'dynamic instruction sequence'),
    ('TranslationID', 'trace translation_id', '5', 'translation txn id'),
    ('RequestID', 'trace request_id / unique_request_id', '206184368',
     'request identity'),
    ('ResponseID', 'trace response_id', '4423', 'response identity'),
    ('OldValue', 'trace before / old_pfn / old_pa / pte_value_before / '
     'descriptor_before / request_pa_before', '834b2', 'hex preserved'),
    ('NewValue', 'trace after / new_pfn / new_pa / pte_value_after / '
     'descriptor_after / request_pa_after', '834b3', 'hex preserved'),
    ('VA', 'trace va', '4000000000', 'hex preserved'),
    ('PA', 'trace pa', '8353d000', 'hex preserved'),
    ('CommitStatus', 'trace commit event / commit_status',
     'COMMITTED if commit node observed', 'derived from events'),
    ('SquashStatus', 'trace squash_status / squash event', 'SQUASH',
     'SQUASHED when squash observed or terminal SQUASHED'),
    ('DetectionStatus', 'terminal + exception_delivery',
     'DETECTED_AND_CONTAINED | SQUASHED_BEFORE_ARCH_UPDATE | NOT_DETECTED',
     'derived'),
    ('TerminalState', 'verdict.TerminalState', 'SDC', 'original, preserved'),
    ('ManifestationType', 'audit classification', 'UNAUTHORIZED_WRITE',
     'added diagnostic dimension'),
    ('OracleResult', 'verdict.OracleResult', 'FAIL', 'original'),
    ('TraceCompleteness', 'verdict.TraceCompleteness', 'COMPLETE', 'original'),
]

MMU_ONLY = [
    ('asid', 'trace asid', 'ASID of the faulting translation'),
    ('vmid', 'trace vmid', 'VMID'),
    ('regime', 'trace regime', 'EL10/EL0t/...'),
    ('security_state', 'trace security_state', 'NonSecure/Secure/Realm'),
    ('tlb_instance', 'trace tlb_instance', 'dtb/itb/l2_shared/walk cache'),
    ('tlb_entry_id', 'trace tlb_entry_id', 'entry identity'),
    ('entry_generation', 'trace entry_generation', 'generation/version'),
    ('entry_valid', 'trace entry_valid', 'valid bit'),
    ('entry_partial', 'trace entry_partial', 'partial-entry flag'),
    ('lookup_id', 'trace lookup_id', 'lookup txn id'),
    ('walk_id', 'trace walk_id', 'PTW walk id'),
    ('walk_level', 'trace walk_level', 'L2/L3'),
    ('pte_address', 'trace pte_address', 'PTE physical address'),
    ('pte_value_before', 'trace pte_value_before', 'PTE before'),
    ('pte_value_after', 'trace pte_value_after', 'PTE after'),
    ('descriptor_before', 'trace descriptor_before', 'descriptor before'),
    ('descriptor_after', 'trace descriptor_after', 'descriptor after'),
    ('permission_before', 'trace permission_before', 'permission decision'),
    ('permission_after', 'trace permission_after', 'inverted decision'),
    ('permission_result', 'trace permission_result', 'deny/grant'),
    ('memory_attribute', 'trace memory_attribute', 'XN/AP/attr'),
    ('pfn', 'trace pfn', 'physical frame number'),
    ('old_pfn', 'trace old_pfn', 'pre-fault PFN'),
    ('new_pfn', 'trace new_pfn', 'post-fault PFN'),
    ('old_pa', 'trace old_pa', 'pre-fault PA'),
    ('new_pa', 'trace new_pa', 'post-fault PA'),
    ('candidate_asid', 'trace candidate_asid', 'M03 foreign ASID'),
    ('candidate_entry_id', 'trace candidate_entry_id', 'M03 entry'),
    ('candidate_generation', 'trace candidate_generation', 'M03 generation'),
    ('candidate_pfn', 'trace candidate_pfn', 'M03 PFN'),
    ('candidate_pa', 'trace candidate_pa', 'M03 PA'),
    ('lookup_outcome', 'trace lookup_outcome', 'false_hit/...'),
    ('decoy_pfn', 'trace decoy_pfn', 'M04/M05 decoy'),
    ('decoy_pa', 'trace decoy_pa', 'M04/M05 decoy PA'),
    ('decoy_va', 'trace decoy_va', 'M05 decoy VA'),
    ('next_table_pa_before', 'trace next_table_pa_before', 'M05'),
    ('next_table_pa_after', 'trace next_table_pa_after', 'M05'),
    ('request_pa_before', 'trace request_pa_before', 'M08'),
    ('request_pa_after', 'trace request_pa_after', 'M08'),
    ('fault_site', 'trace fault_site', 'C++ mutation site'),
    ('fault_field', 'trace fault_field', 'mutated field'),
    ('fault_persistence', 'trace fault_persistence', 'one_shot/entry_lifetime'),
    ('exception_class', 'trace exception_class', 'Translation/Permission'),
    ('retained_entry_id', 'trace retained_entry_id', 'M01'),
    ('retained_entry_generation', 'trace retained_entry_generation', 'M01'),
    ('suppress_count', 'trace suppress_count', 'M01'),
]

LSU_MAPPING = [
    ('Unit', 'constant', 'LSU', 'unit of the injection'),
    ('SubUnit', 'config/registry', 'LSU | Cache | Memory | PRF', 'LSU track'),
    ('FaultModelID', 'LSU manifest', 'LSU model id', 'LSU track model'),
    ('FaultLocation', 'source file/function', 'lsq.cc / CHAOSLSQFwd.cc',
     'LSU injection site'),
    ('FaultID', 'manifest', 'fault instance', 'fault id'),
    ('SampleRunID', 'manifest', 'LSU SampleRunID', 'identity'),
    ('ContextID', 'manifest', 'context', 'identity'),
    ('WorkloadID', 'manifest', 'LSU workload', 'identity'),
    ('ActivationCondition', 'chaos_trigger.hh', 'F0..F5 predicate',
     'LSU trigger mode'),
    ('StateTransition', 'before/after', 'register/LSQ/cache state',
     'state change'),
    ('EventID', 'event_id', 'trace event id', 'shared registry'),
    ('ParentEventID', 'parent_event_id', 'parent', 'shared registry'),
    ('DynamicInstSeqNum', 'dyn_inst_seq', 'sequence', 'shared registry'),
    ('TranslationID', 'translation_id', 'MMU translation link',
     'cross-unit link'),
    ('RequestID', 'request_id', 'request', 'shared registry'),
    ('ResponseID', 'response_id', 'response', 'shared registry'),
    ('OldValue', 'before', 'pre-fault value', 'shared registry'),
    ('NewValue', 'after', 'post-fault value', 'shared registry'),
    ('VA', 'va', 'virtual address', 'shared registry'),
    ('PA', 'pa', 'physical address', 'shared registry'),
    ('CommitStatus', 'commit_status / commit_seq', 'commit state',
     'shared registry'),
    ('SquashStatus', 'squash_status', 'squash state', 'shared registry'),
    ('DetectionStatus', 'detection_layer / contained', 'detection',
     'shared registry'),
    ('TerminalState', 'classifier', 'terminal state', 'tools/classify.py'),
    ('ManifestationType', 'classifier', 'manifestation', 'unit-neutral'),
    ('OracleResult', 'oracle', 'oracle result', 'terminal oracle'),
    ('TraceCompleteness', 'trace_integrity', 'completeness',
     'trace quality'),
]

LSU_ONLY = [
    ('lq_idx', 'trace lq_idx', 'load queue index'),
    ('sq_idx', 'trace sq_idx', 'store queue index'),
    ('store_dyn_inst_seq', 'trace store_dyn_inst_seq', 'store sequence'),
    ('commit_seq', 'trace commit_seq', 'commit sequence'),
    ('pc', 'trace pc', 'program counter'),
    ('opcode', 'trace opcode', 'opcode'),
    ('cache_line', 'trace cache_line', 'cache line address'),
    ('set', 'trace set', 'cache set'),
    ('way', 'trace way', 'cache way'),
    ('cache_name', 'trace cache_name', 'cache instance'),
    ('mshr_id', 'trace mshr_id', 'MSHR id'),
    ('fill_id', 'trace fill_id', 'fill id'),
    ('arch_reg', 'trace arch_reg', 'architectural register'),
    ('phys_reg', 'trace phys_reg', 'physical register'),
    ('request_fragment_id', 'trace request_fragment_id', 'request fragment'),
    ('replay_generation', 'trace replay_generation', 'replay generation'),
    ('execution_attempt_id', 'trace execution_attempt_id', 'attempt id'),
]


def main():
    C.ensure_dirs()
    schema = build_schema()
    C.write_json(C.SCHEMA / 'ARM_CPU_SDC_Propagation_Schema_v1.json', schema)
    mmu_rows = [{'UnifiedField': f, 'MMUSource': s, 'Example': e,
                 'Notes': n} for f, s, e, n in MMU_MAPPING]
    C.write_csv(C.SCHEMA / 'MMU_to_Unified_Schema_Mapping.csv', mmu_rows)
    C.write_json(C.SCHEMA / 'MMU_to_Unified_Schema_Mapping.json', {
        'unified_fields': mmu_rows,
        'mmu_only_extensions_retained': [
            {'field': f, 'source': s, 'notes': n}
            for f, s, n in MMU_ONLY],
    })
    lsu_rows = [{'UnifiedField': f, 'LSUSource': s, 'Example': e,
                 'Notes': n} for f, s, e, n in LSU_MAPPING]
    C.write_csv(C.SCHEMA / 'LSU_to_Unified_Schema_Mapping.csv', lsu_rows)
    C.write_json(C.SCHEMA / 'LSU_to_Unified_Schema_Mapping.json', {
        'unified_fields': lsu_rows,
        'lsu_only_extensions_retained': [
            {'field': f, 'source': s, 'notes': n} for f, s, n in LSU_ONLY],
    })
    md = ['# ARM CPU-SDC Propagation Schema v1\n\n',
          'File: `ARM_CPU_SDC_Propagation_Schema_v1.json` (JSON Schema '
          'draft 2020-12).\n\n',
          '## Design\n\n',
          '- Two record types share one field dictionary: '
          '`PropagationEvent` (one observed node) and `SampleRecord` '
          '(identity + terminal + an `events` array). The root uses '
          '`anyOf` because the two intentionally overlap; validate a known '
          'record type against `$defs/SampleRecord` or '
          '`$defs/PropagationEvent` directly.\n',
          '- The 27 cross-unit fields requested for MMU/LSU unification are '
          'in both definitions.\n',
          '- `additionalProperties: true` is deliberate: MMU-only fields '
          '(ASID, VMID, TLB entry/generation, PTW/PTE, permission, '
          'candidate/decoy, request-PA) and LSU-only fields (LQ/SQ, cache '
          'line/set/way, MSHR, arch/phys reg, replay) are retained, never '
          'dropped to force uniformity.\n',
          '- Hex values are carried as strings to preserve width and '
          'leading zeros; numeric values are allowed where unambiguous.\n',
          '- `TerminalState` keeps the frozen vocabulary; '
          '`ManifestationType` is a separate diagnostic dimension.\n\n',
          '## MMU mapping\n\n',
          'See `MMU_to_Unified_Schema_Mapping.csv`: 27 unified fields mapped '
          'to manifest/verdict/trace sources plus %d MMU-only extension '
          'fields.\n\n' % len(MMU_ONLY),
          '## LSU mapping\n\n',
          'See `LSU_to_Unified_Schema_Mapping.csv`: the shared registry in '
          '`CHAOSPropagation.hh` already provides the 27-field core for LSU '
          'plus %d LSU-only extension fields. `TranslationID` is the '
          'explicit cross-unit link from LSU requests to MMU translations.'
          '\n' % len(LSU_ONLY),
          '## Validation\n\n',
          '`validate_schema.py` validates the schema itself and checks a '
          'representative MMU feature record against `PropagationEvent`.\n']
    (C.SCHEMA / 'Schema_README.md').write_text(''.join(md))
    print(json.dumps({
        'unified_fields': len(UNIFIED_FIELDS),
        'mmu_extensions': len(MMU_EXTENSIONS),
        'lsu_extensions': len(LSU_EXTENSIONS),
        'schema_path': str(C.SCHEMA /
                           'ARM_CPU_SDC_Propagation_Schema_v1.json'),
    }, indent=1))


if __name__ == '__main__':
    main()
