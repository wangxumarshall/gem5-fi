#!/usr/bin/env python3
"""Tasks 3 and 4 - real-case mapping and repeatability design.

No experiment is started. The repeatability matrix is a design artifact; every
selected repeat is checked against the actual frozen trace/manifest first.
"""
import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C
import audit_m07


def cmd_params(cmd):
    out = {}
    i = 0
    while i < len(cmd):
        tok = cmd[i]
        if tok.startswith('--'):
            if i + 1 < len(cmd) and not cmd[i + 1].startswith('--'):
                out[tok] = cmd[i + 1]
                i += 2
            else:
                out[tok] = 'true'
                i += 1
        else:
            i += 1
    return out


def real_case():
    m01_docs = [
        str(C.REPO / 'mmu_phase1_work/design/MMU_Final_Design_Package/'
             '02_Original_Audit_Reports/MMU_Propagation_Path.md'),
        str(C.REPO / 'mmu_phase1_work/design/MMU_Final_Design_Package/'
             '02_Original_Audit_Reports/MMU_Terminal_Oracle.md'),
        str(C.REPO / 'docs/gem5-fi/mmu/MMU_Review_Delta_Package/'
             'M01_Target_TLB_Selection.md'),
    ]
    rows = [{
        'RealCaseID': 'RC-MMU-001',
        'ObservedSymptom': (
            'After the OS updates a page-table mapping and performs correct '
            'TLB maintenance/synchronization, the CPU still uses the old '
            'DTLB entry, accesses the old physical address and reads wrong '
            'data.'),
        'SuspectedUnit': (
            'DTLB (implementation-specific entry/tag-match/invalidation '
            'path; exact level and bank unknown)'),
        'IndirectSignal': (
            'software-visible stale data after correct TLBI with no '
            'exception; the old-PA marker is returned where the new-PA '
            'marker is expected'),
        'CandidateModel': 'M01',
        'MatchingFeatures': (
            'missed TLBI invalidation; entry remains valid=true; stale '
            'entry is consumed by a later lookup after the remap; old PA; '
            'wrong data value; no exception'),
        'DifferentiatingFeatures': (
            'gem5 M01 target is the l2_shared (unified L2) TLB entry, not '
            'the DTB; the injected site is TLB::flush invalidation '
            'suppression after an exact-key tlbi_match; the DTB copy was '
            'not a valid match at that moment (evicted/replaced). The real '
            'silicon defect may sit in DTLB tag matching, invalidation '
            'broadcast, or ASID/VMID handling and is not observable here.'),
        'Evidence': (
            'Researcher-supplied case description (no external citation '
            'exists in the repository); M01 mechanism/oracle documents: %s; '
            'frozen M01 samples M01-F0-W9-S01-R01..R05 with '
            'tlbi_match+tlbi_suppressed and old-marker 0xaa consumption.' %
            '; '.join(m01_docs)),
        'Confidence': 'MEDIUM',
        'FunctionalSemanticMatch': 'HIGH',
        'MicroarchitecturalStructureMatch': 'LOW_TO_MEDIUM',
        'PropagationPathMatch': 'HIGH',
        'DiagnosticFeatureMatch': 'MEDIUM_TO_HIGH',
        'Limitations': (
            'No real-silicon trace, ASID sequence, or erratum/CVE citation '
            'is available; L2/unified TLB is not the DTLB; the gem5 fault '
            'is deliberate suppression of one matched invalidation, whereas '
            'the real root cause is unknown.'),
    }]
    return rows


CANDIDATES = [
    ('M01', 'R01', 'core stale-translation path (SDC)'),
    ('M02', 'R02', 'refill PFN corruption path (SDC)'),
    ('M03', 'R01', 'false-ASID hit ending in legal squash (SQUASHED)'),
    ('M03', 'R05', 'false-ASID hit consumed by Execute (SDC)'),
    ('M04', 'R05', 'resident-entry substitution consumed by ITLB (SDC)'),
    ('M05', 'R05', 'partial walk-cache pointer substitution (SDC)'),
    ('M06', 'R02', 'invalid leaf descriptor detected on a store (W10S)'),
    ('M07', 'R01', 'permission inversion: unauthorized RO write (SDC)'),
    ('M07', 'R05', 'permission inversion: unauthorized XN execute (SDC)'),
    ('M08', 'R01', 'final PA materialization corruption (SDC)'),
]


def repeat_rows():
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    by_mc = {(r['ModelID'], r['ContextID']): r for r in matrix.values()}
    rows = []
    for idx, (model, ctx, reason) in enumerate(CANDIDATES, 1):
        m = by_mc[(model, ctx)]
        sid = m['SampleRunID']
        man = C.manifest(sid)
        ver = C.verdict(sid)
        ch = C.chain(sid)
        act_id = ver['activation_event_id']
        act = next((e for e in ch['Events']
                    if int(e['EventID']) == int(act_id)), {})
        ax = act.get('ExtraFields') or {}
        params = cmd_params(man.get('command', []))
        started = man.get('started_at_utc', '')
        finished = man.get('finished_at_utc', '')
        runtime = ''
        try:
            t0 = datetime.strptime(started, '%Y-%m-%dT%H:%M:%SZ')
            t1 = datetime.strptime(finished, '%Y-%m-%dT%H:%M:%SZ')
            runtime = str(int((t1 - t0).total_seconds())) + ' s'
        except Exception:
            pass
        o = C.parse_kv_line(ver['Details']['oracle']['line'])
        primary, secondary, mismatch, permission, basis = audit_m07.classify(
            model, ctx, man['target_mode'],
            ver['Details']['oracle']['line'], ver['TerminalState'])
        strict = ch.get('StrictChain') or {}
        identity_relation = {
            'M01': 'retained L2 entry valid=true, same entry_id/generation '
                   'survives the matching TLBI and is consumed afterwards',
            'M02': 'refill PFN changes by XOR bit0 (old_pfn 0x834b2 -> '
                   'new_pfn 0x834b3) and the inserted entry is later hit',
            'M03': 'candidate_asid != request ASID; candidate entry/generation '
                   'selected on a miss; R01 ends in squash before arch update',
            'M04': 'resident entry_id/generation stays valid; substituted PFN '
                   'is a different mapped page of the same size',
            'M05': 'partial entry next_table_pa changes; later partial hit '
                   'resumes at the decoy L3 table',
            'M06': 'descriptor bits[1:0] 0b11 -> 0b10 on the fetched leaf; '
                   'PTE memory is not written',
            'M07': 'same VA/PA/PFN; permission_before=false -> '
                   'permission_after=true at the permission checker',
            'M08': 'TLB entry/PFN unchanged; Request PA changes by XOR 0x1000',
        }[model]
        rows.append({
            'RepeatID': 'REP-MMU-%s-%s-01' % (model, ctx),
            'RepeatOfSampleRunID': sid,
            'ModelID': model,
            'ModelMechanism': C.MODEL_MECHANISM[model],
            'WorkloadID': m['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'RunWorkload': man.get('run_workload', ''),
            'ContextID': ctx,
            'AccessMode': man.get('target_mode', ''),
            'TargetVAHex': '0x%x' % man['target_va'],
            'TargetVADec': man['target_va'],
            'TargetASID': man.get('target_asid', ''),
            'FaultParameters': {
                'mmu_fault_model': params.get('--mmu_fault_model', ''),
                'mmu_fault_enable': params.get('--mmu_fault_enable', ''),
                'mmu_target_va': params.get('--mmu_target_va', ''),
                'mmu_target_n': params.get('--mmu_target_n', ''),
                'mmu_eligible_event_index': params.get(
                    '--mmu_eligible_event_index', ''),
                'mmu_target_mode': params.get('--mmu_target_mode', ''),
                'mmu_target_walk_level': params.get(
                    '--mmu_target_walk_level', ''),
                'mmu_m02_dram_lo': params.get('--mmu_m02_dram_lo', ''),
                'mmu_m02_dram_hi': params.get('--mmu_m02_dram_hi', ''),
                'mmu_m08_pa_xor_mask': params.get(
                    '--mmu_m08_pa_xor_mask', ''),
                'seed': man.get('seed', ''),
                'seed_policy': man.get('seed_policy', ''),
            },
            'FrozenBinarySHA256': man.get('gem5_sha256', ''),
            'OriginalConfigSHA256': (C.sha256_file(
                C.sample_dir(sid) / 'Config/config.ini')),
            'WorkloadBinarySHA256': man.get('workload_sha256', ''),
            'WorkloadBinaryPath': man.get('workload_binary', ''),
            'RcsSource': man.get('rcs_source', ''),
            'RcsSourceSHA256': (C.sha256_file(C.repr_path(
                man.get('rcs_source', ''))) if man.get('rcs_source') and
                C.repr_path(man.get('rcs_source')).is_file() else ''),
            'OriginalTerminalState': ver['TerminalState'],
            'OriginalOracleResult': ver['OracleResult'],
            'OriginalPropagationStatus': ver['PropagationStatus'],
            'OriginalTraceCompleteness': ver['TraceCompleteness'],
            'OriginalManifestationType': primary,
            'ExpectedActivationKind': act.get('Kind', ''),
            'ExpectedFaultSite': ax.get('fault_site', ''),
            'ExpectedFaultField': ax.get('fault_field', ''),
            'ExpectedFaultState':
                {k: ax.get(k) for k in ('old_pfn', 'new_pfn', 'old_pa',
                                        'new_pa', 'descriptor_before',
                                        'descriptor_after',
                                        'request_pa_before',
                                        'request_pa_after',
                                        'permission_before',
                                        'permission_after',
                                        'candidate_asid', 'candidate_pfn',
                                        'next_table_pa_before',
                                        'next_table_pa_after')
                 if ax.get(k) not in (None, '')},
            'ExpectedEntryIdentityRelation': identity_relation,
            'ExpectedDownstreamConsumer': (
                'Execute (IFU/LSU)' if man.get('target_mode') == 'Execute'
                else 'LSU %s' % man.get('target_mode', '')),
            'ExpectedTerminalState': ver['TerminalState'],
            'ExpectedSignature': 'see feature library DiagnosticSignature',
            'ExpectedOracleObserved': o.get('observed', ''),
            'ExpectedOracleExpected': (o.get('expected') or
                                       o.get('sentinel') or
                                       o.get('new_marker') or
                                       o.get('expect') or
                                       o.get('target_after') or ''),
            'ComparisonMetrics': (
                'fault_activation;target_event;fault_state;'
                'entry_id_generation_relation;VA_PA_change;'
                'downstream_consumer;terminal_state;propagation_signature'),
            'PassCriteria': (
                'all 8 metrics match; activation event kind/fault_site and '
                'the fault-state relationship must match; exact EventIDs/'
                'ticks are expected under deterministic restore but a '
                'mismatch is investigated, not silently accepted'),
            'OriginalRuntime': runtime,
            'IndependentProcessRequired': True,
            'NewOutputPathTemplate': (
                'runs/MMU_FORMAL_CAMPAIGN_20261113/repeatability/'
                '<RepeatID>/'),
            'NewAttemptID': 'REP01',
            'MustNotOverwriteOriginal': True,
            'OneFaultSourceOnly': True,
            'FullTraceRequired': True,
            'RepeatReason': reason,
            'CandidateVerifiedAgainstActualTrace': True,
            'SelectionNote': (
                'verified: terminal=%s, propagation=%s, activation=%s, '
                'fault_site=%s' % (
                    ver['TerminalState'], ver['PropagationStatus'],
                    act.get('Kind', ''), ax.get('fault_site', '') or
                    ax.get('fault_field', ''))),
        })
    return rows


def main():
    C.ensure_dirs()
    rc = real_case()
    C.write_csv(C.REALCASE / 'RealCase_Mapping.csv', rc)
    C.write_json(C.REALCASE / 'RealCase_Mapping.json', rc)
    md = ['# Real ARM CPU Case Mapping\n\n',
          'Only one real case was supplied by the researcher; no additional '
          'case is invented.\n\n',
          '## Mapping\n\n',
          '| Field | Value |\n|---|---|\n']
    for k, v in rc[0].items():
        md.append('| %s | %s |\n' % (k, v))
    md.append('\n## Four separate match dimensions\n\n')
    md.append('1. **Functional fault semantics — HIGH.** Both are a missed '
              'invalidation of a valid translation after correct software '
              'maintenance, leaving a stale entry consumable. The gem5 M01 '
              'entry is retained (`tlbi_match` then `tlbi_suppressed`) and '
              'later consumed after the remap.\n')
    md.append('2. **Microarchitectural structure — LOW_TO_MEDIUM.** The gem5 '
              'target is `l2_shared` (unified L2 TLB), not the DTB. The DTB '
              'copy was not a valid match at that moment '
              '(`M01_Target_TLB_Selection.md`). This mapping does **not** '
              'claim that the gem5 L2/unified TLB is the real chip\'s '
              'DTLB.\n')
    md.append('3. **Propagation path — HIGH.** stale entry -> old PA -> LSU/'
              'memory -> wrong data -> software oracle, with no exception. '
              'M01 R01-R05 all return the old marker 0xaa instead of the new '
              'marker 0x55.\n')
    md.append('4. **Diagnostic feature match — MEDIUM_TO_HIGH.** The '
              'diagnostic features are `tlbi_match`/`tlbi_suppressed`, a '
              'retained entry identity, a later consumption event and an '
              'old-PA marker. The real case lacks event-level evidence, so '
              'the feature match cannot be raised above medium.\n')
    md.append('\n## Limitations\n\n')
    md.append('- No external erratum/CVE/trace citation exists in the '
              'repository for the real case; the description is '
              'researcher-supplied.\n')
    md.append('- The real fault root cause (tag match vs invalidation '
              'broadcast vs ASID/VMID handling) is unknown.\n')
    md.append('- The gem5 fault is an intentional one-entry TLBI suppression, '
              'not a naturally occurring manufacturing defect.\n')
    md.append('- Cross-chip generality is unproven.\n')
    (C.REALCASE / 'RealCase_Mapping.md').write_text(''.join(md))

    rr = repeat_rows()
    C.write_csv(C.REPEAT / 'MMU_Repeatability_Matrix.csv', rr)
    C.write_json(C.REPEAT / 'MMU_Repeatability_Validation_Plan.json', {
        'plan_version': 'MMU-REPEAT-PLAN-v1',
        'campaign_id': 'MMU-FORMAL-20261113',
        'status': 'DESIGN_ONLY_AWAITING_RESEARCHER_APPROVAL',
        'no_experiment_started': True,
        'repeats': rr,
        'global_requirements': [
            'independent gem5 processes (max 4 concurrent)',
            'new RepeatID/AttemptID and new unique output path',
            'same frozen binary, workload, variant and fault parameters',
            'one fault source per run',
            'full prop_evt trace',
            'never modify or overwrite the original 40 SampleRunIDs',
            'compare event-by-event against the named original sample',
        ],
    })
    _repeat_xlsx(rr)
    _repeat_md(rr)
    print(json.dumps({
        'real_case_rows': len(rc),
        'repeat_rows': len(rr),
        'repeat_models': dict(Counter(r['ModelID'] for r in rr)),
        'terminals': dict(Counter(r['OriginalTerminalState'] for r in rr)),
        'candidates': [{'id': r['RepeatID'], 'of': r['RepeatOfSampleRunID'],
                        'terminal': r['OriginalTerminalState'],
                        'note': r['SelectionNote']} for r in rr],
        'status': 'DESIGN_ONLY_AWAITING_RESEARCHER_APPROVAL',
    }, indent=1))


def _repeat_xlsx(rr):
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Plan'
    for line in [
        ['MMU Independent Repeatability Validation Plan'],
        ['Campaign', 'MMU-FORMAL-20261113'],
        ['Status', 'DESIGN ONLY - awaiting researcher approval'],
        ['Experiments started', 'NO'],
        ['Repeats', len(rr)],
        ['Note', 'The 40 formal samples are different dynamic contexts, not '
                 'independent repeats; A01/A02 retries are not independent '
                 'repeats either.'],
    ]:
        ws.append(line)
    ws['A1'].font = Font(bold=True, size=14)
    ws2 = wb.create_sheet('Matrix')
    headers = ['RepeatID', 'RepeatOfSampleRunID', 'ModelID', 'Mechanism',
               'WorkloadID', 'Variant', 'ContextID', 'AccessMode',
               'TargetVAHex', 'TargetASID', 'FaultParameters',
               'FrozenBinarySHA256', 'WorkloadBinarySHA256',
               'RcsSourceSHA256', 'OriginalTerminalState',
               'OriginalPropagationStatus', 'OriginalManifestationType',
               'ExpectedActivationKind', 'ExpectedFaultSite',
               'ExpectedFaultState', 'ExpectedEntryIdentityRelation',
               'ExpectedDownstreamConsumer', 'ComparisonMetrics',
               'PassCriteria', 'OriginalRuntime', 'NewOutputPathTemplate',
               'NewAttemptID', 'RepeatReason']
    ws2.append(headers)
    for r in rr:
        ws2.append([json.dumps(r[h]) if isinstance(r.get(h), (dict, list))
                    else r.get(h, '') for h in headers])
    ws2.freeze_panes = 'B2'
    ws3 = wb.create_sheet('Requirements')
    ws3.append(['Requirement', 'Value'])
    for req in [
        'independent gem5 process', 'new RepeatID/AttemptID',
        'new unique output path', 'same frozen binary',
        'same workload and fault parameters', 'do not change original 40 '
        'SampleRunIDs', 'one fault source per run', 'record full trace',
        'compare event-by-event with the original sample',
        'max 4 concurrent gem5 processes']:
        ws3.append([req, 'MANDATORY'])
    wb.save(C.REPEAT / 'MMU_Repeatability_Validation_Plan.xlsx')


def _repeat_md(rr):
    md = ['# MMU Independent Repeatability Validation Plan\n\n',
          '**Status: DESIGN ONLY — awaiting researcher approval. No gem5 '
          'experiment was started.**\n\n',
          'The 40 formal samples are different dynamic contexts, not '
          'independent repeats. The A01/A02 retries are not independent '
          'repeats either (A02 replaces an interrupted A01).\n\n',
          '## Why these 10\n\n',
          'Each candidate was checked against the actual frozen trace, '
          'manifest and verdict before selection.\n\n',
          '| RepeatID | Original | Model | Ctx | Mode | Original terminal | '
          'Activation / fault site | Reason |\n|---|---|---|---|---|---|---|---|\n']
    for r in rr:
        md.append('| %s | %s | %s | %s | %s | %s | %s / %s | %s |\n' % (
            r['RepeatID'], r['RepeatOfSampleRunID'], r['ModelID'],
            r['ContextID'], r['AccessMode'], r['OriginalTerminalState'],
            r['ExpectedActivationKind'], r['ExpectedFaultSite'] or
            r['ExpectedFaultField'], r['RepeatReason']))
    md.append('\n## Execution requirements\n\n')
    md.append('1. Use an independent gem5 process per repeat; max 4 '
              'concurrent.\n')
    md.append('2. Use a new `RepeatID`/`AttemptID` and a new output path '
              'under `repeatability/<RepeatID>/`; never overwrite the '
              'original 40 SampleRunIDs.\n')
    md.append('3. Use the same frozen binary (`%s`), workload binary, rcS '
              'and fault parameters recorded per row.\n' % rr[0][
                  'FrozenBinarySHA256'])
    md.append('4. Exactly one fault source per run; record the full '
              '`prop_evt.txt.gz` trace.\n')
    md.append('5. Compare each repeat event-by-event with its original '
              'sample.\n\n')
    md.append('## Comparison metrics (all 8 must be reported)\n\n')
    md.append('1. Fault activation consistent (kind, fault site, field).\n')
    md.append('2. Target event consistent (ordinal/condition).\n')
    md.append('3. Fault state consistent (before/after values).\n')
    md.append('4. EntryID/Generation identity relation as specified.\n')
    md.append('5. VA/PA change consistent.\n')
    md.append('6. Downstream consumer consistent.\n')
    md.append('7. TerminalState consistent.\n')
    md.append('8. PropagationSignature consistent.\n\n')
    md.append('Exact EventIDs/ticks are expected to match under a fresh '
              'deterministic restore; a mismatch is investigated and '
              'reported, not silently accepted.\n\n')
    md.append('## Per-repeat assertions\n\n')
    for r in rr:
        md.append('### %s (repeat of %s)\n\n' % (
            r['RepeatID'], r['RepeatOfSampleRunID']))
        md.append('- Fault parameters: `%s`\n' % json.dumps(
            r['FaultParameters']))
        md.append('- Expected fault state: `%s`\n' % json.dumps(
            r['ExpectedFaultState']))
        md.append('- Entry identity relation: %s\n' %
                  r['ExpectedEntryIdentityRelation'])
        md.append('- Expected consumer: %s; terminal: %s\n\n' % (
            r['ExpectedDownstreamConsumer'], r['ExpectedTerminalState']))
    md.append('## Stop condition\n\n')
    md.append('This round stops after the plan is delivered. No repeat is '
              'started until the researcher approves.\n')
    (C.REPEAT / 'MMU_Repeatability_Validation_Plan.md').write_text(''.join(md))


if __name__ == '__main__':
    main()
