#!/usr/bin/env python3
"""Task 1.5 - M07 terminal semantics audit + 31-SDC semantic audit.

M07 is Permission Grant Inversion.  The audit separates:
  OracleResult=FAIL
  DataValueMismatch
  PermissionPolicyViolation
  ArchitecturalStateCorruption / memory-mutation side effect
and proposes a ManifestationType without overwriting TerminalState.

Also classifies every one of the 31 SDC samples with the same evidence rules.
Read-only.
"""
import gzip
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C


def hx(v):
    try:
        return int(str(v), 16)
    except (TypeError, ValueError):
        return None


def parse(line):
    return C.parse_kv_line(line)


def permission_class(mode):
    if mode in ('Write', 'Atomic'):
        return 'UNAUTHORIZED_WRITE'
    if mode == 'Read':
        return 'UNAUTHORIZED_READ'
    if mode == 'Execute':
        return 'UNAUTHORIZED_EXECUTION'
    return 'PERMISSION_BYPASS'


def oracle_expected(line):
    """Return (expected, observed, basis) for a workload oracle line."""
    o = parse(line)
    if 'new_marker' in o:                      # W9
        return o.get('new_marker'), o.get('observed'), 'new_marker'
    if 'target_after' in o:                    # W10S
        return (o.get('target_after'), o.get('target_observed'),
                'target_after + neighbor_alias')
    if 'sentinel' in o and 'observed' in o:     # W10 / W12 / W13
        return o.get('sentinel'), o.get('observed'), 'sentinel'
    if 'expect' in o:                           # W11
        return o.get('expect'), o.get('observed'), 'expect'
    if 'expected' in o:                         # W14
        return o.get('expected'), o.get('observed'), 'expected'
    return None, None, ''


def value_mismatch(model, line):
    o = parse(line)
    if 'target_after' in o:
        tgt = o.get('target_observed') != o.get('target_after')
        nb = o.get('neighbor_alias_observed') != o.get('neighbor_before')
        return tgt or nb, 'W10S target_after/neighbor_before'
    exp, obs, basis = oracle_expected(line)
    if exp is None:
        return None, basis
    same = str(exp).lower() == str(obs).lower()
    return (not same), basis


def classify(model, context, target_mode, line, terminal):
    o = parse(line)
    mismatch, basis = value_mismatch(model, line)
    permission = model == 'M07'
    if model == 'M07':
        primary = permission_class(target_mode)
        secondary = 'PERMISSION_BYPASS'
        if o.get('shared_changed') == '1':
            secondary += '+DATA_INTEGRITY_SIDE_EFFECT'
        return primary, secondary, bool(mismatch), permission, basis
    if terminal == 'SQUASHED':
        return 'SQUASHED', 'DETECTED_EXCEPTION', bool(mismatch), False, basis
    if terminal == 'DETECTED_CONTAINED':
        return 'DETECTED_EXCEPTION', 'MASKED', bool(mismatch), False, basis
    if model == 'M03':
        return ('WRONG_CODE_PAGE_EXECUTION', 'WRONG_TRANSLATION',
                bool(mismatch), False, basis)
    if model in ('M04', 'M05') and target_mode == 'Execute':
        return ('WRONG_CODE_PAGE_EXECUTION', 'WRONG_TRANSLATION',
                bool(mismatch), False, basis)
    return ('WRONG_DATA_VALUE', 'WRONG_TRANSLATION', bool(mismatch), False,
            basis)


def ev_field(e, *names):
    for name in names:
        v = e.get(name)
        if v not in (None, ''):
            return v
    x = e.get('ExtraFields') or {}
    for name in names:
        v = x.get(name)
        if v not in (None, ''):
            return v
    return ''


def permission_evals(trace_path, va):
    """All permission_eval events for one VA, read from the raw trace."""
    out = []
    with gzip.open(trace_path, 'rt', errors='replace') as fh:
        for line in fh:
            if not line.startswith('PROP-EVT: '):
                continue
            ev = C.parse_evt_line(line)
            if ev.get('kind') == 'permission_eval' and ev.get('va') == va:
                out.append(ev)
    return out


def find(chain_events, kind, tid=None, mode=None, after_id=None):
    out = []
    for e in chain_events:
        if e.get('Kind') != kind:
            continue
        if tid is not None and str(e.get('TranslationID')) != str(tid):
            continue
        x = e.get('ExtraFields') or {}
        if mode is not None and x.get('mode') != mode:
            continue
        if after_id is not None and int(e.get('EventID')) < after_id:
            continue
        out.append(e)
    return out


def m07_rows():
    sids = ['M07-F0-W14-S01-R%02d' % i for i in range(1, 6)]
    rows = []
    for sid in sids:
        man = C.manifest(sid)
        ver = C.verdict(sid)
        ch = C.chain(sid)
        scan = C.scan_cache(sid)
        o = parse(ver['Details']['oracle']['line'])
        c = parse(ver['Details']['control_oracle']['line'])
        act_id = ver['activation_event_id']
        ch_events = ch['Events']
        act = next((e for e in ch_events
                    if int(e['EventID']) == int(act_id)), {})
        actx = act.get('ExtraFields') or {}
        tid = str(act.get('TranslationID') or '')
        # real deny decision: co-temporal permission_eval
        pe = [e for e in ch_events if e.get('Kind') == 'permission_eval' and
              (e.get('ExtraFields') or {}).get('permission_result') == 'deny']
        # downstream consumption for the fault's translation (R04/R05 the
        # activation carries tid=0; use the strict chain join)
        strict = ch.get('StrictChain') or {}
        join = (strict.get('identity') or {}) if strict else {}
        fault_tid = str(join.get('translation_id') or '')
        if fault_tid in ('', '0', 'None'):
            fault_tid = '' if tid in ('', '0') else tid
        tr = (find(ch_events, 'translation_result', tid=fault_tid)
              if fault_tid else find(ch_events, 'translation_result'))
        lsu_mode = 'Write' if man['target_mode'] == 'Atomic' else \
            man['target_mode']
        lsu = (find(ch_events, 'lsu_request', tid=fault_tid, mode=lsu_mode)
               if fault_tid else
               find(ch_events, 'lsu_request', mode=lsu_mode))
        lsux = merged_lsu = None
        if lsu:
            lsux = lsu[0].get('ExtraFields') or {}
        primary, secondary, mismatch, permission, basis = classify(
            'M07', man['context'], man['target_mode'],
            ver['Details']['oracle']['line'], ver['TerminalState'])
        strict_ok = strict.get('ok') if strict else None
        # Full-trace permission_eval context for this VA.  R02's activation
        # (translation_id=7) has no joined permission_eval; a same-VA deny
        # exists on translation_id=5 and must be reported, not hidden.
        all_pe = permission_evals(scan['TraceAbsolutePath'], act.get('VA', ''))
        joined_pe = [e for e in all_pe
                     if fault_tid and ev_field(e, 'translation_id',
                                               'TranslationID') == fault_tid]
        denies = [e for e in all_pe
                  if ev_field(e, 'permission_result') == 'deny']
        if pe:
            nearest = pe[0]
            nearest_source = 'chain'
        elif denies:
            try:
                act_tick = int(ev_field(act, 'tick', 'Tick') or 0)
                nearest = min(denies, key=lambda e: abs(
                    int(ev_field(e, 'tick', 'Tick') or 0) - act_tick))
                nearest_source = 'raw_trace_same_va_nearest'
            except ValueError:
                nearest = denies[0]
                nearest_source = 'raw_trace_same_va'
        else:
            nearest = {}
            nearest_source = ''
        nearest_tick_delta = ''
        try:
            nearest_tick_delta = str(
                int(ev_field(nearest, 'tick', 'Tick') or 0) -
                int(ev_field(act, 'tick', 'Tick') or 0)) if nearest else ''
        except ValueError:
            pass
        row = {
            'SampleRunID': sid,
            'ContextID': ver['context'],
            'TargetVA': '0x%x' % man['target_va'],
            'AccessMode': man['target_mode'],
            'WorkloadPhase': o.get('phase', ''),
            'TerminalStateOriginal': ver['TerminalState'],
            'OracleResultOriginal': ver['OracleResult'],
            'PropagationStatus': ver['PropagationStatus'],
            'TraceCompleteness': ver['TraceCompleteness'],
            'FaultedSignal': o.get('signal', ''),
            'FaultedObserved': o.get('observed', ''),
            'FaultedExpected': o.get('expected', ''),
            'FaultedValueOK': o.get('value_ok', ''),
            'FaultedInjectedSuccess': o.get('injected_success', ''),
            'SharedBefore': o.get('shared_before', ''),
            'SharedAfter': o.get('shared_after', ''),
            'SharedChanged': o.get('shared_changed', ''),
            'ControlSignal': c.get('signal', ''),
            'ControlFaultClass': c.get('fault_class', ''),
            'ControlSICode': c.get('si_code', ''),
            'ControlResult': c.get('result', ''),
            'ControlSharedChanged': c.get('shared_changed', ''),
            'ActivationEventID': act_id,
            'ActivationKind': act.get('Kind', ''),
            'ActivationTID': tid,
            'PermissionEvalEventIDs': ';'.join(
                str(e['EventID']) for e in pe),
            'PermissionEvalResult': 'deny' if pe else '',
            'PermissionBefore': actx.get('permission_before', ''),
            'PermissionAfter': actx.get('permission_after', ''),
            'FaultSite': actx.get('fault_site', ''),
            'TranslationResultEventIDs': ';'.join(
                str(e['EventID']) for e in tr),
            'TranslationResultPA': ';'.join(
                str(e.get('PA', '')) for e in tr),
            'LSURequestEventIDs': ';'.join(
                str(e['EventID']) for e in lsu),
            'LSURequestMode': (lsux or {}).get('mode', '') if lsu else '',
            'PermissionEvalEventPresent': bool(pe),
            'JoinedPermissionEvalEventIDs': ';'.join(
                str(e['EventID']) for e in pe),
            'JoinedPermissionEvalTranslationIDs': ';'.join(
                str(e.get('TranslationID')) for e in pe),
            'NearestPermissionEvalEventID': ev_field(nearest, 'event_id',
                                                     'EventID'),
            'NearestPermissionEvalTranslationID':
                ev_field(nearest, 'translation_id', 'TranslationID'),
            'NearestPermissionEvalResult':
                ev_field(nearest, 'permission_result'),
            'NearestPermissionEvalMode': ev_field(nearest, 'mode'),
            'NearestPermissionEvalTickDelta': nearest_tick_delta,
            'NearestPermissionEvalSource': nearest_source,
            'PermissionEvalNote': (
                '' if pe else
                ('no permission_eval is joined to the activation '
                 'translation_id=%s; nearest same-VA deny is event %s '
                 '(translation_id=%s, mode=%s, tick delta %s), which the '
                 'frozen validator does not associate; the activation '
                 'records permission_before=false and the control shows '
                 'SIGSEGV permission fault' % (
                     fault_tid or tid or 'n/a',
                     ev_field(nearest, 'event_id', 'EventID') or 'n/a',
                     ev_field(nearest, 'translation_id',
                              'TranslationID') or 'n/a',
                     ev_field(nearest, 'mode') or 'n/a',
                     nearest_tick_delta or 'n/a'))
                if nearest else
                ('no permission_eval for this VA in the frozen trace; the '
                 'deny is recorded by mmu_fault_activate '
                 '(permission_before=false) and corroborated by the control '
                 'SIGSEGV permission fault')),
            'StrictChainOK': strict_ok,
            'JoinBasis': strict.get('activation_basis', '') if strict
                         else ('direct activation/translation id'
                               if tid not in ('', '0') else ''),
            'ExactKeyMatchCount': join.get('exact_key_match_count', ''),
            'ExactDenyMatchCount': join.get('exact_key_deny_match_count', ''),
            'ExecuteRequestMatchCount': join.get(
                'execute_request_match_count', ''),
            'ObservedKindsFormal': ';'.join(
                ver['Details'].get('observed_kinds', [])),
            'ChainJoinMismatches': len(scan['ChainJoinMismatches']),
            'DataValueMismatch': bool(mismatch),
            'PermissionPolicyViolation': permission,
            'MemoryMutationSideEffect': o.get('shared_changed') == '1',
            'ExceptionInFaultedRun': o.get('signal') not in ('0', ''),
            'ManifestationTypePrimary': primary,
            'ManifestationTypeSecondary': secondary,
            'ClassificationBasis': (
                'access succeeded without exception on a page/operation the '
                'independent control denies with SIGSEGV+permission fault; '
                'observed value equals expected (value_ok=%s)' %
                o.get('value_ok', '')),
            'SemanticAuditVerdict': (
                'SDC_CONFIRMED_PERMISSION_BYPASS'
                if permission else 'NEEDS_REVIEW'),
            'OriginalTerminalStatePreserved': True,
        }
        rows.append(row)
    return rows


def sdc_audit_rows():
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    rows = []
    for sid in sorted(matrix):
        m = matrix[sid]
        if m['TerminalState'] != 'SDC':
            continue
        man = C.manifest(sid)
        ver = C.verdict(sid)
        o = parse(ver['Details']['oracle']['line'])
        ctl = parse(ver['Details']['control_oracle']['line'])
        primary, secondary, mismatch, permission, basis = classify(
            m['ModelID'], m['ContextID'], man['target_mode'],
            ver['Details']['oracle']['line'], m['TerminalState'])
        proof = (ver['Details'].get('wrong_value_proven') is True or
                 ver['Details'].get('wrong_value_proven') == 'true')
        control_diff = ver['Details']['control_oracle'].get('diff')
        trace_ok = (ver['TraceCompleteness'] == 'COMPLETE' and
                    ver['PropagationStatus'] == 'FULL' and
                    not ver['MissingCausalEdges'])
        terminal_ok = (mismatch or permission)
        status = ('CONFIRMED_SDC' if (terminal_ok and proof and control_diff
                                      and trace_ok) else 'NEEDS_REVIEW')
        rows.append({
            'SampleRunID': sid,
            'ModelID': m['ModelID'],
            'ContextID': m['ContextID'],
            'WorkloadID': m['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'AccessMode': man['target_mode'],
            'TerminalState': m['TerminalState'],
            'OracleResult': m['OracleResult'],
            'PropagationStatus': m['PropagationStatus'],
            'TraceCompleteness': m['TraceCompleteness'],
            'OracleObserved': o.get('observed', ''),
            'OracleExpected': (o.get('new_marker') or o.get('sentinel') or
                               o.get('expect') or o.get('expected') or
                               o.get('target_after') or ''),
            'OracleBasis': basis,
            'ValueOK': o.get('value_ok', ''),
            'SharedChanged': o.get('shared_changed', ''),
            'ControlSignal': ctl.get('signal', ''),
            'ControlResult': ctl.get('result', ''),
            'ControlDiff': control_diff,
            'WrongValueProven': proof,
            'TraceProven': trace_ok,
            'DataValueMismatch': bool(mismatch),
            'PermissionPolicyViolation': permission,
            'ManifestationTypePrimary': primary,
            'ManifestationTypeSecondary': secondary,
            'SemanticAuditStatus': status,
            'EvidenceBasis': (
                'observed=%s expected=%s value_ok=%s; control=%s/%s; '
                'wrong_value_proven=%s; trace=%s/%s' % (
                    o.get('observed', ''), o.get('expected') or
                    o.get('sentinel') or o.get('expect') or
                    o.get('new_marker') or o.get('target_after'),
                    o.get('value_ok', ''), ctl.get('signal', ''),
                    ctl.get('result', ''), proof,
                    m['PropagationStatus'], m['TraceCompleteness'])),
        })
    return rows


def main():
    C.ensure_dirs()
    m07 = m07_rows()
    sdc = sdc_audit_rows()
    C.write_csv(C.AUDIT / 'M07_Sample_Evidence.csv', m07)
    C.write_csv(C.AUDIT / 'SDC_Semantic_Audit.csv', sdc)
    C.write_json(C.AUDIT / 'M07_Terminal_Semantics_Audit.json',
                 {'m07': m07, 'sdc_audit': sdc})

    md = ['# M07 Permission Grant Inversion - Terminal Semantics Audit\n\n',
          'Sources: `sample_manifest.json`, `Validation/verdict.json`, the '
          'frozen `analysis/propagation_chains/M07-*.json` (event IDs '
          'verified against the raw `prop_evt.txt.gz`; zero join mismatches), '
          'the faulted `Run_Log/observed_output.txt` and the independent '
          '`TEST-F1-CTRL2-W14-R0x` control transcripts.\n\n',
          '## Per-sample evidence\n\n',
          '| Ctx | Mode | Phase | Faulted signal | Observed | Expected | '
          'value_ok | shared_changed | Control | Permission eval | '
          'Manifestation |\n|---|---|---|---|---|---|---|---|---|---|---|\n']
    for r in m07:
        md.append('| %s | %s | %s | %s | %s | %s | %s | %s | signal=%s %s | '
                  '%s | **%s** |\n' % (
                      r['ContextID'], r['AccessMode'], r['WorkloadPhase'],
                      r['FaultedSignal'], r['FaultedObserved'],
                      r['FaultedExpected'], r['FaultedValueOK'],
                      r['SharedChanged'], r['ControlSignal'],
                      r['ControlFaultClass'],
                      ('deny (joined %s)' % r['PermissionEvalEventIDs']
                       if r['PermissionEvalEventIDs'] else
                       'none joined; nearest %s/tid%s' % (
                           r['NearestPermissionEvalEventID'],
                           r['NearestPermissionEvalTranslationID'])),
                      r['ManifestationTypePrimary']))
    md.append('\n## Event-level proof\n\n')
    for r in m07:
        md.append('- **%s**: `permission_eval` deny event(s) %s -> '
                  '`mmu_fault_activate` %s (permission_before=%s, '
                  'permission_after=%s, fault_site=%s) -> '
                  '`translation_result` %s at PA %s -> `lsu_request` %s '
                  '(mode=%s). StrictChain ok=%s, join basis=%s.\n' % (
                      r['ContextID'],
                      (r['PermissionEvalEventIDs'] or
                       'none joined (nearest %s/tid%s)' % (
                           r['NearestPermissionEvalEventID'],
                           r['NearestPermissionEvalTranslationID'])),
                      r['ActivationEventID'], r['PermissionBefore'],
                      r['PermissionAfter'], r['FaultSite'],
                      r['TranslationResultEventIDs'],
                      r['TranslationResultPA'], r['LSURequestEventIDs'],
                      r['LSURequestMode'], r['StrictChainOK'],
                      r['JoinBasis']))
        if r['PermissionEvalNote']:
            md.append('  *Note*: %s.\n' % r['PermissionEvalNote'])
    md.append('\n## Classification\n\n')
    md.append('* **R01, R02 = UNAUTHORIZED_WRITE** (+ PERMISSION_BYPASS, '
              '+ DATA_INTEGRITY_SIDE_EFFECT). The store/atomic on a '
              'read-only page completes with no exception and mutates the '
              'shared page (`shared_changed=1`); the independent control '
              'receives SIGSEGV + permission fault and leaves it unchanged.\n')
    md.append('* **R03 = UNAUTHORIZED_READ** (+ PERMISSION_BYPASS). EL0 '
              'reads the PAGE_EXECONLY page (`observed=0x88`, '
              '`value_ok=1`); the control faults with SIGSEGV + permission '
              'fault.\n')
    md.append('* **R04, R05 = UNAUTHORIZED_EXECUTION** (+ PERMISSION_BYPASS). '
              'Code is fetched/executed from an XN mapping and the marker is '
              'returned (0xc7 / 0x5a); the control faults with SIGSEGV + '
              'permission fault. R05 is an indirect-branch fetch '
              '(`stage=indirect_branch insn=br` then `stage=executed '
              'marker=0x5a`).\n\n')
    md.append('## OracleResult=FAIL is not the manifestation\n\n')
    md.append('In every M07 sample `value_ok=1` and `injected_success=1`; '
              'the observed value equals the expected value. There is **no '
              'WRONG_DATA_VALUE** in M07. `OracleResult=FAIL` means the '
              'workload detected that an operation which must be denied '
              'instead succeeded. `PermissionPolicyViolation=true` in all '
              'five; `ArchitecturalStateCorruption` applies only as the '
              'memory-mutation side effect of R01/R02, not as the primary '
              'label. The original `TerminalState=SDC` is preserved; '
              '`ManifestationType` is an added diagnostic dimension, not an '
              'overwrite.\n\n')
    md.append('## Evidence limitation (R04/R05)\n\n')
    md.append('The instruction-fetch activation row carries '
              '`translation_id=0` and `dyn_inst_seq=0` because the C++ hook '
              'runs for a fetch Request with no sequence number. The formal '
              '`Details.observed_kinds` therefore lists only '
              'activation/summary/permission_eval for R04/R05; the '
              'downstream `translation_result` and `lsu_request` carry '
              '`fault_id=0`. The frozen strict chain supplies a co-temporal '
              'join (`exact_key_match_count=1`, `exact_key_deny_match_count'
              '=1`, `execute_request_match_count=1`); the join is never '
              'inferred from event order. This is a method limitation, not a '
              'missing propagation.\n')

    md.append('\n## SDC semantic audit (all 31 samples)\n\n')
    md.append('| Sample | Model | Terminal | Value mismatch | Permission '
              'bypass | Manifestation | Audit |\n|---|---|---|---|---|---|---|\n')
    for r in sdc:
        md.append('| %s | %s | %s | %s | %s | %s | %s |\n' % (
            r['SampleRunID'], r['ModelID'], r['TerminalState'],
            r['DataValueMismatch'], r['PermissionPolicyViolation'],
            r['ManifestationTypePrimary'], r['SemanticAuditStatus']))
    from collections import Counter
    statuses = Counter(r['SemanticAuditStatus'] for r in sdc)
    prim = Counter(r['ManifestationTypePrimary'] for r in sdc)
    md.append('\n**31 SDC samples audited**: %s. Primary manifestation '
              'distribution: %s.\n\n' % (
                  dict(statuses), dict(prim)))
    md.append('No sample was reclassified as a different TerminalState. '
              'The audit confirms each SDC by a software-visible oracle '
              'difference (wrong data value or permission-policy bypass), a '
              'control difference, trace completeness and `wrong_value_proven`.'
              ' OracleResult=FAIL alone was never used as the criterion.\n')
    (C.AUDIT / 'M07_Terminal_Semantics_Audit.md').write_text(''.join(md))
    print(json.dumps({
        'm07': [{k: r[k] for k in (
            'ContextID', 'AccessMode', 'FaultedObserved', 'FaultedExpected',
            'FaultedValueOK', 'SharedChanged', 'ControlSignal',
            'PermissionEvalEventIDs', 'ManifestationTypePrimary',
            'ManifestationTypeSecondary', 'StrictChainOK')} for r in m07],
        'sdc_count': len(sdc),
        'sdc_status': dict(Counter(r['SemanticAuditStatus'] for r in sdc)),
        'sdc_primary': dict(Counter(r['ManifestationTypePrimary']
                                    for r in sdc)),
        'sdc_review': [r['SampleRunID'] for r in sdc
                       if r['SemanticAuditStatus'] != 'CONFIRMED_SDC'],
    }, indent=1))


if __name__ == '__main__':
    main()
