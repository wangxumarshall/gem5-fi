#!/usr/bin/env python3
"""Task 1.4 - attempt history for the two interrupted retries.

Every attempt directory under attempt_A01/ and attempt_A02/ is inventoried from
raw artifacts (never from the summary statistics alone). Read-only.
"""
import datetime
import gzip
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

START_RE = re.compile(r'gem5 started (.+)$', re.M)
PAYLOAD_RE = re.compile(r"base64 -d > \S+ <<'([A-Za-z0-9_]+)'")


def extract_payload_hash(rcs_path):
    try:
        lines = Path(rcs_path).read_text(errors='replace').splitlines()
    except OSError:
        return None
    marker, start = None, None
    for i, line in enumerate(lines):
        m = PAYLOAD_RE.search(line)
        if m:
            marker, start = m.group(1), i + 1
            break
    if marker is None:
        return None
    import base64
    blob = []
    for line in lines[start:]:
        if line.strip() == marker:
            break
        blob.append(line.strip())
    try:
        return C.hashlib.sha256(
            gzip.decompress(base64.b64decode(''.join(blob)))).hexdigest()
    except Exception:
        return None


def trace_stats(path):
    if not path or not Path(path).is_file():
        return {'path': '', 'exists': False, 'size': '', 'sha256': '',
                'events': '', 'kinds': {}, 'fault_activated': None}
    p = Path(path)
    kinds = Counter()
    n = 0
    truncated = False
    try:
        with gzip.open(p, 'rt', errors='replace') as fh:
            for line in fh:
                if not line.startswith('PROP-EVT: '):
                    continue
                n += 1
                ev = C.parse_evt_line(line)
                kinds[ev.get('kind', '')] += 1
    except (EOFError, OSError):
        truncated = True
    return {'path': str(p), 'exists': True, 'size': p.stat().st_size,
            'sha256': C.sha256_file(p), 'events': n,
            'kinds': dict(kinds), 'truncated': truncated,
            'fault_activated': any(k.startswith('mmu_fault_')
                                   or k in ('refill_pfn_corrupt',
                                            'tlbi_suppressed')
                                   for k in kinds)}


def attempt_row(sid, attempt_dir, adopted_attempt):
    d = Path(attempt_dir)
    attempt = d.parent.name.replace('attempt_', '')
    man_p = d / 'sample_manifest.json'
    ver_p = d / 'Validation' / 'verdict.json'
    sum_p = d / 'SHA256' / 'SHA256SUMS.txt'
    res_p = C.CAMP / 'logs' / ('%s.result.json' % sid)
    man = C.load_json(man_p) if man_p.exists() else {}
    res = C.load_json(res_p) if res_p.exists() else {}
    # logs/<sid>.result.json belongs to the adopted attempt only
    res_matches = bool(res) and str(res.get('attempt')) == attempt
    stats = d / 'Run_Log' / 'stats.txt'
    stats_run = d / 'run' / 'stats.txt'
    trace = d / 'Trace' / 'prop_evt.txt.gz'
    if not trace.exists():
        trace = d / 'run' / 'prop_evt.txt.gz'
    cfg = d / 'Config' / 'config.ini'
    if not cfg.exists():
        cfg = d / 'run' / 'config.ini'
    rcS = d / 'rcS.scoped'
    stdout = d / 'Run_Log' / 'gem5_stdout.log'
    exit_p = d / 'Run_Log' / 'gem5_exit_code.txt'
    started = man.get('started_at_utc', '')
    finished = man.get('finished_at_utc', '')
    if not started and stdout.exists():
        m = START_RE.search(stdout.read_text(errors='replace'))
        started = ('gem5_stdout: ' + m.group(1).strip()) if m else ''
    if not finished and res_matches:
        finished = res.get('finished_utc', '')
    complete = (man_p.exists() and ver_p.exists() and sum_p.exists() and
                (stats.exists() and stats.stat().st_size > 0))
    interruptions = []
    if not man_p.exists():
        interruptions.append('no sample_manifest.json')
    if not ver_p.exists():
        interruptions.append('no Validation/verdict.json')
    if not sum_p.exists():
        interruptions.append('no SHA256/SHA256SUMS.txt')
    if not stats.exists():
        interruptions.append('no Run_Log/stats.txt')
    elif stats.stat().st_size == 0:
        interruptions.append('Run_Log/stats.txt is 0 bytes')
    if not exit_p.exists():
        interruptions.append('no gem5_exit_code.txt')
    if not res_matches:
        interruptions.append(
            'no per-attempt logs/%s.result.json (campaign result JSON is for '
            'the adopted attempt only)' % sid)
    t = trace_stats(trace)
    if t['truncated']:
        interruptions.append('trace gzip truncated (EOF before end marker)')
    if complete:
        status = 'COMPLETED_FINAL' if attempt == adopted_attempt else \
            'COMPLETED_SUPERSEDED'
    else:
        status = 'INTERRUPTED_PARTIAL'
    workload_hash = man.get('workload_sha256', '')
    workload_source = 'manifest.workload_sha256'
    if not workload_hash:
        workload_hash = extract_payload_hash(rcS) or ''
        workload_source = 'rcS.scoped embedded payload' if workload_hash \
            else 'n/a (no manifest, no embedded payload)'
    return {
        'SampleRunID': sid,
        'AttemptID': attempt,
        'AttemptDir': str(d),
        'Status': status,
        'Adopted': attempt == adopted_attempt,
        'StartedUTC': started,
        'FinishedUTC': finished,
        'Gem5ExitCode': (man.get('gem5_exit_code')
                         if man else (exit_p.read_text().strip()
                                      if exit_p.exists() else '')),
        'RunnerStatus': res.get('status', '') if res_matches else '',
        'RunnerExitCode': (res.get('runner_exit_code', '')
                           if res_matches else ''),
        'HasManifest': man_p.exists(),
        'HasVerdict': ver_p.exists(),
        'HasSHA256SUMS': sum_p.exists(),
        'HasResultJSON': res_matches,
        'StatsBytes': stats.stat().st_size if stats.exists() else '',
        'TracePath': t['path'],
        'TraceBytes': t['size'],
        'TraceSHA256': t['sha256'],
        'TraceEventCount': t['events'],
        'TraceTruncated': t['truncated'],
        'TraceHasFaultActivation': t['fault_activated'],
        'BinarySHA256': (man.get('gem5_sha256') or
                         C.sha256_file(C.REPO / 'CHAOS/gem5/build/ARM/'
                                       'gem5.opt')),
        'ConfigSHA256': C.sha256_file(cfg) if cfg.exists() else '',
        'WorkloadSHA256': workload_hash,
        'WorkloadHashSource': workload_source,
        'InterruptionEvidence': '; '.join(interruptions),
        'AdoptionReason': '',
    }


def main():
    C.ensure_dirs()
    rows = []
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    for sid in sorted(matrix):
        adopted = matrix[sid]['AttemptID']
        for a in ('attempt_A01', 'attempt_A02'):
            d = C.CAMP / a / sid
            if d.is_dir():
                rows.append(attempt_row(sid, d, adopted))
    # reason text for the two retries
    for r in rows:
        if r['Status'] == 'INTERRUPTED_PARTIAL':
            r['AdoptionReason'] = (
                'superseded by completed attempt A02; A01 lacks completion '
                'artifacts (see interruption evidence) and has a 0-byte '
                'stats file / truncated trace')
        elif r['Status'] == 'COMPLETED_FINAL' and r['SampleRunID'] in (
                'M06-F0-W10-S01-R04', 'M08-F0-W10-S01-R04'):
            r['AdoptionReason'] = (
                'adopted final attempt: status COMPLETED, gem5 exit 0, '
                'manifest+verdict+SHA256SUMS present; replaces interrupted '
                'A01')

    counts = {
        'unique_sample_run_ids': len({r['SampleRunID'] for r in rows}),
        'completed_final_attempts': sum(1 for r in rows
                                        if r['Status'].startswith(
                                            'COMPLETED_FINAL')),
        'completed_superseded_attempts': sum(
            1 for r in rows if r['Status'] == 'COMPLETED_SUPERSEDED'),
        'interrupted_attempts': sum(1 for r in rows
                                    if r['Status'] == 'INTERRUPTED_PARTIAL'),
        'attempt_directories_total': len(rows),
        'a01_dirs': sum(1 for r in rows if r['AttemptID'] == 'A01'),
        'a02_dirs': sum(1 for r in rows if r['AttemptID'] == 'A02'),
    }
    report = {'counts': counts, 'attempts': rows,
              'generated_utc': datetime.datetime.utcnow().isoformat() + 'Z'}
    C.write_json(C.AUDIT / 'Attempt_Audit.json', report)
    C.write_csv(C.AUDIT / 'Attempt_History.csv', rows)

    md = ['# Attempt History Audit\n\n',
          'Inventoried from the raw `attempt_A01/` and `attempt_A02/` '
          'directories, per-sample `sample_manifest.json`, '
          '`Validation/verdict.json`, `SHA256/SHA256SUMS.txt`, '
          '`Run_Log/` and `logs/*.result.json`. No count below is copied '
          'from the campaign summary.\n\n',
          '## Verified counts\n\n',
          '| Metric | Value |\n|---|---|\n']
    for k, v in counts.items():
        md.append('| %s | %s |\n' % (k, v))
    md.append('\n## Interrupted attempts\n\n')
    for r in rows:
        if r['Status'] == 'INTERRUPTED_PARTIAL':
            md.append('### %s / %s\n\n' % (r['SampleRunID'],
                                          r['AttemptID']))
            md.append('- Directory: `%s`\n' % r['AttemptDir'])
            md.append('- Started: `%s`; finished: `%s`\n' % (
                r['StartedUTC'], r['FinishedUTC'] or 'n/a'))
            md.append('- Evidence: %s\n' % r['InterruptionEvidence'])
            md.append('- Partial trace: `%s` (%s bytes, %s events, '
                      'truncated=%s, fault activation observed: %s)\n' % (
                          r['TracePath'], r['TraceBytes'],
                          r['TraceEventCount'], r['TraceTruncated'],
                          r['TraceHasFaultActivation']))
            md.append('- Binary SHA256: `%s`\n' % r['BinarySHA256'])
            md.append('- Config SHA256: `%s`\n' % r['ConfigSHA256'])
            md.append('- Workload SHA256: `%s` (%s)\n\n' % (
                r['WorkloadSHA256'], r['WorkloadHashSource']))
    md.append('## Final attempt adoption\n\n')
    md.append('| Sample | Attempt | Status | Adopted | Reason |\n'
              '|---|---|---|---|---|\n')
    for r in rows:
        if r['SampleRunID'] in ('M06-F0-W10-S01-R04',
                                'M08-F0-W10-S01-R04'):
            md.append('| %s | %s | %s | adopted=%s | %s |\n' % (
                r['SampleRunID'], r['AttemptID'], r['Status'],
                r['Adopted'], r['AdoptionReason']))
    md.append('\nFor both retries the frozen binary and workload hashes are '
              'identical across A01/A02; the `ConfigSHA256` differs because '
              '`config.ini` embeds the absolute attempt `outdir` (3 '
              'occurrences), not because the parameters changed.\n\n')
    md.append('\nThe A02 result JSONs record `status=COMPLETED`, '
              '`runner_exit_code=0`, `gem5_exit_code=0`, and start/finish '
              'times; A01 has no result JSON and no completion artifacts. '
              'The exact external signal that killed A01 is not recorded in '
              'the artifacts; the campaign report attributes it to an '
              'external process interruption, and the artifact state is '
              'consistent with that.\n')
    (C.AUDIT / 'Attempt_Audit.md').write_text(''.join(md))
    print(json.dumps(counts, indent=1))
    for r in rows:
        if r['Status'] == 'INTERRUPTED_PARTIAL':
            print(json.dumps({k: r[k] for k in (
                'SampleRunID', 'AttemptID', 'StartedUTC', 'TraceBytes',
                'TraceEventCount', 'TraceTruncated',
                'TraceHasFaultActivation',
                'BinarySHA256', 'ConfigSHA256', 'WorkloadSHA256',
                'WorkloadHashSource', 'InterruptionEvidence')}, indent=1))


if __name__ == '__main__':
    main()
