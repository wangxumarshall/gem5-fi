#!/usr/bin/env python3
"""Task 1.1 - final audit of the 40 formal samples.

Cross-checks the frozen XLSX / CSV / JSON matrices, the authority matrix,
per-sample manifests, verdicts, runner result JSONs and the per-sample
SHA256SUMS. Read-only over the campaign; writes only under audit/.
"""
import datetime
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

REQ_FIELDS = [
    ('SampleRunID', 'SampleRunID'),
    ('ModelID', 'ModelID'),
    ('ContextID', 'ContextID'),
    ('WorkloadID', 'WorkloadID'),
    ('AttemptID', 'AttemptID'),
    ('FaultID', 'FaultID'),
    ('InjectionStatus', 'ActivationStatus'),
    ('FaultConsumptionStatus', 'FaultConsumptionStatus'),
    ('PropagationStatus', 'PropagationStatus'),
    ('TerminalState', 'TerminalState'),
    ('OracleResult', 'OracleResult'),
    ('TraceCompleteness', 'TraceCompleteness'),
    ('RecordIntegrity', 'RecordIntegrity'),
    ('BinarySHA256', 'BinarySHA256'),
    ('ConfigSHA256', 'ConfigSHA256'),
    ('WorkloadSHA256', 'WorkloadSHA256'),
]
HASH_RE = re.compile(r'^([0-9a-fA-F]{64})\s+(.+)$')


def norm(v):
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'true' if v else 'false'
    s = str(v).strip()
    if s.lower() in ('none', 'null'):
        return ''
    return s


def source_value(src, row, legacy_name):
    if row is None:
        return None
    if src == 'xlsx' and legacy_name not in row:
        return None
    return row.get(legacy_name)


def resolve_shasum_path(sid, entry):
    if entry.startswith('gem5:'):
        return Path(entry[len('gem5:'):])
    if entry.startswith('source:'):
        return C.REPO / entry[len('source:'):]
    if entry.startswith('workload:'):
        return Path(entry[len('workload:'):])
    return C.sample_dir(sid) / entry


def verify_shasums(sid, disk_hash_cache):
    p = C.sample_dir(sid) / 'SHA256' / 'SHA256SUMS.txt'
    out = {'path': str(p), 'exists': p.exists(), 'entries': 0,
           'verified': 0, 'mismatches': [], 'missing': [],
           'disk_img_skipped_actual': False}
    if not p.exists():
        return out
    for line in p.read_text().splitlines():
        m = HASH_RE.match(line.strip())
        if not m:
            continue
        want, entry = m.group(1), m.group(2)
        out['entries'] += 1
        path = resolve_shasum_path(sid, entry)
        if not path.exists():
            out['missing'].append(entry)
            continue
        if path.name == 'disk.img':
            if 'disk' not in disk_hash_cache:
                disk_hash_cache['disk'] = C.sha256_file(path)
            got = disk_hash_cache['disk']
            out['disk_img_skipped_actual'] = True
        else:
            got = C.sha256_file(path)
        if got.lower() == want.lower():
            out['verified'] += 1
        else:
            out['mismatches'].append({'entry': entry, 'recorded': want,
                                      'actual': got})
    out['ok'] = (not out['mismatches'] and not out['missing'])
    return out


def verify_evidence_index(rows, disk_hash_cache):
    by_sid = {}
    for r in rows:
        sid = r['SampleRunID']
        p = Path(r['AbsolutePath'])
        rec = {'file': r['File'], 'exists': p.exists(),
               'recorded': r.get('SHA256', ''), 'actual': '', 'ok': None}
        if p.exists():
            if p.name == 'disk.img':
                if 'disk' not in disk_hash_cache:
                    disk_hash_cache['disk'] = C.sha256_file(p)
                rec['actual'] = disk_hash_cache['disk']
            else:
                rec['actual'] = C.sha256_file(p)
            rec['ok'] = (rec['actual'].lower() ==
                         str(r.get('SHA256', '')).lower())
        by_sid.setdefault(sid, []).append(rec)
    return by_sid


def main():
    C.ensure_dirs()
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    xlsx = {r['SampleRunID']: r for r in C.xlsx_matrix_rows()}
    scsv = {r['SampleRunID']: r for r in C.samples_csv_rows()}
    sjson = {r['SampleRunID']: r for r in C.samples_json_rows()}
    authority = {r['SampleRunID']: r for r in C.authority_matrix_rows()}
    pairs = {r['SampleRunID']: r for r in C.fault_control_pairs()}
    evidx = verify_evidence_index(C.evidence_index_rows(),
                                  {'disk': C.sha256_file(
                                      C.sample_dir(sorted(matrix)[0]) /
                                      'disk.img')})
    gem5_actual = C.sha256_file(
        C.REPO / 'CHAOS' / 'gem5' / 'build' / 'ARM' / 'gem5.opt')

    detail = {'generated_utc': datetime.datetime.utcnow().isoformat() + 'Z',
              'sources': {}, 'samples': [], 'anomalies': [],
              'field_agreement_summary': {}, 'counts': {},
              'campaign_stats_observed': {}, 'campaign_stats_reported': {},
              'gem5_binary_actual_sha256': gem5_actual}
    agreement = {f: Counter() for f, _ in REQ_FIELDS}
    sids = sorted(matrix)
    disk_cache = {'disk': C.sha256_file(C.sample_dir(sids[0]) / 'disk.img')}

    for sid in sids:
        mrow, xrow = matrix[sid], xlsx.get(sid)
        crow, jrow = scsv.get(sid), sjson.get(sid)
        arow = authority.get(sid)
        rdir = C.sample_dir(sid)
        man = C.manifest(sid)
        ver = C.verdict(sid)
        res = C.result_json(sid)
        scan = C.scan_cache(sid)
        notes = []

        srcs = {
            'matrix_csv': mrow, 'matrix_xlsx': xrow,
            'samples_csv': crow, 'samples_json': jrow,
            'manifest': man, 'verdict': ver, 'result_json': res,
            'authority_design': arow,
        }
        # manifest-derived values (AttemptID / status are cross-file joins)
        attempt_from_dir = rdir.parent.name.replace('attempt_', '')
        attempt_from_result = res.get('attempt')
        manifest_join = {
            'SampleRunID': man.get('sample_run_id'),
            'ModelID': man.get('model'),
            'ContextID': man.get('context'),
            'WorkloadID': man.get('workload'),
            'AttemptID': attempt_from_result,
            'FaultID': ver.get('fault_id'),
            'InjectionStatus': ver.get('ActivationStatus'),
            'FaultConsumptionStatus': ver.get('FaultConsumptionStatus'),
            'PropagationStatus': ver.get('PropagationStatus'),
            'TerminalState': ver.get('TerminalState'),
            'OracleResult': ver.get('OracleResult'),
            'TraceCompleteness': ver.get('TraceCompleteness'),
            'RecordIntegrity': ver.get('RecordIntegrity'),
            'BinarySHA256': man.get('gem5_sha256'),
            'ConfigSHA256': (C.sha256_file(rdir / 'Config' / 'config.ini')
                             if (rdir / 'Config' / 'config.ini').exists()
                             else ''),
            'WorkloadSHA256': man.get('workload_sha256'),
        }
        verdict_vals = {
            'SampleRunID': ver.get('sample_run_id'),
            'ModelID': ver.get('model'),
            'ContextID': ver.get('context'),
            'WorkloadID': ver.get('workload'),
            'AttemptID': attempt_from_result,
            'FaultID': ver.get('fault_id'),
            'InjectionStatus': ver.get('ActivationStatus'),
            'FaultConsumptionStatus': ver.get('FaultConsumptionStatus'),
            'PropagationStatus': ver.get('PropagationStatus'),
            'TerminalState': ver.get('TerminalState'),
            'OracleResult': ver.get('OracleResult'),
            'TraceCompleteness': ver.get('TraceCompleteness'),
            'RecordIntegrity': ver.get('RecordIntegrity'),
            'BinarySHA256': '',
            'ConfigSHA256': '',
            'WorkloadSHA256': '',
        }
        result_vals = {'AttemptID': attempt_from_result,
                       'SampleRunID': res.get('sample_run_id')}
        authority_vals = {
            'SampleRunID': arow.get('SampleRunID') if arow else None,
            'ModelID': arow.get('ModelID') if arow else None,
            'ContextID': arow.get('ContextID') if arow else None,
            'WorkloadID': arow.get('WorkloadID') if arow else None,
        }

        fields = {}
        for display, leg in REQ_FIELDS:
            vals = {}
            for src, row in (('matrix_csv', mrow), ('matrix_xlsx', xrow),
                             ('samples_csv', crow), ('samples_json', jrow)):
                if row is not None:
                    vals[src] = norm(source_value(src, row, leg))
            if leg in manifest_join:
                vals['manifest_join'] = norm(manifest_join[leg])
            if leg in verdict_vals and verdict_vals[leg] not in ('', None):
                vals['verdict'] = norm(verdict_vals[leg])
            if leg in result_vals and result_vals[leg] not in ('', None):
                vals['result_json'] = norm(result_vals[leg])
            if leg in authority_vals and authority_vals[leg] not in ('', None):
                vals['authority_design'] = norm(authority_vals[leg])
            # actual files for hashes
            if display == 'BinarySHA256':
                vals['actual_gem5_binary'] = gem5_actual
            if display == 'ConfigSHA256':
                cfg = rdir / 'Config' / 'config.ini'
                if cfg.exists():
                    vals['actual_config_ini'] = C.sha256_file(cfg)
            if display == 'WorkloadSHA256':
                wb = C.repr_path(man.get('workload_binary', ''))
                if wb.is_file():
                    vals['actual_manifest_binary'] = C.sha256_file(wb)
            if display == 'SampleRunID':
                vals['run_dir_name'] = rdir.name
            if display == 'AttemptID':
                vals['run_dir_attempt'] = attempt_from_dir

            present = {k: v for k, v in vals.items() if v != ''}
            explanation = ''
            if not present:
                status = 'MISSING'
            elif len(set(present.values())) == 1:
                status = 'AGREE'
            else:
                status = 'DIFF'
            # W10S is an internal variant: the authoritative WorkloadID stays
            # W10 everywhere except the verdict, which records the run
            # workload.  This is documented and is not a record conflict.
            if (status == 'DIFF' and display == 'WorkloadID' and
                    set(present.values()) == {'W10', 'W10S'} and
                    str(man.get('workload_variant', '')).startswith('W10S')):
                status = 'AGREE_VARIANT'
                explanation = (
                    'authoritative WorkloadID W10; verdict records internal '
                    'run workload W10S (variant %s)' %
                    man.get('workload_variant'))
                notes.append(explanation)
            agreement[display][status] += 1
            fields[display] = {'status': status,
                               'values': vals,
                               'distinct': sorted(set(present.values())),
                               'explanation': explanation}

        sh = verify_shasums(sid, disk_cache)
        ev = evidx.get(sid, [])
        ev_bad = [x for x in ev if not x['exists'] or x['ok'] is False]
        rec_integrity = (ver.get('Details') or {}).get(
            'record_integrity', {})
        event_count_match = (int(ver.get('event_count', -1)) ==
                             int(scan['EventCount']))
        if not event_count_match:
            notes.append('event_count verdict=%s trace=%s' % (
                ver.get('event_count'), scan['EventCount']))
        if not rec_integrity or rec_integrity.get('status') != 'PASS':
            notes.append('record_integrity details not PASS')
        if ev_bad:
            notes.append('%d evidence-index rows failed' % len(ev_bad))
        if not sh.get('ok'):
            notes.append('SHA256SUMS verify failed')
        if (rdir / 'rcS.scoped').exists() is False:
            notes.append('top-level rcS.scoped absent (variant rcS layout)')
        sample_ok = not any(f['status'] == 'DIFF'
                            for f in fields.values())
        sample_ok = sample_ok and sh.get('ok') and not ev_bad and \
            event_count_match and rec_integrity.get('status') == 'PASS'
        rec = {
            'SampleRunID': sid,
            'ModelID': mrow['ModelID'],
            'ContextID': mrow['ContextID'],
            'WorkloadID': mrow['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'RunWorkload': man.get('run_workload', ''),
            'AttemptID': mrow['AttemptID'],
            'RunDir': str(rdir),
            'fields': fields,
            'shasums': sh,
            'evidence_index': {'rows': len(ev), 'failed': ev_bad},
            'verdict_record_integrity': rec_integrity,
            'event_count_verdict': ver.get('event_count'),
            'event_count_trace_scan': scan['EventCount'],
            'event_count_match': event_count_match,
            'chain_event_count': len(C.chain(sid).get('Events', [])),
            'trace_sha256': scan['TraceSHA256'],
            'notes': notes,
            'sample_audit_verdict': 'PASS' if sample_ok else 'REVIEW',
        }
        detail['samples'].append(rec)

    # observed campaign stats, recomputed from our data
    terms = Counter(s['fields']['TerminalState']['values'].get(
        'matrix_csv', '') for s in detail['samples'])
    detail['campaign_stats_observed'] = {
        'planned': len(detail['samples']),
        'completed': sum(1 for s in detail['samples'] if s['fields'][
            'InjectionStatus']['values'].get('matrix_csv') == 'ACTIVATED'),
        'unique_sample_run_ids': len(set(
            s['SampleRunID'] for s in detail['samples'])),
        'activated': sum(1 for s in detail['samples'] if s['fields'][
            'InjectionStatus']['values'].get('matrix_csv') == 'ACTIVATED'),
        'consumed': sum(1 for s in detail['samples'] if s['fields'][
            'FaultConsumptionStatus']['values'].get('matrix_csv') ==
            'CONSUMED'),
        'propagation_full': sum(1 for s in detail['samples'] if s['fields'][
            'PropagationStatus']['values'].get('matrix_csv') == 'FULL'),
        'propagation_partial': sum(1 for s in detail['samples'] if s['fields'][
            'PropagationStatus']['values'].get('matrix_csv') == 'PARTIAL'),
        'trace_complete': sum(1 for s in detail['samples'] if s['fields'][
            'TraceCompleteness']['values'].get('matrix_csv') == 'COMPLETE'),
        'record_integrity_pass': sum(1 for s in detail['samples'] if s[
            'fields']['RecordIntegrity']['values'].get('matrix_csv') == 'PASS'),
        'terminal_distribution': dict(terms),
        'per_model_terminals': {},
        'samples_per_model': {},
    }
    for m in C.MODELS:
        ms = [s for s in detail['samples'] if s['ModelID'] == m]
        detail['campaign_stats_observed']['samples_per_model'][m] = len(ms)
        detail['campaign_stats_observed']['per_model_terminals'][m] = dict(
            Counter(s['fields']['TerminalState']['values'].get(
                'matrix_csv', '') for s in ms))
    fs = C.final_summary()
    detail['campaign_stats_reported'] = {
        'status': fs.get('status'),
        'planned_samples': fs.get('planned_samples'),
        'completed_samples': fs.get('completed_samples'),
        'valid_injection_evidence': fs.get('valid_injection_evidence'),
        'fault_state_consumed': fs.get('fault_state_consumed'),
        'full_propagation': fs.get('full_propagation'),
        'partial_propagation_legal_squash':
            fs.get('partial_propagation_legal_squash'),
        'chain_complete': fs.get('chain_complete'),
        'terminal_distribution': fs.get('terminal_distribution'),
        'control_runs_referenced': fs.get('control_runs_referenced'),
        'control_zero_proven': fs.get('control_zero_proven'),
    }
    o, r = detail['campaign_stats_observed'], detail['campaign_stats_reported']
    detail['campaign_stats_match'] = (
        o['planned'] == r['planned_samples'] and
        o['completed'] == r['completed_samples'] and
        o['activated'] == r['valid_injection_evidence'] and
        o['consumed'] == r['fault_state_consumed'] and
        o['propagation_full'] == r['full_propagation'] and
        o['terminal_distribution'] == r['terminal_distribution'])
    detail['field_agreement_summary'] = {
        f: dict(c) for f, c in agreement.items()}

    # anomaly list
    anomalies = []
    for s in detail['samples']:
        for note in s['notes']:
            severity = ('INFO' if ('variant' in note or
                                   'rcS.scoped' in note) else 'REVIEW')
            anomalies.append({'SampleRunID': s['SampleRunID'],
                              'severity': severity, 'note': note})
    detail['anomalies'] = anomalies
    detail['yaml_comparison'] = {
        'per_sample_yaml': 'n/a - the campaign produced no per-sample YAML',
        'authority_yaml': str(C.REPO / 'phase3/freeze/authority/'
                              'MMU_Formal_Config.yaml'),
        'authority_yaml_sha256': C.sha256_file(
            C.REPO / 'phase3/freeze/authority/MMU_Formal_Config.yaml'),
        'scope': 'design-time model/workload/fault authority only',
    }

    C.write_json(C.AUDIT / 'MMU_40_Sample_Final_Audit.json', detail)

    rows = []
    for s in detail['samples']:
        row = {
            'SampleRunID': s['SampleRunID'],
            'ModelID': s['ModelID'],
            'ContextID': s['ContextID'],
            'WorkloadID': s['WorkloadID'],
            'WorkloadVariant': s['WorkloadVariant'],
            'AttemptID': s['AttemptID'],
            'FaultID': s['fields']['FaultID']['values'].get('matrix_csv'),
            'InjectionStatus': s['fields']['InjectionStatus']['values'].get(
                'matrix_csv'),
            'FaultConsumptionStatus': s['fields'][
                'FaultConsumptionStatus']['values'].get('matrix_csv'),
            'PropagationStatus': s['fields']['PropagationStatus']['values'].get(
                'matrix_csv'),
            'TerminalState': s['fields']['TerminalState']['values'].get(
                'matrix_csv'),
            'OracleResult': s['fields']['OracleResult']['values'].get(
                'matrix_csv'),
            'TraceCompleteness': s['fields']['TraceCompleteness']['values'].get(
                'matrix_csv'),
            'RecordIntegrity': s['fields']['RecordIntegrity']['values'].get(
                'matrix_csv'),
            'BinarySHA256': s['fields']['BinarySHA256']['values'].get(
                'matrix_csv'),
            'ConfigSHA256': s['fields']['ConfigSHA256']['values'].get(
                'matrix_csv'),
            'WorkloadSHA256': s['fields']['WorkloadSHA256']['values'].get(
                'matrix_csv'),
            'RunDir': s['RunDir'],
            'SHA256SUMSEntries': s['shasums'].get('entries'),
            'SHA256SUMSVerified': s['shasums'].get('verified'),
            'SHA256SUMSMismatches': len(s['shasums'].get('mismatches', [])),
            'EvidenceIndexRows': s['evidence_index']['rows'],
            'EvidenceIndexFailed': len(s['evidence_index']['failed']),
            'EventCountVerdict': s['event_count_verdict'],
            'EventCountTrace': s['event_count_trace_scan'],
            'EventCountMatch': s['event_count_match'],
            'ChainEventCount': s['chain_event_count'],
            'TraceSHA256': s['trace_sha256'],
            'DisagreementFields': ','.join(
                f for f, v in s['fields'].items() if v['status'] == 'DIFF'),
            'MissingFields': ','.join(
                f for f, v in s['fields'].items() if v['status'] == 'MISSING'),
            'SampleAuditVerdict': s['sample_audit_verdict'],
            'Notes': '; '.join(s['notes']),
        }
        rows.append(row)
    C.write_csv(C.AUDIT / 'MMU_40_Sample_Final_Audit.csv', rows)

    # ---- report -----------------------------------------------------------
    tot_entries = sum(s['shasums'].get('entries', 0)
                      for s in detail['samples'])
    tot_verified = sum(s['shasums'].get('verified', 0)
                       for s in detail['samples'])
    tot_mismatch = sum(len(s['shasums'].get('mismatches', []))
                       for s in detail['samples'])
    tot_missing = sum(len(s['shasums'].get('missing', []))
                      for s in detail['samples'])
    ev_fail = sum(len(s['evidence_index']['failed'])
                  for s in detail['samples'])
    md = ['# 40-Sample Final Audit\n\n',
          'Frozen campaign `MMU-FORMAL-20261113`. Read-only audit; no '
          'original artifact was modified.\n\n',
          '## Sources cross-checked\n\n',
          '- `MMU_Final_Formal_Campaign_Results.xlsx` sheet '
          '`40_Sample_Matrix`\n',
          '- `40_Sample_Matrix_Completed.csv`\n',
          '- `analysis/samples.csv` and `analysis/samples.json`\n',
          '- each `attempt_*/<SampleRunID>/sample_manifest.json`\n',
          '- each `Validation/verdict.json`\n',
          '- each `logs/<SampleRunID>.result.json`\n',
          '- design-time `authority/MMU_40_Sample_Matrix.csv`\n',
          '- each `SHA256/SHA256SUMS.txt` and the campaign evidence index\n',
          '- per-sample YAML: **n/a** (no per-sample YAML exists); the '
          'authority YAML `%s` is design-time only\n\n' %
          detail['yaml_comparison']['authority_yaml'],
          '## Field agreement (40 samples)\n\n',
          '| Field | AGREE | AGREE_VARIANT | DIFF | MISSING |\n'
          '|---|---|---|---|---|\n']
    for f, c in detail['field_agreement_summary'].items():
        md.append('| %s | %d | %d | %d | %d |\n' % (
            f, c.get('AGREE', 0), c.get('AGREE_VARIANT', 0),
            c.get('DIFF', 0), c.get('MISSING', 0)))
    md.append('\nThe only non-plain-AGREE field is `WorkloadID` on the two '
              'W10S samples: the authoritative matrix/manifest ID stays '
              '`W10`; `verdict.workload` records the internal run workload '
              '`W10S` (`W10S-COLD-STORE`, `W10S-WARM-STORE`). This is the '
              'documented variant encoding, not a conflicting identity.\n\n')
    md.append('## Reconstructed campaign statistics\n\n')
    md.append('| Metric | Recomputed | Reported |\n|---|---|---|\n')
    o = detail['campaign_stats_observed']
    r = detail['campaign_stats_reported']
    pairs = [
        ('planned', o['planned'], r['planned_samples']),
        ('completed', o['completed'], r['completed_samples']),
        ('valid injection', o['activated'], r['valid_injection_evidence']),
        ('fault state consumed', o['consumed'], r['fault_state_consumed']),
        ('FULL propagation', o['propagation_full'], r['full_propagation']),
        ('legal PARTIAL/SQUASHED', o['propagation_partial'],
         r['partial_propagation_legal_squash']),
        ('COMPLETE trace', o['trace_complete'], r['chain_complete']),
        ('terminal distribution', json.dumps(o['terminal_distribution']),
         json.dumps(r['terminal_distribution'])),
    ]
    for name, a, b in pairs:
        md.append('| %s | %s | %s |\n' % (name, a, b))
    md.append('\nRecomputed totals match the reported summary: **%s**.\n\n' %
              detail['campaign_stats_match'])
    md.append('## Integrity checks\n\n')
    md.append('- SHA256SUMS entries recomputed: **%d**, verified **%d**, '
              'mismatches **%d**, missing **%d** (disk.img hashed once and '
              'all 40 recorded values are identical `bb8727...`).\n' % (
                  tot_entries, tot_verified, tot_mismatch, tot_missing))
    md.append('- Evidence-index rows failing existence/hash: **%d**.\n' %
              ev_fail)
    md.append('- Frozen binary `CHAOS/gem5/build/ARM/gem5.opt` actual '
              'SHA256 `%s` equals every sample `BinarySHA256`.\n' %
              detail['gem5_binary_actual_sha256'])
    md.append('- Every `verdict.event_count` equals the raw trace event '
              'count; zero chain-join mismatches in the 40 traces.\n\n')
    md.append('## Anomalies\n\n')
    if detail['anomalies']:
        for a in detail['anomalies']:
            md.append('- **%s** `%s`: %s\n' % (
                a['severity'], a['SampleRunID'], a['note']))
    else:
        md.append('- None.\n')
    md.append('\n## Per-sample result\n\n')
    md.append('| Sample | Model | Ctx | Workload | Attempt | Propagation | '
              'Terminal | Oracle | Trace | Integrity | Audit |\n'
              '|---|---|---|---|---|---|---|---|---|---|---|\n')
    for row in rows:
        md.append('| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | '
                  '%s |\n' % (
                      row['SampleRunID'], row['ModelID'], row['ContextID'],
                      row['WorkloadID'], row['AttemptID'],
                      row['PropagationStatus'], row['TerminalState'],
                      row['OracleResult'], row['TraceCompleteness'],
                      row['RecordIntegrity'], row['SampleAuditVerdict']))
    md.append('\n## Verdict\n\n')
    review = [a for a in detail['anomalies'] if a['severity'] == 'REVIEW']
    md.append('`SAMPLE_AUDIT = %s` — 40/40 unique SampleRunIDs, 5 per model, '
              'R01-R05 per model, zero field conflicts beyond the documented '
              'W10S variant encoding, zero SHA256 mismatches, zero '
              'event-count mismatches, zero blocking anomalies.\n' %
              ('PASS' if not review else 'NEEDS_REVIEW'))
    (C.AUDIT / 'MMU_40_Sample_Final_Audit.md').write_text(''.join(md))

    print(json.dumps({
        'samples': len(detail['samples']),
        'field_agreement': detail['field_agreement_summary'],
        'observed': o, 'reported': r,
        'stats_match': detail['campaign_stats_match'],
        'anomalies': len(anomalies),
        'review_samples': [s['SampleRunID'] for s in detail['samples']
                           if s['sample_audit_verdict'] != 'PASS'],
    }, indent=1))


if __name__ == '__main__':
    main()
