#!/usr/bin/env python3
"""Validate the unified schema itself and representative MMU/LSU records."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C

import jsonschema


def event_from_feature(f, tr):
    i, o, a, t = (f['identity'], f['fault_origin'], f['activation'],
                  f['terminal'])
    ext = {k: tr.get(k) for k in (
        'asid', 'vmid', 'tlb_instance', 'permission_result',
        'permission_before', 'permission_after', 'memory_attribute',
        'old_pfn', 'new_pfn', 'old_pa', 'new_pa', 'pte_address',
        'pte_value_before', 'pte_value_after', 'descriptor_before',
        'descriptor_after', 'request_pa_before', 'request_pa_after',
        'candidate_asid', 'candidate_entry_id', 'candidate_generation',
        'candidate_pfn', 'candidate_pa', 'lookup_outcome', 'decoy_pfn',
        'decoy_va', 'next_table_pa_before', 'next_table_pa_after',
        'fault_site', 'fault_field', 'fault_persistence') if tr.get(k) != ''}
    ev = {
        'Unit': 'MMU',
        'SubUnit': o['TargetSubUnit'],
        'FaultModelID': o['FaultModelID'],
        'FaultLocation': {
            'unit': 'MMU', 'sub_unit': o['TargetSubUnit'],
            'source_file': o['InjectionLocation']['SourceFile'],
            'source_function': o['InjectionLocation']['SourceFunction'],
            'trace_fault_site': o['InjectionLocation']['TraceFaultSite'],
            'target_field': o['TargetField']},
        'FaultID': i['FaultID'],
        'SampleRunID': i['SampleRunID'],
        'ContextID': i['ContextID'],
        'WorkloadID': i['WorkloadID'],
        'ActivationCondition': {
            'eligible_event_condition': a['EligibleEventCondition'],
            'actual_eligible_event': a['ActualEligibleEvent'],
            'event_ordinal': a['EventOrdinal'],
            'activation_tick': a['ActivationTick'],
            'access_mode': a['AccessMode'],
            'walk_level': a['WalkLevel'],
            'asid': a['ASID'] or None,
            'vmid': a['VMID'] or None,
            'tlb_lookup_outcome': a['TLBLookupOutcome']},
        'StateTransition': {
            'event_id': tr['EventID'],
            'field': tr.get('Field', ''),
            'before': tr.get('Before', ''),
            'after': tr.get('After', ''),
            'state_before': tr.get('StateBefore', ''),
            'state_after': tr.get('StateAfter', '')},
        'EventID': tr['EventID'],
        'ParentEventID': tr.get('ParentEventID') or None,
        'DynamicInstSeqNum': tr.get('DynamicInstSeqNum') or None,
        'TranslationID': tr.get('TranslationID') or None,
        'RequestID': None,
        'ResponseID': None,
        'OldValue': tr.get('Before') or None,
        'NewValue': tr.get('After') or None,
        'VA': tr.get('VA') or None,
        'PA': tr.get('PA') or None,
        'CommitStatus': 'COMMITTED' if tr['Kind'] == 'commit' else None,
        'SquashStatus': ('SQUASHED' if tr.get('SquashStatus') == 'SQUASH'
                         else 'NOT_SQUASHED'),
        'DetectionStatus': t['DetectionStatus'],
        'TerminalState': t['TerminalState'],
        'ManifestationType': t['ManifestationTypePrimary'],
        'OracleResult': t['OracleResult'],
        'TraceCompleteness': t['TraceCompleteness'],
    }
    ev.update(ext)
    return ev


def main():
    schema_path = C.SCHEMA / 'ARM_CPU_SDC_Propagation_Schema_v1.json'
    schema = json.load(open(schema_path))
    result = {'schema_path': str(schema_path), 'checks': []}

    try:
        jsonschema.Draft202012Validator.check_schema(schema)
        result['checks'].append({'check': 'schema_meta_validation',
                                 'status': 'PASS'})
    except Exception as exc:
        result['checks'].append({'check': 'schema_meta_validation',
                                 'status': 'FAIL', 'error': str(exc)})
        C.write_json(C.SCHEMA / 'SCHEMA_VALIDATION.json', result)
        raise

    lib = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    f = next(x for x in lib['samples']
             if x['identity']['SampleRunID'] == 'M07-F0-W14-S01-R01')
    events = [event_from_feature(f, tr) for tr in
              f['microarchitectural_state_transitions'][:8]]
    sample = {
        'Unit': 'MMU',
        'SubUnit': f['fault_origin']['TargetSubUnit'],
        'FaultModelID': 'M07',
        'FaultLocation': events[0]['FaultLocation'],
        'FaultID': '1',
        'SampleRunID': f['identity']['SampleRunID'],
        'ContextID': 'R01',
        'WorkloadID': 'W14',
        'ActivationCondition': events[0]['ActivationCondition'],
        'StateTransition': events[0]['StateTransition'],
        'EventID': events[0]['EventID'],
        'TerminalState': f['terminal']['TerminalState'],
        'ManifestationType': f['terminal']['ManifestationTypePrimary'],
        'OracleResult': f['terminal']['OracleResult'],
        'TraceCompleteness': f['terminal']['TraceCompleteness'],
        'CommitStatus': 'COMMITTED',
        'SquashStatus': 'NOT_SQUASHED',
        'DetectionStatus': f['terminal']['DetectionStatus'],
        'events': events,
    }
    def sub_validator(name):
        return jsonschema.Draft202012Validator({
            '$schema': schema['$schema'],
            '$defs': schema['$defs'],
            '$ref': '#/$defs/%s' % name})

    v_sample = sub_validator('SampleRecord')
    errs = sorted(v_sample.iter_errors(sample), key=lambda e: e.path)
    result['checks'].append({
        'check': 'mmu_sample_record', 'status': 'PASS' if not errs else 'FAIL',
        'errors': [('%s: %s' % (list(e.path), e.message)) for e in errs[:10]],
        'events': len(events)})

    lsu_event = {
        'Unit': 'LSU', 'SubUnit': 'LSU/Cache', 'FaultModelID': 'LSU-B0',
        'FaultLocation': 'CHAOS/gem5/src/cpu/o3/lsq.cc',
        'FaultID': '1', 'SampleRunID': 'LSU-EXAMPLE', 'ContextID': 'C01',
        'WorkloadID': 'LSU-W1',
        'ActivationCondition': {'actual_eligible_event': 'store commit',
                                'event_ordinal': 1, 'access_mode': 'Write'},
        'StateTransition': {'event_id': '10', 'field': 'phys_reg',
                            'before': '0x1', 'after': '0x2'},
        'EventID': '10', 'ParentEventID': '9', 'DynamicInstSeqNum': '1234',
        'TranslationID': '7', 'RequestID': '88', 'ResponseID': '89',
        'OldValue': '0x1', 'NewValue': '0x2', 'VA': '0x4000',
        'PA': '0x8000', 'CommitStatus': 'COMMITTED',
        'SquashStatus': 'NOT_SQUASHED', 'DetectionStatus': 'NOT_DETECTED',
        'TerminalState': 'SDC', 'ManifestationType': 'WRONG_DATA_VALUE',
        'OracleResult': 'FAIL', 'TraceCompleteness': 'COMPLETE',
        'lq_idx': '3', 'sq_idx': '4', 'cache_line': '0x8000',
        'mshr_id': '2', 'arch_reg': 'x1', 'phys_reg': 'p12',
    }
    v_event = sub_validator('PropagationEvent')
    errs = sorted(v_event.iter_errors(lsu_event), key=lambda e: e.path)
    result['checks'].append({
        'check': 'lsu_event_record', 'status': 'PASS' if not errs else 'FAIL',
        'errors': [('%s: %s' % (list(e.path), e.message)) for e in errs[:10]]})

    result['mmu_extensions_retained'] = len(schema['x-mmu-extensions'])
    result['lsu_extensions_retained'] = len(schema['x-lsu-extensions'])
    result['overall'] = ('PASS' if all(c['status'] == 'PASS'
                                       for c in result['checks']) else 'FAIL')
    C.write_json(C.SCHEMA / 'SCHEMA_VALIDATION.json', result)
    print(json.dumps(result, indent=1))


if __name__ == '__main__':
    main()
