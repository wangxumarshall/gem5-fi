#!/usr/bin/env python3
"""Run repeat-result tests and persist log/results."""
import io
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
suite = unittest.TestLoader().discover(
    str(HERE), pattern='test_repeat_results.py')
buf = io.StringIO()
result = unittest.TextTestRunner(stream=buf, verbosity=2).run(suite)
print(buf.getvalue())
(HERE / 'REPEAT_TEST_LOG.txt').write_text(buf.getvalue())
summary = {
    'tests_run': result.testsRun,
    'failures': len(result.failures),
    'errors': len(result.errors),
    'skipped': len(result.skipped),
    'success': result.wasSuccessful(),
}
(HERE / 'REPEAT_TEST_RESULTS.json').write_text(
    json.dumps(summary, indent=2) + '\n')
sys.exit(0 if result.wasSuccessful() else 1)
