#!/usr/bin/env python3
"""Independent acceptance of the real repeatability campaign results."""
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path

FINAL = Path(__file__).resolve().parent.parent
RC = FINAL / 'repeat_campaign'
OUT = RC / 'analysis'


def load(p):
    return json.load(open(p))


def rows(p):
    return list(csv.DictReader(open(p)))


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def main():
    checks = []

    def check(g, n, ok, d=''):
        checks.append({'Gate': g, 'Check': n,
                       'Status': 'PASS' if ok else 'FAIL', 'Detail': str(d)})

    audit = load(FINAL / 'reports' / 'Original_40_Sample_Integrity_Audit.json')
    status = load(RC / 'statuses' / 'STATUS.json')
    exec_rows = rows(OUT / 'Repeat_Run_Execution_Matrix.csv')
    comp = rows(OUT / 'Formal_vs_Repeat_Comparison.csv')
    summary = load(OUT / 'Repeatability_Summary.json')
    check('G1', 'formal_data_integrity',
          audit['FORMAL_DATA_INTEGRITY'] == 'PASS', audit)
    check('G1', 'formal_40_unchanged',
          audit['trace_unchanged'] == '40/40' and
          audit['manifest_unchanged'] == '40/40' and
          audit['verdict_unchanged'] == '40/40', '')
    check('G2', 'ten_runs_completed', len(exec_rows) == 10 and all(
        str(r['ExitCode']) == '0' and r['Status'] == 'COMPLETED'
        for r in exec_rows), len(exec_rows))
    check('G2', 'unique_outdirs',
          len({r['Outdir'] for r in exec_rows}) == 10, '')
    check('G2', 'traces_and_terminals', all(
        Path(r['TracePath']).is_file() and Path(r['TracePath']).stat().st_size
        > 0 and Path(r['TerminalPath']).is_file() for r in exec_rows), '')
    check('G2', 'trace_hashes', all(
        r['TraceSHA256'] == sha(r['TracePath']) for r in exec_rows), '')
    check('G2', 'no_placeholders', all(
        '<REPEAT' not in Path(r['CommandScript']).read_text() and
        'FROZEN_DISK_COPY' not in Path(r['CommandScript']).read_text()
        for r in exec_rows), '')
    check('G2', 'control_shared_baseline', all(
        r['ControlDesign'] == 'SHARED_APPROVED_FORMAL_BASELINE' and
        r['IndependentRepeatControlExecuted'] == 'False'
        for r in rows(OUT / 'Fault_Control_Evidence.csv')), '')
    allowed = {'MATCH', 'SEMANTICALLY_EQUIVALENT', 'MISMATCH',
               'INSUFFICIENT_EVIDENCE', 'UNRESOLVED'}
    check('G3', 'comparison_statuses', len(comp) == 10 and all(
        r[k] in allowed for r in comp
        for k in ('ActivationMatch', 'PropagationMatch', 'TerminalMatch')),
        len(comp))
    check('G3', 'mismatches_explained', all(
        r['MismatchReason'] for r in comp
        if 'MISMATCH' in (r['ActivationMatch'], r['PropagationMatch'],
                          r['TerminalMatch'])), '')
    expected_ids = {
        'REP-FINAL-MMU-M03-R01-01', 'REP-FINAL-MMU-M03-R05-01',
        'REP-FINAL-MMU-M06-R02-01', 'REP-FINAL-MMU-M07-R01-01',
        'REP-FINAL-MMU-M07-R05-01'}
    check('G3', 'm03_m06_m07_present',
          expected_ids <= {r['RepeatRunID'] for r in comp}, '')
    slices = list((OUT / 'slices').glob('*.json'))
    check('G3', 'ten_slices_no_fabrication',
          len(slices) == 10 and all(
              not load(p)['missing_event_ids'] and
              load(p)['fabricated_event_count'] == 0 for p in slices),
          len(slices))
    check('G4', 'tests', load(FINAL / 'tests' /
                              'REPEAT_TEST_RESULTS.json')['success'], '')
    check('G4', 'no_gem5_running', subprocess.run(
        ['pgrep', '-x', 'gem5.opt'], capture_output=True,
        text=True).stdout.strip() == '', '')
    check('G4', 'status_complete',
          status['MMU_REPEATABILITY_CAMPAIGN'] in
          ('COMPLETE', 'COMPLETE_WITH_LIMITATIONS') and
          status['MMU_REPEATABILITY_EVIDENCE'] == 'VALIDATED',
          status)
    gates = {g: all(c['Status'] == 'PASS' for c in checks
                    if c['Gate'] == g) for g in ('G1', 'G2', 'G3', 'G4')}
    out = {
        'FORMAL_DATA_INTEGRITY':
            'PASS' if gates['G1'] else 'FAIL',
        'REPEAT_EXECUTION_INTEGRITY':
            'PASS' if gates['G2'] else 'FAIL',
        'PROPAGATION_REPEATABILITY':
            'PASS' if gates['G3'] else 'FAIL',
        'INDEPENDENT_ACCEPTANCE':
            'PASS' if gates['G4'] else 'FAIL',
        'MMU_REPEATABILITY_CAMPAIGN':
            status['MMU_REPEATABILITY_CAMPAIGN'],
        'MMU_REPEATABILITY_EVIDENCE':
            status['MMU_REPEATABILITY_EVIDENCE'],
        'MMU_FINAL_EXPERIMENTAL_FREEZE':
            status['MMU_FINAL_EXPERIMENTAL_FREEZE'],
        'checks': checks, 'gates': gates,
    }
    (FINAL / 'tests' / 'Repeat_Independent_Acceptance.json').write_text(
        json.dumps(out, indent=2) + '\n')
    md = ['# Repeat Independent Acceptance\n\n', '| Gate | Check | Status | '
          'Detail |\n|---|---|---|---|\n']
    for c in checks:
        md.append('| %s | %s | %s | %s |\n' % (
            c['Gate'], c['Check'], c['Status'], c['Detail'][:160]))
    (FINAL / 'tests' / 'Repeat_Independent_Acceptance.md').write_text(
        ''.join(md))
    print(json.dumps({k: v for k, v in out.items()
                      if k not in ('checks', 'gates')}, indent=1))
    return 0 if all(gates.values()) else 1


if __name__ == '__main__':
    sys.exit(main())
