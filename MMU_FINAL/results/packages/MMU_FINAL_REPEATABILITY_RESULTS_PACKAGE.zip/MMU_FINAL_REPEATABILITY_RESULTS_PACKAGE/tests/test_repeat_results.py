#!/usr/bin/env python3
"""Tests for the real 10-run repeatability campaign results."""
import csv
import json
import subprocess
import sys
import unittest
from pathlib import Path

FINAL = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FINAL / 'scripts'))
RC = FINAL / 'repeat_campaign'
OUT = RC / 'analysis'


def csvrows(p):
    return list(csv.DictReader(open(p)))


class TestRepeatResults(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exec_rows = csvrows(OUT / 'Repeat_Run_Execution_Matrix.csv')
        cls.comp = csvrows(OUT / 'Formal_vs_Repeat_Comparison.csv')
        cls.summary = json.load(open(OUT / 'Repeatability_Summary.json'))
        cls.status = json.load(open(RC / 'statuses' / 'STATUS.json')) \
            if (RC / 'statuses' / 'STATUS.json').is_file() else {}
        cls.audit = json.load(open(
            FINAL / 'reports' / 'Original_40_Sample_Integrity_Audit.json'))

    def test_01_ten_runs(self):
        self.assertEqual(len(self.exec_rows), 10)
        self.assertEqual(len({r['RepeatRunID'] for r in self.exec_rows}), 10)

    def test_02_completed(self):
        for r in self.exec_rows:
            self.assertEqual(str(r['ExitCode']), '0', r['RepeatRunID'])
            self.assertEqual(r['Status'], 'COMPLETED', r['RepeatRunID'])

    def test_03_trace_present_and_hash(self):
        for r in self.exec_rows:
            p = Path(r['TracePath'])
            self.assertTrue(p.is_file(), r['RepeatRunID'])
            self.assertGreater(p.stat().st_size, 0, r['RepeatRunID'])
            self.assertEqual(r['TraceSHA256'],
                             __import__('hashlib').sha256(
                                 p.read_bytes()).hexdigest())

    def test_04_terminal_present(self):
        for r in self.exec_rows:
            self.assertTrue(Path(r['TerminalPath']).is_file(),
                            r['RepeatRunID'])

    def test_05_activation_propagation_terminal_evidence(self):
        self.assertEqual(len(self.comp), 10)
        allowed = {'MATCH', 'SEMANTICALLY_EQUIVALENT', 'MISMATCH',
                   'INSUFFICIENT_EVIDENCE', 'UNRESOLVED'}
        for r in self.comp:
            for k in ('ActivationMatch', 'PropagationMatch',
                      'TerminalMatch'):
                self.assertIn(r[k], allowed, (r['RepeatRunID'], k))
            if 'MISMATCH' in (r['ActivationMatch'], r['PropagationMatch'],
                              r['TerminalMatch']):
                self.assertTrue(r['MismatchReason'], r['RepeatRunID'])

    def test_06_slices_no_missing_no_fabrication(self):
        files = list((OUT / 'slices').glob('*.json'))
        self.assertEqual(len(files), 10)
        for p in files:
            d = json.load(open(p))
            self.assertEqual(d['missing_event_ids'], [], p.name)
            self.assertEqual(d['fabricated_event_count'], 0, p.name)
            self.assertGreater(len(d['events']), 0, p.name)

    def test_07_verdicts_10(self):
        self.assertEqual(len(list((OUT / 'verdicts').glob('*.json'))), 10)

    def test_08_formal_integrity(self):
        self.assertEqual(self.audit['FORMAL_DATA_INTEGRITY'], 'PASS')
        self.assertEqual(self.audit['trace_unchanged'], '40/40')
        self.assertEqual(self.audit['original_results_zip_sha256'],
                         'caeaf6506495ed119a06a12075f5193276e2e1279286ddc5'
                         '6610016f39caa151')

    def test_09_no_placeholders(self):
        for r in self.exec_rows:
            cmd = Path(r['CommandScript']).read_text()
            for token in ('<REPEAT', 'FROZEN_DISK_COPY', 'REPEAT_OUTDIR'):
                self.assertNotIn(token, cmd, r['RepeatRunID'])

    def test_10_control_is_shared_baseline(self):
        rows = csvrows(OUT / 'Fault_Control_Evidence.csv')
        self.assertEqual(len(rows), 10)
        for r in rows:
            self.assertEqual(r['ControlDesign'],
                             'SHARED_APPROVED_FORMAL_BASELINE')
            self.assertEqual(r['IndependentRepeatControlExecuted'], 'False')

    def test_11_status(self):
        self.assertEqual(self.summary['PlannedRepeatRuns'], 10)
        self.assertEqual(self.summary['CompletedRepeatRuns'], 10)
        self.assertEqual(self.summary['TraceIncompleteCount'], 0)

    def test_12_no_gem5_running(self):
        self.assertEqual(subprocess.run(
            ['pgrep', '-x', 'gem5.opt'], capture_output=True,
            text=True).stdout.strip(), '')

    def test_13_excel(self):
        import openpyxl
        p = OUT / 'MMU_FINAL_Repeatability_Results.xlsx'
        self.assertTrue(p.is_file())
        wb = openpyxl.load_workbook(p, read_only=True)
        required = {'Original_Formal_Results', 'Repeat_Runs',
                    'Fault_Activation', 'Propagation_Signature',
                    'Terminal_Comparison', 'Oracle_Comparison',
                    'Model_Level_Summary', 'Mismatch_Investigation',
                    'Provenance', 'Research_Limitations'}
        self.assertTrue(required.issubset(set(wb.sheetnames)))


if __name__ == '__main__':
    unittest.main(verbosity=2)
