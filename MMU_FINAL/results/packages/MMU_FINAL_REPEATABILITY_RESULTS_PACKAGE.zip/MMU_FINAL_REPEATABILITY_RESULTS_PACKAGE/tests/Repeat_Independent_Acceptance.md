# Repeat Independent Acceptance

| Gate | Check | Status | Detail |
|---|---|---|---|
| G1 | formal_data_integrity | PASS | {'FORMAL_DATA_INTEGRITY': 'PASS', 'samples': 40, 'sample_id_set_matches_matrix': True, 'trace_unchanged': '40/40', 'manifest_unchanged': '40/40', 'verdict_uncha |
| G1 | formal_40_unchanged | PASS |  |
| G2 | ten_runs_completed | PASS | 10 |
| G2 | unique_outdirs | PASS |  |
| G2 | traces_and_terminals | PASS |  |
| G2 | trace_hashes | PASS |  |
| G2 | no_placeholders | PASS |  |
| G2 | control_shared_baseline | PASS |  |
| G3 | comparison_statuses | PASS | 10 |
| G3 | mismatches_explained | PASS |  |
| G3 | m03_m06_m07_present | PASS |  |
| G3 | ten_slices_no_fabrication | PASS | 10 |
| G4 | tests | PASS |  |
| G4 | no_gem5_running | PASS |  |
| G4 | status_complete | PASS | {'MMU_REPEATABILITY_CAMPAIGN': 'COMPLETE', 'MMU_REPEATABILITY_EVIDENCE': 'VALIDATED', 'MMU_FINAL_EXPERIMENTAL_FREEZE': 'READY', 'FORMAL_DATA_INTEGRITY': 'PASS', |
