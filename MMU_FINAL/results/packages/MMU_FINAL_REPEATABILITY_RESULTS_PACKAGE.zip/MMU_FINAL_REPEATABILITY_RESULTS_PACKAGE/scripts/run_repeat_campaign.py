#!/usr/bin/env python3
"""Sequential real execution of the remaining 9 repeat runs.

One gem5 process at a time.  Never overwrites the formal campaign.  The
canary (M01 R01) is validated separately and is skipped here.
"""
import csv
import gzip
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

RC = FINAL / 'repeat_campaign'
ORDER = [
    'REP-FINAL-MMU-M02-R02-01',
    'REP-FINAL-MMU-M03-R01-01',
    'REP-FINAL-MMU-M03-R05-01',
    'REP-FINAL-MMU-M04-R05-01',
    'REP-FINAL-MMU-M05-R05-01',
    'REP-FINAL-MMU-M06-R02-01',
    'REP-FINAL-MMU-M07-R01-01',
    'REP-FINAL-MMU-M07-R05-01',
    'REP-FINAL-MMU-M08-R01-01',
]

ACTIVATION_KINDS = {
    'M01': 'mmu_fault_arm', 'M02': 'refill_pfn_corrupt',
    'M03': 'mmu_fault_activate', 'M04': 'mmu_fault_activate',
    'M05': 'mmu_fault_activate', 'M06': 'mmu_fault_activate',
    'M07': 'mmu_fault_activate', 'M08': 'mmu_fault_activate',
}


def rows_by_id():
    return {r['RepeatID']: r for r in csv.DictReader(open(
        FINAL / 'repeatability' / 'MMU_10_Sample_Repeatability_Matrix.csv'))}


def trace_summary(path):
    kinds = {}
    n = 0
    with gzip.open(path, 'rt', errors='replace') as fh:
        for line in fh:
            if not line.startswith('PROP-EVT: '):
                continue
            n += 1
            body = line[len('PROP-EVT: '):]
            for tok in body.split(' '):
                if tok.startswith('kind='):
                    k = tok[5:]
                    kinds[k] = kinds.get(k, 0) + 1
                    break
    return n, kinds


def main():
    RC.mkdir(parents=True, exist_ok=True)
    (RC / 'run_logs').mkdir(exist_ok=True)
    (RC / 'analysis').mkdir(exist_ok=True)
    rows = rows_by_id()
    status = {'campaign': 'MMU-REPEATABILITY-20261114',
              'runs': {}, 'order': ORDER, 'started_utc':
              time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    for rid in ORDER:
        r = rows[rid]
        outdir = Path(r['Outdir'])
        outdir.mkdir(parents=True, exist_ok=True)
        trace = outdir / 'prop_evt.txt.gz'
        term = outdir / 'board.terminal'
        exitlog = RC / 'run_logs' / (rid + '.exit.txt')
        if trace.is_file() and trace.stat().st_size > 0 and term.is_file() \
                and exitlog.is_file() and exitlog.read_text().strip() == '0':
            status['runs'][rid] = {'status': 'ALREADY_COMPLETE'}
            print('[SKIP]', rid, flush=True)
            continue
        print('[RUN ]', rid, time.strftime('%H:%M:%S'), flush=True)
        t0 = time.time()
        stdout = RC / 'run_logs' / (rid + '.stdout.log')
        stderr = RC / 'run_logs' / (rid + '.stderr.log')
        with open(stdout, 'w') as of, open(stderr, 'w') as ef:
            try:
                p = subprocess.run(['bash', r['CommandScript']],
                                   stdout=of, stderr=ef, timeout=7200)
                rc = p.returncode
            except subprocess.TimeoutExpired:
                rc = 124
        dt = time.time() - t0
        exitlog.write_text('%d\n' % rc)
        summary = {'status': 'COMPLETED' if rc == 0 else 'FAILED',
                   'exit_code': rc, 'seconds': round(dt, 1)}
        if rc == 0 and trace.is_file() and trace.stat().st_size > 0:
            n, kinds = trace_summary(trace)
            act = ACTIVATION_KINDS[r['ModelID']]
            summary.update({
                'trace_events': n,
                'activation_kind': act,
                'activation_present': kinds.get(act, 0) > 0,
                'fault_tagged_events': sum(
                    v for k, v in kinds.items()
                    if k.startswith(('mmu_fault_', 'fault_',
                                     'refill_pfn_corrupt',
                                     'tlbi_suppressed'))),
                'board_terminal_present': term.is_file(),
                'trace_sha256': C.sha256_file(trace),
                'terminal_sha256': C.sha256_file(term) if term.is_file()
                else '',
            })
            if not summary['activation_present']:
                summary['status'] = 'INJECTION_NOT_ACTIVATED'
        else:
            summary['status'] = 'RUNNER_OR_SIMULATOR_FAILURE'
        (RC / 'run_logs' / (rid + '.status.json')).write_text(
            json.dumps(summary, indent=2) + '\n')
        status['runs'][rid] = summary
        print('[DONE]', rid, summary, flush=True)
        if summary['status'] in ('FAILED', 'RUNNER_OR_SIMULATOR_FAILURE',
                                 'INJECTION_NOT_ACTIVATED'):
            status['status'] = 'STOPPED_ON_FAILURE'
            status['failed'] = rid
            break
    else:
        status['status'] = 'ALL_COMPLETED'
    status['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ',
                                           time.gmtime())
    (RC / 'campaign_status.json').write_text(
        json.dumps(status, indent=2) + '\n')
    print(json.dumps(status, indent=1))


if __name__ == '__main__':
    main()
