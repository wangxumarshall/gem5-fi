#!/usr/bin/env python3
"""Final repeat statuses, manifests, trace index, report and package."""
import csv
import json
import os
import zipfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
PC = FINAL.parent
CAMP = PC.parent
RC = FINAL / 'repeat_campaign'
OUT = RC / 'analysis'
ZIP = CAMP / 'MMU_FINAL_REPEATABILITY_RESULTS_PACKAGE.zip'


def sha(p):
    return __import__('hashlib').sha256(
        open(p, 'rb').read()).hexdigest()


def csvrows(p):
    return list(csv.DictReader(open(p)))


def main():
    (RC / 'manifests').mkdir(exist_ok=True)
    (RC / 'statuses').mkdir(exist_ok=True)
    exec_rows = csvrows(OUT / 'Repeat_Run_Execution_Matrix.csv')
    comp = csvrows(OUT / 'Formal_vs_Repeat_Comparison.csv')
    summary = json.load(open(OUT / 'Repeatability_Summary.json'))
    audit = json.load(open(FINAL / 'reports' /
                           'Original_40_Sample_Integrity_Audit.json'))
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    by_sid = {r['SampleRunID']: r for r in data['samples']}
    comp_by = {r['RepeatRunID']: r for r in comp}
    completed = all(str(r['ExitCode']) == '0' and
                    Path(r['TracePath']).is_file() and
                    Path(r['TerminalPath']).is_file() for r in exec_rows)
    slices_ok = True
    for p in (OUT / 'slices').glob('*.json'):
        d = json.load(open(p))
        if d['missing_event_ids'] or d['fabricated_event_count']:
            slices_ok = False
    unresolved = sum(1 for r in comp if 'UNRESOLVED' in (
        r['ActivationMatch'], r['PropagationMatch'], r['TerminalMatch']))
    mismatches = sum(1 for r in comp if 'MISMATCH' in (
        r['ActivationMatch'], r['PropagationMatch'], r['TerminalMatch']))
    evidence = completed and slices_ok and not unresolved and \
        len(comp) == 10 and len(list((OUT / 'verdicts').glob('*.json'))) == 10
    freeze = audit['FORMAL_DATA_INTEGRITY'] == 'PASS' and evidence
    status = {
        'MMU_REPEATABILITY_CAMPAIGN':
            'COMPLETE' if (completed and evidence) else
            'COMPLETE_WITH_LIMITATIONS' if completed else 'INCOMPLETE',
        'MMU_REPEATABILITY_EVIDENCE':
            'VALIDATED' if evidence else 'PARTIAL',
        'MMU_FINAL_EXPERIMENTAL_FREEZE':
            'READY' if freeze else 'BLOCKED',
        'FORMAL_DATA_INTEGRITY': audit['FORMAL_DATA_INTEGRITY'],
        'PlannedRepeatRuns': 10,
        'CompletedRepeatRuns': summary['CompletedRepeatRuns'],
        'ValidRepeatRuns': summary['ValidRepeatRuns'],
        'ActivationConsistencyCount':
            summary['ActivationConsistencyCount'],
        'PropagationConsistencyCount':
            summary['PropagationConsistencyCount'],
        'TerminalConsistencyCount': summary['TerminalConsistencyCount'],
        'MismatchCount': mismatches,
        'UnresolvedCount': unresolved,
        'SimulatorFailureCount': summary['SimulatorFailureCount'],
        'TraceIncompleteCount': summary['TraceIncompleteCount'],
        'IndependentRepeatControlExecuted': False,
        'RepeatControlDesign': 'SHARED_APPROVED_FORMAL_BASELINE',
    }
    (RC / 'statuses' / 'STATUS.json').write_text(
        json.dumps(status, indent=2) + '\n')
    smd = ['# Final Repeatability Status\n\n', '| Status | Value |\n'
           '|---|---|\n']
    for k, v in status.items():
        smd.append('| `%s` | `%s` |\n' % (k, v))
    (RC / 'statuses' / 'STATUS.md').write_text(''.join(smd))

    # per-repeat manifests
    for r in exec_rows:
        rid = r['RepeatRunID']
        c = comp_by.get(rid, {})
        rec = by_sid[r['OriginalSampleRunID']]
        manifest = dict(r)
        manifest.update({
            'FormalAttemptID': rec['OriginalResult']['AttemptID'],
            'FormalTerminal': rec['OriginalResult']['TerminalState'],
            'FormalOracle': rec['OriginalResult']['OracleResult'],
            'ActivationMatch': c.get('ActivationMatch'),
            'PropagationMatch': c.get('PropagationMatch'),
            'TerminalMatch': c.get('TerminalMatch'),
            'RepeatTerminal': c.get('RepeatTerminal'),
            'RepeatOracleLine': c.get('RepeatTerminalLine'),
            'FormalOracleLine': c.get('FormalOracleLine'),
            'FormalTrace': rec['OriginalResult']['TraceAbsolutePath'],
            'FormalChain': str(C_ANALYSIS(sid=rec['SampleRunID'])),
            'FormalVerdict': str(Path(rec['OriginalResult']['RunDir']) /
                                 'Validation/verdict.json'),
        })
        (RC / 'manifests' / (rid + '.json')).write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + '\n')

    # trace index
    idx = []
    for r in exec_rows:
        rec = by_sid[r['OriginalSampleRunID']]
        idx.append({
            'RepeatRunID': r['RepeatRunID'],
            'OriginalSampleRunID': r['OriginalSampleRunID'],
            'RepeatTracePath': r['TracePath'],
            'RepeatTraceSizeBytes': r['TraceSizeBytes'],
            'RepeatTraceSHA256': r['TraceSHA256'],
            'RepeatTerminalPath': r['TerminalPath'],
            'RepeatTerminalSHA256': r['TerminalSHA256'],
            'FormalTracePath': rec['OriginalResult']['TraceAbsolutePath'],
            'FormalTraceSHA256': rec['OriginalResult']['TraceSHA256'],
            'FormalChainPath': str(C_ANALYSIS(sid=rec['SampleRunID'])),
            'FormalVerdictPath': str(Path(rec['OriginalResult']['RunDir']) /
                                     'Validation/verdict.json'),
        })
    with open(RC / 'trace_index.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(idx[0].keys()))
        w.writeheader(); w.writerows(idx)
    (RC / 'trace_index.json').write_text(json.dumps(idx, indent=2) + '\n')

    # final report
    md = ['# MMU Final Repeatability Campaign Report\n\n',
          'Planned 10; completed %d; valid %d.\n\n' % (
              status['CompletedRepeatRuns'], status['ValidRepeatRuns']),
          '| Status | Value |\n|---|---|\n']
    for k in ('MMU_REPEATABILITY_CAMPAIGN', 'MMU_REPEATABILITY_EVIDENCE',
              'MMU_FINAL_EXPERIMENTAL_FREEZE', 'FORMAL_DATA_INTEGRITY'):
        md.append('| `%s` | `%s` |\n' % (k, status[k]))
    md.append('\n## Consistency\n\n')
    md.append('- Activation: `%s`\n' % json.dumps(
        status['ActivationConsistencyCount']))
    md.append('- Propagation: `%s`\n' % json.dumps(
        status['PropagationConsistencyCount']))
    md.append('- Terminal: `%s`\n' % json.dumps(
        status['TerminalConsistencyCount']))
    md.append('- Mismatch: %d; Unresolved: %d; Simulator failures: %d\n\n' % (
        status['MismatchCount'], status['UnresolvedCount'],
        status['SimulatorFailureCount']))
    md.append('| RepeatRunID | Formal Terminal | Repeat Terminal | '
              'Activation | Propagation | Terminal |\n'
              '|---|---|---|---|---|---|\n')
    for r in comp:
        md.append('| %s | %s | %s | %s | %s | %s |\n' % (
            r['RepeatRunID'], r['FormalTerminal'], r['RepeatTerminal'],
            r['ActivationMatch'], r['PropagationMatch'],
            r['TerminalMatch']))
    md.append('\n## Boundaries\n\n')
    md.append('- Two observations per context only; no statistical or '
              'cross-workload generalization is claimed.\n')
    md.append('- No independent repeat control was authorized; the approved '
              'formal shared controls remain the baseline.\n')
    md.append('- Simulator-only TLB/PTW/PFN internals remain simulator-only '
              'or UNKNOWN for production.\n')
    md.append('- No per-instruction IFU fetch/decode/commit event was '
              'fabricated.\n')
    (OUT / 'Repeatability_Campaign_Report.md').write_text(''.join(md))
    print(json.dumps(status, indent=1))

    # package
    files = []
    include_dirs = [RC / 'preflight', RC / 'run_logs', RC / 'manifests',
                    RC / 'statuses', OUT / 'slices', OUT / 'verdicts']
    for d in include_dirs:
        for p in d.rglob('*'):
            if p.is_file():
                files.append(p)
    for p in OUT.iterdir():
        if p.is_file():
            files.append(p)
    for p in (RC / 'trace_index.csv', RC / 'trace_index.json',
              RC / 'campaign_status.json'):
        if p.is_file():
            files.append(p)
    # repeat traces, terminals, commands, rcS, launch manifests
    for r in exec_rows:
        rid = r['RepeatRunID']
        base = Path(r['Outdir']).parent
        for p in (base / 'command.sh', base / 'rcS.scoped',
                  base / 'launch_manifest.json',
                  base / 'outdir' / 'prop_evt.txt.gz',
                  base / 'outdir' / 'board.terminal'):
            if p.is_file():
                files.append(p)
    # evidence/provenance/tests/scripts
    for d in (FINAL / 'reports', FINAL / 'provenance'):
        for p in d.iterdir():
            if p.is_file():
                files.append(p)
    for p in (FINAL / 'tests').iterdir():
        if p.is_file():
            files.append(p)
    for p in (FINAL / 'scripts').iterdir():
        if p.is_file():
            files.append(p)
    files = sorted(set(files), key=str)
    manifest = RC / 'SHA256_MANIFEST.txt'
    manifest.write_text(''.join(
        '%s  %s\n' % (sha(p), p.relative_to(FINAL)) for p in files))
    if ZIP.exists():
        ZIP.unlink()
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for p in files:
            zf.write(p, arcname='MMU_FINAL_REPEATABILITY_RESULTS_PACKAGE/'
                     + str(p.relative_to(FINAL)))
        zf.write(manifest, arcname='MMU_FINAL_REPEATABILITY_RESULTS_PACKAGE/'
                              'repeat_campaign/SHA256_MANIFEST.txt')
    digest = sha(ZIP)
    (CAMP / (ZIP.name + '.sha256')).write_text(
        '%s  %s\n' % (digest, ZIP.name))
    print(json.dumps({'zip': str(ZIP), 'zip_sha256': digest,
                      'zip_size_bytes': ZIP.stat().st_size,
                      'files': len(files)}, indent=1))


def C_ANALYSIS(sid):
    return CAMP / 'analysis' / 'propagation_chains' / (sid + '.json')


if __name__ == '__main__':
    main()
