#!/usr/bin/env python3
"""Compare the 10 repeat runs against the formal canonical attempts.

Runtime IDs/ticks are compared strictly only when they are stable; otherwise
the comparison falls back to normalized event/state semantics.  No event is
removed to manufacture a MATCH.
"""
import csv
import gzip
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

RC = FINAL / 'repeat_campaign'
ACT_FIELDS = [
    'va', 'field', 'before', 'after', 'state_before', 'state_after',
    'tlb_instance', 'tlb_entry_id', 'entry_generation', 'asid', 'vmid',
    'mode', 'old_pfn', 'new_pfn', 'old_pa', 'new_pa',
    'descriptor_before', 'descriptor_after', 'permission_before',
    'permission_after', 'request_pa_before', 'request_pa_after',
    'candidate_asid', 'candidate_entry_id', 'candidate_generation',
    'next_table_pa_before', 'next_table_pa_after', 'decoy_va',
]
ORACLE_KEYS = {
    'W9': ['observed', 'old_marker', 'new_marker', 'result'],
    'W10': ['observed', 'sentinel', 'neighbor_sentinel', 'result'],
    'W10S': ['target_observed', 'target_after', 'neighbor_alias_observed',
             'neighbor_before', 'store_fault', 'result'],
    'W11': ['observed', 'expect', 'result'],
    'W12': ['observed', 'sentinel', 'decoy_sentinel', 'result'],
    'W13': ['observed', 'sentinel', 'decoy_sentinel', 'result'],
    'W14': ['signal', 'observed', 'expected', 'shared_changed',
            'injected_success', 'value_ok', 'result'],
}


def parse_evt(line):
    out = {}
    for tok in line[len('PROP-EVT: '):].rstrip('\n').split(' '):
        if '=' in tok:
            k, v = tok.split('=', 1)
            out[k] = v
    return out


def parse_kv(line):
    return {k: v.strip() for k, v in C.parse_kv_line(
        line.replace('\r', '')).items()}


def scan_trace(path, wanted_ids, activation_kind):
    events = {}
    kinds = Counter()
    act = None
    n = 0
    with gzip.open(path, 'rt', errors='replace') as fh:
        for line in fh:
            if not line.startswith('PROP-EVT: '):
                continue
            n += 1
            ev = parse_evt(line)
            k = ev.get('kind', '')
            kinds[k] += 1
            try:
                eid = int(ev.get('event_id', '-1'))
            except ValueError:
                eid = -1
            if k == activation_kind and act is None:
                act = ev
            if eid in wanted_ids or eid in (-1,):
                events[eid] = ev
    return n, kinds, events, act


def oracle_line(terminal_path, workload, ctx, target_va):
    text = Path(terminal_path).read_text(errors='replace')
    lines = [ln for ln in text.splitlines() if '_RESULT' in ln]
    for ln in lines:
        o = parse_kv(ln)
        if 'ctx' in o and o.get('ctx') != ctx:
            continue
        if 'target_va' in o:
            try:
                if int(o['target_va'], 16) != target_va:
                    continue
            except ValueError:
                pass
        if workload == 'W10':
            prefixes = ('W10S_RESULT', 'W10_RESULT')
        elif workload == 'W10S':
            prefixes = ('W10S_RESULT',)
        else:
            prefixes = ('%s_RESULT' % workload,)
        if any(ln.startswith(p) for p in prefixes):
            return ln.replace('\r', ''), o
    return '', {}


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    by_sid = {r['SampleRunID']: r for r in data['samples']}
    rows = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'MMU_10_Sample_Repeatability_Matrix.csv')))
    out = FINAL / 'repeat_campaign' / 'analysis'
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for row in rows:
        rid = row['RepeatID']; sid = row['RepeatOfSampleRunID']
        rec = by_sid[sid]
        gt = rec['GroundTruth']; orig = rec['OriginalResult']
        model = gt['FaultModelID']; ctx = orig['ContextID']
        workload = orig['WorkloadID']
        outdir = Path(row['Outdir'])
        trace = outdir / 'prop_evt.txt.gz'
        terminal = outdir / 'board.terminal'
        chain = C.chain(sid)
        formal_events = {int(e['EventID']): e for e in chain['Events']}
        verdict = C.verdict(sid)
        act_id = int(verdict['activation_event_id'])
        cons_id = int(verdict['consumption_event_id'])
        act_kind = formal_events[act_id]['Kind'] if act_id in formal_events \
            else verdict['Details']['activation_kind']
        n, kinds, rep_events, act = (0, Counter(), {}, None)
        if trace.is_file():
            n, kinds, rep_events, act = scan_trace(
                trace, set(formal_events) | {act_id, cons_id}, act_kind)
        # Activation comparison
        act_match = 'INSUFFICIENT_EVIDENCE'
        activation_details = {}
        if act is not None:
            fe = formal_events.get(act_id, {})
            fx = fe.get('ExtraFields') or {}
            diffs = {}
            for k in ACT_FIELDS:
                want = fx.get(k, fe.get(k, ''))
                got = act.get(k, '')
                if str(want) != '' and str(want) != str(got):
                    diffs[k] = (want, got)
            same_id = str(act.get('event_id')) == str(act_id)
            same_tick = str(act.get('tick')) == str(fe.get('Tick', ''))
            if not diffs and same_id and same_tick:
                act_match = 'MATCH'
            elif not diffs:
                act_match = 'SEMANTICALLY_EQUIVALENT'
            else:
                act_match = 'MISMATCH'
            activation_details = {
                'RepeatActivationEventID': act.get('event_id'),
                'FormalActivationEventID': act_id,
                'RepeatActivationKind': act.get('kind'),
                'FormalActivationKind': act_kind,
                'EventIDStable': same_id,
                'TickStable': same_tick,
                'StateDiffs': diffs,
                'TargetVA': act.get('va'),
                'Mode': act.get('mode', gt['AccessMode']),
            }
        # Propagation comparison
        prop_match = 'INSUFFICIENT_EVIDENCE'
        missing, kind_mismatch, tick_mismatch, semantic_mismatch = [], [], [], []
        if trace.is_file() and rep_events:
            for eid, fe in formal_events.items():
                re_ = rep_events.get(eid)
                if re_ is None:
                    missing.append(eid); continue
                if re_.get('kind') != fe.get('Kind'):
                    kind_mismatch.append(eid)
                if str(re_.get('tick')) != str(fe.get('Tick')):
                    tick_mismatch.append(eid)
                for kf, rf in (('VA', 'va'), ('PA', 'pa'),
                               ('TranslationID', 'translation_id'),
                               ('EntryID', 'entry_index')):
                    w = fe.get(kf, '')
                    g = re_.get(rf, '')
                    if str(w) not in ('', 'None') and str(w) != str(g):
                        semantic_mismatch.append((eid, kf, w, g))
            if not missing and not kind_mismatch and not tick_mismatch and \
                    not semantic_mismatch:
                prop_match = 'MATCH'
            elif not missing and not kind_mismatch and not semantic_mismatch:
                prop_match = 'SEMANTICALLY_EQUIVALENT'
            else:
                prop_match = 'MISMATCH'
        # Terminal comparison
        line, o = oracle_line(terminal, workload, ctx, gt['TargetVA'] and
                              int(gt['TargetVA'], 16))
        formal_line = (verdict.get('Details', {}).get('oracle') or {}).get(
            'line', '')
        fo = parse_kv(formal_line)
        keys = ORACLE_KEYS.get(workload, [])
        oracle_diffs = {k: (fo.get(k, ''), o.get(k, ''))
                        for k in keys if fo.get(k, '') != o.get(k, '')}
        if line:
            term_match = 'MATCH' if not oracle_diffs else 'MISMATCH'
        else:
            term_match = 'UNRESOLVED'
        exception = kinds.get('exception_delivery', 0)
        squash = kinds.get('squash', 0)
        derived_term = 'UNRESOLVED'
        if line:
            if o.get('result') == 'FAIL':
                derived_term = 'SDC'
            elif exception and o.get('result') == 'PASS':
                derived_term = 'DETECTED_CONTAINED'
            elif squash and o.get('result') == 'PASS':
                derived_term = 'SQUASHED'
        results.append({
            'OriginalSampleRunID': sid,
            'RepeatRunID': rid,
            'ModelID': model,
            'ContextID': ctx,
            'FormalAttemptID': orig['AttemptID'],
            'RepeatAttemptID': 'REP01',
            'FormalActivation': act_kind,
            'RepeatActivation': activation_details.get(
                'RepeatActivationKind', ''),
            'FormalSignature': '|'.join(
                e['Kind'] for e in chain['Events']),
            'RepeatSignature': '|'.join(
                rep_events[eid]['kind'] for eid in sorted(rep_events)
                if eid in formal_events) if rep_events else '',
            'FormalTerminal': orig['TerminalState'],
            'RepeatTerminal': derived_term,
            'ActivationMatch': act_match,
            'PropagationMatch': prop_match,
            'TerminalMatch': term_match,
            'MismatchReason': '; '.join(filter(None, [
                ('missing events %s' % missing) if missing else '',
                ('kind mismatch %s' % kind_mismatch) if kind_mismatch else '',
                ('tick mismatch %s' % tick_mismatch) if tick_mismatch else '',
                ('oracle diff %s' % oracle_diffs) if oracle_diffs else ''])),
            'EvidencePaths': json.dumps({
                'RepeatTrace': str(trace),
                'RepeatTerminal': str(terminal),
                'RepeatLogs': str(RC / 'run_logs'),
                'FormalTrace': orig['TraceAbsolutePath'],
                'FormalChain': str(C.ANALYSIS / 'propagation_chains' /
                                   ('%s.json' % sid)),
                'FormalVerdict': str(C.sample_dir(sid) /
                                     'Validation/verdict.json')}),
            'RepeatTraceEvents': n,
            'RepeatTraceSHA256': C.sha256_file(trace) if trace.is_file()
            else '',
            'RepeatTerminalLine': line,
            'FormalOracleLine': formal_line,
            'ActivationStateDiffs': activation_details.get('StateDiffs', {}),
            'MissingChainEvents': missing,
            'KindMismatches': kind_mismatch,
            'TickMismatches': tick_mismatch,
            'SemanticMismatches': semantic_mismatch,
            'RepeatExceptionEvents': exception,
            'RepeatSquashEvents': squash,
        })
    C.write_csv(out / 'Formal_vs_Repeat_Comparison.csv', results)
    C.write_json(out / 'Formal_vs_Repeat_Comparison.json', results)
    def count(key):
        return dict(Counter(r[key] for r in results))
    summary = {
        'PlannedRepeatRuns': 10,
        'CompletedRepeatRuns': sum(1 for r in results
                                   if r['RepeatTraceEvents'] > 0),
        'ValidRepeatRuns': sum(1 for r in results
                               if r['TerminalMatch'] != 'UNRESOLVED'),
        'ActivationConsistencyCount': count('ActivationMatch'),
        'PropagationConsistencyCount': count('PropagationMatch'),
        'TerminalConsistencyCount': count('TerminalMatch'),
        'MismatchCount': sum(1 for r in results if 'MISMATCH' in
                             (r['ActivationMatch'], r['PropagationMatch'],
                              r['TerminalMatch'])),
        'UnresolvedCount': sum(1 for r in results if 'UNRESOLVED' in
                               (r['ActivationMatch'], r['PropagationMatch'],
                                r['TerminalMatch'])),
        'SimulatorFailureCount': 0,
        'TraceIncompleteCount': sum(1 for r in results
                                    if r['RepeatTraceEvents'] == 0),
        'results': results,
    }
    C.write_json(out / 'Repeatability_Summary.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k != 'results'},
                     indent=1))
    for r in results:
        print(r['RepeatRunID'], r['ActivationMatch'],
              r['PropagationMatch'], r['TerminalMatch'],
              r['FormalTerminal'], '->', r['RepeatTerminal'],
              r['MismatchReason'][:120])


if __name__ == '__main__':
    main()
