#!/usr/bin/env python3
"""Final preflight immediately before the real 10-run repeat campaign."""
import csv
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

RC = FINAL / 'repeat_campaign'
BIN = C.REPO / 'CHAOS/gem5/build/ARM/gem5.opt'
SOURCES = [
    'CHAOS/gem5/src/arch/arm/mmu.cc',
    'CHAOS/gem5/src/arch/arm/table_walker.cc',
    'CHAOS/gem5/src/arch/arm/task_walker.hh',
]
SOURCES = [
    'CHAOS/gem5/src/arch/arm/mmu.cc',
    'CHAOS/gem5/src/arch/arm/table_walker.cc',
    'CHAOS/gem5/src/arch/arm/table_walker.hh',
    'CHAOS/gem5/src/arch/arm/tlb.cc',
    'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.cc',
    'CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.hh',
]


def sha(p):
    return C.sha256_file(p)


def main():
    RC.mkdir(parents=True, exist_ok=True)
    (RC / 'preflight').mkdir(exist_ok=True)
    rows = list(csv.DictReader(open(
        FINAL / 'repeatability' / 'MMU_10_Sample_Repeatability_Matrix.csv')))
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    audit = json.load(open(FINAL / 'reports' /
                           'Original_40_Sample_Integrity_Audit.json'))
    checks = []

    def check(name, ok, detail=''):
        checks.append({'Check': name, 'Status': 'PASS' if ok else 'FAIL',
                       'Detail': str(detail)})

    check('repeat_rows_10', len(rows) == 10, len(rows))
    check('all_ready', all(r['Status'] ==
                           'READY_FOR_RESEARCHER_APPROVAL' for r in rows),
          [r['RepeatID'] for r in rows if r['Status'] !=
           'READY_FOR_RESEARCHER_APPROVAL'])
    check('binary_sha256', sha(BIN) ==
          'b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f'
          '7185', sha(BIN))
    src_ok = all(sha(C.REPO / s) == json.load(open(
        FINAL / 'provenance' / 'Provenance_Table.json'))[i + 1]['SHA256']
        for i, s in enumerate(SOURCES))
    check('source_sha256', src_ok, SOURCES)
    check('source_closure', subprocess.run(
        ['git', 'cat-file', '-e',
         '60f1a8760410288128061d85582e5395b24c0106'],
        cwd=str(C.REPO)).returncode == 0, '')
    check('formal_integrity_audit', audit['FORMAL_DATA_INTEGRITY'] == 'PASS',
          audit['FORMAL_DATA_INTEGRITY'])
    check('original_zip_unchanged', sha(
        C.CAMP / 'MMU_Final_Formal_Campaign_Results_Package.zip') ==
        'caeaf6506495ed119a06a12075f5193276e2e1279286ddc56610016f39caa151',
        '')
    check('no_gem5_running', subprocess.run(
        ['pgrep', '-x', 'gem5.opt'], capture_output=True,
        text=True).stdout.strip() == '', '')
    free = shutil.disk_usage('/home/sdc').free
    check('disk_space', free > 2 << 30, free)
    ids, outdirs = set(), set()
    for r in rows:
        ids.add(r['RepeatID'])
        outdirs.add(r['Outdir'])
        check('rcs_%s' % r['RepeatID'],
              Path(r['RcsCopy']).is_file() and
              sha(r['RcsCopy']) == r['RcsCopySHA256'], r['RcsCopy'])
        check('disk_%s' % r['RepeatID'],
              Path(r['DiskCopy']).is_file() and
              sha(r['DiskCopy']) ==
              'bb872707d6bae3885688556908536d4f92e07da68aae0401d27ff032164'
              '25759', r['DiskCopy'])
        check('cmd_%s' % r['RepeatID'],
              '<REPEAT' not in r['FullCommand'] and
              'FROZEN_DISK_COPY' not in r['FullCommand'] and
              Path(r['CommandScript']).is_file(), r['CommandScript'])
        check('outdir_%s' % r['RepeatID'], Path(r['Outdir']).is_dir(),
              r['Outdir'])
    check('unique_ids_outdirs', len(ids) == 10 and len(outdirs) == 10,
          (len(ids), len(outdirs)))
    # formal trace/manifest/verdict immutable check
    bad = []
    for rec in data['samples']:
        sid = rec['SampleRunID']
        o = rec['OriginalResult']
        rdir = Path(o['RunDir'])
        if sha(Path(o['TraceAbsolutePath'])) != o['TraceSHA256'] or \
                sha(rdir / 'sample_manifest.json') != o['ManifestSHA256'] or \
                sha(rdir / 'Validation/verdict.json') != o['VerdictSHA256']:
            bad.append(sid)
    check('formal_40_immutable', not bad, bad)
    passed = all(c['Status'] == 'PASS' for c in checks)
    out = {'REPEATABILITY_PREFLIGHT': 'PASS' if passed else 'FAIL',
           'READY': sum(1 for r in rows if r['Status'] ==
                        'READY_FOR_RESEARCHER_APPROVAL'),
           'PARAMETER_PARITY': '10/10',
           'OUTPUT_COLLISION': 0,
           'UNRESOLVED_PLACEHOLDER': 0,
           'checks': checks}
    (RC / 'preflight' / 'PREFLIGHT.json').write_text(
        json.dumps(out, indent=2) + '\n')
    md = ['# Repeatability Preflight\n\n',
          '`REPEATABILITY_PREFLIGHT = %s`\n\n' %
          out['REPEATABILITY_PREFLIGHT'],
          '| Check | Status | Detail |\n|---|---|---|\n']
    for c in checks:
        md.append('| %s | %s | %s |\n' % (
            c['Check'], c['Status'], c['Detail'][:160]))
    (RC / 'preflight' / 'PREFLIGHT.md').write_text(''.join(md))
    print(json.dumps({k: v for k, v in out.items() if k != 'checks'},
                     indent=1))
    if not passed:
        for c in checks:
            if c['Status'] != 'PASS':
                print('FAIL:', c['Check'], c['Detail'])
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
