#!/usr/bin/env python3
"""Build MMU_FINAL_Repeatability_Results.xlsx from repeat artifacts."""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

import openpyxl
from openpyxl.styles import Font

OUT = FINAL / 'repeat_campaign' / 'analysis'


def rows(p):
    return list(csv.DictReader(open(p)))


def add(wb, title, data, cols=None):
    ws = wb.create_sheet(title)
    if not data:
        ws.append(['(empty)']); return
    cols = cols or list(data[0].keys())
    ws.append(cols); ws['A1'].font = Font(bold=True)
    for r in data:
        ws.append([json.dumps(r.get(c, ''), sort_keys=True)
                   if isinstance(r.get(c), (dict, list))
                   else r.get(c, '') for c in cols])
    ws.freeze_panes = 'B2'


def main():
    data = json.load(open(FINAL / 'data' / 'MMU_Final_Dataset.json'))
    formal = []
    for r in data['samples']:
        o = r['OriginalResult']; g = r['GroundTruth']
        formal.append({
            'SampleRunID': r['SampleRunID'],
            'ModelID_LABEL': g['FaultModelID'],
            'ContextID': o['ContextID'],
            'WorkloadID': o['WorkloadID'],
            'AttemptID': o['AttemptID'],
            'TerminalState': o['TerminalState'],
            'OracleResult': o['OracleResult'],
            'PropagationStatus': o['PropagationStatus'],
            'TraceCompleteness': o['TraceCompleteness'],
            'TraceSHA256': o['TraceSHA256'],
            'BinarySHA256': o['BinarySHA256'],
        })
    exec_rows = rows(OUT / 'Repeat_Run_Execution_Matrix.csv')
    comp = rows(OUT / 'Formal_vs_Repeat_Comparison.csv')
    act = [{k: r[k] for k in ('OriginalSampleRunID', 'RepeatRunID',
                              'ModelID', 'ContextID', 'FormalActivation',
                              'RepeatActivation', 'ActivationMatch',
                              'ActivationStateDiffs', 'MissingChainEvents',
                              'KindMismatches', 'TickMismatches')}
           for r in comp]
    prop = [{k: r[k] for k in ('OriginalSampleRunID', 'RepeatRunID',
                               'FormalSignature', 'RepeatSignature',
                               'PropagationMatch', 'RepeatTraceEvents',
                               'RepeatExceptionEvents', 'RepeatSquashEvents')}
            for r in comp]
    term = [{k: r[k] for k in ('OriginalSampleRunID', 'RepeatRunID',
                               'FormalTerminal', 'RepeatTerminal',
                               'TerminalMatch', 'FormalOracleLine',
                               'RepeatTerminalLine', 'MismatchReason')}
            for r in comp]
    oracle = [{k: r[k] for k in ('OriginalSampleRunID', 'RepeatRunID',
                                 'FormalOracleLine', 'RepeatTerminalLine',
                                 'TerminalMatch')} for r in comp]
    model = {}
    for r in comp:
        m = model.setdefault(r['ModelID'], {'ModelID': r['ModelID'],
                                            'Samples': 0,
                                            'ActivationMatch': 0,
                                            'PropagationMatch': 0,
                                            'TerminalMatch': 0})
        m['Samples'] += 1
        m['ActivationMatch'] += int(r['ActivationMatch'] == 'MATCH')
        m['PropagationMatch'] += int(r['PropagationMatch'] == 'MATCH')
        m['TerminalMatch'] += int(r['TerminalMatch'] == 'MATCH')
    model_rows = sorted(model.values(), key=lambda x: x['ModelID'])
    mismatch = [r for r in comp if 'MISMATCH' in (
        r['ActivationMatch'], r['PropagationMatch'], r['TerminalMatch'])]
    summary = json.load(open(OUT / 'Repeatability_Summary.json'))
    prov = rows(FINAL / 'provenance' / 'Provenance_Table.csv')
    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = 'Readme'
    for line in [
        ['MMU FINAL Repeatability Results'],
        ['Campaign', 'MMU-REPEATABILITY-20261114'],
        ['Planned', 10],
        ['Completed', summary['CompletedRepeatRuns']],
        ['Valid', summary['ValidRepeatRuns']],
        ['Activation', json.dumps(summary['ActivationConsistencyCount'])],
        ['Propagation', json.dumps(summary['PropagationConsistencyCount'])],
        ['Terminal', json.dumps(summary['TerminalConsistencyCount'])],
        ['Mismatch', summary['MismatchCount']],
        ['Note', 'Two observations per context only; no statistical '
                 'generalization is claimed.'],
    ]:
        ws.append(line)
    ws['A1'].font = Font(bold=True, size=14)
    add(wb, 'Original_Formal_Results', formal)
    add(wb, 'Repeat_Runs', exec_rows)
    add(wb, 'Fault_Activation', act)
    add(wb, 'Propagation_Signature', prop)
    add(wb, 'Terminal_Comparison', term)
    add(wb, 'Oracle_Comparison', oracle)
    add(wb, 'Model_Level_Summary', model_rows)
    add(wb, 'Mismatch_Investigation', mismatch)
    add(wb, 'Provenance', prov)
    add(wb, 'Research_Limitations', [
        {'Limitation': x} for x in [
            'Only two observations per context (formal + one repeat).',
            'No statistical stability or cross-workload generalization is '
            'claimed.',
            'Simulator-only TLB/PTW/PFN internals are not proven production '
            'observable.',
            'M03 squash is not detection; M06 detection is not generic '
            'masking.',
            'M07 permission bypass is not a wrong-value computation.',
            'M01 microarchitecture is l2_shared, not the real DTB.',
            'No repeat control was authorized; formal shared controls remain '
            'the baseline.',
            'No per-instruction IFU fetch/decode/commit nodes are fabricated.',
        ]])
    out = OUT / 'MMU_FINAL_Repeatability_Results.xlsx'
    wb.save(out)
    print(json.dumps({'xlsx': str(out), 'sheets': wb.sheetnames,
                      'size_bytes': out.stat().st_size}, indent=1))


if __name__ == '__main__':
    main()
