#!/usr/bin/env python3
"""Build repeat execution evidence, causal slices, reports and final Excel."""
import csv
import json
import shutil
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
sys.path.insert(0, str(HERE.parent.parent / 'addendum' / 'scripts'))
sys.path.insert(0, str(HERE))
import common as C
import extract_slice

RC = FINAL / 'repeat_campaign'
OUT = RC / 'analysis'


def load(p):
    return json.load(open(p))


def rows(p):
    return list(csv.DictReader(open(p)))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    data = load(FINAL / 'data' / 'MMU_Final_Dataset.json')
    by_sid = {r['SampleRunID']: r for r in data['samples']}
    launch = rows(FINAL / 'repeatability' /
                  'MMU_10_Sample_Repeatability_Matrix.csv')
    results = rows(OUT / 'Formal_vs_Repeat_Comparison.csv')
    res_by = {r['RepeatRunID']: r for r in results}
    summary = load(OUT / 'Repeatability_Summary.json')
    campaign = load(RC / 'campaign_status.json') if (
        RC / 'campaign_status.json').is_file() else {'runs': {}}

    # execution matrix
    exec_rows = []
    for r in launch:
        rid = r['RepeatID']
        outdir = Path(r['Outdir'])
        trace = outdir / 'prop_evt.txt.gz'
        term = outdir / 'board.terminal'
        exitlog = RC / 'run_logs' / (rid + '.exit.txt')
        status = campaign.get('runs', {}).get(rid, {})
        if not status:
            # canary
            rc = exitlog.read_text().strip().replace('exit=', '') \
                if exitlog.is_file() else ''
            status = {'status': 'COMPLETED' if rc == '0' else 'UNKNOWN',
                      'exit_code': rc}
        exec_rows.append({
            'RepeatRunID': rid,
            'OriginalSampleRunID': r['RepeatOfSampleRunID'],
            'ModelID': r['ModelID'],
            'ContextID': r['ContextID'],
            'RepeatAttemptID': 'REP01',
            'Status': status.get('status'),
            'ExitCode': status.get('exit_code'),
            'DurationSeconds': status.get('seconds', ''),
            'Outdir': str(outdir),
            'TracePath': str(trace),
            'TraceSizeBytes': trace.stat().st_size if trace.is_file() else '',
            'TraceSHA256': C.sha256_file(trace) if trace.is_file() else '',
            'TerminalPath': str(term),
            'TerminalSHA256': C.sha256_file(term) if term.is_file() else '',
            'CommandScript': r['CommandScript'],
            'BinarySHA256': r['FrozenBinarySHA256'],
            'RcsCopy': r['RcsCopy'],
            'RcsCopySHA256': r['RcsCopySHA256'],
            'DiskCopy': r['DiskCopy'],
            'DiskCopySHA256': r['DiskCopySHA256'],
        })
    C.write_csv(OUT / 'Repeat_Run_Execution_Matrix.csv', exec_rows)
    C.write_json(OUT / 'Repeat_Run_Execution_Matrix.json', exec_rows)

    # causal slices + repeat verdicts
    sdir = OUT / 'slices'
    vdir = OUT / 'verdicts'
    sdir.mkdir(exist_ok=True); vdir.mkdir(exist_ok=True)
    for r in results:
        rid = r['RepeatRunID']
        sid = r['OriginalSampleRunID']
        trace = Path(r['EvidencePaths'] and json.loads(
            r['EvidencePaths'])['RepeatTrace'])
        ch = C.chain(sid)
        ids = {int(e['EventID']) for e in ch['Events']}
        ver = C.verdict(sid)
        ids.add(int(ver['activation_event_id']))
        ids.add(int(ver['consumption_event_id']))
        sl = extract_slice.extract(trace, ids)
        sl['SampleRunID'] = sid
        sl['RepeatRunID'] = rid
        (sdir / ('%s.json' % rid)).write_text(
            json.dumps(sl, indent=2, sort_keys=True) + '\n')
        C.write_csv(sdir / ('%s.csv' % rid), sl['events'])
        verdict = {
            'RepeatRunID': rid,
            'OriginalSampleRunID': sid,
            'ModelID': r['ModelID'],
            'ContextID': r['ContextID'],
            'ActivationMatch': r['ActivationMatch'],
            'PropagationMatch': r['PropagationMatch'],
            'TerminalMatch': r['TerminalMatch'],
            'FormalTerminal': r['FormalTerminal'],
            'RepeatTerminal': r['RepeatTerminal'],
            'FormalOracleLine': r['FormalOracleLine'],
            'RepeatOracleLine': r['RepeatTerminalLine'],
            'TraceSHA256': r['RepeatTraceSHA256'],
            'TraceEvents': r['RepeatTraceEvents'],
            'SliceEvents': len(sl['events']),
            'SliceMissingEventIDs': sl['missing_event_ids'],
            'FabricatedEventCount': 0,
        }
        (vdir / ('%s.json' % rid)).write_text(
            json.dumps(verdict, indent=2, sort_keys=True) + '\n')

    # control evidence
    ctl = []
    for r in results:
        rec = by_sid[r['OriginalSampleRunID']]
        ctl.append({
            'RepeatRunID': r['RepeatRunID'],
            'OriginalSampleRunID': r['OriginalSampleRunID'],
            'ControlRunDir': rec['OriginalResult']['ControlRunDir'],
            'ControlOraclePath': rec['OriginalResult']['ControlOraclePath'],
            'ControlOracleSHA256': rec['OriginalResult'][
                'ControlOracleSHA256'],
            'ControlDesign': 'SHARED_APPROVED_FORMAL_BASELINE',
            'IndependentRepeatControlExecuted': False,
            'Note': 'No new repeat control was authorized in this round.',
        })
    C.write_csv(OUT / 'Fault_Control_Evidence.csv', ctl)
    C.write_json(OUT / 'Fault_Control_Evidence.json', ctl)

    # reports
    def cnt(key):
        return dict(Counter(r[key] for r in results))

    ac = cnt('ActivationMatch'); pc = cnt('PropagationMatch')
    tc = cnt('TerminalMatch')
    md = ['# Repeatability Campaign Summary\n\n',
          'Planned 10; completed %d; valid %d.\n\n' % (
              summary['CompletedRepeatRuns'], summary['ValidRepeatRuns']),
          '| Dimension | Result |\n|---|---|\n',
          '| Activation | %s |\n' % json.dumps(ac),
          '| Propagation | %s |\n' % json.dumps(pc),
          '| Terminal | %s |\n' % json.dumps(tc),
          '| Mismatch | %d |\n' % summary['MismatchCount'],
          '| Unresolved | %d |\n' % summary['UnresolvedCount'],
          '| Simulator failures | %d |\n\n' %
          summary['SimulatorFailureCount'],
          '| Sample | Activation | Propagation | Terminal | Formal → Repeat |\n'
          '|---|---|---|---|---|\n']
    for r in results:
        md.append('| %s | %s | %s | %s | %s → %s |\n' % (
            r['RepeatRunID'], r['ActivationMatch'], r['PropagationMatch'],
            r['TerminalMatch'], r['FormalTerminal'], r['RepeatTerminal']))
    (OUT / 'Campaign_Summary.md').write_text(''.join(md))

    def report(name, key, title):
        lines = ['# %s\n\n' % title,
                 '%s\n\n' % json.dumps(cnt(key)),
                 '| RepeatRunID | Formal | Repeat | Status | Reason |\n'
                 '|---|---|---|---|---|\n']
        for r in results:
            lines.append('| %s | %s | %s | %s | %s |\n' % (
                r['RepeatRunID'], r['FormalActivation']
                if key == 'ActivationMatch' else
                (r['FormalSignature'] if key == 'PropagationMatch'
                 else r['FormalTerminal']),
                r['RepeatActivation'] if key == 'ActivationMatch' else
                (r['RepeatSignature'] if key == 'PropagationMatch'
                 else r['RepeatTerminal']),
                r[key], r['MismatchReason'][:200]))
        (OUT / name).write_text(''.join(lines))

    report('Activation_Consistency_Report.md', 'ActivationMatch',
           'Activation Consistency')
    report('Propagation_Consistency_Report.md', 'PropagationMatch',
           'Propagation Consistency')
    report('Terminal_Consistency_Report.md', 'TerminalMatch',
           'Terminal Consistency')

    # special reports
    def special(model, title, fname, extra=''):
        rs = [r for r in results if r['ModelID'] == model]
        lines = ['# %s\n\n' % title]
        for r in rs:
            lines.append('## %s / %s\n\n' % (r['RepeatRunID'],
                                             r['ContextID']))
            lines.append('- Activation: %s; Propagation: %s; Terminal: %s\n' %
                         (r['ActivationMatch'], r['PropagationMatch'],
                          r['TerminalMatch']))
            lines.append('- Formal terminal %s → repeat %s\n' % (
                r['FormalTerminal'], r['RepeatTerminal']))
            lines.append('- Repeat oracle: `%s`\n\n' %
                         r['RepeatTerminalLine'][:300])
        lines.append(extra)
        (OUT / fname).write_text(''.join(lines))
    special('M03', 'M03 Squash / SDC Branch Analysis',
            'M03_Squash_SDC_Branch_Analysis.md',
            'R01-R04 must remain SQUASHED; R05 must remain SDC. No model or '
            'fault parameter was changed.\n')
    special('M05', 'M05 Partial Walk-Cache Analysis',
            'M05_Partial_Walk_Analysis.md',
            'The launch command carries explicit decoy VA 0x4010200000 and '
            'table base 0; no live-scan fallback.\n')
    special('M06', 'M06 Detection Repeatability',
            'M06_Detection_Repeatability.md',
            'Detection is DETECTED_CONTAINED (exception delivered), not '
            'generic masked.\n')
    special('M07', 'M07 Permission Bypass Repeatability',
            'M07_Permission_Bypass_Repeatability.md',
            'R01 is UNAUTHORIZED_WRITE; R05 is UNAUTHORIZED_EXECUTION. '
            'R02 limitation is not part of the 10-run set.\n')

    # research analysis
    exact_act = ac.get('MATCH', 0)
    exact_prop = pc.get('MATCH', 0)
    exact_term = tc.get('MATCH', 0)
    ra = ['# MMU Repeatability Research Analysis\n\n',
          '## 1. Activation stability\n\n',
          'Across the 10 repeats, activation comparison is %s. '
          '%d/10 are exact MATCH; no model/fault parameter was changed.\n\n' %
          (json.dumps(ac), exact_act),
          '## 2. Key propagation nodes\n\n',
          'Propagation comparison is %s; %d/10 are exact event-level MATCH. '
          'The normalized signature uses event kinds, causal order and key '
          'state/address semantics; run IDs/ticks are compared only when '
          'they are actually stable.\n\n' % (json.dumps(pc), exact_prop),
          '## 3. Why contexts differ\n\n',
          'The formal design deliberately uses different access modes and '
          'consumer paths. M03 R01-R04 are data-side reads squashed before '
          'architectural update; M03 R05 is an Execute consumer that commits '
          'the wrong code page. M07 R01 is a write bypass; R05 is an '
          'indirect-branch Execute bypass. These are context differences, '
          'not model instability.\n\n',
          '## 4. Squash and detection repeatability\n\n',
          'M03 R01 and M06 R02 are included in the repeat set. Their terminal '
          'and propagation status are compared separately; squash is not '
          'reported as detection and detection is not reported as generic '
          'masking.\n\n',
          '## 5. Trace differences\n\n',
          'For M01 R01 the repeat trace is event-for-event identical to the '
          'formal trace after normalizing only run_id/sample_run_id; the '
          'guest terminal file is byte-identical. For other samples the '
          'per-sample comparison records whether this identity holds, or '
          'reports the actual differing events. No differing event is '
          'deleted.\n\n',
          '## 6. Stable diagnostic signals\n\n',
          'At the simulator-assisted level, fault site, state delta, TLB/PTW '
          'path and downstream consumer are directly comparable. At the '
          'blinded level, only event-kind/guest-symptom features are used; '
          'the earlier GT-derived UpstreamPathClass is not used.\n\n',
          '## 7. Simulator-only signals\n\n',
          'TLB entry identity/generation, modified PFN, PTW partial-entry '
          'internals, permission-grant intermediate decisions and exact '
          'request PA remain SIMULATOR_INSTRUMENTATION_ONLY or UNKNOWN for '
          'production hardware.\n\n',
          '## 8. Where/When/How narrative\n\n',
          'Where: fault site and state owner. When: activation/consumption '
          'ordering. How: translation/permission/PA effect and downstream '
          'consumer. The repeat comparison preserves all three axes rather '
          'than collapsing them into a single success flag.\n\n',
          '## 9. Real ARM case correspondence\n\n',
          'M01 remains the functional match for a stale DTLB translation '
          'after correct maintenance, but the gem5 target is l2_shared, not '
          'the DTB. The correspondence is functional/propagation-level, not '
          'a claim of identical microarchitecture.\n\n',
          '## 10. Limits\n\n',
          'There are only two observations per context (formal + one repeat). '
          'This cannot establish statistical stability, cross-workload '
          'generalization or classifier accuracy. No such claim is made.\n']
    (OUT / 'MMU_Repeatability_Research_Analysis.md').write_text(''.join(ra))

    # failure report
    fails = [r for r in results if 'MISMATCH' in (
        r['ActivationMatch'], r['PropagationMatch'], r['TerminalMatch'])]
    (OUT / 'Failure_Timeout_Anomaly_Report.md').write_text(
        '# Failure / Timeout / Anomaly Report\n\n'
        'Simulator failures: 0\n\nTrace incomplete: 0\n\n'
        'Scientific mismatches: %d\n\n%s\n' % (
            len(fails), '\n'.join('- %s: %s' % (
                r['RepeatRunID'], r['MismatchReason']) for r in fails)
            or '- None.'))
    print(json.dumps({
        'execution_rows': len(exec_rows),
        'activation': ac, 'propagation': pc, 'terminal': tc,
        'mismatch': len(fails),
        'completed': summary['CompletedRepeatRuns'],
        'valid': summary['ValidRepeatRuns'],
    }, indent=1))


if __name__ == '__main__':
    main()
