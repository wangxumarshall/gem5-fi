#!/usr/bin/env python3
"""Addendum task 4 - independent trace sampling and slice verification.

Copies 7 original traces/manifests/verdicts, extracts causal slices with the
included extract_slice.py, and verifies every slice event against the original
trace.  No event is synthesized.
"""
import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C
import extract_slice

ADD = C.OUT / 'addendum'
OUT = ADD / 'trace_samples'

SAMPLES = [
    'M01-F0-W9-S01-R01',
    'M03-F0-W11-S01-R01',
    'M03-F0-W11-S01-R05',
    'M05-F0-W13-S01-R05',
    'M06-F0-W10-S01-R02',
    'M07-F0-W14-S01-R02',
    'M07-F0-W14-S01-R05',
]


def sha(p):
    return C.sha256_file(p)


def collect_ids(obj, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if (k.lower().endswith('event_id') or
                    k.lower() in ('eventid', 'activationeventid',
                                  'consumptioneventid')):
                try:
                    out.add(int(v))
                except (TypeError, ValueError):
                    pass
            collect_ids(v, out)
    elif isinstance(obj, list):
        for v in obj:
            collect_ids(v, out)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    m07 = {r['SampleRunID']: r for r in csv.DictReader(
        open(C.AUDIT / 'M07_Sample_Evidence.csv'))}
    summary = []
    for sid in SAMPLES:
        src = C.sample_dir(sid)
        dst = OUT / sid
        dst.mkdir(parents=True, exist_ok=True)
        files = {
            'prop_evt.txt.gz': src / 'Trace' / 'prop_evt.txt.gz',
            'sample_manifest.json': src / 'sample_manifest.json',
            'verdict.json': src / 'Validation' / 'verdict.json',
            'observed_output.txt': src / 'Run_Log' / 'observed_output.txt',
            'board.terminal': src / 'Run_Log' / 'board.terminal',
        }
        copied = {}
        for name, p in files.items():
            q = dst / name
            shutil.copy2(p, q)
            copied[name] = {'source': str(p), 'copy': str(q),
                            'source_sha256': sha(p), 'copy_sha256': sha(q),
                            'byte_identical': sha(p) == sha(q)}
        ch = C.chain(sid)
        ver = C.verdict(sid)
        ids = set()
        roles = {}
        for e in ch.get('Events', []):
            eid = int(e['EventID'])
            ids.add(eid); roles[eid] = 'chain'
        ids.add(int(ver['activation_event_id']))
        roles[int(ver['activation_event_id'])] = 'activation'
        ids.add(int(ver['consumption_event_id']))
        roles[int(ver['consumption_event_id'])] = 'consumption'
        collect_ids(ch.get('StrictChain') or {}, ids)
        for eid in list(ids):
            roles.setdefault(eid, 'strict_chain')
        if sid in m07:
            nearest = m07[sid].get('NearestPermissionEvalEventID', '')
            if nearest and not m07[sid].get('PermissionEvalEventIDs'):
                ids.add(int(nearest))
                roles[int(nearest)] = 'nearest_same_va_permission_eval_not_joined'
        res = extract_slice.extract(dst / 'prop_evt.txt.gz', ids)
        for e in res['events']:
            e['SliceRole'] = roles.get(int(e['event_id']), 'chain')
        C.write_json(dst / 'event_slice.json', {
            'SampleRunID': sid,
            'trace': copied['prop_evt.txt.gz'],
            'requested_event_ids': res['requested_event_ids'],
            'found_event_ids': res['found_event_ids'],
            'missing_event_ids': res['missing_event_ids'],
            'fabricated_event_count': 0,
            'events': res['events'],
        })
        fields = ['event_id', 'parent_event_id', 'kind', 'SliceRole', 'tick',
                  'cycle', 'fault_id', 'translation_id', 'lookup_id',
                  'walk_id', 'entry_index', 'field', 'before', 'after',
                  'state_before', 'state_after', 'va', 'pa', 'asid', 'vmid',
                  'tlb_instance', 'mode', 'permission_result',
                  'descriptor_before', 'descriptor_after',
                  'request_pa_before', 'request_pa_after', 'decoy_va',
                  'candidate_asid', 'candidate_entry_id',
                  'candidate_generation', 'squash_status', 'outcome']
        C.write_csv(dst / 'event_slice.csv', res['events'], fields)
        # verify chain event fields against the frozen chain JSON
        by_id = {int(e['event_id']): e for e in res['events']}
        mismatches = []
        for ce in ch.get('Events', []):
            eid = int(ce['EventID'])
            ev = by_id.get(eid)
            if ev is None:
                mismatches.append({'EventID': eid, 'problem': 'not_found'})
                continue
            for raw_key, chain_key in (('kind', 'Kind'), ('tick', 'Tick'),
                                       ('parent_event_id',
                                        'ParentEventID')):
                want = str(ce.get(chain_key, ''))
                got = str(ev.get(raw_key, ''))
                if want not in ('', 'None') and got != want:
                    mismatches.append({'EventID': eid, 'field': raw_key,
                                       'chain': want, 'trace': got})
        verification = {
            'SampleRunID': sid,
            'SourceTraceAbsolutePath': copied['prop_evt.txt.gz']['source'],
            'SourceTraceSHA256':
                copied['prop_evt.txt.gz']['source_sha256'],
            'CopiedTraceAbsolutePath': copied['prop_evt.txt.gz']['copy'],
            'CopiedTraceSHA256': copied['prop_evt.txt.gz']['copy_sha256'],
            'TraceByteIdentical': copied['prop_evt.txt.gz']['byte_identical'],
            'ManifestByteIdentical':
                copied['sample_manifest.json']['byte_identical'],
            'VerdictByteIdentical':
                copied['verdict.json']['byte_identical'],
            'ObservedOutputByteIdentical':
                copied['observed_output.txt']['byte_identical'],
            'BoardTerminalByteIdentical':
                copied['board.terminal']['byte_identical'],
            'TraceEventCount': res['trace_event_count'],
            'RequestedEventCount': len(ids),
            'SliceEventCount': len(res['events']),
            'MissingEventIDs': res['missing_event_ids'],
            'ChainFieldMismatches': mismatches,
            'FabricatedEventCount': 0,
            'CopiedFiles': copied,
            'Verdict': (
                'PASS' if (copied['prop_evt.txt.gz']['byte_identical'] and
                           not res['missing_event_ids'] and not mismatches and
                           len(res['events']) == len(ids)) else 'FAIL'),
        }
        C.write_json(dst / 'slice_verification.json', verification)
        summary.append({
            'SampleRunID': sid,
            'SourceTraceAbsolutePath':
                verification['SourceTraceAbsolutePath'],
            'SourceTraceSHA256': verification['SourceTraceSHA256'],
            'CopiedTraceSHA256': verification['CopiedTraceSHA256'],
            'TraceByteIdentical': verification['TraceByteIdentical'],
            'TraceEventCount': verification['TraceEventCount'],
            'SliceEventCount': verification['SliceEventCount'],
            'MissingEventIDs': verification['MissingEventIDs'],
            'ChainFieldMismatches': len(mismatches),
            'FabricatedEventCount': 0,
            'Verdict': verification['Verdict'],
        })
        print('%s slice=%d/%d missing=%d mismatches=%d %s' % (
            sid, len(res['events']), len(ids), len(res['missing_event_ids']),
            len(mismatches), verification['Verdict']), flush=True)
    C.write_csv(OUT / 'Trace_Sample_Verification.csv', summary)
    C.write_json(OUT / 'Trace_Sample_Verification.json', summary)
    md = ['# Independent Trace Sampling Verification\n\n',
          'Seven original traces were copied byte-for-byte (SHA256 verified) '
          'and causal slices were extracted from the copied originals with '
          '`scripts/extract_slice.py`. No event was synthesized.\n\n',
          '| Sample | Trace events | Slice events | Missing | Chain '
          'mismatches | Fabricated | Verdict |\n'
          '|---|---|---|---|---|---|---|\n']
    for r in summary:
        md.append('| %s | %d | %d | %s | %d | 0 | %s |\n' % (
            r['SampleRunID'], r['TraceEventCount'], r['SliceEventCount'],
            r['MissingEventIDs'] or 'none', r['ChainFieldMismatches'],
            r['Verdict']))
    md.append('\n## Slice roles\n\n')
    for sid in SAMPLES:
        v = json.load(open(OUT / sid / 'slice_verification.json'))
        md.append('### %s\n\n' % sid)
        md.append('- Source trace: `%s`\n' %
                  v['SourceTraceAbsolutePath'])
        md.append('- Source SHA256: `%s`\n' % v['SourceTraceSHA256'])
        md.append('- Copied SHA256: `%s` (identical=%s)\n' % (
            v['CopiedTraceSHA256'], v['TraceByteIdentical']))
        md.append('- Requested/slice: %d/%d; missing: %s; chain mismatches: '
                  '%d; fabricated: 0\n\n' % (
                      v['RequestedEventCount'], v['SliceEventCount'],
                      v['MissingEventIDs'] or 'none',
                      len(v['ChainFieldMismatches'])))
    md.append('## Verdict\n\n')
    bad = [r for r in summary if r['Verdict'] != 'PASS']
    md.append('`TRACE_SAMPLE_VERIFICATION = %s` (%d/7 PASS).\n' % (
        'PASS' if not bad else 'FAIL', len(summary) - len(bad)))
    (OUT / 'Trace_Sample_Verification.md').write_text(''.join(md))
    print(json.dumps({'samples': len(summary),
                      'pass': sum(1 for r in summary
                                  if r['Verdict'] == 'PASS'),
                      'fabricated': 0}, indent=1))
    return 0 if not bad else 1


if __name__ == '__main__':
    sys.exit(main())
