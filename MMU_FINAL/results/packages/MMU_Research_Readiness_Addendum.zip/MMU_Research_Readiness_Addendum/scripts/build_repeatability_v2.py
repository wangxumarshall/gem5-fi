#!/usr/bin/env python3
"""Addendum task 1 - corrected 10-sample repeatability design.

Uses the read-only runner --describe outputs plus the original formal command,
manifest, rcS/disk identity and authority records.  No gem5 run is started.
"""
import base64
import csv
import gzip
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'
DESC = ADD / 'describe'
RAW = DESC / 'raw'
REPV2 = ADD / 'repeatability_v2'
AUTH_XLSX = C.PKG / 'authority' / 'gem5-fi-MMU-Final-Paper-Experiment-Plan.xlsx'
AUTH_CSV = C.PKG / 'authority' / 'MMU_40_Sample_Matrix.csv'
AUTH_JSON = C.PKG / 'authority' / 'MMU_Parameter_Authority_v3.0.2.json'
M05_DECOY_VA = 0x4010200000

SIDS = [
    'M01-F0-W9-S01-R01', 'M02-F0-W10-S01-R02',
    'M03-F0-W11-S01-R01', 'M03-F0-W11-S01-R05',
    'M04-F0-W12-S01-R05', 'M05-F0-W13-S01-R05',
    'M06-F0-W10-S01-R02', 'M07-F0-W14-S01-R01',
    'M07-F0-W14-S01-R05', 'M08-F0-W10-S01-R01',
]
PAYLOAD_RE = re.compile(r"base64 -d > \S+ <<'([A-Za-z0-9_]+)'")


def sha(p):
    return C.sha256_file(p)


def payload_hash(rcs_path):
    p = Path(rcs_path)
    if not p.is_file():
        return None
    lines = p.read_text(errors='replace').splitlines()
    marker = start = None
    for i, line in enumerate(lines):
        m = PAYLOAD_RE.search(line)
        if m:
            marker, start = m.group(1), i + 1
            break
    if marker is None:
        return None
    blob = []
    for line in lines[start:]:
        if line.strip() == marker:
            break
        blob.append(line.strip())
    try:
        return hashlib.sha256(
            gzip.decompress(base64.b64decode(''.join(blob)))).hexdigest()
    except Exception:
        return None


def cmd_map(cmd):
    out = {}
    i = 0
    while i < len(cmd):
        tok = cmd[i]
        if tok.startswith('--'):
            if i + 1 < len(cmd) and not cmd[i + 1].startswith('--'):
                out[tok] = cmd[i + 1]
                i += 2
            else:
                out[tok] = 'true'
                i += 1
        else:
            i += 1
    return out


def resolve(p):
    p = Path(str(p))
    return p if p.is_absolute() else C.REPO / p


def disk_hash(sid):
    sums = (C.sample_dir(sid) / 'SHA256' / 'SHA256SUMS.txt')
    for line in sums.read_text().splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2 and parts[1].strip() == 'disk.img':
            return parts[0]
    return ''


def main():
    REPV2.mkdir(parents=True, exist_ok=True)
    matrix = {r['SampleRunID']: r for r in C.matrix_rows()}
    auth_rows = {r['SampleRunID']: r for r in csv.DictReader(
        open(AUTH_CSV))}
    auth_json = json.load(open(AUTH_JSON))
    pairs = {r['SampleRunID']: r for r in C.fault_control_pairs()}
    m05_values = {}

    rows = []
    parity_rows = []
    describe_md_by_sid = {}
    for sid in SIDS:
        raw = json.load(open(RAW / ('%s.json' % sid)))
        plan = raw['plan']
        model = plan['model']
        man = C.manifest(sid)
        ver = C.verdict(sid)
        rdir = C.sample_dir(sid)
        orig_cmd = man['command']
        orig = cmd_map(orig_cmd)
        desc_cmd = plan['command']
        desc = cmd_map(desc_cmd)
        readfile = resolve(orig.get('--readfile', ''))
        rsrc = resolve(man.get('rcs_source', ''))
        executed = payload_hash(rsrc)
        executed_basis = 'rcS embedded payload: %s' % rsrc
        installed_guest = ''
        if model == 'M01':
            install = C.REPO / 'configs/fs/mmu_w9.rcS'
            installed_guest = payload_hash(install) or ''
            executed = installed_guest
            executed_basis = (
                'guest /root/mmu_w9 from frozen disk image (disk SHA256 %s); '
                'install script %s embeds %s; rcS actually used only executes '
                '/root/mmu_w9' % (disk_hash(sid), install, installed_guest))
        disk_sha = disk_hash(sid)
        repeat_workload_sha = executed or man.get('workload_sha256', '')
        canonical_sha = man.get('workload_sha256', '')
        workload_divergence = (model == 'M01' and canonical_sha != executed)
        m05 = (model == 'M05')
        auth_rec = (auth_json.get('samples') or {}).get(sid, {})
        w13 = ((auth_json.get('provenance') or {}).get('W13_DECOY_VA')
               or {})
        excel_va = auth_rows[sid].get('M05DecoyVA', '')
        excel_tb = auth_rows[sid].get('M05DecoyTableBase', '')
        if m05:
            m05_values[sid] = {
                'ExcelDecoyVA': excel_va,
                'AuthorityDecoyVA': auth_rec.get('M05DecoyVA'),
                'PilotDecoyVA': auth_rec.get('pilot_decoy_va'),
                'W13DecoyVA': w13.get('value'),
                'PlanDecoyVA': plan.get('m05_decoy_va'),
                'CommandDecoyVA': orig.get('--mmu_m05_decoy_va'),
                'ExcelDecoyTableBase': excel_tb,
                'AuthorityDecoyTableBase': auth_rec.get(
                    'M05DecoyTableBase'),
                'PilotDecoyTableBase': auth_rec.get(
                    'pilot_decoy_table_base'),
                'PlanDecoyTableBase': plan.get('m05_decoy_table_base'),
                'CommandDecoyTableBase': orig.get(
                    '--mmu_m05_decoy_table_base'),
                'Source': man.get('m05_decoy_source'),
            }

        # repeat command: exact original command with only run-scoped paths
        # replaced.  The frozen disk copy must preserve its SHA256.
        rep_cmd = []
        skip_next = False
        for i, tok in enumerate(orig_cmd):
            if skip_next:
                skip_next = False
                continue
            if tok == '--outdir':
                rep_cmd += [tok, '<REPEAT_OUTDIR>']
                skip_next = True
            elif tok == '--readfile':
                rep_cmd += [tok, '<REPEAT_RCS>']
                skip_next = True
            elif tok == '--disk':
                rep_cmd += [tok, '<FROZEN_DISK_COPY>']
                skip_next = True
            elif tok == '--prop_run_id':
                rep_cmd += [tok, '<REPEAT_RUN_ID>']
                skip_next = True
            elif tok == '--prop_sample_run_id':
                rep_cmd += [tok, '<REPEAT_SAMPLE_RUN_ID>']
                skip_next = True
            else:
                rep_cmd.append(tok)

        def check(cid, ok, expected, actual, note='', status=None):
            st = status or ('PASS' if ok else 'FAIL')
            parity_rows.append({
                'SampleRunID': sid, 'CheckID': cid, 'Status': st,
                'Expected': str(expected), 'Actual': str(actual),
                'Note': note})

        check('describe.status', raw.get('status') == 'READY',
              'READY', raw.get('status'))
        check('describe.would_run', raw.get('would_run') is False,
              False, raw.get('would_run'))
        check('describe.parity_ok', raw.get('parity_ok') is True,
              True, raw.get('parity_ok'))
        check('original.parameter_parity',
              man.get('parameter_parity', {}).get('ok') is True, True,
              man.get('parameter_parity', {}).get('ok'))
        check('identity.sample', plan.get('sample_run_id') == sid,
              sid, plan.get('sample_run_id'))
        check('identity.model', plan.get('model') == matrix[sid]['ModelID'],
              matrix[sid]['ModelID'], plan.get('model'))
        check('identity.context',
              plan.get('context') == matrix[sid]['ContextID'],
              matrix[sid]['ContextID'], plan.get('context'))
        check('identity.workload',
              plan.get('workload') == matrix[sid]['WorkloadID'],
              matrix[sid]['WorkloadID'], plan.get('workload'))
        check('target.va', plan.get('target_va') == man.get('target_va'),
              man.get('target_va'), plan.get('target_va'))
        check('target.mode',
              plan.get('target_mode') == man.get('target_mode'),
              man.get('target_mode'), plan.get('target_mode'))
        check('target.n', plan.get('target_n') == man.get('target_n'),
              man.get('target_n'), plan.get('target_n'))
        check('target.eligible_event_index',
              plan.get('eligible_event_index') ==
              man.get('eligible_event_index'),
              man.get('eligible_event_index'),
              plan.get('eligible_event_index'))
        check('binary.gem5_sha256',
              plan.get('gem5_sha256') == man.get('gem5_sha256'),
              man.get('gem5_sha256'), plan.get('gem5_sha256'))
        check('workload.canonical_sha256',
              plan.get('workload_sha256') == man.get('workload_sha256'),
              man.get('workload_sha256'), plan.get('workload_sha256'))
        check('workload.executed_sha256_vs_canonical',
              not workload_divergence, canonical_sha, executed,
              'M01 canonical field differs from the executed guest; '
              'documented divergence, repeat pins the executed build'
              if workload_divergence else '',
              'DOCUMENTED_DIVERGENCE' if workload_divergence else 'PASS')
        check('rcs.source_sha256', rsrc.is_file(), 'exists',
              sha(rsrc) if rsrc.is_file() else 'MISSING')
        check('rcs.readfile_sha256', readfile.is_file(), 'exists',
              sha(readfile) if readfile.is_file() else 'MISSING')
        check('disk.sha256', bool(disk_sha), 'recorded',
              disk_sha)
        check('control.oracle_path',
              plan.get('control_oracle', {}).get('path') ==
              man.get('control_oracle', {}).get('path'),
              man.get('control_oracle', {}).get('path'),
              plan.get('control_oracle', {}).get('path'))
        check('control.oracle_sha256',
              plan.get('control_oracle', {}).get('sha256') ==
              man.get('control_oracle_sha256'),
              man.get('control_oracle_sha256'),
              plan.get('control_oracle', {}).get('sha256'))
        # command-level flags: all --mmu_* and --prop_* must be identical
        orig_flags = {k: v for k, v in orig.items()
                      if k.startswith(('--mmu_', '--prop_'))}
        desc_flags = {k: v for k, v in desc.items()
                      if k.startswith(('--mmu_', '--prop_'))}
        check('command.mmu_prop_flags', orig_flags == desc_flags,
              json.dumps(orig_flags, sort_keys=True),
              json.dumps(desc_flags, sort_keys=True))
        if m05:
            vals = m05_values[sid]
            check('m05.decoy_va_explicit',
                  orig.get('--mmu_m05_decoy_va') is not None,
                  'present', orig.get('--mmu_m05_decoy_va'))
            check('m05.decoy_va_value',
                  int(orig.get('--mmu_m05_decoy_va', '0'), 0) ==
                  M05_DECOY_VA, hex(M05_DECOY_VA),
                  orig.get('--mmu_m05_decoy_va'))
            check('m05.decoy_table_base_explicit',
                  orig.get('--mmu_m05_decoy_table_base') is not None,
                  'present', orig.get('--mmu_m05_decoy_table_base'))
            check('m05.decoy_table_base_value',
                  int(orig.get('--mmu_m05_decoy_table_base', '-1'), 0) == 0,
                  '0', orig.get('--mmu_m05_decoy_table_base'))
            same_va = len({int(x, 0) for x in (
                excel_va, vals['AuthorityDecoyVA'], vals['PilotDecoyVA'],
                vals['W13DecoyVA'], vals['PlanDecoyVA'],
                vals['CommandDecoyVA']) if x not in (None, '')}) == 1
            check('m05.cross_source_decoy_va', same_va,
                  hex(M05_DECOY_VA), json.dumps(vals, sort_keys=True))
            same_tb = len({int(x, 0) for x in (
                excel_tb, vals['AuthorityDecoyTableBase'],
                vals['PilotDecoyTableBase'], vals['PlanDecoyTableBase'],
                vals['CommandDecoyTableBase']) if x not in (None, '')}) == 1
            check('m05.cross_source_table_base', same_tb, '0',
                  json.dumps(vals, sort_keys=True))
            check('m05.no_live_scan_fallback',
                  int(orig.get('--mmu_m05_decoy_va', '0'), 0) != 0,
                  'nonzero explicit VA', orig.get('--mmu_m05_decoy_va'))
        if model == 'M07':
            exact = man.get('target_va')
            check('m07.exact_target_va',
                  plan.get('target_va') == exact, exact,
                  plan.get('target_va'))
            check('m07.page_membership',
                  (plan.get('target_va') & ~0xFFF) == (exact & ~0xFFF),
                  hex(exact & ~0xFFF), hex(plan.get('target_va') & ~0xFFF))
        if model == 'M02':
            check('m02.old_pfn', orig.get('--mmu_m02_old_pfn') == '0x834b2',
                  '0x834b2', orig.get('--mmu_m02_old_pfn'))
        if model == 'M04':
            check('m04.decoy_pfn',
                  orig.get('--mmu_m04_decoy_pfn') == '0x8353c',
                  '0x8353c', orig.get('--mmu_m04_decoy_pfn'))
        if model == 'M03':
            check('m03.candidate_asid',
                  orig.get('--mmu_m03_candidate_asid') == '-1',
                  '-1', orig.get('--mmu_m03_candidate_asid'))
        if model == 'M06':
            check('m06.walk_level',
                  orig.get('--mmu_target_walk_level') == '3', '3',
                  orig.get('--mmu_target_walk_level'))
        if model == 'M08':
            check('m08.pa_xor_mask',
                  orig.get('--mmu_m08_pa_xor_mask') == '0x1000',
                  '0x1000', orig.get('--mmu_m08_pa_xor_mask'))
        if model == 'M05':
            check('m05.target_n', orig.get('--mmu_target_n') == '21',
                  '21', orig.get('--mmu_target_n'))

        row = {
            'RepeatID': 'REP2-MMU-%s-%s-01' % (model, matrix[sid]['ContextID']),
            'RepeatOfSampleRunID': sid,
            'ModelID': model,
            'WorkloadID': matrix[sid]['WorkloadID'],
            'WorkloadVariant': man.get('workload_variant', ''),
            'RunWorkload': man.get('run_workload', ''),
            'ContextID': matrix[sid]['ContextID'],
            'AccessMode': plan.get('target_mode', ''),
            'TargetVAHex': '0x%x' % plan['target_va'],
            'TargetVADec': plan['target_va'],
            'TargetN': plan.get('target_n'),
            'EligibleEventIndex': plan.get('eligible_event_index'),
            'TargetInstruction': plan.get('target_instruction', ''),
            'FrozenBinarySHA256': plan.get('gem5_sha256', ''),
            'MatrixWorkloadSHA256': matrix[sid]['WorkloadSHA256'],
            'CanonicalWorkloadSHA256': canonical_sha,
            'ExecutedGuestBinarySHA256': executed,
            'ExecutedGuestBinaryBasis': executed_basis,
            'RepeatGuestBinarySHA256': repeat_workload_sha,
            'DiskImageSHA256': disk_sha,
            'RuntimeScriptSource': str(rsrc),
            'RuntimeScriptSourceSHA256': sha(rsrc) if rsrc.is_file() else '',
            'RuntimeScriptUsed': str(readfile),
            'RuntimeScriptUsedSHA256':
                sha(readfile) if readfile.is_file() else '',
            'OriginalConfigSHA256': sha(rdir / 'Config' / 'config.ini'),
            'OriginalRunDir': str(rdir),
            'OriginalManifestSHA256': sha(rdir / 'sample_manifest.json'),
            'OriginalVerdictSHA256': sha(rdir / 'Validation' / 'verdict.json'),
            'OriginalTerminalState': ver['TerminalState'],
            'OriginalOracleResult': ver['OracleResult'],
            'OriginalPropagationStatus': ver['PropagationStatus'],
            'OriginalTraceCompleteness': ver['TraceCompleteness'],
            'ControlRunDir': pairs[sid]['ControlRunDir'],
            'ControlOraclePath': pairs[sid]['ControlOraclePath'],
            'ControlOracleSHA256': pairs[sid]['ControlOracleSHA256'],
            'FaultParametersComplete': json.dumps(
                {k: v for k, v in orig.items()
                 if k.startswith('--mmu_')}, sort_keys=True),
            'ModelSpecificParameters': json.dumps(
                {k: v for k, v in orig.items()
                 if k.startswith('--mmu_') and not k.startswith(
                     ('--mmu_fault_model', '--mmu_fault_enable',
                      '--mmu_target_va', '--mmu_target_n',
                      '--mmu_eligible_event_index'))},
                sort_keys=True),
            'M05DecoyVA': orig.get('--mmu_m05_decoy_va', '') if m05 else '',
            'M05DecoyTableBase':
                orig.get('--mmu_m05_decoy_table_base', '') if m05 else '',
            'M05DecoySource': man.get('m05_decoy_source', '') if m05 else '',
            'M05NoLiveScanFallback': bool(
                m05 and int(orig.get('--mmu_m05_decoy_va', '0'), 0) != 0),
            'OriginalCommand': ' '.join(orig_cmd),
            'RepeatCommandTemplate': ' '.join(rep_cmd),
            'RepeatOutputPathTemplate':
                'runs/MMU_FORMAL_CAMPAIGN_20261113/post_campaign_closure/'
                'addendum/repeatability_runs/<RepeatID>/',
            'RepeatAttemptID': 'REP2',
            'RepeatTraceRunID': 'REP2-MMU-%s-%s-01' % (
                model, matrix[sid]['ContextID']),
            'RepeatTraceSampleRunID': 'REP2-MMU-%s-%s-01' % (
                model, matrix[sid]['ContextID']),
            'TraceIdentityPolicy': (
                'repeat trace uses REP2 IDs; the original trace is untouched; '
                'event comparison uses EventID/kind/tick/semantic fields, not '
                'the run_id label'),
            'RepeatRcsPolicy': (
                'copy the original RuntimeScriptUsed byte-for-byte to '
                '<REPEAT_RCS>; do not edit'),
            'RepeatDiskPolicy': (
                'use a byte-identical copy of the original disk.img; its '
                'SHA256 must equal DiskImageSHA256; do not rebuild'),
            'IndependentProcessRequired': True,
            'OneFaultSourceOnly': True,
            'FullTraceRequired': True,
            'MustNotOverwriteOriginal': True,
            'CandidateVerifiedAgainstActualTrace': True,
        }
        rows.append(row)

        # per-sample describe markdown
        checks = [p for p in parity_rows if p['SampleRunID'] == sid]
        failed = [p for p in checks if p['Status'] == 'FAIL']
        md = ['# Read-Only Describe: %s\n\n' % sid,
              'Status: `%s`; would_run=`%s`; parity_ok=`%s`.\n\n' % (
                  raw.get('status'), raw.get('would_run'),
                  raw.get('parity_ok')),
              '## Identity and target\n\n',
              '| Field | Value |\n|---|---|\n',
              '| Model | %s |\n' % model,
              '| Workload / variant | %s / %s |\n' % (
                  matrix[sid]['WorkloadID'], man.get('workload_variant')),
              '| Context | %s |\n' % matrix[sid]['ContextID'],
              '| Target VA | `0x%x` |\n' % plan['target_va'],
              '| Target mode / n / ordinal | %s / %s / %s |\n' % (
                  plan.get('target_mode'), plan.get('target_n'),
                  plan.get('eligible_event_index')),
              '| Target instruction | %s |\n' % plan.get(
                  'target_instruction', ''),
              '| Frozen gem5 SHA256 | `%s` |\n\n' % plan.get('gem5_sha256'),
              '## Executed guest identity (corrected)\n\n',
              '- Canonical manifest workload hash: `%s`\n' % canonical_sha,
              '- Executed guest binary hash: `%s`\n' % executed,
              '- Basis: %s\n' % executed_basis,
              '- Frozen disk image SHA256: `%s`\n' % disk_sha,
              '- Workload identity divergence: **%s**\n\n' % (
                  'YES - documented, repeat uses executed hash'
                  if workload_divergence else 'NO'),
              '## Complete original gem5 command\n\n```bash\n%s\n```\n\n' % (
                  ' '.join(orig_cmd)),
              '## Repeat command template\n\n```bash\n%s\n```\n\n' % (
                  ' '.join(rep_cmd)),
              '## Fault parameters (verbatim from the original command)\n\n',
              '| Flag | Value |\n|---|---|\n']
        for k, v in sorted(orig.items()):
            if k.startswith('--mmu_'):
                md.append('| `%s` | `%s` |\n' % (k, v))
        if m05:
            md.append('\n## M05 decoy parity\n\n')
            md.append('| Source | Decoy VA | Table base |\n|---|---|---|\n')
            vals = m05_values[sid]
            md.append('| Excel | `%s` | `%s` |\n' % (
                vals['ExcelDecoyVA'], vals['ExcelDecoyTableBase']))
            md.append('| Authority v3.0.2 | `%s` | `%s` |\n' % (
                vals['AuthorityDecoyVA'], vals['AuthorityDecoyTableBase']))
            md.append('| Final F1 pilot | `%s` | `%s` |\n' % (
                vals['PilotDecoyVA'], vals['PilotDecoyTableBase']))
            md.append('| W13_DECOY_VA symbol | `%s` | - |\n' %
                      vals['W13DecoyVA'])
            md.append('| Describe plan | `%s` | `%s` |\n' % (
                vals['PlanDecoyVA'], vals['PlanDecoyTableBase']))
            md.append('| Original command | `%s` | `%s` |\n' % (
                vals['CommandDecoyVA'], vals['CommandDecoyTableBase']))
            md.append('\nLive-scan fallback: **FORBIDDEN**; repeat must pass '
                      'both explicit flags.\n')
        md.append('\n## Control relation\n\n')
        md.append('- Fault control dir: `%s`\n' % pairs[sid]['ControlRunDir'])
        md.append('- Oracle: `%s`\n' % pairs[sid]['ControlOraclePath'])
        md.append('- Oracle SHA256: `%s`\n\n' % pairs[sid][
            'ControlOracleSHA256'])
        md.append('## Parity checks\n\n')
        md.append('| Check | Status | Expected | Actual |\n|---|---|---|---|\n')
        for p in checks:
            md.append('| %s | %s | `%s` | `%s` |\n' % (
                p['CheckID'], p['Status'], p['Expected'][:120],
                p['Actual'][:120]))
        md.append('\nResult: **%s** (%d checks, %d failures).\n' % (
            'PASS' if not failed else 'FAIL', len(checks), len(failed)))
        describe_md_by_sid[sid] = ''.join(md)

    # write describe docs
    for sid, text in describe_md_by_sid.items():
        (DESC / ('%s.md' % sid)).write_text(text)
    C.write_csv(DESC / 'Describe_Parity_Check.csv', parity_rows,
                ['SampleRunID', 'CheckID', 'Status', 'Expected', 'Actual',
                 'Note'])
    C.write_json(DESC / 'Describe_Parity_Check.json', parity_rows)
    C.write_csv(REPV2 / 'MMU_Repeatability_Matrix_v2.csv', rows)
    C.write_json(REPV2 / 'MMU_Repeatability_Validation_Plan_v2.json', {
        'plan_version': 'MMU-REPEAT-PLAN-v2',
        'corrections': [
            'M01/R01 repeat workload identity uses the executed guest binary '
            '4f3ddbf2... (disk /root/mmu_w9 + install payload), not the '
            'canonical mmu_rev build ec525687...',
            'M05/R05 repeat records explicit --mmu_m05_decoy_va 0x4010200000 '
            'and --mmu_m05_decoy_table_base 0; live-scan fallback forbidden',
            'all 10 rows carry the complete verbatim --mmu_* parameter set '
            'and the full original/repeat command',
        ],
        'no_experiment_started': True,
        'status': 'CORRECTED_DESIGN_READY_FOR_RESEARCHER_APPROVAL',
        'repeats': rows,
    })
    _write_xlsx(rows, parity_rows, m05_values)
    _write_md(rows, parity_rows, m05_values)
    failures = [p for p in parity_rows if p['Status'] == 'FAIL']
    print(json.dumps({
        'rows': len(rows),
        'parity_checks': len(parity_rows),
        'parity_failures': len(failures),
        'm05': m05_values,
        'm01_executed': rows[0]['ExecutedGuestBinarySHA256'],
        'm01_canonical': rows[0]['CanonicalWorkloadSHA256'],
        'describe_status': raw.get('status'),
    }, indent=1))
    return 1 if failures else 0


def _write_xlsx(rows, parity, m05_values):
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Matrix_v2'
    headers = list(rows[0].keys())
    ws.append(headers)
    ws['A1'].font = Font(bold=True)
    for r in rows:
        ws.append([r.get(h, '') for h in headers])
    ws.freeze_panes = 'B2'
    ws2 = wb.create_sheet('Parity_Checks')
    ph = ['SampleRunID', 'CheckID', 'Status', 'Expected', 'Actual', 'Note']
    ws2.append(ph)
    for r in parity:
        ws2.append([r.get(h, '') for h in ph])
    ws2.freeze_panes = 'B2'
    ws3 = wb.create_sheet('M05_Decoy')
    ws3.append(['SampleRunID'] + list(next(iter(m05_values.values())).keys()))
    for sid, vals in m05_values.items():
        ws3.append([sid] + [vals[k] for k in vals])
    wb.save(REPV2 / 'MMU_Repeatability_Matrix_v2.xlsx')


def _write_md(rows, parity, m05_values):
    md = ['# Corrected 10-Sample Repeatability Design (v2)\n\n',
          'Status: `CORRECTED_DESIGN_READY_FOR_RESEARCHER_APPROVAL`. '
          'No gem5 experiment was started.\n\n',
          '## Corrections\n\n',
          '1. **M01/R01 executed guest**: the formal matrix records the '
          'canonical mmu_rev build `ec525687...`, but the guest actually '
          'executed `/root/mmu_w9` from the frozen disk (install payload '
          '`4f3ddbf2...`). The repeat row now pins `4f3ddbf2...` plus the '
          'frozen disk SHA256; the original matrix/manifest are untouched.\n',
          '2. **M05/R05 decoy**: the repeat row now records explicit '
          '`--mmu_m05_decoy_va 0x4010200000` and '
          '`--mmu_m05_decoy_table_base 0`, cross-checked against Excel, '
          'authority v3.0.2, final F1 pilot and `W13_DECOY_VA`. Live-scan '
          'fallback is forbidden.\n',
          '3. All 10 rows carry the complete verbatim `--mmu_*` parameter '
          'set, full original command and a repeat command template. The '
          'repeat copies the original rcS byte-for-byte and uses a '
          'byte-identical copy of the frozen disk image (SHA256 pinned); no '
          'rebuild is allowed. Repeat traces use new `REP2-*` run IDs; the '
          'original trace is never overwritten.\n\n',
          '## Parity / describe result\n\n',
          '| Metric | Value |\n|---|---|\n',
          '| Read-only describes | 10/10 `READY` |\n',
          '| Runner parity_ok | 10/10 true |\n',
          '| Independent checks | %d |\n' % len(parity),
          '| Failures | %d |\n\n' % len(
              [p for p in parity if p['Status'] == 'FAIL']),
          '## Matrix\n\n',
          '| RepeatID | Original | Executed guest SHA256 | Disk SHA256 | '
          'M05 decoy VA / table base |\n|---|---|---|---|---|\n']
    for r in rows:
        md.append('| %s | %s | `%s` | `%s` | %s / %s |\n' % (
            r['RepeatID'], r['RepeatOfSampleRunID'],
            r['ExecutedGuestBinarySHA256'][:16] + '...',
            r['DiskImageSHA256'][:16] + '...',
            r['M05DecoyVA'] or '-', r['M05DecoyTableBase'] or '-'))
    md.append('\n## M05 decoy cross-source evidence\n\n')
    for sid, v in m05_values.items():
        md.append('### %s\n\n' % sid)
        md.append('| Source | Decoy VA | Table base |\n|---|---|---|\n')
        md.append('| Excel | `%s` | `%s` |\n' % (
            v['ExcelDecoyVA'], v['ExcelDecoyTableBase']))
        md.append('| Authority | `%s` | `%s` |\n' % (
            v['AuthorityDecoyVA'], v['AuthorityDecoyTableBase']))
        md.append('| Pilot | `%s` | `%s` |\n' % (
            v['PilotDecoyVA'], v['PilotDecoyTableBase']))
        md.append('| W13 symbol | `%s` | - |\n' % v['W13DecoyVA'])
        md.append('| Plan | `%s` | `%s` |\n' % (
            v['PlanDecoyVA'], v['PlanDecoyTableBase']))
        md.append('| Command | `%s` | `%s` |\n\n' % (
            v['CommandDecoyVA'], v['CommandDecoyTableBase']))
    md.append('## Stop condition\n\n')
    md.append('No repeat was executed. The 10 runs require researcher '
              'approval.\n')
    (REPV2 / 'MMU_Repeatability_Validation_Plan_v2.md').write_text(''.join(md))


if __name__ == '__main__':
    sys.exit(main())
