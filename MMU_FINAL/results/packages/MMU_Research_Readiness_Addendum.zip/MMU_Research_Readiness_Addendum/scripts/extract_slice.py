#!/usr/bin/env python3
"""Extract an event slice from an original gem5 prop_evt trace.

Read-only: opens the trace gzip, copies matching events verbatim (only
non-empty key=value fields are kept), and never synthesizes an event.

Usage:
  extract_slice.py --trace T.gz --event-ids 1,2,3 --out-json slice.json
  extract_slice.py --trace T.gz --event-ids ids.json --out-csv slice.csv
"""
import argparse
import csv
import gzip
import json
import os
import sys


def parse_evt_line(line):
    body = line[len('PROP-EVT: '):].rstrip('\n')
    out = {}
    for token in body.split(' '):
        if '=' in token:
            k, v = token.split('=', 1)
            out[k] = v
    return out


def load_ids(arg):
    if os.path.isfile(arg):
        data = json.load(open(arg))
        if isinstance(data, dict):
            data = data.get('event_ids', [])
        return sorted({int(x) for x in data})
    return sorted({int(x) for x in arg.split(',') if str(x).strip()})


def extract(trace_path, wanted):
    wanted = set(int(x) for x in wanted)
    events = []
    total = 0
    with gzip.open(trace_path, 'rt', errors='replace') as fh:
        for line in fh:
            if not line.startswith('PROP-EVT: '):
                continue
            total += 1
            ev = parse_evt_line(line)
            try:
                eid = int(ev.get('event_id', '-1'))
            except ValueError:
                continue
            if eid in wanted:
                events.append({k: v for k, v in ev.items() if v != ''})
    events.sort(key=lambda e: int(e['event_id']))
    return {
        'trace_path': os.path.abspath(trace_path),
        'trace_event_count': total,
        'requested_event_ids': sorted(wanted),
        'found_event_ids': [int(e['event_id']) for e in events],
        'missing_event_ids': sorted(wanted - {int(e['event_id'])
                                              for e in events}),
        'fabricated_event_count': 0,
        'events': events,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--trace', required=True)
    ap.add_argument('--event-ids', required=True)
    ap.add_argument('--out-json')
    ap.add_argument('--out-csv')
    args = ap.parse_args()
    result = extract(args.trace, load_ids(args.event_ids))
    if args.out_json:
        with open(args.out_json, 'w') as fh:
            json.dump(result, fh, indent=2, sort_keys=True)
            fh.write('\n')
    if args.out_csv:
        fields = []
        for ev in result['events']:
            for k in ev:
                if k not in fields:
                    fields.append(k)
        with open(args.out_csv, 'w', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=fields, extrasaction='ignore')
            w.writeheader()
            for ev in result['events']:
                w.writerow(ev)
    print(json.dumps({k: result[k] for k in (
        'trace_path', 'trace_event_count', 'requested_event_ids',
        'found_event_ids', 'missing_event_ids',
        'fabricated_event_count')}, indent=2))


if __name__ == '__main__':
    main()
