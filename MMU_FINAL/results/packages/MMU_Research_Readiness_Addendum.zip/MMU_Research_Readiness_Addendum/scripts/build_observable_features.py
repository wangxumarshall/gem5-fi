#!/usr/bin/env python3
"""Addendum task 2 - de-labelled observable diagnostic feature view.

Ground-truth model IDs, fault origin/site/field and injector-only identifiers
are never diagnostic inputs.  TerminalState/OracleResult/ManifestationType are
kept only as labels or software-visible symptoms.  Every field is classified by
observability tier; unproven production availability is UNKNOWN.
"""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'
OUT = ADD / 'observable_features'


def parse_line(line):
    return C.parse_kv_line(line)


def guest_values(ver):
    line = (ver.get('Details', {}).get('oracle') or {}).get('line', '')
    o = parse_line(line)
    expected = None
    basis = ''
    if 'new_marker' in o:
        expected = o.get('new_marker'); basis = 'new_marker'
    elif 'target_after' in o:
        expected = o.get('target_after'); basis = 'target_after'
    elif 'sentinel' in o:
        expected = o.get('sentinel'); basis = 'sentinel'
    elif 'expect' in o:
        expected = o.get('expect'); basis = 'expect'
    elif 'expected' in o:
        expected = o.get('expected'); basis = 'expected'
    observed = o.get('observed') or o.get('target_observed')
    mismatch = None
    if expected is not None and observed is not None:
        mismatch = str(expected).lower() != str(observed).lower()
    if 'neighbor_alias_observed' in o and 'neighbor_before' in o:
        nb = (o.get('neighbor_alias_observed') != o.get('neighbor_before'))
        mismatch = bool(mismatch) or nb
        if nb:
            basis += '+neighbor_alias'
    ctl = (ver.get('Details', {}).get('control_oracle') or {})
    c = parse_line(ctl.get('line', ''))
    unexpected_success = (
        c.get('signal') not in (None, '', '0') and
        o.get('signal') in ('0', '') and
        o.get('result') == 'FAIL')
    return {
        'GuestSignal': o.get('signal', ''),
        'GuestSICode': o.get('si_code', ''),
        'GuestFaultClass': o.get('fault_class', ''),
        'GuestObservedValue': observed or '',
        'GuestExpectedValue': expected or '',
        'GuestValueMismatch': mismatch,
        'GuestValueBasis': basis,
        'GuestResult': o.get('result', ''),
        'ControlSignal': c.get('signal', ''),
        'ControlResult': c.get('result', ''),
        'GuestUnexpectedSuccess': unexpected_success,
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    fd = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    labels = {r['SampleRunID']: r for r in csv.DictReader(
        open(ADD / 'semantic_labels' / 'MMU_Manifestation_Labels_v2.csv'))}
    rows = []
    for f in fd['samples']:
        sid = f['identity']['SampleRunID']
        i, o, a, tc = (f['identity'], f['fault_origin'],
                       f['activation'], f['translation_effect'])
        term = f['terminal']
        ver = C.verdict(sid)
        ch = C.chain(sid)
        kinds = [e['Kind'] for e in ch['Events']]
        fault_site = o['InjectionLocation']['TraceFaultSite']
        # path class from observable event kinds/state, never from model ID
        if 'tlbi_suppressed' in kinds:
            path_class = 'TLBI_SUPPRESSION'
        elif 'refill_pfn_corrupt' in kinds:
            path_class = 'PTW_REFILL'
        elif fault_site == 'tlb_lookup_miss_false_hit':
            path_class = 'FOREIGN_ASID_FALSE_HIT'
        elif 'tlb_entry_lineage' in kinds:
            path_class = 'RESIDENT_HIT'
        elif fault_site == 'ptw_insertPartialTableEntry':
            path_class = 'PTW_PARTIAL_WALK'
        elif fault_site == 'ptw_doLongDescriptor_valid_clear':
            path_class = 'PTW_PTE_DECODE'
        elif (a.get('FaultStateBefore') or {}).get('permission_before') or \
                (a.get('FaultStateBefore') or {}).get('permission_after'):
            path_class = 'PERMISSION_CHECK'
        elif (a.get('FaultStateBefore') or {}).get('request_pa_before') or \
                (a.get('FaultStateBefore') or {}).get('request_pa_after'):
            path_class = 'POST_TRANSLATION_PA'
        else:
            path_class = 'OTHER'
        state_keys = sorted(set(a.get('FaultStateBefore', {})) |
                            set(a.get('FaultStateAfter', {})))
        refill_changed = (
            'refill_pfn_corrupt' in kinds or
            (tc.get('OldPFN') and tc.get('NewPFN') and
             tc.get('OldPFN') != tc.get('NewPFN') and
             a.get('ActivationKind') == 'refill_pfn_corrupt'))
        descriptor_changed = bool(
            tc.get('DescriptorBefore') and tc.get('DescriptorAfter') and
            tc.get('DescriptorBefore') != tc.get('DescriptorAfter'))
        permission_inverted = (
            str(tc.get('PermissionBefore')).lower() in ('false', '0') and
            str(tc.get('PermissionAfter')).lower() in ('true', '1'))
        request_pa_changed = bool(
            tc.get('RequestPABefore') and tc.get('RequestPAAfter') and
            tc.get('RequestPABefore') != tc.get('RequestPAAfter'))
        next_table_changed = bool(
            tc.get('NextTablePABefore') and tc.get('NextTablePAAfter') and
            tc.get('NextTablePABefore') != tc.get('NextTablePAAfter'))
        foreign_asid = bool(
            tc.get('CandidateASID') and a.get('ASID') and
            str(tc.get('CandidateASID')) != str(a.get('ASID')))
        lineage = 'tlb_entry_lineage' in kinds
        squash = (term['SquashStatus'] == 'SQUASHED' or
                  any(e.get('SquashStatus') == 'SQUASH'
                      for e in ch['Events']))
        consumed = 'fault_state_consumed' in kinds
        exception = labels[sid]['ExceptionDelivered_TraceEvidence'] in (
            True, 'True', 'true')
        exc_class = ''
        for e in ch['Events']:
            if e['Kind'] == 'fault_result_propagated':
                exc_class = (e.get('ExtraFields') or {}).get(
                    'exception_class', '')
        g = guest_values(ver)
        row = {
            'SampleRunID': sid,
            'ContextID': i['ContextID'],
            'GroundTruthModelID_LABEL': i['ModelID'],
            'TerminalState_LABEL': ver['TerminalState'],
            'OracleResult_LABEL': ver['OracleResult'],
            'ManifestationType_v2_LABEL': labels[sid]['Primary_v2'],
            'AccessMode_SW': a.get('AccessMode', ''),
            'TargetVA_SW': o.get('TargetVA', ''),
            'ActivationEventKind_SIM': a.get('ActivationKind', ''),
            'TLBInstance_SIM': o.get('TLBInstance', ''),
            'WalkLevel_SIM': a.get('WalkLevel', ''),
            'UpstreamPathClass_SIM': path_class,
            'EventKindSequence_SIM': '|'.join(kinds),
            'StateFieldsPresent_SIM': ','.join(state_keys),
            'RefillPFNChanged_SIM': refill_changed,
            'DescriptorChanged_SIM': descriptor_changed,
            'PermissionDecisionInverted_SIM': permission_inverted,
            'RequestPAChanged_SIM': request_pa_changed,
            'NextTablePAChanged_SIM': next_table_changed,
            'ForeignASIDCandidate_SIM': foreign_asid,
            'EntryLineagePresent_SIM': lineage,
            'SquashObserved_SIM': squash,
            'TerminalSquash_LABEL': ver['TerminalState'] == 'SQUASHED',
            'FaultStateConsumed_SIM': consumed,
            'ExceptionDelivered_POT_SW': exception,
            'ExceptionClass_POT_SW': exc_class,
            'GuestSignal_SW': g['GuestSignal'],
            'GuestSICode_SW': g['GuestSICode'],
            'GuestFaultClass_SW': g['GuestFaultClass'],
            'GuestObservedValue_SW': g['GuestObservedValue'],
            'GuestExpectedValue_SW': g['GuestExpectedValue'],
            'GuestValueMismatch_SW': g['GuestValueMismatch'],
            'GuestUnexpectedSuccess_SW': g['GuestUnexpectedSuccess'],
            'ProductionWrongData_SYMPTOM': bool(g['GuestValueMismatch']),
            'ProductionUnexpectedSuccess_SYMPTOM':
                g['GuestUnexpectedSuccess'],
            'ProductionException_SYMPTOM':
                bool(exception) or g['GuestSignal'] not in ('', '0'),
            'ProductionAttributionProven': False,
            'ObservabilityLimitations': (
                'SIMULATOR_ONLY: event kinds, TLB instance/entry identity, '
                'walk level/PTE/PFN/request PA, squash status, permission '
                'decision inversion. PRODUCTION availability of these fields '
                'is UNKNOWN and must not be assumed. Labels are not inputs.'),
        }
        rows.append(row)
    fields = list(rows[0].keys())
    C.write_csv(OUT / 'MMU_Diagnostic_Observable_Features.csv', rows, fields)
    C.write_json(OUT / 'MMU_Diagnostic_Observable_Features.json', {
        'version': 1,
        'note': (
            'De-labelled view. GroundTruthModelID_LABEL, TerminalState_LABEL, '
            'OracleResult_LABEL and ManifestationType_v2_LABEL are labels / '
            'symptoms, never inputs. FaultModelID, FaultOrigin, '
            'InjectionLocation and FaultField are excluded. No classifier '
            'accuracy is claimed.'),
        'observability_tiers': [
            'SIMULATOR_ONLY', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
            'PRODUCTION_AVAILABLE', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
            'LABEL_OR_SYMPTOM_ONLY', 'FORBIDDEN_AS_INPUT'],
        'rows': rows,
    })
    _classification()
    _confusability(rows)
    _readme()
    print(json.dumps({
        'rows': len(rows),
        'columns': len(fields),
        'label_columns': [c for c in fields if c.endswith('_LABEL')],
        'simulator_only_inputs': [c for c in fields if c.endswith('_SIM')],
        'production_symptoms': [c for c in fields
                                if c.endswith('_SYMPTOM')],
    }, indent=1))


def _classification():
    catalog = [
        ('FaultModelID', 'FORBIDDEN_AS_INPUT',
         'injector ground truth; directly names the model', False),
        ('FaultOrigin', 'FORBIDDEN_AS_INPUT',
         'injector ground truth / mutation site', False),
        ('InjectionLocation', 'FORBIDDEN_AS_INPUT',
         'source file/function/site known only to the injector', False),
        ('FaultField', 'FORBIDDEN_AS_INPUT',
         'mutated field known only to the injector', False),
        ('TerminalState', 'LABEL_OR_SYMPTOM_ONLY',
         'frozen result label, not an origin feature', False),
        ('OracleResult', 'LABEL_OR_SYMPTOM_ONLY',
         'workload oracle label', False),
        ('ManifestationType', 'LABEL_OR_SYMPTOM_ONLY',
         'audit classification label', False),
        ('TerminalSquash', 'LABEL_OR_SYMPTOM_ONLY',
         'terminal result label; not an origin feature', False),
        ('AccessMode', 'PRODUCTION_AVAILABLE',
         'software knows the access it issued', True),
        ('TargetVA', 'PRODUCTION_AVAILABLE',
         'software knows the virtual address it accessed', True),
        ('GuestSignal', 'PRODUCTION_AVAILABLE',
         'a real process can receive SIGSEGV/SIGBUS', True),
        ('GuestSICode', 'PRODUCTION_AVAILABLE',
         'si_code is visible to a real process', True),
        ('GuestFaultClass', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'fault class mapping to ARM ESR/FSC is plausible but unproven here',
         True),
        ('GuestObservedValue', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'requires an application-level expected-value oracle', True),
        ('GuestExpectedValue', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'oracle-dependent; not always available', True),
        ('GuestValueMismatch', 'PRODUCTION_AVAILABLE',
         'with an oracle, a wrong value is a production symptom', True),
        ('GuestUnexpectedSuccess', 'PRODUCTION_AVAILABLE',
         'an access that should fault but returns normally is visible', True),
        ('ExceptionDelivered', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'architectural exception delivery can be software-visible; the trace '
         'event itself is simulator instrumentation', True),
        ('ExceptionClass', 'POTENTIALLY_SOFTWARE_OBSERVABLE',
         'ESR/FSC-like class may be visible; exact hardware mapping UNKNOWN',
         True),
        ('ActivationEventKind', 'SIMULATOR_ONLY',
         'injector trace event name; no production equivalent', False),
        ('TLBInstance', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'DTLB/ITLB/L2/walk-cache internals are not proven software-visible',
         False),
        ('TLBEntryID', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'entry identity is simulator instrumentation', False),
        ('TLBEntryGeneration', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'generation/version is simulator instrumentation', False),
        ('WalkLevel', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'PTW level is not proven software-visible', False),
        ('UpstreamPathClass', 'SIMULATOR_ONLY',
         'derived from trace event kinds; not a production signal', False),
        ('EventKindSequence', 'SIMULATOR_ONLY',
         'trace instrumentation sequence', False),
        ('RefillPFNChanged', 'SIMULATOR_ONLY',
         'PTW refill internals; production observability UNKNOWN', False),
        ('DescriptorChanged', 'SIMULATOR_ONLY',
         'PTE descriptor before/after is simulator instrumentation', False),
        ('PermissionDecisionInverted', 'SIMULATOR_ONLY',
         'internal permission decision; production observability UNKNOWN',
         False),
        ('RequestPAChanged', 'SIMULATOR_ONLY',
         'final request PA is simulator instrumentation', False),
        ('NextTablePAChanged', 'SIMULATOR_ONLY',
         'intermediate table pointer is simulator instrumentation', False),
        ('ForeignASIDCandidate', 'SIMULATOR_ONLY',
         'ASID comparator internals are not proven software-visible', False),
        ('EntryLineagePresent', 'SIMULATOR_ONLY',
         'TLB entry lineage is simulator instrumentation', False),
        ('SquashObserved', 'SIMULATOR_ONLY',
         'pipeline squash is simulator instrumentation', False),
        ('FaultStateConsumed', 'SIMULATOR_ONLY',
         'injector lifecycle event', False),
        ('PerformanceCounters', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'not collected in this campaign; availability/attribution unproven',
         False),
        ('TLBEntryPFN', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'PFN values are not software-visible on real hardware in general',
         False),
        ('PTEBeforeAfter', 'UNKNOWN_PRODUCTION_OBSERVABILITY',
         'requires privileged page-table inspection; not generally available',
         False),
    ]
    rows = [{
        'Feature': f, 'Category': c, 'Rationale': r,
        'UsableAsDiagnosticInput': 'YES' if u else 'NO',
        'ProductionAvailability': (
            'YES' if c == 'PRODUCTION_AVAILABLE' else
            'POTENTIAL' if c == 'POTENTIALLY_SOFTWARE_OBSERVABLE' else
            'UNKNOWN' if c in ('UNKNOWN_PRODUCTION_OBSERVABILITY',) else
            'NO'),
    } for f, c, r, u in catalog]
    C.write_csv(OUT / 'Feature_Observability_Classification.csv', rows)


def _confusability(rows):
    by_model = {}
    for r in rows:
        by_model.setdefault(r['GroundTruthModelID_LABEL'], []).append(r)
    md = ['# Model-ID-Free Confusability Analysis\n\n',
          'This is a feature-availability analysis, **not** a trained '
          'classifier. No accuracy number is claimed. Ground-truth model IDs '
          'are used only to group the evidence below.\n\n',
          '## M02 / M04 / M08 (all can produce wrong data or wrong PA)\n\n',
          '| Model | RefillPFNChanged | EntryLineage | RequestPAChanged | '
          'PTW upstream | SquashObserved | Guest wrong value |\n'
          '|---|---|---|---|---|---|---|\n']
    for m in ('M02', 'M04', 'M08'):
        rs = by_model.get(m, [])
        def frac(key):
            n = sum(1 for r in rs if r[key] in (True, 'True', 'true'))
            return '%d/%d' % (n, len(rs))
        pt = sum(1 for r in rs if 'PTW' in r['UpstreamPathClass_SIM'])
        md.append('| %s | %s | %s | %s | %d/%d | %s | %s |\n' % (
            m, frac('RefillPFNChanged_SIM'), frac('EntryLineagePresent_SIM'),
            frac('RequestPAChanged_SIM'), pt, len(rs),
            frac('SquashObserved_SIM'), frac('GuestValueMismatch_SW')))
    md.append('\n**Model-free separators when trace events are available:**\n\n')
    md.append('- `RefillPFNChanged_SIM=True` and PTW upstream -> M02-like '
              'refill-PFN corruption.\n')
    md.append('- `EntryLineagePresent_SIM=True` with no PTW upstream -> '
              'M04-like resident-entry substitution.\n')
    md.append('- `RequestPAChanged_SIM=True`, `RefillPFNChanged_SIM=False`, '
              '`EntryLineagePresent_SIM=False` -> M08-like final-PA '
              'corruption.\n\n')
    md.append('**Non-separable conditions:** if only `GuestValueMismatch_SW` '
              'or the production symptom `wrong data value` is available, '
              'these three are indistinguishable. If the trace lacks the '
              'refill/lineage/request-PA events, no model-free separation is '
              'possible. Production attribution is **UNKNOWN**.\n\n')
    md.append('## M01 / M03 (stale vs foreign TLB entry)\n\n')
    md.append('| Model | TLBI suppression path | ForeignASIDCandidate | '
              'TerminalSquash label | Guest wrong value |\n'
              '|---|---|---|---|---|\n')
    for m in ('M01', 'M03'):
        rs = by_model.get(m, [])
        def frac(key):
            n = sum(1 for r in rs if r[key] in (True, 'True', 'true'))
            return '%d/%d' % (n, len(rs))
        tlbi = sum(1 for r in rs
                   if r['UpstreamPathClass_SIM'] == 'TLBI_SUPPRESSION')
        md.append('| %s | %d/%d | %s | %s | %s |\n' % (
            m, tlbi, len(rs), frac('ForeignASIDCandidate_SIM'),
            frac('TerminalSquash_LABEL'), frac('GuestValueMismatch_SW')))
    md.append('\n**Model-free separators when trace events are available:**\n\n')
    md.append('- `UpstreamPathClass_SIM=TLBI_SUPPRESSION` and no foreign '
              'ASID candidate -> M01-like stale-translation path.\n')
    md.append('- `ForeignASIDCandidate_SIM=True` -> M03-like foreign-ASID '
              'false match; M03 may squash (detected) or be consumed by '
              'Execute (SDC).\n\n')
    md.append('**Non-separable conditions:** with only the production symptom '
              '"stale data after correct maintenance", both are possible. '
              'Without TLBI match/suppression or candidate-ASID evidence, no '
              'model-free separation is possible. Production availability of '
              'those events is **UNKNOWN**.\n\n')
    md.append('## What is actually production-available\n\n')
    md.append('Only generic software symptoms are proven available: wrong '
              'data value (with an oracle), unexpected access success, and '
              'SIGSEGV/exception class. None of the injector-internal TLB/PTW '
              'fields is proven production-observable; they are marked '
              '`UNKNOWN_PRODUCTION_OBSERVABILITY` or `SIMULATOR_ONLY`.\n\n')
    md.append('## Scope\n\n')
    md.append('No classifier was trained. This document only states which '
              'features separate the confusable pairs when simulator trace '
              'events are available, and where separation is impossible with '
              'production signals alone.\n')
    (OUT / 'Confusability_Analysis_NoModelID.md').write_text(''.join(md))


def _readme():
    md = '''# De-labelled Observable Feature View

`MMU_Diagnostic_Observable_Features.csv/json` is a diagnostic view built from
the frozen feature library. It deliberately excludes:

- `FaultModelID`
- `FaultOrigin` / `InjectionLocation` / `FaultField`
- any injector-only identifier used to infer the model

`TerminalState`, `OracleResult` and `ManifestationType` are retained only with
`_LABEL` suffix; they are labels or software-visible symptoms, never
unconditional origin features.

## Observability tiers

- `SIMULATOR_ONLY`: trace instrumentation; no proven production equivalent.
- `POTENTIALLY_SOFTWARE_OBSERVABLE`: an architectural/software signal is
  plausible, but this campaign did not prove real-hardware availability.
- `PRODUCTION_AVAILABLE`: generic software-visible symptoms (wrong value with
  an oracle, unexpected success, SIGSEGV).
- `UNKNOWN_PRODUCTION_OBSERVABILITY`: cannot be proven available; must not be
  assumed.

`Feature_Observability_Classification.csv` lists every field and its tier.

## Important limitation

No diagnostic classifier was trained and no accuracy is claimed. The
confusability analysis shows when model-free separation is possible from
simulator events and when it is impossible from production signals alone.

See `Confusability_Analysis_NoModelID.md`.
'''
    (OUT / 'README.md').write_text(md)


if __name__ == '__main__':
    main()
