#!/usr/bin/env python3
"""Addendum task 3 - versioned secondary semantic labels (v2).

Corrections only; original TerminalState / OracleResult / feature library v1
are never overwritten.
"""
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'
OUT = ADD / 'semantic_labels'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    fd = json.load(open(C.FEAT / 'MMU_Diagnostic_Feature_Library.json'))
    rows = []
    for f in fd['samples']:
        sid = f['identity']['SampleRunID']
        model = f['identity']['ModelID']
        ctx = f['identity']['ContextID']
        ver = C.verdict(sid)
        ch = C.chain(sid)
        kinds = [e['Kind'] for e in ch['Events']]
        v1 = f['terminal']
        exception = kinds.count('exception_delivery')
        result_prop = kinds.count('fault_result_propagated')
        state_consumed = kinds.count('fault_state_consumed')
        squash = kinds.count('squash')
        primary2 = v1['ManifestationTypePrimary']
        secondary2 = v1['ManifestationTypeSecondary']
        detection2 = v1['DetectionStatus']
        masking2 = v1['MaskingStatus']
        correction = 'UNCHANGED'
        limitation = ''
        exception_flag = bool(exception)
        if model == 'M03' and ctx in ('R01', 'R02', 'R03', 'R04'):
            # No exception_delivery and no fault_result_propagated exist in
            # these traces; only squash.  DETECTED_EXCEPTION was unsupported.
            assert exception == 0 and result_prop == 0 and squash > 0
            primary2 = 'SQUASHED'
            secondary2 = 'SQUASH_BEFORE_ARCH_UPDATE'
            detection2 = 'SQUASHED_BEFORE_COMMIT'
            masking2 = 'NOT_MASKED_SQUASHED'
            correction = (
                'REMOVED_DETECTED_EXCEPTION: trace has squash only; '
                'exception_delivery=0, fault_result_propagated=0')
        elif model == 'M06':
            assert exception > 0 and result_prop > 0 and state_consumed > 0
            primary2 = 'DETECTED_CONTAINED'
            secondary2 = 'TRANSLATION_FAULT_DETECTED_AND_CONTAINED'
            detection2 = 'DETECTED_AND_CONTAINED'
            masking2 = 'CONTAINED_BY_EXCEPTION_DELIVERY'
            correction = (
                'DETECTED_CONTAINED is not generic MASKED: '
                'fault_state_consumed=%d, fault_result_propagated=%d, '
                'exception_delivery=%d; PTE memory unchanged; guest observes '
                'the correct sentinel' % (state_consumed, result_prop,
                                          exception))
        elif model == 'M07' and ctx == 'R02':
            limitation = (
                'NO_PERMISSION_EVAL_JOINED_TO_ACTIVATION_TRANSLATION_ID_7; '
                'nearest same-VA deny is event 345 on translation_id=5 '
                '(tick delta -2331), not associated by the frozen validator; '
                'permission_before=false is recorded by mmu_fault_activate')
            correction = 'KEPT_PRIMARY; ADDED_EVIDENCE_LIMITATION'
        rows.append({
            'SampleRunID': sid,
            'GroundTruthModelID_LABEL': model,
            'ContextID': ctx,
            'TerminalState_ORIGINAL': ver['TerminalState'],
            'OracleResult_ORIGINAL': ver['OracleResult'],
            'Primary_v1': v1['ManifestationTypePrimary'],
            'Secondary_v1': v1['ManifestationTypeSecondary'],
            'DetectionStatus_v1': v1['DetectionStatus'],
            'MaskingStatus_v1': v1['MaskingStatus'],
            'Primary_v2': primary2,
            'Secondary_v2': secondary2,
            'DetectionStatus_v2': detection2,
            'MaskingStatus_v2': masking2,
            'ExceptionDelivered_TraceEvidence': exception_flag,
            'ExceptionDeliveryEventCount': exception,
            'FaultResultPropagatedEventCount': result_prop,
            'FaultStateConsumedEventCount': state_consumed,
            'SquashEventCount': squash,
            'Correction': correction,
            'EvidenceLimitation': limitation,
        })
    fields = list(rows[0].keys())
    C.write_csv(OUT / 'MMU_Manifestation_Labels_v2.csv', rows, fields)
    C.write_json(OUT / 'MMU_Manifestation_Labels_v2.json', {
        'version': 'v2',
        'rule': (
            'Secondary labels require direct trace evidence. '
            'DETECTED_EXCEPTION is retained only when exception_delivery '
            'exists. DETECTED_CONTAINED is distinguished from generic MASKED '
            'by fault_state_consumed + fault_result_propagated + '
            'exception_delivery and an unchanged PTE / correct guest value. '
            'Original TerminalState and OracleResult are preserved.'),
        'rows': rows,
    })
    # markdown
    md = ['# Manifestation Labels v2 (corrections only)\n\n',
          'Original `TerminalState` / `OracleResult` and feature library v1 '
          'are unchanged. These are versioned secondary labels.\n\n',
          '## Corrections\n\n',
          '- **M03 R01-R04**: removed `DETECTED_EXCEPTION`. Evidence: '
          '`exception_delivery=0`, `fault_result_propagated=0`, one `squash`. '
          'New secondary label: `SQUASH_BEFORE_ARCH_UPDATE`.\n',
          '- **M06 R01-R05**: primary is `DETECTED_CONTAINED`, not generic '
          '`MASKED`. Evidence: `fault_state_consumed` + '
          '`fault_result_propagated` + `exception_delivery`, PTE memory '
          'unchanged, guest observes the correct sentinel. New masking label: '
          '`CONTAINED_BY_EXCEPTION_DELIVERY`.\n',
          '- **M07 R02**: primary unchanged (`UNAUTHORIZED_WRITE`); the '
          'missing same-TranslationID `permission_eval` association is '
          'retained as an explicit evidence limitation.\n\n',
          '## Table\n\n',
          '| Sample | Terminal (original) | Primary v2 | Secondary v2 | '
          'Detection v2 | Masking v2 | Correction |\n'
          '|---|---|---|---|---|---|---|\n']
    for r in rows:
        md.append('| %s | %s | %s | %s | %s | %s | %s |\n' % (
            r['SampleRunID'], r['TerminalState_ORIGINAL'],
            r['Primary_v2'], r['Secondary_v2'], r['DetectionStatus_v2'],
            r['MaskingStatus_v2'], r['Correction']))
    md.append('\n## Counts\n\n')
    md.append('Corrections: %s\n' % json.dumps(
        dict(Counter(r['Correction'] for r in rows))))
    md.append('Changed samples: %s\n' % ', '.join(
        r['SampleRunID'] for r in rows
        if r['Correction'] not in ('UNCHANGED',)))
    (OUT / 'MMU_Manifestation_Labels_v2.md').write_text(''.join(md))
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Labels_v2'
    ws.append(fields)
    for r in rows:
        ws.append([r.get(k, '') for k in fields])
    wb.save(OUT / 'MMU_Manifestation_Labels_v2.xlsx')
    print(json.dumps({
        'rows': len(rows),
        'corrections': dict(Counter(r['Correction'] for r in rows)),
        'changed': [r['SampleRunID'] for r in rows
                    if r['Correction'] != 'UNCHANGED'],
    }, indent=1))


if __name__ == '__main__':
    main()
