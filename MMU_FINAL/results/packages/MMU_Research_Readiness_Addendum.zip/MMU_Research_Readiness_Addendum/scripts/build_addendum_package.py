#!/usr/bin/env python3
"""Addendum task 6 - statuses, modification log, SHA256 manifest and ZIP."""
import csv
import datetime
import json
import os
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'scripts'))
import common as C

ADD = C.OUT / 'addendum'
OUT_ZIP = C.CAMP / 'MMU_Research_Readiness_Addendum.zip'


def sha(p):
    return C.sha256_file(p)


def walk_files(root, exclude_names=()):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root)
        for fn in sorted(filenames):
            if fn in exclude_names:
                continue
            p = Path(dirpath) / fn
            out.append((p, str(rel_dir / fn)))
    return sorted(out, key=lambda x: x[1])


def main():
    # remove empty scratch dirs/files
    outroot = ADD / 'describe' / 'outroot'
    if outroot.is_dir() and not any(outroot.iterdir()):
        outroot.rmdir()
    for p in (ADD / 'describe' / 'raw').glob('*.err'):
        if p.stat().st_size == 0:
            p.unlink()

    parity = json.load(open(ADD / 'describe' /
                            'Describe_Parity_Check.json'))
    status_counts = {}
    for p in parity:
        status_counts[p['Status']] = status_counts.get(p['Status'], 0) + 1
    trace = json.load(open(ADD / 'trace_samples' /
                           'Trace_Sample_Verification.json'))
    obs = json.load(open(ADD / 'observable_features' /
                         'MMU_Diagnostic_Observable_Features.json'))
    labels = json.load(open(ADD / 'semantic_labels' /
                            'MMU_Manifestation_Labels_v2.json'))
    matrix_v2 = list(csv.DictReader(open(
        ADD / 'repeatability_v2' / 'MMU_Repeatability_Matrix_v2.csv')))
    original_zip = C.CAMP / 'MMU_Final_Formal_Campaign_Results_Package.zip'
    original_summary = C.ANALYSIS / 'final_summary.json'
    original_matrix = C.PKG / '40_Sample_Matrix_Completed.csv'

    status = {
        'generated_utc': datetime.datetime.utcnow().isoformat() + 'Z',
        'POST_CAMPAIGN_DATA_STATUS':
            'FROZEN_40_SAMPLES_INTACT_AND_ORIGINAL_HASHES_UNCHANGED',
        'REPEATABILITY_DESIGN_STATUS':
            'CORRECTED_10_SAMPLE_DESIGN_READY_FOR_APPROVAL',
        'DIAGNOSTIC_FEATURE_STATUS':
            'LABEL_FREE_OBSERVABLE_VIEW_READY_WITH_OBSERVABILITY_LIMITS',
        'SEMANTIC_LABEL_STATUS': 'V2_CORRECTED_WITH_TRACE_EVIDENCE',
        'TRACE_SAMPLE_STATUS': (
            '7_OF_7_VERIFIED_NO_FABRICATION'
            if all(r['Verdict'] == 'PASS' for r in trace) else 'FAIL'),
        'no_new_gem5_experiment': True,
        'original_artifacts_modified': False,
        'classifier_accuracy_claim': False,
        'details': {
            'original_results_zip': {
                'path': str(original_zip), 'sha256': sha(original_zip)},
            'original_final_summary': {
                'path': str(original_summary),
                'sha256': sha(original_summary)},
            'original_40_sample_matrix': {
                'path': str(original_matrix),
                'sha256': sha(original_matrix)},
            'formal_samples': 40,
            'repeatability': {
                'samples': len(matrix_v2),
                'describes_ready': sum(
                    1 for p in (ADD / 'describe' / 'raw').glob('M*.json')
                    if json.load(open(p)).get('status') == 'READY'),
                'parity_checks': len(parity),
                'parity_status': status_counts,
                'm01_canonical_hash':
                    matrix_v2[0]['CanonicalWorkloadSHA256'],
                'm01_executed_hash':
                    matrix_v2[0]['ExecutedGuestBinarySHA256'],
                'm05_decoy_va': next(
                    (r['M05DecoyVA'] for r in matrix_v2
                     if r['M05DecoyVA']), ''),
                'm05_decoy_table_base': next(
                    (r['M05DecoyTableBase'] for r in matrix_v2
                     if r['M05DecoyVA']), ''),
                'm05_live_scan_fallback': False,
                'repeat_rcs_policy':
                    matrix_v2[0]['RepeatRcsPolicy'],
                'repeat_disk_policy':
                    matrix_v2[0]['RepeatDiskPolicy'],
            },
            'diagnostics': {
                'observable_rows': len(obs['rows']),
                'observable_columns': len(obs['rows'][0]),
                'simulator_only_inputs': [
                    c for c in obs['rows'][0] if c.endswith('_SIM')],
                'label_columns': [
                    c for c in obs['rows'][0] if c.endswith('_LABEL')],
                'forbidden_inputs': [
                    'FaultModelID', 'FaultOrigin', 'InjectionLocation',
                    'FaultField'],
                'corrections': {
                    'M03_R01_R04': 'removed unsupported DETECTED_EXCEPTION',
                    'M06_R01_R05': 'DETECTED_CONTAINED != generic MASKED',
                    'M07_R02': 'permission_eval association limitation kept',
                },
                'label_rows': len(labels['rows']),
            },
            'trace_samples': {
                'samples': [r['SampleRunID'] for r in trace],
                'all_pass': all(r['Verdict'] == 'PASS' for r in trace),
                'fabricated_events': 0,
            },
        },
    }
    (ADD / 'statuses').mkdir(parents=True, exist_ok=True)
    C.write_json(ADD / 'statuses' / 'STATUS.json', status)
    md = ['# Addendum Status\n\n',
          '| Status key | Value |\n|---|---|\n']
    for k, v in status.items():
        if k in ('details', 'generated_utc'):
            continue
        md.append('| `%s` | `%s` |\n' % (k, v))
    md.append('\n## Repeatability\n\n')
    md.append('- %d corrected rows; 10/10 runner describes `READY`.\n' %
              len(matrix_v2))
    md.append('- %d parity checks: %s.\n' % (len(parity),
                                             json.dumps(status_counts)))
    md.append('- M01 canonical `%s` vs executed guest `%s`; the repeat '
              'uses the executed guest and pins the frozen disk.\n' % (
                  matrix_v2[0]['CanonicalWorkloadSHA256'],
                  matrix_v2[0]['ExecutedGuestBinarySHA256']))
    md.append('- M05 decoy VA `%s`, table base `%s`, explicit flags, no '
              'live-scan fallback.\n\n' % (
                  status['details']['repeatability']['m05_decoy_va'],
                  status['details']['repeatability']['m05_decoy_table_base']))
    md.append('## Diagnostics\n\n')
    md.append('- The observable view has %d rows x %d columns; labels are '
              'separated with `_LABEL`; injector identifiers are excluded.\n' %
              (len(obs['rows']), len(obs['rows'][0])))
    md.append('- No classifier was trained and no accuracy is claimed.\n')
    md.append('- Semantic labels v2 changed 10 rows: 4 M03 squash labels, '
              '5 M06 contained labels, 1 M07 evidence limitation.\n\n')
    md.append('## Trace samples\n\n')
    md.append('- %d/7 PASS; 0 fabricated events.\n\n' % sum(
        1 for r in trace if r['Verdict'] == 'PASS'))
    md.append('## Stop condition\n\nNo repeat was executed. Researcher '
              'approval is required before the 10 repeats.\n')
    (ADD / 'statuses' / 'STATUS.md').write_text(''.join(md))

    mod = ['# Modification Log\n\n',
           'Version: addendum v1 (repeatability design v2)\n\n',
           '## What was corrected\n\n',
           '1. **Repeatability matrix v2**: M01/R01 now uses the executed '
           'guest binary `4f3ddbf2...` from the frozen disk/install path, not '
           'the canonical `ec525687...` field. M05/R05 explicitly carries '
           '`--mmu_m05_decoy_va 0x4010200000` and '
           '`--mmu_m05_decoy_table_base 0`, cross-checked against Excel, '
           'authority v3.0.2, final F1 pilot and `W13_DECOY_VA`. All 10 rows '
           'carry the full original command and a repeat command template.\n',
           '2. **Observable feature view**: new de-labelled CSV/JSON; '
           '`FaultModelID`, `FaultOrigin`, `InjectionLocation`, `FaultField` '
           'are excluded; labels/symptoms are separated; observability tiers '
           'are recorded; confusability analysis is model-ID-free.\n',
           '3. **Semantic labels v2**: M03 R01-R04 `DETECTED_EXCEPTION` '
           'removed (no exception evidence); M06 R01-R05 labelled '
           '`DETECTED_CONTAINED` rather than generic `MASKED`; M07 R02 '
           'permission_eval association limitation retained. Original '
           'TerminalState/OracleResult are unchanged.\n',
           '4. **Trace samples**: 7 original traces copied byte-for-byte; '
           'causal slices extracted and verified; 0 missing and 0 fabricated '
           'events.\n\n',
           '## What was NOT modified\n\n',
           '- No C++ hook, frozen gem5 binary or workload.\n',
           '- No formal SampleRunID, trace, manifest, verdict or original '
           'matrix.\n',
           '- No original result package.\n',
           '- No gem5 experiment was started; the 10 describes use '
           '`--describe` with `would_run=false`.\n\n',
           '## Original artifact hashes\n\n',
           '| Artifact | SHA256 |\n|---|---|\n',
           '| Original results ZIP | `%s` |\n' % sha(original_zip),
           '| Original final_summary.json | `%s` |\n' % sha(original_summary),
           '| Original 40-sample matrix | `%s` |\n\n' % sha(original_matrix),
           '## New artifacts\n\n',
           'All files under this addendum directory are new and listed in '
           '`SHA256_MANIFEST.txt`.\n']
    (ADD / 'Modification_Log.md').write_text(''.join(mod))

    readme = '''# MMU Research Readiness Addendum

Status:
- `POST_CAMPAIGN_DATA_STATUS = FROZEN_40_SAMPLES_INTACT_AND_ORIGINAL_HASHES_UNCHANGED`
- `REPEATABILITY_DESIGN_STATUS = CORRECTED_10_SAMPLE_DESIGN_READY_FOR_APPROVAL`
- `DIAGNOSTIC_FEATURE_STATUS = LABEL_FREE_OBSERVABLE_VIEW_READY_WITH_OBSERVABILITY_LIMITS`

No gem5 experiment was started. No original formal sample, trace, manifest,
verdict, workload, C++ hook or frozen binary was modified.

## Contents

| Path | Content |
|---|---|
| `describe/` | 10 read-only runner describes + 228-check parity table |
| `repeatability_v2/` | corrected 10-sample matrix (CSV/XLSX/JSON/MD) |
| `observable_features/` | de-labelled features + observability tiers + confusability |
| `semantic_labels/` | versioned ManifestationType v2 corrections |
| `trace_samples/` | 7 original traces/manifests/verdicts + verified event slices |
| `statuses/` | three status outputs |
| `Modification_Log.md` | correction record and unchanged-artifact hashes |
| `scripts/` | describe/parity, observable, label, slice and packaging scripts |
| `SHA256_MANIFEST.txt` | hash of every addendum file |

## Key corrections

1. M01/R01 repeat uses executed guest `4f3ddbf2...` (frozen disk + install
   payload), not canonical `ec525687...`; original matrix untouched.
2. M05/R05 repeat explicitly uses decoy VA `0x4010200000` and table base `0`,
   with no live-scan fallback.
3. Observable features exclude injector identifiers; labels and symptoms are
   separated; unproven production fields are `UNKNOWN`.
4. M03 R01-R04 no longer carry an unsupported `DETECTED_EXCEPTION`; M06 is
   `DETECTED_CONTAINED`, not generic `MASKED`; M07 R02 keeps its evidence
   limitation.
5. Seven original traces and causal slices are copied and verified;
   0 fabricated events.

## Stop condition

Await researcher review and authorization. Do not start the 10 repeats.
'''
    (ADD / 'README.md').write_text(readme)

    # manifest and zip
    manifest = ADD / 'SHA256_MANIFEST.txt'
    files = walk_files(ADD, exclude_names={'SHA256_MANIFEST.txt'})
    manifest.write_text(''.join('%s  %s\n' % (sha(p), rel)
                                for p, rel in files))
    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for p, rel in files:
            zf.write(p, arcname='MMU_Research_Readiness_Addendum/' + rel)
        zf.write(manifest, arcname='MMU_Research_Readiness_Addendum/'
                              'SHA256_MANIFEST.txt')
    digest = sha(OUT_ZIP)
    (C.CAMP / (OUT_ZIP.name + '.sha256')).write_text(
        '%s  %s\n' % (digest, OUT_ZIP.name))
    print(json.dumps({
        'zip': str(OUT_ZIP),
        'zip_sha256': digest,
        'zip_size_bytes': OUT_ZIP.stat().st_size,
        'files_manifested': len(files),
        'status': {
            'POST_CAMPAIGN_DATA_STATUS':
                status['POST_CAMPAIGN_DATA_STATUS'],
            'REPEATABILITY_DESIGN_STATUS':
                status['REPEATABILITY_DESIGN_STATUS'],
            'DIAGNOSTIC_FEATURE_STATUS':
                status['DIAGNOSTIC_FEATURE_STATUS'],
        },
    }, indent=1))


if __name__ == '__main__':
    main()
