# MMU Research Readiness Addendum

Status:
- `POST_CAMPAIGN_DATA_STATUS = FROZEN_40_SAMPLES_INTACT_AND_ORIGINAL_HASHES_UNCHANGED`
- `REPEATABILITY_DESIGN_STATUS = CORRECTED_10_SAMPLE_DESIGN_READY_FOR_APPROVAL`
- `DIAGNOSTIC_FEATURE_STATUS = LABEL_FREE_OBSERVABLE_VIEW_READY_WITH_OBSERVABILITY_LIMITS`

No gem5 experiment was started. No original formal sample, trace, manifest,
verdict, workload, C++ hook or frozen binary was modified.

## Contents

| Path | Content |
|---|---|
| `describe/` | 10 read-only runner describes + 228-check parity table |
| `repeatability_v2/` | corrected 10-sample matrix (CSV/XLSX/JSON/MD) |
| `observable_features/` | de-labelled features + observability tiers + confusability |
| `semantic_labels/` | versioned ManifestationType v2 corrections |
| `trace_samples/` | 7 original traces/manifests/verdicts + verified event slices |
| `statuses/` | three status outputs |
| `Modification_Log.md` | correction record and unchanged-artifact hashes |
| `scripts/` | describe/parity, observable, label, slice and packaging scripts |
| `SHA256_MANIFEST.txt` | hash of every addendum file |

## Key corrections

1. M01/R01 repeat uses executed guest `4f3ddbf2...` (frozen disk + install
   payload), not canonical `ec525687...`; original matrix untouched.
2. M05/R05 repeat explicitly uses decoy VA `0x4010200000` and table base `0`,
   with no live-scan fallback.
3. Observable features exclude injector identifiers; labels and symptoms are
   separated; unproven production fields are `UNKNOWN`.
4. M03 R01-R04 no longer carry an unsupported `DETECTED_EXCEPTION`; M06 is
   `DETECTED_CONTAINED`, not generic `MASKED`; M07 R02 keeps its evidence
   limitation.
5. Seven original traces and causal slices are copied and verified;
   0 fabricated events.

## Stop condition

Await researcher review and authorization. Do not start the 10 repeats.
