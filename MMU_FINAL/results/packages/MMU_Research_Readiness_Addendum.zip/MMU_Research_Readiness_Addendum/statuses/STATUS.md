# Addendum Status

| Status key | Value |
|---|---|
| `POST_CAMPAIGN_DATA_STATUS` | `FROZEN_40_SAMPLES_INTACT_AND_ORIGINAL_HASHES_UNCHANGED` |
| `REPEATABILITY_DESIGN_STATUS` | `CORRECTED_10_SAMPLE_DESIGN_READY_FOR_APPROVAL` |
| `DIAGNOSTIC_FEATURE_STATUS` | `LABEL_FREE_OBSERVABLE_VIEW_READY_WITH_OBSERVABILITY_LIMITS` |
| `SEMANTIC_LABEL_STATUS` | `V2_CORRECTED_WITH_TRACE_EVIDENCE` |
| `TRACE_SAMPLE_STATUS` | `7_OF_7_VERIFIED_NO_FABRICATION` |
| `no_new_gem5_experiment` | `True` |
| `original_artifacts_modified` | `False` |
| `classifier_accuracy_claim` | `False` |

## Repeatability

- 10 corrected rows; 10/10 runner describes `READY`.
- 228 parity checks: {"PASS": 227, "DOCUMENTED_DIVERGENCE": 1}.
- M01 canonical `ec525687a757fd0f3865294481c687e754c06dc6a073dd2aa80306b04621732b` vs executed guest `4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98`; the repeat uses the executed guest and pins the frozen disk.
- M05 decoy VA `0x4010200000`, table base `0`, explicit flags, no live-scan fallback.

## Diagnostics

- The observable view has 40 rows x 38 columns; labels are separated with `_LABEL`; injector identifiers are excluded.
- No classifier was trained and no accuracy is claimed.
- Semantic labels v2 changed 10 rows: 4 M03 squash labels, 5 M06 contained labels, 1 M07 evidence limitation.

## Trace samples

- 7/7 PASS; 0 fabricated events.

## Stop condition

No repeat was executed. Researcher approval is required before the 10 repeats.
