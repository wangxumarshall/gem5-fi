# Modification Log

Version: addendum v1 (repeatability design v2)

## What was corrected

1. **Repeatability matrix v2**: M01/R01 now uses the executed guest binary `4f3ddbf2...` from the frozen disk/install path, not the canonical `ec525687...` field. M05/R05 explicitly carries `--mmu_m05_decoy_va 0x4010200000` and `--mmu_m05_decoy_table_base 0`, cross-checked against Excel, authority v3.0.2, final F1 pilot and `W13_DECOY_VA`. All 10 rows carry the full original command and a repeat command template.
2. **Observable feature view**: new de-labelled CSV/JSON; `FaultModelID`, `FaultOrigin`, `InjectionLocation`, `FaultField` are excluded; labels/symptoms are separated; observability tiers are recorded; confusability analysis is model-ID-free.
3. **Semantic labels v2**: M03 R01-R04 `DETECTED_EXCEPTION` removed (no exception evidence); M06 R01-R05 labelled `DETECTED_CONTAINED` rather than generic `MASKED`; M07 R02 permission_eval association limitation retained. Original TerminalState/OracleResult are unchanged.
4. **Trace samples**: 7 original traces copied byte-for-byte; causal slices extracted and verified; 0 missing and 0 fabricated events.

## What was NOT modified

- No C++ hook, frozen gem5 binary or workload.
- No formal SampleRunID, trace, manifest, verdict or original matrix.
- No original result package.
- No gem5 experiment was started; the 10 describes use `--describe` with `would_run=false`.

## Original artifact hashes

| Artifact | SHA256 |
|---|---|
| Original results ZIP | `caeaf6506495ed119a06a12075f5193276e2e1279286ddc56610016f39caa151` |
| Original final_summary.json | `1451a3a1ab308ac3c8e976fbe98e4bc5e73b788cb5b2db62b9ae52fb842934fd` |
| Original 40-sample matrix | `d65f6933c9d890c5b770a194ed8fe5c88168e4948b503b38fd9dcb30ddf5f18d` |

## New artifacts

All files under this addendum directory are new and listed in `SHA256_MANIFEST.txt`.
