# Corrected 10-Sample Repeatability Design (v2)

Status: `CORRECTED_DESIGN_READY_FOR_RESEARCHER_APPROVAL`. No gem5 experiment was started.

## Corrections

1. **M01/R01 executed guest**: the formal matrix records the canonical mmu_rev build `ec525687...`, but the guest actually executed `/root/mmu_w9` from the frozen disk (install payload `4f3ddbf2...`). The repeat row now pins `4f3ddbf2...` plus the frozen disk SHA256; the original matrix/manifest are untouched.
2. **M05/R05 decoy**: the repeat row now records explicit `--mmu_m05_decoy_va 0x4010200000` and `--mmu_m05_decoy_table_base 0`, cross-checked against Excel, authority v3.0.2, final F1 pilot and `W13_DECOY_VA`. Live-scan fallback is forbidden.
3. All 10 rows carry the complete verbatim `--mmu_*` parameter set, full original command and a repeat command template. The repeat copies the original rcS byte-for-byte and uses a byte-identical copy of the frozen disk image (SHA256 pinned); no rebuild is allowed. Repeat traces use new `REP2-*` run IDs; the original trace is never overwritten.

## Parity / describe result

| Metric | Value |
|---|---|
| Read-only describes | 10/10 `READY` |
| Runner parity_ok | 10/10 true |
| Independent checks | 228 |
| Failures | 0 |

## Matrix

| RepeatID | Original | Executed guest SHA256 | Disk SHA256 | M05 decoy VA / table base |
|---|---|---|---|---|
| REP2-MMU-M01-R01-01 | M01-F0-W9-S01-R01 | `4f3ddbf2615ebefc...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M02-R02-01 | M02-F0-W10-S01-R02 | `733b8a80150b9728...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M03-R01-01 | M03-F0-W11-S01-R01 | `1393b2737e33db75...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M03-R05-01 | M03-F0-W11-S01-R05 | `1393b2737e33db75...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M04-R05-01 | M04-F0-W12-S01-R05 | `8fa269fd88eaf912...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M05-R05-01 | M05-F0-W13-S01-R05 | `6e7d926e863c1543...` | `bb872707d6bae388...` | 0x4010200000 / 0 |
| REP2-MMU-M06-R02-01 | M06-F0-W10-S01-R02 | `fede5f3ea4c3224f...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M07-R01-01 | M07-F0-W14-S01-R01 | `f15dc78e2efc683f...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M07-R05-01 | M07-F0-W14-S01-R05 | `f15dc78e2efc683f...` | `bb872707d6bae388...` | - / - |
| REP2-MMU-M08-R01-01 | M08-F0-W10-S01-R01 | `733b8a80150b9728...` | `bb872707d6bae388...` | - / - |

## M05 decoy cross-source evidence

### M05-F0-W13-S01-R05

| Source | Decoy VA | Table base |
|---|---|---|
| Excel | `0x4010200000` | `0` |
| Authority | `0x4010200000` | `0` |
| Pilot | `0x4010200000` | `0` |
| W13 symbol | `0x4010200000` | - |
| Plan | `0x4010200000` | `0` |
| Command | `0x4010200000` | `0` |

## Stop condition

No repeat was executed. The 10 runs require researcher approval.
