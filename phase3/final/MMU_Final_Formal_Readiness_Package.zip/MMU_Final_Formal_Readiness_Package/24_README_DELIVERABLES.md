# MMU Final Formal Readiness Package — deliverable map

| Task deliverable | Package location |
|---|---|
| 1. Excel authority | `01_MMU_40_Sample_Matrix.csv`, `04/05` config (workbook in the source-tree authority dir) |
| 2. 40-sample matrix | `01_MMU_40_Sample_Matrix.csv` |
| 3/4. JSON/YAML config | `04_MMU_Formal_Config.json`, `05_MMU_Formal_Config.yaml` |
| 5/6. Model/Context readiness | `02_MMU_Model_Readiness_FINAL.csv`, `03_MMU_Context_Readiness_FINAL.csv` |
| 7. Final binary SHA | `15_FINAL_BINARY.sha256` |
| 8. Source version | `07_MMU_Source_Version_Report.md` |
| 9. Seed audit | `06_MMU_Seed_Semantics_Audit.md` |
| 10. Preflight | `08_MMU_Formal_Preflight_Report.md`, `17_MMU_40_Sample_DryRun.csv` |
| 11. Trace validation | `09_MMU_Trace_Validation_Report.md`, `14_evidence_index.json` |
| 12. Golden controls | `10_MMU_Golden_Control_Report.md`, `23_Golden_Controls/` |
| 13. M07 change | `11_MMU_M07_Change_Report.md` |
| 14. Blockers | `12_MMU_Final_Blockers.md` |
| 15. Change log | `13_MMU_Change_Log.md` |
| 16. Runner + scripts | `20_Formal_Runner/` |
| 17. Source diff | `21_Source_Diff/Frozen_Source.patch` |
| 18. Pilot evidence | `22_Pilot_Evidence/` (manifests, verdicts, observed output, revalidated verdicts) |
| 19. Golden control evidence | `23_Golden_Controls/` |
| 20. SHA256 manifest | `SHA256_MANIFEST.txt` |

Raw traces are not duplicated (hundreds of MB); each pilot evidence entry names its
`runs/<RunID>/Trace/prop_evt.txt.gz` in the frozen workspace.
