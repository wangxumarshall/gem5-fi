# MMU Final Source / Binary Version Report

Workspace: `/home/sdc/gem5-fi-mmu-impl-v2`
Git HEAD: `60f1a8760410288128061d85582e5395b24c0106`
Final binary declared by Main: `b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185`
Final binary status: **FROZEN_BY_MAIN**

## Final binary

| Field | Value |
|---|---|
| Path | `CHAOS/gem5/build/ARM/gem5.opt` |
| SHA256 (declared) | `b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185` |
| SHA256 (on disk) | `b3eb1559f742e86f1f9796e8ad21d0bb4f35ae1106d3ddae22b9df1eb91f7185` |
| Source commit | `60f1a8760410288128061d85582e5395b24c0106` |

## Platform checkpoint and capability

| Field | Value |
|---|---|
| Checkpoint | `runs/mmu_bootF1/cpt.244799013609` |
| Checkpoint SHA256 (sorted file-manifest digest) | `4aa1ba38b5288fe1c7e58dde73a1f27166e67f846f77f241fcd1fb2cd89e6417` |
| FEAT_EPAN | enabled: ID_AA64MMFR1_EL1.PAN=3 |
| EPAN scope | execute-only user mappings only (protection_map[4/12]); read/execute and read-only mappings are unchanged |

## Commit provenance

Base commit the pilots were launched from: `f24b6b77af9f4217c026d9a39e58e5a04c69dea3`.
The closure commit containing exactly the frozen source above: `60f1a8760410288128061d85582e5395b24c0106`.
Pilot manifests record the base commit (`git_head`) plus the six per-file `source_sha256` values; the preflight requires those hashes to equal the frozen values.

## Frozen source hashes

| File | SHA256 |
|---|---|
| `CHAOS/gem5/src/arch/arm/mmu.cc` | `bba49e65398f80aaf58b3ce5a954f4ffbd68278dd0b5c888124d249e28dd1c1b` (on disk `bba49e65398f80aaf58b3ce5a954f4ffbd68278dd0b5c888124d249e28dd1c1b`) |
| `CHAOS/gem5/src/arch/arm/table_walker.cc` | `54dbeeff2e40891eb018c4bf891a5446ab2b8c4fe88f69c40647c26923595985` (on disk `54dbeeff2e40891eb018c4bf891a5446ab2b8c4fe88f69c40647c26923595985`) |
| `CHAOS/gem5/src/arch/arm/table_walker.hh` | `89110e2081da62743e4c2325aa656976e945f086959bcd29f18882412e44b611` (on disk `89110e2081da62743e4c2325aa656976e945f086959bcd29f18882412e44b611`) |
| `CHAOS/gem5/src/arch/arm/tlb.cc` | `b81b7b4cc9eee2c7ba0b592775587dcc7610c8d18c237ba412d2c69ba80d52f4` (on disk `b81b7b4cc9eee2c7ba0b592775587dcc7610c8d18c237ba412d2c69ba80d52f4`) |
| `CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.cc` | `38c0942ab5d2c4c73b7ee3763c1d7503b708ba9ba4f73c2fd051db6836052dc4` (on disk `38c0942ab5d2c4c73b7ee3763c1d7503b708ba9ba4f73c2fd051db6836052dc4`) |
| `CHAOS/gem5/src/cpu/o3/CHAOSPropagation/CHAOSPropagation.hh` | `90ea1b55a9a7e51db04fad4a23ceee3107ebc2d375c3d5c5902b9ffb6b2d3336` (on disk `90ea1b55a9a7e51db04fad4a23ceee3107ebc2d375c3d5c5902b9ffb6b2d3336`) |

## Workload hashes

| Workload | SHA256 |
|---|---|
| W10 | `733b8a80150b9728b640fbaad0889f139b09b92a98462778753975a4917a63ae` |
| W10S | `fede5f3ea4c3224f34ef9768a8cbb0fe49b071cab86306e67e7a73610f11b0a3` |
| W11 | `1393b2737e33db75a8dfa38dbd0fa888d7640e7fb791cb7da1df815bd21451c4` |
| W12 | `8fa269fd88eaf9126f67cf80d5d77f13600e211948db5cd7f4b89f42c147fdbc` |
| W13 | `6e7d926e863c15433b3887e3ac069169e510751190d4b0de5dae0e7aa886ec70` |
| W14 | `f15dc78e2efc683f2a653a40ed47d293b71c27aaa018594e67274e9098a7be36` |
| W9 | `ec525687a757fd0f3865294481c687e754c06dc6a073dd2aa80306b04621732b` |

W9 executed guest binary (installed at `/root/mmu_w9` by the checkpoint): `4f3ddbf2615ebefcbc6e8499a862666679ba4c13e478af09dda9104ee6508c98`. The EPAN checkpoint installs /root/mmu_w9 from the current workloads/mmu/W9 build (4f3ddbf2...); the runner records the canonical source-identical build ec5256... . Both are the same W9 source; the executed guest binary is the install blob.

If the final binary SHA is `PENDING_MAIN_FREEZE`, Main has not frozen the post-integration build yet; no hash is guessed.
