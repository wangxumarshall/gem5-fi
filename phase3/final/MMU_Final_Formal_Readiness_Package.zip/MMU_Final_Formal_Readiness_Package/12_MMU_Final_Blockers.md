# MMU Final Blockers

Only real, currently observed blockers are listed.  A sample with no entry here is READY in the preflight.

No blockers: all 40 samples are READY.
