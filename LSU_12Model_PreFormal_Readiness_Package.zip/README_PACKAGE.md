# LSU 12-Model Pre-Formal Readiness Package (v3.3.0)

Date: 2026-11-11. Branch `lsu-preformal-v3.3.0-20261111`, base
`lsu-platform-v3.2.12` @ `9e3d104c`, HEAD `c1846ae4`.
Final binary `d3807fbef631354a41d9d6d8cf14c11020e396439f80bdd516225c6b5e37e2b2`.

Verdict: **12_MODEL_FORMAL_READY = NO / NOT_READY** (see A_Report/LSU_Final_Blockers.md).

## Contents

- `A_Report/` — acceptance report, blockers, binary provenance, git log/diff,
  binary SHA256.
- `B_Audits/` — the seven required machine-readable audits:
  `LSU_60Context_Readiness_Matrix.csv`, `LSU_Workload_Oracle_Audit.csv`,
  `LSU_Fault_Control_Pair_Audit.csv`, `LSU_Propagation_Closure_Final.csv`,
  `LSU_Diagnostic_Features_Final.csv`, `LSU_12Model_Source_Hook_Audit.csv`,
  `LSU_Formal_Config_Freeze_Checklist.csv`, plus the six agent findings MDs
  and the raw 60-context matrix before the formal-gate adjudication.
- `C_Excel/` — `LSU_12Model_60Sample_PreFormal_v3.3.xlsx`: the authoritative
  v3.2.7 workbook with its original 60 rows untouched, plus audit sheets
  23–29.
- `D_Patches/` — the five reviewed diff proposals (all applied except the
  W4 workload, which is a tracked proposal).
- `E_Evidence/runs/` — every v3.3 pilot/control directory (command, config,
  manifest, meta, oracle, stdout/stderr, trace, stats), resource gate JSON,
  and the two real pytest logs.
- `F_Independent/` — independent acceptance findings.

## Reproduce

```bash
cd <worktree>
git checkout lsu-preformal-v3.3.0-20261111
sha256sum build/ARM/gem5.opt     # d3807fbe...
cd CHAOS/gem5 && scons -j126 build/ARM/gem5.opt   # exit 0
# targeted re-verification:
python3 docs/gem5-fi/lsu/implementation_v3_2/platform/run_pilot.py \
  --model A01 --pilot-id REPRO-A01-C02 --context-index 2 --probability 0.0 \
  --outdir /tmp/repro-a01c --gem5 build/ARM/gem5.opt
```

No formal campaign was run. No SampleRunID/Seed/model semantics were changed;
the frozen workbook rows are preserved verbatim.
