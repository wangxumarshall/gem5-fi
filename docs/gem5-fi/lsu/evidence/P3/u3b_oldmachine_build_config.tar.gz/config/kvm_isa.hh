#define KVM_ISA "arm"
