# Preserved historical deliverables

This package adds a new v3.2.3 progress snapshot. It does not overwrite or delete
any earlier deliverable. The earlier packages remain in place with these hashes:

| Deliverable | SHA256 |
|---|---|
| LSU_v3.2.2_Implementation_Package.zip | d20315152048e9191a453f8b37f6ec37fcd9e24f09327687aa98d545b0a709ac |
| LSU_v3.2.3_Propagation_Closure_Package.zip | 1e3e8377f20d03bb3ee9a1d41e5e715f95c8e6df732a8d432a0aa56bc267b141 |

v3.2.1 and earlier artifacts (implementation_v3_2, pilots, pilots_v3_2_1,
baselines, runs/) are unchanged. No experiment result was deleted.
