#include "cpu/o3/CHAOSLSQFwd/CHAOSLSQFwd.hh"
#include "cpu/o3/CHAOSPropagation/CHAOSPropagation.hh"  // v3.2 FW02 trace
#include "sim/sim_exit.hh"
#include "params/CHAOSLSQFwd.hh"

#include <iostream>
#include <fstream>

#include "base/output.hh"
#include "cpu/o3/cpu.hh"
#include "debug/LSQUnit.hh"

namespace gem5
{

    CHAOSLSQFwd::CHAOSLSQFwd(const CHAOSLSQFwdParams &p)
        : SimObject(p),
          cpu(dynamic_cast<o3::CPU *>(p.cpu)),
          probability(p.probability),
          fault_type_enum(stringToFaultType(p.faultType)),
          struct_mode(stringToStructMode(p.structMode)),
          fault_mask(std::bitset<64>(p.faultMask)),
          num_bits_to_change(p.bitsToChange),
          byte_offset(p.byteOffset),
          lane_skew_k(p.laneSkewK),
          first_clock(Cycles(p.firstClock)),
          last_clock(Cycles(p.lastClock)),
          max_faults(p.maxFaults),
          faults_injected_count(0),
          rng_seed(p.rngSeed),
          write_log(p.writeLog),
          l03_mode(p.l03Mode),   // [LSU][SEM-B]
          f6_event_ordinal(p.f6EventOrdinal),
          rng(rng_seed != 0 ? rng_seed : rd()),
          log_stream(nullptr),
          stats(nullptr)
    {
        // LSU W2/W5: event-normalized trigger (05 r2-r8; off = legacy).
        if (p.lsuTier != "off") {
            auto tier = ChaOSLsuTier::F0;
            if (p.lsuTier == "F1") tier = ChaOSLsuTier::F1;
            else if (p.lsuTier == "F2") tier = ChaOSLsuTier::F2;
            else if (p.lsuTier == "F3") tier = ChaOSLsuTier::F3;
            else if (p.lsuTier == "F4") tier = ChaOSLsuTier::F4;
            else if (p.lsuTier == "F5") tier = ChaOSLsuTier::F5;
            else if (p.lsuTier == "F6") tier = ChaOSLsuTier::F6;
            lsuTrigger = new ChaOSLsuTrigger(tier, rng_seed ? rng_seed : 1,
                                             p.lsuWarmupEvents, p.lsuSpanEvents,
                                             ChaOSLsuEvent::SqForward,
                                             p.f6EventOrdinal);
        }
        if (lsuTrigger) {
            // W5: funnel lines at exit (chaos_l0 discipline: log file, not
            // stdout). activated = same near-tautological approximation as
            // CHAOSAddrPath (the forwarded data is consumed by the load's
            // writeback immediately after this hook).
            registerExitCallback([this]() {
                if (lsuTrigger)
                    lsuTrigger->summary("CHAOSLSQFwd");
                l0_funnel.attempted = lsuTrigger->attempted;
                l0_funnel.eligible  = lsuTrigger->eligible;
                l0_funnel.injected  = faults_injected_count;
                l0_funnel.activated = faults_injected_count;
                if (write_log && log_stream && log_stream->stream()) {
                    *(log_stream->stream()) << l0_funnel.line("CHAOSLSQFwd")
                                            << std::endl;
                }
            });
        }
        if (!cpu) {
            throw std::runtime_error(
                "CHAOSLSQFwd: cpu is not an O3CPU. CHAOSLSQFwd only supports "
                "O3CPU (it hooks the O3 LSQ store->load forwarding path). "
                "Cast failed.");
        }
        if (probability > 0.0f || struct_mode == StructMode::F6Fw02) {
            log_stream = simout.create("lsq_fwd_injections.log", false, true);
            if (!log_stream || !log_stream->stream()) {
                panic("CHAOSLSQFwd: Could not open log file");
            }
            // Sampling-bias fix (findings.md Phase 2.2, same as
            // CHAOSL1DForward): skip a geometric(p=0.1) number of eligible
            // forwarding events before the first injection, so the single
            // fault (maxFaults=1) lands on a seed-dependent event instead
            // of always the first eligible one (same dynamic store->load
            // pair every rep on a deterministic stream).
            // v1.1 Phase 8.2: fixed uniform skip (driver-provided,
            // chaos_event_sample.hh) overrides the legacy geometric(0.1)
            // draw; UINT64_MAX sentinel keeps legacy behavior.
            if (p.eventsToSkip != ~0ULL)
                events_to_skip = p.eventsToSkip;
            else {
                std::geometric_distribution<uint64_t> skip_dist(0.1);
                events_to_skip = skip_dist(rng);
            }
            count_only = p.countOnly;
            // v1.1 Phase 8.2: print CHAOS_ELIGIBLE_COUNT at sim exit (the
            // destructor may not run before gem5's exit path; the exit
            // callback always fires). Registered here because CHAOSLSQFwd
            // self-attaches in the ctor (no startup() override).
            if (count_only) {
                registerExitCallback([this]() {
                    if (log_stream && log_stream->stream())
                        *(log_stream->stream()) << "CHAOS_ELIGIBLE_COUNT="
                            << eligible_count << std::endl;
                });
            }
            stats = std::make_unique<CHAOSLSQFwdStats>(this);
            random_fault_distribution = std::discrete_distribution<int>(
                {0.9, 0.05, 0.05});  // bit_flip / stuck0 / stuck1
            // Register self with the CPU so lsq_unit.cc can reach this
            // injector via cpu->lsqFwd. cpu is guaranteed constructed first
            // (it was passed as a Param). Safe because lsq_unit only reads
            // lsqFwd during execute(), long after SimObject construction.
            cpu->lsqFwd = this;
        }
        if (struct_mode == StructMode::F6Fw02) {
            // FW02: attach even with probability==0 (this mode suppresses a
            // forwarding match, it does not corrupt forwarded bytes).
            if (!cpu->lsqFwd) cpu->lsqFwd = this;
            if (max_faults == 0) max_faults = 1;
            registerExitCallback([this]() {
                if (write_log && log_stream && log_stream->stream()) {
                    *(log_stream->stream())
                        << "CHAOS_FW02_SUMMARY: observed=" << f6_observed
                        << " suppressed=" << (f6_fired ? 1 : 0)
                        << " load_seq=" << f6_load_seq
                        << " store_seq=" << f6_store_seq << std::endl;
                }
            });
        }
    }

    CHAOSLSQFwd::~CHAOSLSQFwd()
    {
        // v1.1 Phase 8.2 countOnlyMode: the driver's dry-run learns
        // N_eligible from this line (campaign.py parses the log).
        if (count_only && log_stream && log_stream->stream()) {
            *(log_stream->stream()) << "CHAOS_ELIGIBLE_COUNT=" << eligible_count
                << std::endl;
        }
    }

    CHAOSLSQFwd::FaultType
    CHAOSLSQFwd::stringToFaultType(const std::string &s) {
        if (s == "bit_flip") return FaultType::BitFlip;
        else if (s == "stuck_at_zero") return FaultType::StuckAtZero;
        else if (s == "stuck_at_one") return FaultType::StuckAtOne;
        return FaultType::Random;
    }

    const char*
    CHAOSLSQFwd::faultTypeToString(FaultType f) {
        switch (f) {
            case FaultType::BitFlip: return "bit_flip";
            case FaultType::StuckAtZero: return "stuck_at_zero";
            case FaultType::StuckAtOne: return "stuck_at_one";
            case FaultType::Random: return "random";  // §2.4: clear -Wswitch
        }
        return "random";
    }

    // §2.4 structured fault mode (fi-h6-h7 branch, H5 closed).
    CHAOSLSQFwd::StructMode
    CHAOSLSQFwd::stringToStructMode(const std::string &s) {
        if (s == "byte_lane_skew") return StructMode::ByteLaneSkew;
        if (s == "all_zero") return StructMode::AllZero;
        if (s == "fwd_source_sub") return StructMode::FwdSourceSub;
        if (s == "phase_offset") return StructMode::PhaseOffset;
        if (s == "f6_fw02") return StructMode::F6Fw02;
        if (s == "sq01_bit3") return StructMode::Sq01Bit3;
        return StructMode::ByteFlip;  // default / unknown
    }

    int
    CHAOSLSQFwd::generateRandomMask(int bits_to_change)
    {
        // 8-bit mask (applied to one byte of the forwarded buffer)
        int mask = 0;
        std::uniform_int_distribution<int> bitDist(0, 7);
        while (bits_to_change-- > 0) mask |= (1 << bitDist(rng));
        return mask;
    }

    void
    CHAOSLSQFwd::writeLog(const char *type, unsigned size, Addr vaddr,
                          int byte_off, int mask)
    {
        if (!write_log) return;
        *(log_stream->stream())
            << "Cycle: " << cpu->curCycle()
            << ", CPU: " << cpu->name()
            << ", Site: store->load_forward"
            << ", FaultType: " << type
            << ", Vaddr: 0x" << std::hex << vaddr << std::dec
            << ", FwdSize: " << size
            << ", ByteOffset: " << byte_off
            << ", Mask: " << std::bitset<8>(mask)
            << std::endl;
    }

    void
    CHAOSLSQFwd::corrupt(uint8_t *data, unsigned size, Addr vaddr)
    {
        // Hot-path short-circuit: no injection configured.
        if (probability <= 0.0f) return;
        // fwd_source_sub injects at the DECISION point (maybeSubstituteSource,
        // called before the memcpy); this post-forward corrupt hook must NOT
        // also fire in that mode (double-injection bug found in Phase 4.2
        // verification: an unlimited-faults run showed bit_flip lines while
        // in fwd_source_sub mode — the old hook was still active).
        // phase_offset likewise acts at the WRITEBACK-SCHEDULE point
        // (maybeDelayForward) — no data mutation there either.
        if (struct_mode == StructMode::FwdSourceSub) return;
        if (struct_mode == StructMode::PhaseOffset) return;
        // FW02 acts only at the forwarding DECISION point (suppress one
        // match); it must never also mutate the forwarded bytes.
        if (struct_mode == StructMode::F6Fw02) return;
        // [LSU][SEM-B] L03 hook split: with --lsqfwd_l03 the SQ-forward
        // data path is NOT L03's event source — the trigger stream must be
        // violation checks only (checkViolations site), not the mixed stream.
        if (l03_mode) return;
        if (lsuTrigger) {
            // LSU W2/W5 path (05 r2-r8): the event-normalized trigger owns
            // warm-up/repetition semantics; the legacy cycle window,
            // events_to_skip and the Bernoulli roll do NOT apply here.
            lsuTrigger->onAttempt();
            if (!lsuTrigger->onEligible()) return;
        } else {
            Cycles cur = cpu->curCycle();
            if (cur < first_clock) return;
            if (last_clock != Cycles(0) && cur > last_clock) return;
            if (max_faults != 0 && faults_injected_count >= max_faults) return;

            // Sampling-bias fix (findings.md Phase 2.2): skip the first N
            // eligible forwarding events (N ~ geometric(0.1) from the seed)
            // so the single fault lands on a seed-dependent event.
            if (count_only) { ++eligible_count; return; }
            if (events_to_skip > 0) {
                --events_to_skip;
                return;
            }

            // Bernoulli: does this forwarding event get corrupted?
            std::uniform_real_distribution<float> dist(0.0f, 1.0f);
            if (dist(rng) >= probability) return;
        }
        if (size == 0) return;

        // §2.4 structured fault modes (fi-h6-h7 branch, H5 closed):
        if (struct_mode == StructMode::ByteLaneSkew) {
            // Rotate the whole forwarded buffer by k bytes (rol_k) —
            // core179 D1 byte-lane phase signature (method2).
            int k = lane_skew_k % (int)size;
            if (k < 0) k += (int)size;
            if (k != 0) {
                uint8_t tmp[16];
                for (unsigned i = 0; i < size; i++) tmp[i] = data[i];
                for (unsigned i = 0; i < size; i++)
                    data[i] = tmp[(i + k) % size];
            }
            stats->numFaultsInjected++;
            ++faults_injected_count;
            writeLog("byte_lane_skew", size, vaddr, lane_skew_k, 0);
            DPRINTF(LSQUnit, "CHAOSLSQFwd: byte_lane_skew rol %d (vaddr=%#x)\n",
                    lane_skew_k, vaddr);
            return;
        }
        if (struct_mode == StructMode::AllZero) {
            for (unsigned i = 0; i < size; i++) data[i] = 0;
            stats->numFaultsInjected++;
            ++faults_injected_count;
            writeLog("all_zero", size, vaddr, 0, 0);
            DPRINTF(LSQUnit, "CHAOSLSQFwd: all_zero (vaddr=%#x size=%u)\n",
                    vaddr, size);
            return;
        }

        // Choose byte to corrupt.
        int off = byte_offset;
        if (off < 0) {
            std::uniform_int_distribution<int> bdist(0, (int)size - 1);
            off = bdist(rng);
        }
        if (off >= (int)size) off = (int)size - 1;

        int mask = fault_mask.any()
            ? (int)(fault_mask.to_ulong() & 0xff)
            : generateRandomMask(num_bits_to_change);

        FaultType chosen = fault_type_enum;
        if (fault_type_enum == FaultType::Random) {
            int idx = random_fault_distribution(rng);
            chosen = static_cast<FaultType>(idx);
        }

        switch (chosen) {
            case FaultType::StuckAtZero:
                data[off] &= ~(uint8_t)mask;
                stats->numStuckAtZero++;
                break;
            case FaultType::StuckAtOne:
                data[off] |= (uint8_t)mask;
                stats->numStuckAtOne++;
                break;
            case FaultType::BitFlip:
                data[off] ^= (uint8_t)mask;
                stats->numBitFlips++;
                break;
            default: break;
        }
        stats->numFaultsInjected++;
        ++faults_injected_count;
        writeLog(faultTypeToString(chosen), size, vaddr, off, mask);
        DPRINTF(LSQUnit, "CHAOSLSQFwd: corrupted forwarded byte %d (vaddr=%#x "
                "mask=%#x type=%s)\n", off, vaddr, mask,
                faultTypeToString(chosen));
    }

    bool
    CHAOSLSQFwd::maybeSubstituteSource(uint8_t *load_data,
                                       const uint8_t *true_src,
                                       unsigned copy_size,
                                       const uint8_t *alt_src,
                                       unsigned alt_size, Addr vaddr)
    {
        // §2.4 fwd_source_sub (F5): wrong-source store->load forwarding.
        // Only active in FwdSourceSub mode; other modes return false and the
        // caller does its normal memcpy (zero regression).
        if (struct_mode != StructMode::FwdSourceSub) return false;
        if (probability <= 0.0f) return false;
        if (!load_data || !true_src || !alt_src) return false;
        if (copy_size == 0 || alt_size == 0) return false;

        Cycles cur = cpu->curCycle();
        if (cur < first_clock) return false;
        if (last_clock != Cycles(0) && cur > last_clock) return false;
        if (max_faults != 0 && faults_injected_count >= max_faults) return false;

        // sampling-bias fix: consume skip only on eligible wrong-source
        // opportunities (an older SQ entry exists with data)
        if (count_only) { ++eligible_count; return false; }
        if (events_to_skip > 0) { --events_to_skip; return false; }

        std::uniform_real_distribution<float> dist(0.0f, 1.0f);
        if (dist(rng) >= probability) return false;

        // Copy the WRONG store's data into the load buffer. If the wrong
        // source is smaller than the load, copy what it has (the tail keeps
        // whatever the caller's buffer held — the mismatch IS the fault).
        unsigned n = copy_size < alt_size ? copy_size : alt_size;
        memcpy(load_data, alt_src, n);
        stats->numFaultsInjected++;
        ++faults_injected_count;
        if (write_log) {
            *(log_stream->stream())
                << "Cycle: " << cpu->curCycle()
                << ", Site: store->load_forward_decision"
                << ", FaultType: fwd_source_sub"
                << ", Vaddr: 0x" << std::hex << vaddr << std::dec
                << ", TrueSrcSize: " << copy_size
                << ", AltSrcSize: " << alt_size
                << ", Copied: " << n
                << ", faults_injected: " << faults_injected_count
                << std::endl;
        }
        DPRINTF(LSQUnit, "CHAOSLSQFwd: fwd_source_sub wrong-source forward "
                "(vaddr=%#x true=%uB alt=%uB)\n", vaddr, copy_size, alt_size);
        return true;
    }

    Cycles
    CHAOSLSQFwd::maybeDelayForward(Addr vaddr, unsigned size)
    {
        // §2.4 F6 phase_offset (Phase 4.7, the REAL method3 forward-path
        // phase proxy): delay ONE forward's WritebackEvent by phaseOffset
        // CPU cycles. The method3 field signature ('add a no-op ALU ->
        // trigger rate collapses') is a forward-path timing race — the
        // load's writeback landing LATER than the dependent instruction's
        // read window (or vice versa) changes what the consumer sees.
        // Only active in PhaseOffset mode; other modes return Cycles(0)
        // (zero regression — the caller schedules at curTick() as usual).
        if (struct_mode != StructMode::PhaseOffset) return Cycles(0);
        if (probability <= 0.0f) return Cycles(0);
        if (max_faults != 0 && faults_injected_count >= max_faults)
            return Cycles(0);

        Cycles cur = cpu->curCycle();
        if (cur < first_clock) return Cycles(0);
        if (last_clock != Cycles(0) && cur > last_clock) return Cycles(0);

        // sampling-bias fix: skip budget consumed on eligible forwards
        if (count_only) { ++eligible_count; return Cycles(0); }
        if (events_to_skip > 0) { --events_to_skip; return Cycles(0); }

        std::uniform_real_distribution<float> dist(0.0f, 1.0f);
        if (dist(rng) >= probability) return Cycles(0);

        faults_injected_count++;
        stats->numFaultsInjected++;
        if (write_log) {
            *(log_stream->stream())
                << "Cycle: " << cpu->curCycle()
                << ", Site: store->load_forward_wb_schedule"
                << ", FaultType: phase_offset"
                << ", Vaddr: 0x" << std::hex << vaddr << std::dec
                << ", FwdSize: " << size
                << ", DelayCycles: +" << lane_skew_k
                << ", faults_injected: " << faults_injected_count
                << std::endl;
        }
        DPRINTF(LSQUnit, "CHAOSLSQFwd: phase_offset delay +%d cycles "
                "(vaddr=%#x)\n", lane_skew_k, vaddr);
        // reuse lane_skew_k as the offset knob (the --lsq_lane_skew_k CLI
        // arg; documented here as the phase offset in cycles)
        return Cycles(lane_skew_k > 0 ? lane_skew_k : 1);
    }

    CHAOSLSQFwd::CHAOSLSQFwdStats::CHAOSLSQFwdStats(statistics::Group *parent)
        : statistics::Group(parent),
          ADD_STAT(numFaultsInjected, statistics::units::Count::get(),
                   "Total forwarded-data faults injected"),
          ADD_STAT(numBitFlips, statistics::units::Count::get(),
                   "Bit-flip faults on forwarded data"),
          ADD_STAT(numStuckAtZero, statistics::units::Count::get(),
                   "Stuck-at-0 faults on forwarded data"),
          ADD_STAT(numStuckAtOne, statistics::units::Count::get(),
                   "Stuck-at-1 faults on forwarded data")
    {}

    bool
    CHAOSLSQFwd::maybeCorruptStoreData(uint8_t *data, unsigned size,
                                       uint64_t dyn_seq, uint64_t store_idx,
                                       uint64_t generation)
    {
        if (struct_mode != StructMode::Sq01Bit3 || !data || size == 0)
            return false;
        if (lsuTrigger) {
            lsuTrigger->onAttempt();
            if (!lsuTrigger->onEligible())
                return false;
        } else if (max_faults != 0 && faults_injected_count >= max_faults) {
            return false;
        }
        const uint8_t old_byte = data[0];
        const uint8_t new_byte = old_byte ^ 0x08;
        data[0] = new_byte;
        ++faults_injected_count;
        if (auto *prop = CHAOSPropagation::instance()) {
            prop->noteStoreDataInjection(dyn_seq, store_idx, generation,
                                         old_byte, new_byte, "sq01_bit3");
        }
        if (write_log && log_stream && log_stream->stream()) {
            *(log_stream->stream())
                << "Tick: " << curTick()
                << ", Site: lsq_write_sq_entry"
                << ", FaultType: sq01_bit3_flip"
                << ", seq: " << dyn_seq
                << ", sq_idx: " << store_idx
                << ", entry_generation: " << generation
                << ", old_byte0: 0x" << std::hex << (unsigned)old_byte
                << ", new_byte0: 0x" << (unsigned)new_byte << std::dec
                << ", faults_injected: " << faults_injected_count << std::endl;
        }
        return true;
    }

    bool
    CHAOSLSQFwd::maybeSuppressForwarding(uint64_t load_seq, uint64_t store_seq,
                                         Addr vaddr, unsigned size)
    {
        if (struct_mode != StructMode::F6Fw02) return false;
        ++f6_observed;
        if (f6_fired) return false;
        if (f6_event_ordinal && f6_observed != f6_event_ordinal) return false;
        if (max_faults != 0 && faults_injected_count >= max_faults)
            return false;
        // The caller reaches this point only inside the FullAddrRangeCoverage
        // branch, i.e. a real older-store/younger-load pair exists. That pair
        // IS the F6 trigger; suppress exactly this forwarding match.
        f6_fired = true;
        f6_load_seq = load_seq;
        f6_store_seq = store_seq;
        ++faults_injected_count;
        // v3.2 trace bridge: register the false-miss at the decision point.
        // The subsequent memory request/response for this load is matched by
        // (dyn_inst_seq, vaddr) and continues the normal L3 chain.
        last_fwd_ptag = 0;
        if (auto *prop = CHAOSPropagation::instance()) {
            last_fwd_ptag = prop->registerInjection(
                "lsq_fwd_decision", load_seq, vaddr, vaddr,
                true, size, size);
        }
        DPRINTF(LSQUnit,
                "CHAOSFW02: suppress forwarding load_sn:%llu store_sn:%llu "
                "addr:%#x size:%u\n",
                (unsigned long long)load_seq, (unsigned long long)store_seq,
                vaddr, size);
        if (write_log && log_stream && log_stream->stream()) {
            *(log_stream->stream())
                << "Tick: " << curTick()
                << ", Site: store->load_forward_decision"
                << ", FaultType: f6_fw02_suppress"
                << ", load_seq: " << load_seq
                << ", store_seq: " << store_seq
                << ", Vaddr: 0x" << std::hex << vaddr << std::dec
                << ", FwdSize: " << size
                << ", faults_injected: " << faults_injected_count
                << std::endl;
        }
        return true;
    }

    bool
    CHAOSLSQFwd::violationCorrupt(Addr& cmp_addr)
    {
        // [LSU][SEM-B] the violation site is L03's ONLY injection point;
        // non-L03 runs must not inject here (was: mixed into any lsqfwd run).
        if (!lsuTrigger || !l03_mode) return false;
        lsuTrigger->onAttempt();
        if (!lsuTrigger->onEligible()) return false;
        const uint64_t bit = rng() % 20;
        cmp_addr ^= (1ULL << bit);
        ++faults_injected_count;
        ++l0_funnel.injected;
        ++l0_funnel.activated;
        if (write_log && log_stream && log_stream->stream()) {
            *(log_stream->stream()) << "Cycle: " << cpu->curCycle()
                << ", Site: checkViolations_L03"
                << ", FaultType: violation_addr_bitflip"
                << ", faults_injected: " << faults_injected_count
                << std::endl;
        }
        return true;
    }

} // namespace gem5
