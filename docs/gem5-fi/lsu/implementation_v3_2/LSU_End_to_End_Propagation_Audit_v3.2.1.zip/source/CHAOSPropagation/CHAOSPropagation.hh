#ifndef __CPU_O3_CHAOS_PROPAGATION_HH__
#define __CPU_O3_CHAOS_PROPAGATION_HH__

// CHAOSPropagation — [LSU][OBS-L3] real L3 propagation-chain tracer for LSU
// non-PRF faults (central correction directive 2026-10-13: L3 must be a REAL
// propagation correlation, not commit-divergence counting and not a PRF
// liveness proxy). Observation-only for architectural state: it READS the
// fault-injection call path, the LSQ request/response path and the commit
// stream, and never writes any CPU state. The only writes are to
// prop_trace.csv.gz and its own registries/taint set.
//
// COVERED FAMILIES (v1): addrpath (CHAOSAddrPath, both the sendFragment
// post hook and the pushRequest PRE family) and cache (CHAOSCache data /
// data_shift field faults). lsqfwd / prefetch / exmod families are NOT
// wired — the driver does not pass --chaos_propagation for them and
// tools/lsu_l3_propagation.py reports them unsupported (honest).
//
// ============================ prop_trace.csv.gz v1 =========================
// First line (comment, exactly):
//   # lsu-propagation v1: node_id,tick,ptag,kind,dyn_inst_seq,request_id,
//   (continued) addr,phys_reg,arch_reg,detail
// Every following line is one CSV node:
//   node_id      sequential node counter, starts at 0
//   tick         curTick()
//   ptag         propagation tag (per-fault chain id, 1-based; 0 = rows not
//                bound to one chain, i.e. funnel rows)
//   kind         inj | addr_form | mem_req | resp | taint_reg | consumer |
//                errant_commit | funnel
//   dyn_inst_seq DynInst::seqNum of the involved dynamic instruction
//                ("" when not applicable)
//   request_id   Request::getReqInstSeqNum() — the request→dyn-inst binding
//                gem5 v25 actually maintains (gem5 v25 Request has NO unique
//                id(); CONTRACT DEVIATION, documented in the design doc)
//                ("" when not applicable / not stamped)
//   addr         hex, lowercase, no 0x prefix ("" when not applicable)
//   phys_reg     physical register index within its class
//                ("" when not applicable; the class is in detail k=v)
//   arch_reg     architectural register index ("" when not applicable)
//   detail       compact "k=v;k=v" fields, NO commas; numeric values are
//                decimal, address-bearing values are bare hex (no 0x)
// Numeric columns with no value are EMPTY STRINGS (never placeholders).
//
// kind semantics:
//   inj            the fault was injected (injector call site); detail
//                  carries site=, family=, mode/field=, old/new addrs...
//   addr_form      the erroneous address was formed (addrpath): addr column
//                  = new (corrupted) address; detail carries old_addr/new_addr
//   mem_req        a memory Request carrying the fault left the LSQ toward
//                  translation/memory (sendFragmentToTranslation); matched
//                  against the addr registry (addrpath: range overlap +
//                  dyn_inst_seq match) or the faulted-byte registry (cache:
//                  range overlap, SE vaddr==paddr assumption)
//   resp           the memory response delivering the fault returned to the
//                  CPU (completeDataAccess, pre-writeback); detail carries
//                  data_fnv (FNV-1a-64 of the response bytes) and fault=
//                  when the inst carries a fault
//   taint_reg      a load destination physical register received data
//                  delivered through the fault path and entered the taint
//                  set (resp + register writeback, completeDataAccess)
//   consumer       a committed instruction read a source phys reg in the
//                  taint set (Commit::commitHead anchor)
//   errant_commit  the FIRST commit on a fault path — either the faulting
//                  load itself committing its tainted dest, or the first
//                  consumer. Field-level "first wrong architectural commit"
//                  remains L2 commit_diff.first_errant_commit (authoritative);
//                  this node is the propagation-view alignment point.
//   funnel         attempted/eligible/injected funnel row (one per injection
//                  + one final per injector at exit); ptag=0. Written
//                  Z_SYNC_FLUSH-per-node so ABORTED runs keep the funnel
//                  (central requirement: abort samples must carry
//                  attempted/eligible).
//
// Crash durability (W2.1/W2.4 contract, CHAOSMicroSnap/CHAOSCommitTrace
// pattern): raw zlib gzFile at simout.resolve(trace_file) — NOT
// simout.create's gz streambuf. EVERY node is followed by
// gzflush(Z_SYNC_FLUSH), so an aborted run leaves every completed node
// readable (the file then lacks only the gzip trailer; the Python parser
// salvages the prefix and flags truncated=true). The trailer is written by
// gzclose in an exit callback (destructor is a backstop only — gem5's exit
// path does not reliably run SimObject destructors).
//
// Attachment (setter pattern, CHAOSCommitTrace/CHAOSMicroSnap): startup()
// dynamic_casts p.cpu to o3::CPU and sets BOTH
//   cpu->setChaosPropagation(this)          (LSQ-side hooks: lsq.cc,
//                                            lsq_unit.cc read it via
//                                            cpu->chaosPropagation)
//   cpu->o3Commit().setChaosPropagation(this) (commit.cc commitHead hook)
// CHAOSCache has no CPU pointer, so it reaches the tracer through the
// static instance() (single-core campaign; BaseCache::chaosVictimHook /
// chaosLsuF6Notify static-hook precedent).
//
// ===================== registries / taint set (v1 rules) ===================
// addr registry (addrpath): map<new_addr_base, {ptag, dyn_seq, size, tick}>.
//   A Request matches when [vaddr, vaddr+size) overlaps [base, base+size)
//   AND req->getReqInstSeqNum() == dyn_seq (the faulted request belongs to
//   the faulting instruction; replays of the same inst via savedRequest
//   legitimately re-match — the corrupted vaddr/addr is baked into the
//   reused LSQRequest). Entries expire addrExpiryTicks after registration
//   (lazy sweep on insert/lookup) to bound address-reuse misattribution.
// faulted-byte registry (cache): map over [byte_addr, byte_end) ranges
//   (single byte for data faults; whole block for data_shift; metadata
//   field faults tag/valid/dirty/coh and the victim path register NO range —
//   their chain honestly stops at the inj node).
// taint set: map<(classValue, phys idx), {ptag, taintor_seq}>.
//   + taint_reg at completeDataAccess (resp hit + needWBToRegister +
//     NoFault + not squashed — exactly the condition under which
//     LSQUnit::writeback performs completeAcc and writes the PRF).
//   + consumer at commitHead when a source phys reg is tainted.
//   + dest re-taint when a consumer commits (its dests carry the wrong
//     value onward); clean-overwrite erase when an UNRELATED producer
//     commits onto a tainted phys cell (the cell is rewritten with a fresh,
//     untainted value — bounds stale taint after phys-reg recycling).
//   + the tainting load's own commit keeps its dest taint (taintor_seq
//     match) — that commit IS the first architectural materialization.
//   Squash-race residual (documented): a load tainted at writeback then
//     squashed before commit can leave stale taint on a recycled phys reg;
//     the clean-overwrite rule bounds it; no squash hook in v1.
// errant_commit: once per run (first overall). Single-fault campaign
//   (maxFaults=1) ⇒ one ptag; multi-fault runs attribute the node to the
//   first involved chain (detail says which).

#include <zlib.h>

#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <utility>

#include "base/types.hh"
#include "mem/request.hh"          // RequestPtr (CHAOSAddrPath.hh precedent)
#include "params/CHAOSPropagation.hh"
#include "sim/sim_object.hh"
#include "base/output.hh"
#include "cpu/base.hh"
#include "cpu/reg_class.hh"

namespace gem5 { namespace o3 { class CPU; } }
namespace gem5 { namespace o3 { class DynInst; } }
namespace gem5 { class Packet; }

namespace gem5
{

class CHAOSPropagation : public SimObject
{
  public:
    CHAOSPropagation(const CHAOSPropagationParams &p);
    ~CHAOSPropagation();

    // CHAOSCache (no CPU pointer) reaches the tracer through this static
    // (single-instance assumption: single-core campaign; the static-hook
    // precedent is BaseCache::chaosVictimHook / chaosLsuF6Notify).
    static CHAOSPropagation *instance() { return chaos_instance; }

    void startup() override;

    // ---- injector-facing registration (fault-injection time) --------------
    // addrpath family: an AGU address fault just mutated a request address
    // (old_addr→new_addr; sizes as known at the site, 0 = unknown for the
    // post hook). Allocates a ptag, writes the inj + addr_form nodes and
    // registers [new_addr, new_addr+new_size) in the addr registry.
    // Returns the ptag (0 = tracer disabled / no-op).
    uint64_t registerInjection(const char *site, uint64_t dyn_inst_seq,
                               Addr old_addr, Addr new_addr, bool is_load,
                               unsigned old_size, unsigned new_size);

    // cache family: a CHAOSCache fault just landed on block_addr.
    //   byte_offset >= 0 : data fault on one byte (registry range =
    //                      [block+off, block+off+1))
    //   byte_offset == -1: whole-block fault (data_shift; registry range =
    //                      [block, block+block_size))
    //   byte_offset == -2: metadata field fault (tag/valid/dirty/coh) or the
    //                      victim path — inj node only, NO delivery tracking
    //                      (the chain honestly stops at inj).
    uint64_t registerCacheFault(Addr block_addr, int byte_offset,
                                Addr block_size, const char *field);

    // Funnel row (attempted/eligible/injected as of NOW). Called by the
    // injectors at every successful injection AND at their exit callbacks
    // (final counts). Per-node Z_SYNC_FLUSH ⇒ abort-survivable.
    void noteFunnel(const char *site, uint64_t attempted, uint64_t eligible,
                    uint64_t injected);

    // ---- pipeline hooks (read-only w.r.t. CPU state) -----------------------
    // LSQ::LSQRequest::sendFragmentToTranslation: the fragment Request is
    // about to leave for translation/memory. Writes a mem_req node when it
    // matches the addr registry (addrpath) or the faulted-byte registry
    // (cache).
    void noteMemRequest(const char *site, uint64_t dyn_inst_seq,
                        const RequestPtr &req, int64_t lq_idx = -1,
                        int64_t sq_idx = -1);

    // LSQUnit::completeDataAccess (pre-writeback, squashed-guarded inside):
    // writes a resp node when the packet delivers a registered fault, and —
    // for register-writeback loads/SC/atomics with NoFault — taint_reg nodes
    // for the dest phys regs (added to the taint set).
    void noteMemResponse(o3::DynInst *inst, Packet *pkt, bool wb_to_reg);

    // Commit::commitHead (the W2.1/W2.4 anchor): commit-side taint
    // propagation. consumer nodes for tainted source phys regs, first
    // errant_commit, dest re-taint / clean-overwrite.
    void noteCommit(ThreadID tid, o3::DynInst *head_inst);

    // Real LSQ lifecycle events. These are called only from actual
    // reschedule/squash sites, never inferred from ptag order.
    void noteReplay(o3::DynInst *inst, const char *reason);
    void noteSquash(o3::DynInst *inst, const char *reason);

    // Store-to-load forwarding decision. ptag=0 for an unfaulted normal
    // forward; the FW02 injection passes its registered ptag so the
    // decision is attached to the fault chain.
    void noteForwarding(uint64_t ptag, uint64_t load_seq, uint64_t store_seq,
                        Addr vaddr, unsigned size,
                        const uint8_t *store_data, unsigned store_size,
                        const uint8_t *fwd_data, unsigned fwd_size,
                        bool suppressed, bool memory_path);

  private:
    // One CSV row: numeric fields with has_x=false print as "".
    uint64_t writeNode(uint64_t ptag, const char *kind, uint64_t dyn_seq,
                   bool has_seq, uint64_t request_id, bool has_req_id,
                   Addr addr, bool has_addr, uint64_t phys_reg, bool has_phys,
                   uint64_t arch_reg, bool has_arch, const std::string &detail);

    void writeEdgeRow(uint64_t ptag, uint64_t source_node,
                      uint64_t destination_node, uint64_t producer_seq,
                      uint64_t consumer_seq, const std::string &source_hash,
                      const std::string &destination_hash,
                      const char *edge_type);

    std::string bytesToHex(const uint8_t *p, unsigned n) const;
    std::string regValueHash(o3::DynInst *inst, PhysRegIdPtr phys,
                             ThreadID tid, uint64_t *value_out,
                             unsigned *bytes_out) const;

    uint64_t fnv1a64(const void *blob, size_t n) const;
    const char *regClassName(int class_value) const;

    // Lazy expiry sweep (called on insert/lookup; registries are tiny).
    void sweepExpired();

    BaseCPU *cpu;
    o3::CPU *o3cpu = nullptr;      // resolved at startup(); nullptr = disabled
    std::string trace_file;        // simout.resolve target (.gz, self-managed)
    bool write_log;                // gate ALL tracking + writing
    uint64_t addr_expiry_ticks;    // registry entry lifetime (0 = never expire)
    gzFile gz_file = nullptr;      // raw zlib stream; crash-durability note

    static CHAOSPropagation *chaos_instance;

    uint64_t next_node_id = 0;
    uint64_t next_ptag = 0;        // 0 reserved ("no chain")
    uint64_t next_request_id = 0;
    uint64_t next_response_id = 0;
    uint64_t next_fragment_id = 0;
    uint64_t commit_seq = 0;
    bool errant_commit_seen = false;

    struct RequestMeta {
        uint64_t request_id;
        uint64_t fragment_id;
    };
    std::map<const Request *, RequestMeta> req_meta;
    std::set<uint64_t> fault_seqs;   // dynamic insts that received a fault
    std::map<uint64_t, uint64_t> resp_node_by_ptag;
    std::map<uint64_t, std::string> resp_hash_by_ptag;

    struct AddrEntry {
        uint64_t ptag;
        uint64_t dyn_seq;
        Addr base;
        Addr size;                 // 0 = address-only marker (never matches)
        Tick registered;
    };
    std::map<Addr, AddrEntry> addr_registry;

    struct BlkEntry {
        uint64_t ptag;
        Addr byte_begin;           // inclusive
        Addr byte_end;             // exclusive
        Tick registered;
    };
    std::map<Addr, BlkEntry> blk_registry;

    struct TaintEntry {
        uint64_t ptag;
        uint64_t taintor_seq;      // DynInst::seqNum of the tainting inst
        uint64_t node_id;          // taint_reg event node
        std::string value_hash;    // stable hash of the writeback value
    };
    std::map<std::pair<int, uint32_t>, TaintEntry> taint_set;
};

} // namespace gem5

#endif // __CPU_O3_CHAOS_PROPAGATION_HH__
