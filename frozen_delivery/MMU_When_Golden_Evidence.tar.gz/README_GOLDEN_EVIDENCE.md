# MMU When Golden Evidence — package index

Golden no-fault pre-scan / Control evidence for the 8×5×3 WHEN-5X3
campaign.  Every Control is one full-ROI no-fault gem5 run reused by all
three timings of the same (Model, Context).

Contents:
- `runs/W5X3/CTRL-*/` — Control manifests, raw `prop_evt.txt.gz`, terminal
  output and command.  `CTRL-M04-*-DECOY` are the decoy-PFN discovery runs
  required by the frozen M04 hook.
- `runs/W5X3/DISC-M01-*/` — M01 ASID-discovery runs (`--mmu_m01_asid -1`);
  the final Controls use the discovered exact ASID.
- `analysis/eligible_events/<ControlID>.csv` — complete eligible-event
  stream (ordinal, event id, tick, VA, ASID, key fields).
- `analysis/timing_map.csv` — N, ceil(0.1N/0.5N/0.9N), actual ordinal and
  selected event id for every fault sample.
- `analysis/controls.csv` — Control status, N and zero-activation proof.
- `analysis/per_condition.json`, `analysis/fault_control_compare.csv`.
- `provenance/A01_A02_A03_audit.json`.

Raw fault traces are under `runs/W5X3/M0*-F0-*/` on 0202 and are not
duplicated here.
