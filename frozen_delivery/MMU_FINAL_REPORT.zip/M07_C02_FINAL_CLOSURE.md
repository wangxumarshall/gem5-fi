# M07-C02 最终定向闭环

> **W5X3-OBS-0222 终态升级（2026-11-19）**：本文件（0202c）裁定 T01/T02 为
> REQUEST_PENDING_AT_ROI_END / PARTIAL。0222 轮通过 LSQ 翻译生命周期观测埋点
> （`mmuNoteLsqTranslationFinish`）在运行时证明请求确被 `squashTranslation()`
> 丢弃（dec=discard_due_to_prior_squash, released=1）并阻止进入 Cache，终态由此升级为
> **SQUASHED_BEFORE_MEMORY_ACCESS（FULL）**。权威终态见
> `M07_C02_T01_COMPLETE_PROPAGATION.md` / `M07_C02_T02_COMPLETE_PROPAGATION.md`。
> 下文保留 0202c 的技术闭环证据（walk-period squash、Request 对象身份、9+2 唯一请求
> 计数、PID/Episode 映射），其中「无 cache_request 即丢弃」现已被运行时事件直接证实。 — T01/T02 技术核查与终态裁定（含 PID/Episode 关联）

本文件是 M07-C02-T01/T02（样本 `M07-F0-W14-W5X3-C02-T01` / `...-T02`）最终闭环的
权威技术证据。结论为 **结果 B**：两条样本保留 **PARTIAL**
（`REQUEST_PENDING_AT_ROI_END`），不强行升为 FULL；给出充分技术证据与原因。

本版相对上一版新增：**(a)** 三个 Episode / 三个子进程 PID 与动态指令（DynInstSeq）
的映射恢复；(b) 埋点完整性统计修正（"10 条 load 完整走通" → 实为 **9 条完整 + 2 条
未完成**）；(c) 故障指令"页面游走期间被 squash"的直接证据及其三向对照（Fault /
Control / 非目标 load）；(d) 数据侧 `exception_delivery` 事件在此构建中本就缺省（Control
同样为 0 条），因此"无 exception_delivery"不是故障指令独有的判据。

## 1. 故障语义

- Where（冻结）：`mmu.cc::ArmISA::MMU::checkPermissions64`
- Mutation：权限授权判定反转（`grant` false → true），one-shot（单次授权判定）。
- 上下文：W14 R03（`read_exec_only`）—— EL0 对真实 PROT_EXEC execute-only 映射做
  `ldrb w0, [x19]`（PC=`0x401a54`，VA=`0x400d200000`），预期被拒 → SIGSEGV。

## 2. 观测埋点完整性（修正后）

eb327 构建（`eb327197c073dddf…`，M07-C02-T01/T02 的构建）的 Trace 已含完整 O3
LSQ/Cache/Commit/异常观测埋点。**修正后的唯一请求计数**（以 T01 为例，T02 结构相同）：

| 事件类别 | 唯一请求数（按 dyn_inst_seq / request_id） |
|---|---|
| `lsu_request`（LSU 请求） | **11** |
| `cache_request`（Cache 请求） | **9** |
| `memory_response`（内存响应） | **9** |
| 完整走通整条链的 load | **9** |
| 发出 lsu_request 但无 cache_request 的 load | **2** |

- 9 条完整链：`translation → … → permission_eval → translation_result(NoFault)
  → lsu_request → cache_request → mshr_alloc → cache_response → memory_response
  → rf_writeback → commit`。dyn_inst_seq =
  `23560322 / 24028466 / 24445150 / 26482959 / 26951646 / 27344442 /
   29133118 / 29616598 / 30014924`（含三条 setup read `24028466/26951646/29616598`
  在 `pc=0x4017a4`）。
- 2 条未完成：**故障指令 `seq=24118302`**（T01 目标）与 **非目标请求 `seq=30014904`**
  （T01 `translation_id=15`）。二者均发出 `lsu_request` 但无 `cache_request`，
  见 §3/§4 的 squash 证据。

> 上一版"10 条 load 完整走通"系把故障指令的 `lsu_request` 误计为"已发出即完成"。
> 以**唯一请求**计，完整为 9 条，未完成为 2 条。独立核查亦确认：每条相关 Trace 有
> 9 个唯一 request_id 具备 Cache Request 与 Memory Response，另有一个非目标请求
> `seq=30014904` 无 Cache Request。

## 3. 三个 Episode / 三个子进程 PID ↔ DynInstSeq 映射

rcS（`campaign/rcs/M07-C02.rcS`）循环 3 次执行 `/tmp/w5x3_workload --ctx R03`；
每次 `main()` 经 `run_one_ctx()` `fork()` 一个子进程执行 `child_run()`。因此每个
Episode 恰有一个子进程访问目标 VA `0x400d200000`，并打印其 `getpid()`。

**权威证据链**：

1. **PID（guest 侧）** — `board.terminal` 逐 Episode 打印：
   `W14_CHILD ctx=R03 pid=<N> …`，且 T01 与 T02 完全一致（确定性）：
   - Episode 1 → pid=**318**
   - Episode 2 → pid=**320**
   - Episode 3 → pid=**322**

2. **ASID（trace 侧）** — 每个子进程是独立地址空间，Trace 的 `translation_start`
   等事件携带 `asid`。三个子进程 ASID 依次为 **236 / 242 / 248**（单调递增，与
   Episode 顺序一致）。

3. **workload 结构（w14.c `child_run`）** — 每个子进程对目标 VA 恰好做两次 load：
   - `touch` load（mprotect 前，`pc=0x4017a4`，可写映射 → 成功，NoFault）；
   - `observed` load（mprotect 后，`pc=0x401a54`，execute-only → 拒绝）。
   两次 load 之间夹一次 mprotect 的 TLBI（`tlbi_invalidate asid=…`）。

4. **dyn_inst_seq（trace 侧）** — 三个子进程的 `observed` ldrb（`pc=0x401a54`）：

| Episode | PID (guest) | ASID (trace) | touch load (`pc=0x4017a4`) | observed ldrb (`pc=0x401a54`) |
|---|---|---|---|---|
| 1 | 318 | 236 | seq=24028466 (tid=3, NoFault) | **seq=24118302 (tid=4)** |
| 2 | 320 | 242 | seq=26951646 (tid=8, NoFault) | **seq=27030544 (tid=9)** |
| 3 | 322 | 248 | seq=29616598 (tid=13, NoFault) | **seq=29694101 (tid=14)** |

**故障放置**（one-shot、`mmu_eligible_event_index=1`，不同 Timing 选到不同 Episode 的
首条 `observed` load）：

- T01：故障落在 **Episode 1** 的 `seq=24118302`（asid=236，pid=318）。
- T02：故障落在 **Episode 2** 的 `seq=27030544`（asid=242，pid=320）。

**对应关系是否可由现有日志直接证明？** 是。PID↔ASID 不直接同号（一个是 Linux PID、
一个是硬件 ASID），但二者通过 **board.terminal 的 Episode 顺序** + **trace 的 ASID 单调
顺序** + **workload 每 Episode 恰 fork 一个子进程的结构** 建立 1:1 对应，且 T01/T02 双向
一致。无需新增观测字段、无需重编译。

## 4. 故障指令链（以 T01 为例，T02 结构相同）

T01 故障指令 `dyn_inst_seq=24118302`（`translation_id=4`，`asid=236`，`pc=0x401a54`，
`va=400d200000`，`tick=251412474528`）：

| event | kind | 说明 |
|---|---|---|
| 319 | translation_start | 翻译开始（tid=4） |
| 320–324 | tlb_lookup_miss ×2 / ptw_start / pte_read / ptw_request | 页表游走开始 |
| **325** | **squash** | **负载在游走期间被 squash**（`squash_status=squashed`，游走继续） |
| 326–341 | ptw_response / pte_decode / … / tlb_fill / tlb_entry_insert | 游走继续并完成、TLB 填充 |
| 342 | tlb_lookup_hit | 命中 |
| 343 | permission_eval | 真实授权判定 grant=false（拒） |
| 344 | mmu_eligible_selected | 故障选中该事件 |
| 345 | mmu_fault_activate | 反转 false→true（`fault_id=1`） |
| 346 | translation_result | `fault_status=NoFault`（反转后放行） |
| 347 | lsu_request | `pa=83496000`，翻译完成后移交 LSU |
| — | （无后续） | 无 cache_request / memory_response / rf_writeback / commit / 后续 squash / exception_delivered |

- `chain_end`（event 942）`parent_event_id=347`，链在 `lsu_request` 终止。
- `mmu_fault_summary`（event 944）：`outcome=activated_not_consumed`、
  `masked_reason=request_issued_not_completed_at_roi_end`、`consumed=0`、
  `exception_class=none`、`exception_delivered=0`、`faulting_inst_squashed=0`、
  `faulting_inst_squash_event_id=0`。

T02 故障指令 `dyn_inst_seq=27030544`（`translation_id=9`，`asid=242`，
`tick=252700191189`）：event 580(mmu_fault_activate) → 581(translation_result
NoFault) → 582(lsu_request)，同样无任何下游事件，且游走期间同样存在一次 squash。

> **Pre-activation Squash 与 `faulting_inst_squashed=0` 的阶段区分。** 本样本在 Fault
> Activation 之前存在一次 **Pre-activation Squash**（event 325，位于 Fault
> Activation=345 之前）：负载在页表游走期间被 squash（`squash_status=squashed`），
> 游走仍继续并完成。`mmu_fault_summary.faulting_inst_squashed=0` 只统计**故障激活之后**
> 观测到的 squash（`faulting_inst_squash_event_id=0`），**不能**用来否定原始 Trace 中
> 已经存在的这次 Pre-activation Squash。完整阶段序列为：**Pre-activation
> Squash（325）→ Fault Activation（345）→ Translation Completion/Result（346）→
> LSU Request（347）→ 被 squash 指令走 `squashTranslation()` 丢弃**（无
> Post-activation Squash / Cache Request / Architectural Exception Delivery）。
> 不能把 `faulting_inst_squashed=0` 解释为"该负载从未被 squash"。

### 4.1 关键判定：lsu_request ≠ 内存请求已发出（且负载已被 squash）

`lsu_request` 由 `mmu.cc::translateMmuOn` 的 `!delay` 完成块（`fault == NoFault &&
req->hasPaddr()`）发出，表示 **MMU 翻译完成、NoFault、即将把请求移交给 LSQ**，**不是**
内存请求已发往 Cache。真正的 Cache 请求由 `cache.cc::Cache::access()` 发 `cache_request`。

对故障指令 `seq=24118302` / `seq=27030544`，全 Trace **不存在** 任何
`cache_request`（`request_id==seq`）。根因是 O3 LSQ 的翻译完成回调
`LSQ::SingleDataRequest::finish`（`lsq.cc:988`）：当翻译完成时若
`_inst->isSquashed()` 为真，则走 `squashTranslation()`（`lsq.hh:609`，标记
`TranslationSquashed` 并自毁），**负载的 NoFault 翻译被丢弃、永不发往 Cache**。

### 4.2 关键判定：游走期间 squash 是通用 µarch 现象，非故障特有

故障指令游走期间的那次 squash（event 325）并非 M07 注入的特有结果，三向对照证明：

1. **Control `CTRL2-M07-C02`**（同 eb327 构建、无故障）：同一条 load `seq=24118302`
   游走期间**同样**出现一次 squash（`squash_status=squashed`），随后
   `translation_result(fault_status=Data)`（未注入，正常拒绝）。
2. **非目标 load `seq=30014904`**（T01 `tid=15`、`asid=246`，Episode 3 父进程，
   与故障无关）：同样"游走期间 squash → 游走完成 → `translation_result(NoFault)` +
   `lsu_request` → 无 `cache_request`"，与故障指令结构完全一致。

故"游走期间被 squash、lsu_request 后无 cache_request"是 O3 在 syscall/上下文切换边界
对投机负载的通用 replay/丢弃现象，故障指令恰好命中该现象，one-shot 授权反转被消耗在
一条已死（被 squash）的指令上——即 workload 源码注释所警示的
"the one-shot would be spent on a dead instruction"。

### 4.3 关键判定：数据侧 `exception_delivery` 事件在本构建中缺省

本构建的 Trace 中，**T01/T02 与 Control 的 `kind=exception_delivery` 事件数均为 0**。
`exception_delivery` 事件由 `commit.cc::commitHead`（`commit.cc:1266`）在**指令级取指
异常**到达 ROB 头时发出（M06 取指侧 DETECTED_DELIVERED 用此证据）；数据侧 Data Abort
的投递表现为 `translation_result(fault_status=Data)` + `squash`（`lsq_unit.cc:1208`），
并不产生独立 `exception_delivery` 事件。因此"故障指令无 exception_delivery"不能单独
作为"未发生异常"的判据——它同样适用于正常拒绝的 load（Control 亦然）。

## 5. 关键判定：故障确实改变了微架构路径（对照 Control）

同一构建（eb327）的 Control `CTRL2-M07-C02` 中，同一条 load（`seq=24118302`，
`asid=236`，`translation_id=4`）：
`permission_eval → translation_result(fault_status=Data)`（Data Abort），**无**
`lsu_request`（因为 `translateMmuOn` 仅在 `fault==NoFault` 时才发 `lsu_request`）。

即：Control 中该 load 被拒（Data Abort）；Fault 中该 load 被反转放行（NoFault +
lsu_request）。**故障确实改变了微架构翻译结果**——但改变没有推进到内存完成（被
squash 丢弃），因此没有形成被掩盖的 SDC。

## 6. 关键判定：Guest SIGSEGV 的来源（按 PID/Episode/PC/VA/DynInstSeq/异常事件）

Guest 每个 episode 报告 `W14_RESULT signal=11 si_code=2 fault_addr=0x400d200000
injected_success=0 result=PASS`（架构预期 SIGSEGV，`si_code=2`=SEGV_ACCERR=权限拒绝）。
逐条证据：

1. **故障动态指令不是 SIGSEGV 来源**（以 T01 为例）：
   - 故障指令 `seq=24118302` 得到 `translation_result(fault_status=NoFault)`（授权反转
     后放行），**无** Data Abort、**无** `exception_delivered`、**无** commit、**无**
     后续 squash，链在 `lsu_request` 终止。它本身**未**投递异常。
2. **未故障的架构拒绝路径是 ep2/ep3 的 SIGSEGV 来源（直接可证）**：
   - T01 中 `pc=0x401a54` 的另两条 `observed` ldrb：`seq=27030544`（ep2, asid=242）
     与 `seq=29694101`（ep3, asid=248）均为 `translation_result(fault_status=Data)`
     + `squash`——这两条未被故障（one-shot 已消耗），投递 Data Abort → SIGSEGV。
3. **故障 Episode（ep1）的 SIGSEGV 来源存在证据边界**：
   - 故障指令已证不是来源（见 1）；trace 中 ep1（asid=236）**不存在**第二次
     `permission_eval` / `translation_result`（无可见的 re-execution / retry）；
     `exception_delivery` 事件在本构建数据侧缺省（见 4.3）。
   - 最简一致的机制是：被 squash 的负载经架构重执行（re-execution），此时 one-shot
     已消耗、权限复判为拒绝 → Data Abort → SIGSEGV。该重执行的 Data Abort **未能**
     以独立的 `translation_result` 或 `exception_delivery` 事件在本构建 Trace 中直接
     观测到。

**结论**：不能简单声称"ep1 SIGSEGV 来自非故障重试"而不加限定；但可以**证伪**"来自
故障动态指令"（它得 NoFault）。ep2/ep3 的 SIGSEGV 来自未故障的架构拒绝路径（直接
可证）；ep1 的 SIGSEGV 来自故障指令之外的架构拒绝（重执行），其精确动态指令在当前
Trace 中不可直接观测——保留 PARTIAL，不强行 FULL。

## 7. 终态裁定

| 项 | 值 |
|---|---|
| 故障指令终点 | `lsu_request`（请求在 ROI 结束前未完成，且负载在游走期间被 squash） |
| 终态 | `REQUEST_PENDING_AT_ROI_END` |
| Completeness | PARTIAL（architecture 维度缺失 response/writeback/consumer/commit/异常投递） |
| masked_reason | `request_issued_not_completed_at_roi_end` |
| 结果 | **结果 B** — 保留 PARTIAL，不升 FULL |

技术原因：M07 one-shot 反转使翻译返回 NoFault 并发 `lsu_request`，但该 load 在页表
游走期间已被 squash（O3 投机负载在 syscall/上下文切换边界的通用 replay 现象，Control
与非目标 load 均复现），其 NoFault 翻译在 `SingleDataRequest::finish` 中被
`squashTranslation` 丢弃，故无 `cache_request`/response/writeback/commit/异常投递，
ROI 结束前未完成。one-shot 授权反转被消耗在一条已死指令上。Guest SIGSEGV 来自未故障
的架构拒绝路径（ep2/ep3 直接可证；ep1 的精确来源在当前 Trace 中不可直接观测）。

## 8. 溯源（SHA256）

- T01 trace：`runs/W5X3_RETRY2/M07-F0-W14-W5X3-RETRY2-C02-T01/Trace/prop_evt.txt.gz`
  SHA256 `6008835ce070acc18ea76282aa1f954284952ce3b72140416b64a87b3216f421`
- T02 trace：`runs/W5X3_RETRY2/M07-F0-W14-W5X3-RETRY2-C02-T02/Trace/prop_evt.txt.gz`
  SHA256 `6c88100bdcab0083ee3ed8ede201b1c05832c193c4ffedc097a861c0fe24cce5`
- build：`eb327197c073dddf039fdb63662d2cfa266394507ae0cb4630d0f4ff4dd76f65`
- Control：`CTRL2-M07-C02`（build `eb327197…`，disk/rcS/terminal 与 Fault 一致）
- 未重跑任何实验；未改变 Where/Context/Timing。
