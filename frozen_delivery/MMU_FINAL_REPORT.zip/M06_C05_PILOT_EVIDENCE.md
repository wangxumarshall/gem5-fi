# M06-C05 Pilot 证据（speculative wrong-path 可行性边界）

M06-C05（C05 = SPEC，3 条样本）冻结配置下判定为 **N/A**。本文件收录 Pilot 结果、
必要 Trace、运行命令与 SHA256，作为可行性边界的实证（不重跑 Pilot）。

## 结论

- **conclusion**：`INFEASIBLE_SPECULATIVE`
- 3 条 eligible 事件均为 **CORRECT-PATH**（架构、冷取指 PTW 走查，
  `mode=Execute`、`dyn_inst_seq=0`、translation 上无 squash）。
  `eligible_walks_squashed=0` —— 没有 speculative（wrong-path、被 flush）的冷走查形成。
- 根因：冻结的 O3 fetch 单元不会对 indirect-branch 目标做投机预测，故 mispredict
  构造从未产生 wrong-path 冷取指；一个自包含的 load 无法在**不改变模型/工作负载语义**
  的前提下让 O3 投机走查非顺序 mmap 页。

## 运行命令

```text
/home/sdc/gem5-fi-mmu-when5x3/CHAOS/gem5/build/ARM/gem5.opt --outdir /home/sdc/gem5-fi-mmu-when5x3/runs/pilot/M06-C05/run /home/sdc/gem5-fi-mmu-when5x3/configs/fs/lsu_b0_fs.py --kernel /home/sdc/gem5-fi-mmu-when5x3/gem5-fs/vmlinux --disk /home/sdc/gem5-fi-mmu-when5x3/runs/pilot/M06-C05/disk.img --bootloader /home/sdc/gem5-fi-mmu-when5x3/gem5-fs/boot.arm64 --cpu O3 --restore-checkpoint /home/sdc/gem5-fi-mmu-when5x3/runs/mmu_bootF1/cpt.244799013609 --readfile /home/sdc/gem5-fi-mmu-when5x3/runs/pilot/M06-C05/M06-C05.rcS --chaos_propagation --prop_mmu_va_lo 0x4001600000 --prop_mmu_va_hi 0x4001700000 --prop_run_id PILOT-M06-C05 --prop_sample_run_id PILOT-M06-C05 --prop_mmu_trace --prop_write_log on --mmu_fault_model M06 --mmu_fault_enable true --mmu_eligible_event_index 1 --mmu_prescan true --mmu_m02_dram_lo 0x80000000 --mmu_m02_dram_hi 0x100000000 --mmu_target_va 0x4001680000 --mmu_target_n 12 --mmu_target_mode Execute --mmu_target_walk_level 3
```

## 结果参数

- target_va `0x4001680000`；target_mode `Execute`；walk_level `3`
- eligible_total `3`；returncode `0`
- 工作负载 `workloads/mmu_w5x3/mmu_w15`

## SHA256

| 文件 | SHA256 |
|---|---|
| pilot_result.json | `b1458fa95aaa255ecad99f5571db6c9174aa7b082e34bb3083fe9777825df5f6` |
| M06-C05.rcS | `6174c4b25aba9d9f1a648134d7120e957b3291672c39d0ece8faa661e624e0d3` |
| Run_Log/command.txt | `f812579fd9f3a0fe00951f3f4bb8f0dcdb1372cd07d998c8f26eefa4012cb8a1` |
| Run_Log/board.terminal | `39b6c432189b31a395c3522faae93a4e9976b06e6c45672752473c524808bd6f` |
| Run_Log/gem5_stdout.log | `3ca9fc61033ebd96b8f5ae13f9b04efcc16c29b351ee508c33805fee38376523` |
| Trace/prop_evt.txt.gz | `58fb341ffc6f3a9a14d5e4cb55a07f02947620a0f29bf1900c897662184f9984` |
| build (gem5) | `741cdc567f4894448ed9aea08bcf9f9db2d65f42e089becac587890bfe9047b3` |
| workload mmu_w15 | `b079174eb6518ee4f821c22ee55d12cfa4c94e7de131d92d9093ff55d1231082` |