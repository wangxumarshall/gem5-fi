# MMU E2E V3 最终因果链重建、终态修正及证据验收 — 交付报告

Round 0202c-close · `gem5-fi-mmu-when5x3` · 2026-11-18

本轮只修正 V2 的因果重建与终态分类，不重新执行全部 120 条实验、不改冻结 Where/Context/Timing、无 git 操作。

## 1. 最终实验状态（120 条件）

| 维度 | 数量 |
|---|---|
| 总条件 | 120 |
| 已执行 (COMPLETE) | 117 |
| FULL | **115** |
| PARTIAL | **2** |
| N/A | 3（M06-C05）|

PARTIAL 仅来自两类真实边界：M07-C02-T01/T02（请求在 ROI 结束时未完成）与 M06-C05（冻结配置下 speculative wrong-path 可行性边界，N/A）。

### 逐模型

| Model | FULL | PARTIAL | N/A |
|---|---:|---:|---:|
| M01 | 15 | 0 | 0 |
| M02 | 15 | 0 | 0 |
| M03 | 15 | 0 | 0 |
| M04 | 15 | 0 | 0 |
| M05 | 15 | 0 | 0 |
| M06 | 12 | 0 | 3 |
| M07 | 13 | 2 | 0 |
| M08 | 15 | 0 | 0 |
| **Total** | **115** | **2** | 3 |

### 终态汇总

| TerminalState | Count |
|---|---:|
| SDC | 74 |
| ACTIVATED_MASKED | 15 |
| PROPAGATED_BUT_SQUASHED | 9 |
| DETECTED_DELIVERED | 9 |
| ACTIVATED_UNCONSUMED | 5 |
| DETECTED_LOCALLY | 3 |
| N/A | 3 |
| REQUEST_PENDING_AT_ROI_END | 2 |

## 2. M05 数据传播链（最高优先级）

M05-C03/C04/C05 共 9 条样本全部重新解析并纳入完整 Data Dependency DAG：partial entry → PTW → complete DTB entry → 暖命中 → memory_response → rf_writeback → data consumer (consumer_of) → consumer 自己的 commit。

| 样本 | 终态 | Response | Writeback | Consumer | ConsumerCommit |
|---|---|---|---|---|---|
| T01 | ACTIVATED_MASKED | 565 | 566 | 568 (consumer, consumer_of=24240476) | 569 (commit) |
| T02 | ACTIVATED_MASKED | 759 | 760 | 762 (consumer, consumer_of=26758134) | 763 (commit) |
| T03 | ACTIVATED_MASKED | 953 | 954 | 956 (consumer, consumer_of=29038984) | 957 (commit) |
| T01 | SDC | 551 | 552 | 557 (consumer, consumer_of=24239933) | 558 (commit) |
| T02 | SDC | 745 | 746 | 751 (consumer, consumer_of=26757836) | 752 (commit) |
| T03 | SDC | 932 | 933 | 938 (consumer, consumer_of=29035743) | 939 (commit) |
| T01 | SDC | 532 | 533 | 535 (consumer, consumer_of=24239743) | 536 (commit) |
| T02 | SDC | 726 | 727 | 729 (consumer, consumer_of=26757181) | 730 (commit) |
| T03 | SDC | 913 | 914 | 916 (consumer, consumer_of=29035016) | 917 (commit) |

- C03 消费者 PC=0x401c0c：读 decoy 0x51 后 `mov x25,#0` 丢弃（weak/dead consumer），故 observed=0x0、result=PASS —— 不是 SDC。

- C04 消费者 PC=0x401bb4：LDR→addr→二次 LDR，错误数据经 offset 派生二次 load 进入 W13_RESULT（observed=0x51, FAIL）。

- C05 消费者 PC=0x401b50：LDR→CMP→条件分支，0x51≠0x7d → branch=2, FAIL。

- 反汇编见 ZIP3 `disasm/W13_consumer_disasm.md`。

## 3. M05 Partial Entry → DTB Entry 状态传递

不再仅用 fault_id 建立 partial_entry_insert→tlb_entry_insert 关联；
现按 source_event_id / walk_id / request_id / parent_event_id 恢复完整 PTW 链：partial_entry_insert → fault_entry_reuse(source=partial) → ptw_start → pte_read → ptw_request → ptw_response → pte_decode → tlb_fill → tlb_entry_insert → reuse(source=insert)。见 causal_edges.csv 的 source_event_id / request_id / parent_event_id 边。

## 4. M07-C02 终态修正

> **W5X3-OBS-0222 终态升级（2026-11-19）**：M07-C02-T01/T02 通过纯观测埋点
> 在运行时证明完整故障→终止链，终态由 REQUEST_PENDING_AT_ROI_END（PARTIAL）升级为
> **SQUASHED_BEFORE_MEMORY_ACCESS（FULL）**。证据：`translation_response_received →
> squash_translation_decision(dec=discard_due_to_prior_squash, released=1) →
> squash_translation_invoked → translation_request_discarded(terminal_reason=
> prior_squash_before_translation_completion) → cache_dispatch_decision(
> cache_dispatch_blocked_by_squash)`，逐级 parent_event_id 相连、fault_id=1。新 Build
> `ce80a9c9…`；Fault/Control 复跑于 `runs/W5X3_OBS/`。详见
> `M07_C02_T01/T02_COMPLETE_PROPAGATION.md`。以下为历史（0202c 终态）分析，作为背景保留。
>
- M07-C02-T01/T02 不再误标 ACTIVATED_MASKED/FULL，改为 **REQUEST_PENDING_AT_ROI_END**（PARTIAL）：翻译已授权并发出 LSU 请求，但 ROI 结束前无 memory response / consumer / commit / 异常投递（masked_reason=request_issued_not_completed_at_roi_end）。故障指令得 `fault_status=NoFault`（授权反转），非 SIGSEGV 来源；ep2/ep3 SIGSEGV 来自未故障架构拒绝路径（`translation_result(Data)`+`squash`，直接可证）；故障 Episode 的 SIGSEGV 来自故障指令之外的架构拒绝（one-shot 消耗后），其精确动态指令在当前 Trace 中不可直接观测（数据侧无 exception_delivery 事件）。

- 定向闭环（埋点完整性按唯一请求计数）：同 Trace 内 **9 条 load** 完整走通 translation→lsu_request→cache_request→cache_response→memory_response→rf_writeback→commit（证明埋点完整），**2 条 load** 发出 `lsu_request` 但无 `cache_request` —— 故障指令 `seq=24118302`（T01）/`seq=27030544`（T02）与非目标请求 `seq=30014904`（T01 tid=15）。故障指令在页表游走期间已被 squash（`squash_status=squashed`，Control 与非目标 load 同结构复现），其 NoFault 翻译在 `SingleDataRequest::finish` 被 `squashTranslation` 丢弃，故请求未发往 Cache；Control `CTRL2-M07-C02` 中同一 load 为 `fault_status=Data`（证故障确实改变了微架构路径但未形成 SDC）。PID/Episode 关联：ep1/2/3 = pid 318/320/322 = asid 236/242/248。详见 `M07_C02_FINAL_CLOSURE.md`。

- M07-C02-T03（原构建）为真实 SDC（ep3 injected_success=1）。

- expected_stages() 不再把 M07/M08 非 Execute 的 Read consumer 误标为 N/A；并明确记录 ROI 截止边界。

## 5. Fault-Control 对照

- 建立 `analysis/control_map.json`，逐 (Model,Context) 记录 ControlRunID、build hash、trace SHA256、eligible N；`ControlID` 已从权威 `conditions.json` 按 SampleRunID 恢复（此前被误写为 CTRL-M08-C05）。

- `ControlRunID` 使用**实际运行目录名**（以 `ControlTraceSHA256` 逐样本 `sha256sum` 校验）：M02→`CTRL-M02-C0X-PFN`、M04-C01/03/04/05→`CTRL-M04-C0X-DECOY`、取指侧(M03-C02/M04-C02/M05-C02/M07-C05)→`CTRL2-*`、M05-C03/04/05→`CTRL2B-*`、M07-C02-T01/T02→`CTRL2-M07-C02`（T03→`CTRL-M07-C02`）。非后缀 `CTRL-M02-C0X`/`CTRL-M04-C0X` 为过期 stub（manifest 指向 -PFN/-DECOY trace 但自身盘上 trace 与注入目标参数不同），已排除。

- 构建选择：原构建 Fault→原 Control；eb327 Fault→CTRL2；fb1b M05-C03/04/05 → fb1b Control。

- A20 实际检查：build hash 之外，还逐样本核对 disk_sha256 / rcs_sha256 / config-kernel-bootloader-checkpoint / 共享运行参数（不再仅凭 build hash 声称 配置一致）。注入目标参数（mmu_m02_old_pfn、mmu_m04_decoy_pfn）为逐样本标定值；与正确标定 Control 比对后全部匹配（declared injection-target diff=0，此前 27 条系过期 stub Control 所致）。当前 A20=PASS；build-mismatch 0 条；config-mismatch 0 条

## 6. IFU 事件定义 + A19

- `ifu_response`=Fetch::processCacheCompletion；`ifu_decode`=Fetch::buildInst 的 DynInst 构建（Fetch 侧），**不等同** O3 `Decode::tick`。

- A19 验证真实 ifu_response / ifu_decode / commit 与 translation_id 关联，不再只检查 commit/squash 终点。A19=PASS。

## 7. Episode / ActualValue

- W13 多 Episode 逐条记录 observed/expected/result；ActualValue 取 FAIL Episode 的 observed（0x51），不被前一个 PASS 的 0x7d 覆盖。

## 8. 已知问题关闭矩阵

- `final_issue_closure.csv`（见 ZIP1）逐项记录 CLOSED / VERIFIED_BOUNDARY。

## 9. 验收

- A01–A22 见 `final_acceptance.md` / `acceptance.json`；`campaign/validate.py` 全部一致性检查通过。

- 全部派生 CSV/JSON/MD 由同一份最新数据重生成（finalize → export_evidence → acceptance → validate → gen_v2_delivery → gen_causal_dag）。
