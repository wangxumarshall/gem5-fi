# PARTIAL23 补全专项证据

原 23 条 PARTIAL：21 条补全为 FULL（取指 12 + M05 数据消费者 9），M07-C02-T01/T02 正确重分类为 REQUEST_PENDING_AT_ROI_END （PARTIAL，请求在 ROI 结束前未完成）。

## 取指传播链 (instruction-fetch IFU) (12 条)
- M03-C02
- M04-C02
- M05-C02
- M07-C05

## M05 错误提交消费者 (6 条)
- M05-C04
- M05-C05

## 掩盖路径 (masked) (3 条)
- M05-C03

## ROI 结束前请求未完成 (REQUEST_PENDING_AT_ROI_END, PARTIAL) (2 条)
- M07-C02

## 核查要点

- A (取指 12): Fault -> MMU Translation -> Execute Request -> IFU Response -> Decode -> Commit，以 translation_id + 真实 dyn_inst_seq 关联；合成 lsu_request 与真实 ifu_response 区分。
- B (M05 9): 错误 partial entry 身份 -> PTW -> complete DTB entry -> 暖命中消费者 -> memory_response -> rf_writeback -> data consumer(consumer_of) -> consumer commit。
- C (掩盖 3): M05-C03 weak/dead consumer 显式掩盖。
- D (ROI pending 2): M07-C02 请求在 ROI 结束前未完成，保留 PARTIAL（非 FULL/非 MASKED）。完整技术核查见交付根目录 `M07_C02_FINAL_CLOSURE.md`。
