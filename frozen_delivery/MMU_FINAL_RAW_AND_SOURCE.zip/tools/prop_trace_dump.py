#!/usr/bin/env python3
"""Compact prop_evt trace dumper for the WHEN5X3 MMU campaign.

Parses a PROP-EVT trace (gzip or plain) and prints a compact one-line-per-event
summary suitable for inspecting causal chains.  Keys of interest are selected
so a chain can be followed by translation_id / parent_event_id / dyn_inst_seq /
request_id / commit_seq without dumping 200 columns.
"""
import gzip
import sys

COLS = [
    "kind", "event_id", "parent_event_id", "fault_id", "translation_id",
    "request_id", "dyn_inst_seq", "commit_seq", "va", "pa", "mode",
    "tlb_instance", "tlb_entry_id", "entry_generation", "outcome",
    "commit_status", "squash_status", "state_consumed", "pfn",
    "consume_kind", "lineage_state", "reuse_ordinal",
]


def parse_header(line):
    assert line.startswith("#")
    # first field is "# prop-evt v1:", rest are space-separated field names
    toks = line.split()
    # drop the first two tokens: "#" and "prop-evt"
    return toks[2:]


def parse_line(line, fields):
    d = {}
    for tok in line.split():
        if "=" in tok:
            k, _, v = tok.partition("=")
            d[k] = v
    return d


def main(path):
    op = gzip.open if path.endswith(".gz") else open
    with op(path, "rt") as f:
        header = None
        for ln in f:
            ln = ln.rstrip("\n")
            if ln.startswith("#"):
                header = parse_header(ln)
                continue
            if not ln.startswith("PROP-EVT:"):
                continue
            body = ln[len("PROP-EVT:"):].strip()
            d = parse_line(body, header)
            parts = []
            for c in COLS:
                v = d.get(c, "")
                if v not in ("", "0", "none", "NoFault"):
                    parts.append(f"{c}={v}")
            print(" ".join(parts))


if __name__ == "__main__":
    main(sys.argv[1])