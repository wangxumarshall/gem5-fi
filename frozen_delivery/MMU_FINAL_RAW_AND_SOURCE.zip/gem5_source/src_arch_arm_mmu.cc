/*
 * Copyright (c) 2010-2013, 2016-2025 Arm Limited
 * All rights reserved
 *
 * The license below extends only to copyright in the software and shall
 * not be construed as granting a license to any other intellectual
 * property including but not limited to intellectual property relating
 * to a hardware implementation of the functionality of the software
 * licensed hereunder.  You may use the software subject to the license
 * terms below provided that you ensure that this notice is replicated
 * unmodified and in its entirety in all distributions of the software,
 * modified or unmodified, in source code or in binary form.
 *
 * Copyright (c) 2001-2005 The Regents of The University of Michigan
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "arch/arm/mmu.hh"

#include "arch/arm/isa.hh"
#include "arch/arm/mpam.hh"
#include "arch/arm/reg_abi.hh"
#include "arch/arm/self_debug.hh"
#include "arch/arm/stage2_lookup.hh"
#include "arch/arm/table_walker.hh"
#include "arch/arm/tlb.hh"
// [MDSPEC][H2] TLB translate unified event: reached through the static
// instance (CHAOSCache precedent — the MMU has no CPU pointer).
#include "cpu/o3/CHAOSPropagation/CHAOSPropagation.hh"
#include <cstdlib>
#include <cxxabi.h>
#include <sstream>
#include <typeinfo>
#include "arch/arm/tlbi_op.hh"
#include "arch/arm/types.hh"
#include "debug/MMU.hh"
#include "mem/packet_access.hh"
#include "params/ArmMMU.hh"
#include "sim/process.hh"
#include "sim/pseudo_inst.hh"

namespace gem5
{

using namespace ArmISA;

MMU::MMU(const ArmMMUParams &p)
    : BaseMMU(p),
      itbStage2(p.stage2_itb),
      dtbStage2(p.stage2_dtb),
      walker(p.walker),
      test(nullptr),
      miscRegContext(0),
      s1State(this, false),
      s2State(this, true),
      _attr(0),
      _release(nullptr),
      _hasWalkCache(false),
      stats(this)
{
    // Cache system-level properties
    if (FullSystem) {
        ArmSystem *arm_sys = dynamic_cast<ArmSystem *>(p.sys);
        assert(arm_sys);
        haveLargeAsid64 = arm_sys->haveLargeAsid64();
        physAddrRange = arm_sys->physAddrRange();

        _release = arm_sys->releaseFS();
    } else {
        haveLargeAsid64 = false;
        physAddrRange = 48;

        _release = p.release_se;
    }

    m5opRange = p.sys->m5opRange();
}

void
MMU::init()
{
    walker->setMmu(this);

    itbStage2->setTableWalker(walker);
    dtbStage2->setTableWalker(walker);
    getITBPtr()->setTableWalker(walker);
    getDTBPtr()->setTableWalker(walker);

    getDTBPtr()->setTableWalker(walker, true);

    BaseMMU::init();

    _hasWalkCache = checkWalkCache();
}

bool
MMU::checkWalkCache() const
{
    for (auto tlb : instruction) {
        if (static_cast<TLB*>(tlb)->walkCache())
            return true;
    }
    for (auto tlb : data) {
        if (static_cast<TLB*>(tlb)->walkCache())
            return true;
    }
    for (auto tlb : unified) {
        if (static_cast<TLB*>(tlb)->walkCache())
            return true;
    }

    return false;
}

void
MMU::drainResume()
{
    s1State.miscRegValid = false;
    s2State.miscRegValid = false;
}

ArmISA::TLB *
MMU::getDTBPtr() const
{
    return static_cast<ArmISA::TLB *>(dtb);
}

ArmISA::TLB *
MMU::getITBPtr() const
{
    return static_cast<ArmISA::TLB *>(itb);
}

TLB *
MMU::getTlb(BaseMMU::Mode mode, bool stage2) const
{
    if (mode == BaseMMU::Execute) {
        if (stage2)
            return itbStage2;
        else
            return getITBPtr();
    } else {
        if (stage2)
            return dtbStage2;
        else
            return getDTBPtr();
    }
}

TlbEntry *
MMU::translateFunctional(ThreadContext *tc, Addr va)
{
    CachedState& state = updateMiscReg(tc, NormalTran, false);

    auto tlb = getTlb(BaseMMU::Read, state.directToStage2);

    TlbEntry::KeyType lookup_data;

    lookup_data.va = va;
    lookup_data.asn = state.asid;
    lookup_data.ignoreAsn = false;
    lookup_data.vmid = state.vmid;
    lookup_data.ss = state.securityState;
    lookup_data.functional = true;
    lookup_data.targetRegime = state.currRegime;
    lookup_data.mode = BaseMMU::Read;

    return tlb->multiLookup(lookup_data);
}

bool
MMU::translateFunctional(ThreadContext *tc, Addr va, Addr &pa)
{
    if (TlbEntry *e = translateFunctional(tc, va); !e) {
        return false;
    } else {
        pa = e->pAddr(va);
        return true;
    }
}

void
MMU::invalidateMiscReg()
{
    s1State.miscRegValid = false;
    s1State.computeAddrTop.flush();
    s2State.computeAddrTop.flush();
}

namespace {

// [MMU-TRACE v1] Demangled TLBI operation class name.
std::string
mmuTlbiOpName(const TLBIOp &op)
{
    int status = 0;
    char *demangled = abi::__cxa_demangle(typeid(op).name(), nullptr, nullptr,
                                          &status);
    std::string out;
    if (status == 0 && demangled) {
        out = demangled;
        const size_t pos = out.rfind("::");
        if (pos != std::string::npos)
            out = out.substr(pos + 2);
    } else {
        out = "TLBI";
    }
    std::free(demangled);
    return out;
}

const char *
mmuModeName(BaseMMU::Mode mode)
{
    switch (mode) {
      case BaseMMU::Read:    return "Read";
      case BaseMMU::Write:   return "Write";
      case BaseMMU::Execute: return "Execute";
      default:               return "Unknown";
    }
}

} // anonymous namespace

uint64_t
MMU::beginTlbiTrace(const TLBIOp &tlbi_op)
{
    CHAOSPropagation *const prop = CHAOSPropagation::instance();
    if (!prop || !prop->mmuTraceEnabled())
        return 0;
    const uint64_t id = prop->mmuNewTlbiId();
    prop->mmuNoteTlbiIssue(id, mmuTlbiOpName(tlbi_op).c_str(),
                           tlbi_op.stage1Flush(), tlbi_op.stage2Flush());
    auto set_id = [&](const auto &tlbs) {
        for (auto *tlb : tlbs) {
            if (tlb)
                static_cast<TLB *>(tlb)->chaosTlbiId = id;
        }
    };
    set_id(instruction);
    set_id(data);
    set_id(unified);
    if (itbStage2)
        itbStage2->chaosTlbiId = id;
    if (dtbStage2)
        dtbStage2->chaosTlbiId = id;
    return id;
}

void
MMU::flush(const TLBIOp &tlbi_op)
{
    if (tlbi_op.stage1Flush()) {
        flushStage1(tlbi_op);
    }

    if (tlbi_op.stage2Flush()) {
        flushStage2(tlbi_op);
    }
}

void
MMU::flushStage1(const TLBIOp &tlbi_op)
{
    // TLBI VA/ASID ops call flushStage1 directly (tlbi_op.cc); the trace id
    // must be allocated here, not only in MMU::flush.
    beginTlbiTrace(tlbi_op);
    for (auto tlb : instruction) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
    for (auto tlb : data) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
    for (auto tlb : unified) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
}

void
MMU::flushStage2(const TLBIOp &tlbi_op)
{
    beginTlbiTrace(tlbi_op);
    itbStage2->flush(tlbi_op);
    dtbStage2->flush(tlbi_op);
}

void
MMU::iflush(const TLBIOp &tlbi_op)
{
    beginTlbiTrace(tlbi_op);
    for (auto tlb : instruction) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
    for (auto tlb : unified) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
}

void
MMU::dflush(const TLBIOp &tlbi_op)
{
    beginTlbiTrace(tlbi_op);
    for (auto tlb : data) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
    for (auto tlb : unified) {
        static_cast<TLB*>(tlb)->flush(tlbi_op);
    }
}

void
MMU::flushAll()
{
    BaseMMU::flushAll();
    itbStage2->flushAll();
    dtbStage2->flushAll();
}


Fault
MMU::testAndFinalize(const RequestPtr &req,
                     ThreadContext *tc, Mode mode,
                     TlbEntry* te, CachedState &state) const
{
    // If we don't have a valid tlb entry it means virtual memory
    // is not enabled
    auto domain = te ? te-> domain : DomainType::NoAccess;

    mpam::tagRequest(tc, req, mode == Execute);

    // Check for a tester generated address fault
    Fault fault = testTranslation(req, mode, domain, state);
    if (fault != NoFault) {
        return fault;
    } else {
        // Now that we checked no fault has been generated in the
        // translation process, we can finalize the physical address
        return finalizePhysical(req, tc, mode);
    }
}

Fault
MMU::finalizePhysical(const RequestPtr &req,
                      ThreadContext *tc, Mode mode) const
{
    const Addr paddr = req->getPaddr();

    if (m5opRange.contains(paddr)) {
        uint8_t func;
        pseudo_inst::decodeAddrOffset(paddr - m5opRange.start(), func);
        req->setLocalAccessor(
            [func, mode](ThreadContext *tc, PacketPtr pkt) -> Cycles
            {
                uint64_t ret;
                if (inAArch64(tc))
                    pseudo_inst::pseudoInst<RegABI64>(tc, func, ret);
                else
                    pseudo_inst::pseudoInst<RegABI32>(tc, func, ret);

                if (mode == Read)
                    pkt->setLE(ret);

                return Cycles(1);
            }
        );
    }

    return NoFault;
}


Fault
MMU::translateSe(const RequestPtr &req, ThreadContext *tc, Mode mode,
                 Translation *translation, bool &delay, bool timing,
                 CachedState &state)
{
    updateMiscReg(tc, NormalTran, state.isStage2);
    Addr vaddr_tainted = req->getVaddr();
    Addr vaddr = 0;
    if (state.aarch64) {
        vaddr = purifyTaggedAddr(vaddr_tainted, tc, state.exceptionLevel,
            static_cast<TCR>(state.ttbcr), mode==Execute, state);
    } else {
        vaddr = vaddr_tainted;
    }
    Request::Flags flags = req->getFlags();

    bool is_fetch = (mode == Execute);
    bool is_write = (mode == Write);

    if (!is_fetch) {
        if (state.sctlr.a || !(flags & AllowUnaligned)) {
            if (vaddr & mask(flags & AlignmentMask)) {
                // LPAE is always disabled in SE mode
                return std::make_shared<DataAbort>(
                    vaddr_tainted,
                    DomainType::NoAccess, is_write,
                    ArmFault::AlignmentFault, state.isStage2,
                    TranMethod::VmsaTran);
            }
        }
    }

    Process *p = tc->getProcessPtr();
    if (const auto pte = p->pTable->lookup(vaddr); !pte) {
        return std::make_shared<GenericPageTableFault>(vaddr_tainted);
    } else {
        req->setPaddr(pte->paddr + p->pTable->pageOffset(vaddr));

        if (pte->flags & EmulationPageTable::Uncacheable)
            req->setFlags(Request::UNCACHEABLE);

        return finalizePhysical(req, tc, mode);
    }
}

Addr
MMU::getValidAddr(Addr vaddr, ThreadContext *tc, Mode mode)
{
    auto& state = updateMiscReg(tc, NormalTran, false);
    Addr purified_vaddr = 0;
    if (state.aarch64) {
        purified_vaddr = purifyTaggedAddr(vaddr, tc, state.exceptionLevel,
            static_cast<TCR>(state.ttbcr), mode==Execute, state);
    } else {
        purified_vaddr = vaddr;
    }
    return purified_vaddr;
}

Fault
MMU::checkPermissions(TlbEntry *te, const RequestPtr &req, Mode mode,
                      bool stage2)
{
    return checkPermissions(te, req, mode, stage2 ? s2State : s1State);
}

Fault
MMU::checkPermissions(TlbEntry *te, const RequestPtr &req, Mode mode,
                      CachedState &state)
{
    // a data cache maintenance instruction that operates by MVA does
    // not generate a Data Abort exeception due to a Permission fault
    if (req->isCacheMaintenance()) {
        return NoFault;
    }

    Addr vaddr = req->getVaddr(); // 32-bit don't have to purify
    Request::Flags flags = req->getFlags();
    bool is_fetch  = (mode == Execute);
    bool is_write  = (mode == Write);
    bool is_priv   = state.isPriv && !(flags & UserMode);

    // Get the translation type from the actuall table entry
    TranMethod tran_method = te->longDescFormat ?
        TranMethod::LpaeTran : TranMethod::VmsaTran;

    // If this is the second stage of translation and the request is for a
    // stage 1 page table walk then we need to check the HCR.PTW bit. This
    // allows us to generate a fault if the request targets an area marked
    // as a device or strongly ordered.
    if (state.isStage2 && req->isPTWalk() && state.hcr.ptw &&
        (te->mtype != TlbEntry::MemoryType::Normal)) {
        return std::make_shared<DataAbort>(
            vaddr, te->domain, is_write,
            ArmFault::PermissionLL + te->lookupLevel,
            state.isStage2, tran_method);
    }

    // Generate an alignment fault for unaligned data accesses to device or
    // strongly ordered memory
    if (!is_fetch) {
        if (te->mtype != TlbEntry::MemoryType::Normal) {
            if (vaddr & mask(flags & AlignmentMask)) {
                stats.alignFaults++;
                return std::make_shared<DataAbort>(
                    vaddr, DomainType::NoAccess, is_write,
                    ArmFault::AlignmentFault, state.isStage2,
                    tran_method);
            }
        }
    }

    if (te->nonCacheable) {
        // Prevent prefetching from I/O devices.
        if (req->isPrefetch()) {
            // Here we can safely use the fault status for the short
            // desc. format in all cases
            return std::make_shared<PrefetchAbort>(
                vaddr, ArmFault::PrefetchUncacheable,
                state.isStage2, tran_method);
        }
    }

    if (!te->longDescFormat) {
        switch ((state.dacr >> (static_cast<uint8_t>(te->domain) * 2)) & 0x3) {
          case 0:
            stats.domainFaults++;
            DPRINTF(MMU, "MMU Fault: Data abort on domain. DACR: %#x"
                    " domain: %#x write:%d\n", state.dacr,
                    static_cast<uint8_t>(te->domain), is_write);
            if (is_fetch) {
                // Use PC value instead of vaddr because vaddr might
                // be aligned to cache line and should not be the
                // address reported in FAR
                return std::make_shared<PrefetchAbort>(
                    req->getPC(),
                    ArmFault::DomainLL + te->lookupLevel,
                    state.isStage2, tran_method);
            } else
                return std::make_shared<DataAbort>(
                    vaddr, te->domain, is_write,
                    ArmFault::DomainLL + te->lookupLevel,
                    state.isStage2, tran_method);
          case 1:
            // Continue with permissions check
            break;
          case 2:
            panic("UNPRED domain\n");
          case 3:
            return NoFault;
        }
    }

    // The 'ap' variable is AP[2:0] or {AP[2,1],1b'0}, i.e. always three bits
    uint8_t ap  = te->longDescFormat ? te->ap << 1 : te->ap;
    uint8_t hap = te->hap;

    if (state.sctlr.afe == 1 || te->longDescFormat)
        ap |= 1;

    bool abt;
    bool isWritable = true;
    // If this is a stage 2 access (eg for reading stage 1 page table entries)
    // then don't perform the AP permissions check, we stil do the HAP check
    // below.
    if (state.isStage2) {
        abt = false;
    } else {
        switch (ap) {
          case 0:
            DPRINTF(MMU, "Access permissions 0, checking rs:%#x\n",
                    (int)state.sctlr.rs);
            if (!state.sctlr.xp) {
                switch ((int)state.sctlr.rs) {
                  case 2:
                    abt = is_write;
                    break;
                  case 1:
                    abt = is_write || !is_priv;
                    break;
                  case 0:
                  case 3:
                  default:
                    abt = true;
                    break;
                }
            } else {
                abt = true;
            }
            break;
          case 1:
            abt = !is_priv;
            break;
          case 2:
            abt = !is_priv && is_write;
            isWritable = is_priv;
            break;
          case 3:
            abt = false;
            break;
          case 4:
            panic("UNPRED premissions\n");
          case 5:
            abt = !is_priv || is_write;
            isWritable = false;
            break;
          case 6:
          case 7:
            abt        = is_write;
            isWritable = false;
            break;
          default:
            panic("Unknown permissions %#x\n", ap);
        }
    }

    bool hapAbt = is_write ? !(hap & 2) : !(hap & 1);
    bool xn     = te->xn || (isWritable && state.sctlr.wxn) ||
                            (ap == 3    && state.sctlr.uwxn && is_priv);
    if (is_fetch && (abt || xn ||
                     (te->longDescFormat && te->pxn && is_priv) ||
                     (state.securityState == SecurityState::Secure &&
                        te->ns && state.scr.sif))) {
        stats.permsFaults++;
        DPRINTF(MMU, "MMU Fault: Prefetch abort on permission check. AP:%d "
                     "priv:%d write:%d ns:%d sif:%d sctlr.afe: %d \n",
                     ap, is_priv, is_write, te->ns,
                     state.scr.sif, state.sctlr.afe);
        // Use PC value instead of vaddr because vaddr might be aligned to
        // cache line and should not be the address reported in FAR
        return std::make_shared<PrefetchAbort>(
            req->getPC(),
            ArmFault::PermissionLL + te->lookupLevel,
            state.isStage2, tran_method);
    } else if (abt | hapAbt) {
        stats.permsFaults++;
        DPRINTF(MMU, "MMU Fault: Data abort on permission check. AP:%d priv:%d"
               " write:%d\n", ap, is_priv, is_write);
        return std::make_shared<DataAbort>(
            vaddr, te->domain, is_write,
            ArmFault::PermissionLL + te->lookupLevel,
            state.isStage2 | !abt, tran_method);
    }
    return NoFault;
}

Fault
MMU::checkPermissions64(TlbEntry *te, const RequestPtr &req, Mode mode,
                        ThreadContext *tc, bool stage2)
{
    return checkPermissions64(te, req, mode, tc, stage2 ? s2State : s1State);
}

Fault
MMU::checkPermissions64(TlbEntry *te, const RequestPtr &req, Mode mode,
                        ThreadContext *tc, CachedState &state)
{
    assert(state.aarch64);

    // A data cache maintenance instruction that operates by VA does
    // not generate a Permission fault unless:
    // * It is a data cache invalidate (dc ivac) which requires write
    //   permissions to the VA, or
    // * It is executed from EL0
    if (req->isCacheClean() && state.exceptionLevel != EL0 && !state.isStage2) {
        return NoFault;
    }

    Addr vaddr_tainted = req->getVaddr();
    Request::Flags flags = req->getFlags();
    bool is_fetch  = (mode == Execute);
    // Cache clean operations require read permissions to the specified VA
    bool is_write = !req->isCacheClean() && mode == Write;
    bool is_atomic = req->isAtomic();

    updateMiscReg(tc, state.curTranType, state.isStage2);

    // If this is the second stage of translation and the request is for a
    // stage 1 page table walk then we need to check the HCR.PTW bit. This
    // allows us to generate a fault if the request targets an area marked
    // as a device or strongly ordered.
    if (state.isStage2 && req->isPTWalk() && state.hcr.ptw &&
        (te->mtype != TlbEntry::MemoryType::Normal)) {
        return std::make_shared<DataAbort>(
            vaddr_tainted, te->domain, is_write,
            ArmFault::PermissionLL + te->lookupLevel,
            state.isStage2, TranMethod::LpaeTran);
    }

    // Generate an alignment fault for unaligned accesses to device or
    // strongly ordered memory
    if (!is_fetch) {
        if (te->mtype != TlbEntry::MemoryType::Normal) {
            if (vaddr_tainted & mask(flags & AlignmentMask)) {
                stats.alignFaults++;
                return std::make_shared<DataAbort>(
                    vaddr_tainted,
                    DomainType::NoAccess,
                    is_atomic ? false : is_write,
                    ArmFault::AlignmentFault, state.isStage2,
                    TranMethod::LpaeTran);
            }
        }
    }

    if (te->nonCacheable) {
        // Prevent prefetching from I/O devices.
        if (req->isPrefetch()) {
            // Here we can safely use the fault status for the short
            // desc. format in all cases
            return std::make_shared<PrefetchAbort>(
                vaddr_tainted,
                ArmFault::PrefetchUncacheable,
                state.isStage2, TranMethod::LpaeTran);
        }
    }

    bool grant = false;
    // grant_read is used for faults from an atomic instruction that
    // both reads and writes from a memory location. From a ISS point
    // of view they count as read if a read to that address would have
    // generated the fault; they count as writes otherwise
    bool grant_read = true;

    if (state.isStage2) {
        std::tie(grant, grant_read) = s2PermBits64(te, req, mode, tc, state,
            (!is_write && !is_fetch), is_write, is_fetch);
    } else {
        std::tie(grant, grant_read) = s1PermBits64(te, req, mode, tc, state,
            (!is_write && !is_fetch), is_write, is_fetch);
    }

    // [MMU-TRACE v1] Record the computed grant decision before the fault
    // branch. Observation only; the decision is unchanged.
    if (CHAOSPropagation *const prop = CHAOSPropagation::instance()) {
        if (prop->mmuTraceEnabled())
            prop->mmuNotePermission(req, vaddr_tainted, grant,
                                    mmuModeName(mode), state.isStage2);
    }

    // [MMU-PHASE3 / M07] Permission-grant decision inversion. Stage-1 only:
    // when the untouched permission evaluation above just denied the target
    // access, the one-shot M07 event flips the decision to grant and skips
    // the Permission Fault branch below. The translated PA is unchanged.
    // mmuNotePermission has already observed the REAL (deny) decision; the
    // activation event records the inversion explicitly and never feeds back
    // into the evaluation.
    if (!grant) {
        if (CHAOSPropagation *const m07_prop =
                CHAOSPropagation::instance()) {
            if (m07_prop->mmuFaultModelIs("M07") && !state.isStage2) {
                const uint64_t m07_seq = req->hasInstSeqNum()
                    ? req->getReqInstSeqNum() : 0;
                const char *const m07_mode =
                    is_atomic ? "Atomic" : mmuModeName(mode);
                if (m07_prop->mmuTargetKeyMatch(vaddr_tainted, te->asid,
                        (uint16_t)te->vmid, te->N,
                        (unsigned)te->regime, (unsigned)te->ss,
                        nullptr, -1, m07_mode) &&
                        m07_prop->mmuTargetSeqMatch(m07_seq) &&
                        m07_prop->mmuEligibleEvent(7, {
                            {"va", std::to_string(vaddr_tainted)},
                            {"asid", std::to_string(te->asid)},
                            {"vmid", std::to_string((unsigned)te->vmid)},
                            {"mode", m07_mode},
                            {"permission_before", "false"},
                            {"dyn_inst_seq", std::to_string(m07_seq)},
                        })) {
                    // A warm TLB hit has no miss-triggered transaction, so
                    // create the consumer transaction that owns this access
                    // before activating (0 when tracing is off).
                    uint64_t m07_tid =
                        m07_prop->mmuTxnForSeqVa(m07_seq, vaddr_tainted);
                    if (!m07_tid && m07_seq == 0) {
                        // [W5X3-OBS] Instruction-side (Execute) activation
                        // carries no DynInst seq.  Join the open synthetic
                        // fetch transaction by VA so the activation is
                        // causally linked (translation_id) to the same
                        // translation_result / Execute lsu_request instead of
                        // relying on a co-temporal tick match.  Observation-
                        // only: the grant inversion below is unchanged.
                        m07_tid = m07_prop->mmuTxnForVa(vaddr_tainted);
                    }
                    if (!m07_tid) {
                        m07_tid = m07_prop->mmuBeginConsumerTranslation(
                            m07_seq, vaddr_tainted, m07_mode, false,
                            state.asid, state.vmid,
                            (unsigned)state.currRegime,
                            (unsigned)state.securityState);
                    }
                    const uint64_t m07_ptag = m07_prop->mmuFaultActivate(
                        "M07", "mmu_checkPermissions64", m07_tid, m07_seq,
                        vaddr_tainted,
                        {
                         {"permission_before", "false"},
                         {"permission_after", "true"},
                         {"mode", m07_mode},
                         {"stage", "1"},
                         {"asid", std::to_string(te->asid)},
                         {"vmid", std::to_string((unsigned)te->vmid)},
                         {"regime", CHAOSPropagation::mmuRegimeName(
                             (unsigned)te->regime)},
                         {"security_state",
                             CHAOSPropagation::mmuSecurityStateName(
                                 (unsigned)te->ss)},
                        });
                    // Invert ONLY on a real one-shot activation; otherwise
                    // the normal Permission Fault is taken.
                    if (m07_ptag)
                        grant = true;
                }
            }
        }
    }

    if (!grant) {
        if (is_fetch) {
            stats.permsFaults++;
            DPRINTF(MMU, "MMU Fault: Prefetch abort on permission check. "
                    "ns:%d scr.sif:%d sctlr.afe: %d\n",
                    te->ns, state.scr.sif, state.sctlr.afe);
            // Use PC value instead of vaddr because vaddr might be aligned to
            // cache line and should not be the address reported in FAR
            return std::make_shared<PrefetchAbort>(
                req->getPC(),
                ArmFault::PermissionLL + te->lookupLevel,
                state.isStage2, TranMethod::LpaeTran);
        } else {
            stats.permsFaults++;
            DPRINTF(MMU, "MMU Fault: Data abort on permission check."
                    " ns:%d\n", te->ns);
            return std::make_shared<DataAbort>(
                vaddr_tainted, te->domain,
                (is_atomic && !grant_read) ? false : is_write,
                ArmFault::PermissionLL + te->lookupLevel,
                state.isStage2, TranMethod::LpaeTran);
        }
    }

    return NoFault;
}

std::pair<bool, bool>
MMU::s2PermBits64(TlbEntry *te, const RequestPtr &req, Mode mode,
                  ThreadContext *tc, CachedState &state, bool r, bool w, bool x)
{
    assert(ArmSystem::haveEL(tc, EL2) && state.exceptionLevel != EL2);

    // In stage 2 we use the hypervisor access permission bits.
    // The following permissions are described in ARM DDI 0487A.f
    // D4-1802
    bool grant = false;
    bool grant_read = te->hap & 0b01;
    bool grant_write = te->hap & 0b10;

    uint8_t xn =  te->xn;
    uint8_t pxn = te->pxn;

    if (ArmSystem::haveEL(tc, EL3) &&
        state.securityState == SecurityState::Secure &&
        te->ns && state.scr.sif) {
        xn = true;
    }

    DPRINTF(MMU,
            "Checking S2 permissions: hap:%d, xn:%d, pxn:%d, r:%d, "
            "w:%d, x:%d\n", te->hap, xn, pxn, r, w, x);

    if (x) {
        grant = !xn;
    } else if (req->isAtomic()) {
        grant = grant_read || grant_write;
    } else if (w) {
        grant = grant_write;
    } else if (r) {
        grant = grant_read;
    } else {
        panic("Invalid Operation\n");
    }

    return std::make_pair(grant, grant_read);
}

std::tuple<bool, bool, bool>
MMU::s1IndirectPermBits64(TlbEntry *te, const RequestPtr &req, Mode mode,
                          ThreadContext *tc, CachedState &state,
                          bool r, bool w, bool x)
{
    const bool is_priv = state.isPriv && !(req->getFlags() & UserMode);
    TranslationRegime regime = !is_priv ? TranslationRegime::EL10 :
                                          state.currRegime;

    bool wxn = false;
    uint8_t xn =  te->xn;
    uint8_t pxn = te->pxn;

    // Read PIR corresponding to target configuration.
    uint8_t piindex = te->piindex;
    uint8_t ppi = bits(state.pir, 4 * piindex + 3, 4 * piindex);
    uint8_t upi = bits(state.pire0, 4 * piindex + 3, 4 * piindex);

    DPRINTF(MMU, "Checking S1 indirect permissions: "
                 "piindex:%d, ppi:%d, xn:%d, pxn:%d, r:%d, "
                 "w:%d, x:%d, is_priv: %d, wxn: %d\n", piindex, ppi,
                 xn, pxn, r, w, x, is_priv, wxn);

    // Indirect permission check.
    // Decode indirect permissions
    bool pr = false;
    bool pw = false;
    bool px = false;
    bool p_wxn = ppi == 0b0110;
    switch (ppi) {
      // No access
      case 0b0000: pr = 0; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged read
      case 0b0001: pr = 1; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged execute
      case 0b0010: pr = 0; pw = 0; px = 1; /* pgcs = 0; */ break;
      // Privileged read and execute
      case 0b0011: pr = 1; pw = 0; px = 1; /* pgcs = 0; */ break;
      // Reserved
      case 0b0100: pr = 0; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged read and write
      case 0b0101: pr = 1; pw = 1; px = 0; /* pgcs = 0; */ break;
      // Privileged read, write and execute
      case 0b0110: pr = 1; pw = 1; px = 1; /* pgcs = 0; */ break;
      // Privileged read, write and execute
      case 0b0111: pr = 1; pw = 1; px = 1; /* pgcs = 0; */ break;
      // Privileged read
      case 0b1000: pr = 1; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged read and gcs
      case 0b1001: pr = 1; pw = 0; px = 0; /* pgcs = 1; */ break;
      // Privileged read and execute
      case 0b1010: pr = 1; pw = 0; px = 1; /* pgcs = 0; */ break;
      // Reserved
      case 0b1011: pr = 0; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged read and write
      case 0b1100: pr = 1; pw = 1; px = 0; /* pgcs = 0; */ break;
      // Reserved
      case 0b1101: pr = 0; pw = 0; px = 0; /* pgcs = 0; */ break;
      // Privileged read, write and execute
      case 0b1110: pr = 1; pw = 1; px = 1; /* pgcs = 0; */ break;
      // Reserved
      case 0b1111: pr = 0; pw = 0; px = 0; /* pgcs = 0; */ break;
    }

    bool grant_read;
    bool grant_write;
    bool grant_exec;
    if (hasUnprivRegime(regime)) {
        bool ur = false;
        bool uw = false;
        bool ux = false;
        bool u_wxn = upi == 0b0110;
        switch (upi) {
          // No access
          case 0b0000: ur = 0; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read
          case 0b0001: ur = 1; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged execute
          case 0b0010: ur = 0; uw = 0; ux = 1; /* ugcs = 0; */ break;
          // Unprivileged read and execute
          case 0b0011: ur = 1; uw = 0; ux = 1; /* ugcs = 0; */ break;
          // Reserved
          case 0b0100: ur = 0; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read and write
          case 0b0101: ur = 1; uw = 1; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read, write and execute
          case 0b0110: ur = 1; uw = 1; ux = 1; /* ugcs = 0; */ break;
          // Unprivileged read, write and execute
          case 0b0111: ur = 1; uw = 1; ux = 1; /* ugcs = 0; */ break;
          // Unprivileged read
          case 0b1000: ur = 1; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read and gcs
          case 0b1001: ur = 1; uw = 0; ux = 0; /* ugcs = 1; */ break;
          // Unprivileged read and execute
          case 0b1010: ur = 1; uw = 0; ux = 1; /* ugcs = 0; */ break;
          // Reserved
          case 0b1011: ur = 0; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read and write
          case 0b1100: ur = 1; uw = 1; ux = 0; /* ugcs = 0; */ break;
          // Reserved
          case 0b1101: ur = 0; uw = 0; ux = 0; /* ugcs = 0; */ break;
          // Unprivileged read,write and execute
          case 0b1110: ur = 1; uw = 1; ux = 1; /* ugcs = 0; */ break;
          // Reserved
          case 0b1111: ur = 0; uw = 0; ux = 0; /* ugcs = 0; */ break;
        }

        // PAN does not affect CMOs other than DC ZVA
        bool pan_access = !req->isCacheMaintenance() ||
            req->getFlags() & Request::CACHE_BLOCK_ZERO;

        if (_release->has(ArmExtension::FEAT_PAN) && pan_access) {
            if (state.cpsr.pan && upi != 0) {
                pr = false;
                pw = false;
            }
        }

        grant_read = is_priv ? pr : ur;
        grant_write = is_priv ? pw : uw;
        grant_exec = is_priv ? px : ux;
        wxn = is_priv ? p_wxn : u_wxn;
    } else {
        grant_read = pr;
        grant_write = pw;
        grant_exec = px;
        wxn = p_wxn;
    }

    // Do not allow execution from writable location
    // if wxn is set
    grant_exec = grant_exec && !(wxn && grant_write);

    if (ArmSystem::haveEL(tc, EL3) &&
        state.securityState == SecurityState::Secure && te->ns) {
        grant_exec = grant_exec && !state.scr.sif;
    }

    return std::make_tuple(grant_read, grant_write, grant_exec);
}

std::tuple<bool, bool, bool>
MMU::s1DirectPermBits64(TlbEntry *te, const RequestPtr &req, Mode mode,
                        ThreadContext *tc, CachedState &state,
                        bool r, bool w, bool x)
{
    const uint8_t ap  = te->ap & 0b11;  // 2-bit access protection field
    const bool is_priv = state.isPriv && !(req->getFlags() & UserMode);

    bool wxn = state.sctlr.wxn;
    uint8_t xn =  te->xn;
    uint8_t pxn = te->pxn;

    DPRINTF(MMU, "Checking S1 direct permissions: ap:%d, xn:%d, pxn:%d, r:%d, "
                 "w:%d, x:%d, is_priv: %d, wxn: %d\n", ap, xn,
                  pxn, r, w, x, is_priv, wxn);

    bool grant_read;
    bool grant_write;
    bool grant_exec;

    TranslationRegime regime = !is_priv ? TranslationRegime::EL10 :
                                          state.currRegime;
    // Tranditional permission check.
    if (hasUnprivRegime(regime)) {
        bool pr = false;
        bool pw = false;
        bool ur = false;
        bool uw = false;
        // Apply leaf permissions
        switch (ap) {
          case 0b00: // Privileged access
            pr = 1; pw = 1; ur = 0; uw = 0;
            break;
          case 0b01: // No effect
            pr = 1; pw = 1; ur = 1; uw = 1;
            break;
          case 0b10: // Read-only, privileged access
            pr = 1; pw = 0; ur = 0; uw = 0;
            break;
          case 0b11: // Read-only
            pr = 1; pw = 0; ur = 1; uw = 0;
            break;
        }

        // Locations writable by unprivileged cannot be executed by
        // privileged
        const bool px = !(pxn || uw);
        const bool ux = !xn;

        // PAN does not affect CMOs other than DC ZVA
        bool pan_access = !req->isCacheMaintenance() ||
            req->getFlags() & Request::CACHE_BLOCK_ZERO;

        if (_release->has(ArmExtension::FEAT_PAN) && pan_access) {
            bool pan = state.cpsr.pan && (ur || uw);
            pr = pr && !pan;
            pw = pw && !pan;
        }

        grant_read = is_priv ? pr : ur;
        grant_write = is_priv ? pw : uw;
        grant_exec = is_priv ? px : ux;
    } else {
        switch (bits(ap, 1)) {
          case 0b0: // No effect
            grant_read = 1; grant_write = 1;
            break;
          case 0b1: // Read-Only
            grant_read = 1; grant_write = 0;
            break;
        }
        grant_exec = !xn;
    }

    // Do not allow execution from writable location
    // if wxn is set
    grant_exec = grant_exec && !(wxn && grant_write);

    if (ArmSystem::haveEL(tc, EL3) &&
        state.securityState == SecurityState::Secure && te->ns) {
        grant_exec = grant_exec && !state.scr.sif;
    }

    return std::make_tuple(grant_read, grant_write, grant_exec);
}

std::pair<bool, bool>
MMU::s1PermBits64(TlbEntry *te, const RequestPtr &req, Mode mode,
                  ThreadContext *tc, CachedState &state,
                  bool r, bool w, bool x)
{
    bool grant = false;
    bool grant_read = true, grant_write = true, grant_exec = true;

    // Check the feature of indirected premission.
    if (state.pie) {
        std::tie(grant_read, grant_write, grant_exec) =
            s1IndirectPermBits64(te, req, mode, tc, state, r, w, x);
    } else {
        std::tie(grant_read, grant_write, grant_exec) =
            s1DirectPermBits64(te, req, mode, tc, state, r, w, x);
    }

    if (x) {
        grant = grant_exec;
    } else if (req->isAtomic()) {
        grant = grant_read && grant_write;
    } else if (w) {
        grant = grant_write;
    } else {
        grant = grant_read;
    }

    return std::make_pair(grant, grant_read);
}

bool
MMU::hasUnprivRegime(TranslationRegime regime)
{
    switch (regime) {
      case TranslationRegime::EL10:
      case TranslationRegime::EL20:
        return true;
      default:
        return false;
    }
}

Addr
MMU::purifyTaggedAddr(Addr vaddr_tainted, ThreadContext *tc,
                      ExceptionLevel el,
                      TCR tcr, bool is_inst, CachedState& state)
{
    const bool selbit = bits(vaddr_tainted, 55);

    // Call the memoized version of computeAddrTop
    const auto topbit = state.computeAddrTop(tc, selbit, is_inst, tcr, el);

    return maskTaggedAddr(vaddr_tainted, tc, el, topbit);
}

Fault
MMU::translateMmuOff(ThreadContext *tc, const RequestPtr &req, Mode mode,
        ArmTranslationType tran_type, Addr vaddr, bool long_desc_format,
        CachedState &state)
{
    bool is_fetch  = (mode == Execute);
    bool is_atomic = req->isAtomic();
    req->setPaddr(vaddr);
    // When the MMU is off the security attribute corresponds to the
    // security state of the processor
    if (state.securityState == SecurityState::Secure)
        req->setFlags(Request::SECURE);
    else
        req->clearFlags(Request::SECURE);
    if (state.aarch64) {
        bool selbit = bits(vaddr, 55);
        TCR tcr1 = tc->readMiscReg(MISCREG_TCR_EL1);
        int topbit = computeAddrTop(tc, selbit, is_fetch, tcr1, currEL(tc));
        int addr_sz = bits(vaddr, topbit, physAddrRange);
        if (addr_sz != 0){
            Fault f;
            if (is_fetch)
                f = std::make_shared<PrefetchAbort>(vaddr,
                    ArmFault::AddressSizeLL, state.isStage2,
                    TranMethod::LpaeTran);
            else
                f = std::make_shared<DataAbort>( vaddr,
                    DomainType::NoAccess,
                    is_atomic ? false : mode==Write,
                    ArmFault::AddressSizeLL, state.isStage2,
                    TranMethod::LpaeTran);
            return f;
        }
    }

    // @todo: double check this (ARM ARM issue C B3.2.1)
    if (long_desc_format || state.sctlr.tre == 0 || state.nmrr.ir0 == 0 ||
        state.nmrr.or0 == 0 || state.prrr.tr0 != 0x2) {
        if (!req->isCacheMaintenance()) {
            req->setFlags(Request::UNCACHEABLE);
        }
        req->setFlags(Request::STRICT_ORDER);
    }

    // Set memory attributes
    bool in_secure_state = state.securityState == SecurityState::Secure;
    TlbEntry temp_te;
    temp_te.ns = !in_secure_state;
    bool dc = (HaveExt(tc, ArmExtension::FEAT_VHE) &&
               state.hcr.e2h == 1 && state.hcr.tge == 1) ? 0: state.hcr.dc;
    bool i_cacheability = state.sctlr.i && !state.sctlr.m;
    if (state.isStage2 || !dc || state.exceptionLevel == EL2) {
        temp_te.mtype      = is_fetch ? TlbEntry::MemoryType::Normal
                                      : TlbEntry::MemoryType::StronglyOrdered;
        temp_te.innerAttrs = i_cacheability? 0x2: 0x0;
        temp_te.outerAttrs = i_cacheability? 0x2: 0x0;
        temp_te.shareable  = true;
        temp_te.outerShareable = true;
    } else {
        temp_te.mtype      = TlbEntry::MemoryType::Normal;
        temp_te.innerAttrs = 0x3;
        temp_te.outerAttrs = 0x3;
        temp_te.shareable  = false;
        temp_te.outerShareable = false;
    }
    temp_te.setAttributes(long_desc_format);
    DPRINTF(MMU, "(No MMU) setting memory attributes: shareable: "
            "%d, innerAttrs: %d, outerAttrs: %d, stage2: %d\n",
            temp_te.shareable, temp_te.innerAttrs, temp_te.outerAttrs,
            state.isStage2);
    setAttr(temp_te.attributes);

    return testAndFinalize(req, tc, mode, nullptr, state);
}

Fault
MMU::translateMmuOn(ThreadContext* tc, const RequestPtr &req, Mode mode,
                    Translation *translation, bool &delay, bool timing,
                    bool functional, Addr vaddr,
                    TranMethod tran_method, CachedState &state)
{
    TlbEntry *te = NULL;
    bool is_fetch  = (mode == Execute);
    TlbEntry mergeTe;

    Request::Flags flags = req->getFlags();
    Addr vaddr_tainted = req->getVaddr();

    Fault fault = getResultTe(&te, req, tc, mode, translation, timing,
                              functional, &mergeTe, state);
    // only proceed if we have a valid table entry
    if (!isCompleteTranslation(te) && (fault == NoFault)) delay = true;

    // If we have the table entry transfer some of the attributes to the
    // request that triggered the translation
    if (isCompleteTranslation(te)) {
        // Set memory attributes
        DPRINTF(MMU,
                "Setting memory attributes: shareable: %d, innerAttrs: %d, "
                "outerAttrs: %d, mtype: %d, stage2: %d\n",
                te->shareable, te->innerAttrs, te->outerAttrs,
                static_cast<uint8_t>(te->mtype), state.isStage2);
        setAttr(te->attributes);

        if (te->nonCacheable && !req->isCacheMaintenance())
            req->setFlags(Request::UNCACHEABLE);

        // Require requests to be ordered if the request goes to
        // strongly ordered or device memory (i.e., anything other
        // than normal memory requires strict order).
        if (te->mtype != TlbEntry::MemoryType::Normal)
            req->setFlags(Request::STRICT_ORDER);

        Addr pa = te->pAddr(vaddr);
        req->setPaddr(pa);

        if (state.securityState == SecurityState::Secure && !te->ns) {
            req->setFlags(Request::SECURE);
        } else {
            req->clearFlags(Request::SECURE);
        }
        if (!is_fetch && fault == NoFault &&
            (vaddr & mask(flags & AlignmentMask)) &&
            (te->mtype != TlbEntry::MemoryType::Normal)) {
                // Unaligned accesses to Device memory should always cause an
                // abort regardless of sctlr.a
                stats.alignFaults++;
                bool is_write  = (mode == Write);
                fault = std::make_shared<DataAbort>(
                    vaddr_tainted,
                    DomainType::NoAccess, is_write,
                    ArmFault::AlignmentFault, state.isStage2,
                    tran_method);
        }

        if (fault == NoFault)
            fault = testAndFinalize(req, tc, mode, te, state);

        // [MMU-PHASE3 / M08] Final request-PA corruption. This runs ONLY
        // after a complete translation AND a successful permission /
        // alignment check, and it changes ONLY the outgoing Request's
        // physical address. The TLB entry, its PFN and the page-table PTE
        // stay correct (old_pfn == new_pfn is recorded as proof).
        if (fault == NoFault) {
            CHAOSPropagation *const pa_prop =
                CHAOSPropagation::instance();
            if (pa_prop && pa_prop->mmuFaultModelIs("M08")) {
                const uint64_t pa_seq = req->hasInstSeqNum()
                    ? req->getReqInstSeqNum() : 0;
                // A translation whose instruction was already squashed is
                // wrong-path: its request PA is never consumed, so spending
                // the one-shot injection there would mask a real context
                // (observed for M08 R02-R04). Wait for the first live
                // translation of the target instead.
                if (!pa_prop->mmuSeqSquashed(pa_seq) &&
                        pa_prop->mmuTargetSeqMatch(pa_seq) &&
                        pa_prop->mmuTargetKeyMatch(vaddr, te->asid,
                            (uint16_t)te->vmid, te->N,
                            (unsigned)te->regime, (unsigned)te->ss,
                            nullptr, -1, mmuModeName(mode))) {
                    const Addr new_pa = pa ^ pa_prop->mmuM08PaXorMask();
                    if (new_pa >= pa_prop->mmuPaDomainLo() &&
                            new_pa < pa_prop->mmuPaDomainHi() &&
                            pa_prop->mmuEligibleEvent(8, {
                                {"va", std::to_string(vaddr)},
                                {"asid", std::to_string(te->asid)},
                                {"vmid", std::to_string((unsigned)te->vmid)},
                                {"old_pa", std::to_string(pa)},
                                {"new_pa", std::to_string(
                                    pa ^ pa_prop->mmuM08PaXorMask())},
                                {"tlb_entry_id",
                                    std::to_string(te->chaosEntryId)},
                                {"page_size_n", std::to_string(te->N)},
                                {"mode", mmuModeName(mode)},
                            })) {
                        const auto hexs = [](Addr v) {
                            std::ostringstream os;
                            os << "0x" << std::hex << v;
                            return os.str();
                        };
                        pa_prop->mmuFaultActivate("M08",
                            "mmu_translate_set_paddr", 0, pa_seq, vaddr,
                            {
                             {"old_pa", hexs(pa)},
                             {"new_pa", hexs(new_pa)},
                             {"pa", hexs(new_pa)},
                             {"request_pa_before", hexs(pa)},
                             {"request_pa_after", hexs(new_pa)},
                             {"old_pfn", hexs(te->pfn)},
                             {"new_pfn", hexs(te->pfn)},
                             {"tlb_entry_id",
                                 std::to_string(te->chaosEntryId)},
                             {"entry_generation",
                                 std::to_string(te->chaosEntryGeneration)},
                             {"page_size_n", std::to_string(te->N)},
                             {"stage", state.isStage2 ? "2" : "1"},
                             {"mode", mmuModeName(mode)},
                            });
                        req->setPaddr(new_pa);
                    }
                }
            }
        }
    }

    // [MDSPEC][T-series] Close an injected lookup only after the MMU has
    // materialized the effective PA and run permission/alignment checks.
    // A delayed walk is intentionally left pending; T08-a closes itself at
    // the observed drop point because no completion callback can follow.
    if (!delay) {
        CHAOSPropagation *tlb_prop = CHAOSPropagation::instance();
        if (tlb_prop && req && req->hasVaddr()) {
            tlb_prop->noteTlbTranslationResult(
                req->hasInstSeqNum() ? req->getReqInstSeqNum() : 0,
                vaddr, req->hasPaddr(), req->hasPaddr() ? req->getPaddr() : 0,
                fault != NoFault ? fault->name() : "NoFault");

            // [MMU-TRACE v1] Materialized translation result + outgoing LSU
            // request. TLB entry fields are the real selected entry.
            if (tlb_prop->mmuTraceEnabled() && isCompleteTranslation(te)) {
                tlb_prop->mmuNoteTranslationResult(
                    req, vaddr,
                    req->hasPaddr() ? req->getPaddr() : 0, req->hasPaddr(),
                    fault != NoFault ? fault->name() : "NoFault", te->pfn,
                    te->N, (uint8_t)te->mtype, te->shareable, te->innerAttrs,
                    te->outerAttrs, te->nonCacheable, te->xn, te->ap,
                    te->chaosEntryId, te->chaosEntryGeneration);
                if (fault == NoFault && req->hasPaddr())
                    tlb_prop->mmuNoteLsuRequest(
                        req, vaddr, req->getPaddr(), mmuModeName(mode),
                        mode == Execute, true);
            }
        }
    }
    return fault;
}

Fault
MMU::translateFs(const RequestPtr &req, ThreadContext *tc, Mode mode,
        Translation *translation, bool &delay, bool timing,
        ArmTranslationType tran_type, bool functional,
        CachedState &state)
{
    // No such thing as a functional timing access
    assert(!(timing && functional));

    Addr vaddr_tainted = req->getVaddr();
    Addr vaddr = 0;
    if (state.aarch64) {
        vaddr = purifyTaggedAddr(vaddr_tainted, tc, state.exceptionLevel,
            static_cast<TCR>(state.ttbcr), mode==Execute, state);
    } else {
        vaddr = vaddr_tainted;
    }
    Request::Flags flags = req->getFlags();

    bool is_fetch  = (mode == Execute);
    bool is_write  = (mode == Write);
    bool long_desc_format = state.aarch64 || longDescFormatInUse(tc);
    TranMethod tran_method = long_desc_format ?
        TranMethod::LpaeTran : TranMethod::VmsaTran;

    DPRINTF(MMU,
            "CPSR is priv:%d UserMode:%d secure:%d S1S2NsTran:%d\n",
            state.isPriv, flags & UserMode,
            state.securityState == SecurityState::Secure,
            tran_type & S1S2NsTran);

    DPRINTF(MMU, "translateFs addr %#x, mode %d, st2 %d, scr %#x sctlr %#x "
                 "flags %#lx tranType 0x%x\n", vaddr_tainted, mode,
                 state.isStage2, state.scr, state.sctlr, flags, tran_type);

    if (!state.isStage2) {
        if ((req->isInstFetch() && (!state.sctlr.i)) ||
            ((!req->isInstFetch()) && (!state.sctlr.c))){
            if (!req->isCacheMaintenance()) {
                req->setFlags(Request::UNCACHEABLE);
            }
            req->setFlags(Request::STRICT_ORDER);
        }
    }
    if (!is_fetch) {
        if (state.sctlr.a || !(flags & AllowUnaligned)) {
            if (vaddr & mask(flags & AlignmentMask)) {
                stats.alignFaults++;
                return std::make_shared<DataAbort>(
                    vaddr_tainted,
                    DomainType::NoAccess, is_write,
                    ArmFault::AlignmentFault, state.isStage2,
                    tran_method);
            }
        }
    }

    bool vm = state.hcr.vm;
    if (HaveExt(tc, ArmExtension::FEAT_VHE) &&
        state.hcr.e2h == 1 && state.hcr.tge == 1)
        vm = 0;
    else if (state.hcr.dc == 1)
        vm = 1;

    Fault fault = NoFault;
    // If guest MMU is off or hcr.vm=0 go straight to stage2
    if ((state.isStage2 && !vm) || (!state.isStage2 && !state.sctlr.m)) {
        fault = translateMmuOff(tc, req, mode, tran_type, vaddr,
                                long_desc_format, state);
    } else {
        DPRINTF(MMU, "Translating %s=%#x context=%d\n",
                state.isStage2 ? "IPA" : "VA", vaddr_tainted, state.asid);
        // Translation enabled
        fault = translateMmuOn(tc, req, mode, translation, delay, timing,
                               functional, vaddr, tran_method, state);
    }

    // Check for Debug Exceptions
    SelfDebug *sd = ArmISA::ISA::getSelfDebug(tc);

    if (sd->enabled() && fault == NoFault) {
        fault = sd->testDebug(tc, req, mode);
    }

    return fault;
}

Fault
MMU::translateAtomic(const RequestPtr &req, ThreadContext *tc, Mode mode,
    ArmTranslationType tran_type)
{
    return translateAtomic(req, tc, mode, tran_type, false);
}

Fault
MMU::translateAtomic(const RequestPtr &req, ThreadContext *tc, Mode mode,
    ArmTranslationType tran_type, bool stage2)
{
    auto& state = updateMiscReg(tc, tran_type, stage2);

    bool delay = false;
    Fault fault;
    if (FullSystem)
        fault = translateFs(req, tc, mode, NULL, delay, false,
            tran_type, false, state);
    else
        fault = translateSe(req, tc, mode, NULL, delay, false, state);
    assert(!delay);
    return fault;
}

Fault
MMU::translateFunctional(const RequestPtr &req, ThreadContext *tc, Mode mode)
{
    return translateFunctional(req, tc, mode, NormalTran, false);
}

Fault
MMU::translateFunctional(const RequestPtr &req, ThreadContext *tc, Mode mode,
    ArmTranslationType tran_type)
{
    return translateFunctional(req, tc, mode, tran_type, false);
}

Fault
MMU::translateFunctional(const RequestPtr &req, ThreadContext *tc, Mode mode,
    ArmTranslationType tran_type, bool stage2)
{
    auto& state = updateMiscReg(tc, tran_type, stage2);

    bool delay = false;
    Fault fault;
    if (FullSystem)
        fault = translateFs(req, tc, mode, NULL, delay, false,
            tran_type, true, state);
   else
        fault = translateSe(req, tc, mode, NULL, delay, false, state);
    assert(!delay);
    return fault;
}

void
MMU::translateTiming(const RequestPtr &req, ThreadContext *tc,
    Translation *translation, Mode mode, ArmTranslationType tran_type,
    bool stage2)
{
    auto& state = updateMiscReg(tc, tran_type, stage2);

    assert(translation);

    // [MDSPEC][H2] unified tlb_translate event (spec sheet 9, 39-RunID
    // family: L2 — the fragment leaves for VA→PA translation). THIS is the
    // SE+FS funnel (lsq.cc sendFragmentToTranslation calls it directly);
    // SE translates via translateSe and NEVER reaches TLB::lookup
    // (tlb.cc:173 comment) — so this is the only translate node an SE run
    // can see. Emitted ONLY for fault-correlated requests (spec sheet 11:
    // propagation stream). pa stays empty at entry (translation not yet
    // done — honest pending; PA materialization is covered by the resp
    // node). tlb.cc lookup / table_walker.cc walk+refill nodes are FS-only
    // paths — deferred to the FS TLB track (W4 workload BLOCKED), NOT
    // silently skipped.
    {
        CHAOSPropagation *h2_prop = CHAOSPropagation::instance();
        if (h2_prop && req && req->hasVaddr() && req->hasInstSeqNum()) {
            const char *h2_corr = nullptr;   // [R4-1-review-I1]
            const uint64_t h2_ptag = h2_prop->correlateRequest(
                req->getReqInstSeqNum(), req->getVaddr(),
                req->getSize(), &h2_corr);
            if (h2_ptag) {
                std::ostringstream h2_hex;
                h2_hex << std::hex << req->getVaddr();
                h2_prop->notePropEvt("tlb_translate", {
                    {"fault_id", std::to_string(h2_ptag)},
                    {"corr", h2_corr ? h2_corr : ""},
                    {"dyn_inst_seq", std::to_string(req->getReqInstSeqNum())},
                    {"request_id", std::to_string(req->getReqInstSeqNum())},
                    {"va", h2_hex.str()},
                });
            }
        }
    }

    // [MDSPEC][H2-fix] Capture the translation fault — A01 POST pilot
    // root cause: a01_bit corrupts the startup store's vaddr to an
    // UNMAPPED address in 5/5 samples → translation faults → write()
    // never called → SQ entry empty ("Fault on Store, Size = 0" debug
    // evidence) → store never reaches L3. The translation fault IS the
    // detection/containment point — emit tlb_fault so the chain gets
    // L2 detection evidence instead of an honest but uninformative
    // "unknown beyond L2".
    const Fault h2_fault = translateComplete(req, tc, translation, mode,
        tran_type, stage2, state);
    if (h2_fault != NoFault) {
        CHAOSPropagation *h2f = CHAOSPropagation::instance();
        if (h2f && req && req->hasVaddr() && req->hasInstSeqNum()) {
            const char *h2f_corr = nullptr;   // [R4-1-review-I1]
            const uint64_t h2f_ptag = h2f->correlateRequest(
                req->getReqInstSeqNum(), req->getVaddr(),
                req->getSize(), &h2f_corr);
            if (h2f_ptag) {
                std::ostringstream h2f_hex;
                h2f_hex << std::hex << req->getVaddr();
                h2f->notePropEvt("tlb_fault", {
                    {"fault_id", std::to_string(h2f_ptag)},
                    {"corr", h2f_corr ? h2f_corr : ""},
                    {"dyn_inst_seq", std::to_string(req->getReqInstSeqNum())},
                    {"request_id", std::to_string(req->getReqInstSeqNum())},
                    {"va", h2f_hex.str()},
                    {"outcome", h2_fault->name()},
                    // detection_layer=Hardware：MMU 检测到无效地址。
                    // contained 不在此预定——终局（Contained/Crash/Handled）
                    // 由 chain_end + runner/oracle 离线 join 决定（规格：
                    // 不得推断）。空 = pending offline join。
                    {"detection_layer", "Hardware"},
                    {"contained", ""},
                });
            }
        }
    }
}

Fault
MMU::translateComplete(const RequestPtr &req, ThreadContext *tc,
        Translation *translation, Mode mode, ArmTranslationType tran_type,
        bool call_from_s2)
{
    return translateComplete(req, tc, translation, mode, tran_type,
        call_from_s2, s1State);
}

Fault
MMU::translateComplete(const RequestPtr &req, ThreadContext *tc,
        Translation *translation, Mode mode, ArmTranslationType tran_type,
        bool call_from_s2, CachedState &state)
{
    bool delay = false;
    Fault fault;
    if (FullSystem)
        fault = translateFs(req, tc, mode, translation, delay, true, tran_type,
            false, state);
    else
        fault = translateSe(req, tc, mode, translation, delay, true, state);

    DPRINTF(MMU, "Translation returning delay=%d fault=%d\n", delay,
            fault != NoFault);
    // If we have a translation, and we're not in the middle of doing a stage
    // 2 translation tell the translation that we've either finished or its
    // going to take a while. By not doing this when we're in the middle of a
    // stage 2 translation we prevent marking the translation as delayed twice,
    // one when the translation starts and again when the stage 1 translation
    // completes.

    if (translation && (call_from_s2 || !state.stage2Req || req->hasPaddr() ||
        fault != NoFault)) {
        if (!delay)
            translation->finish(fault, req, tc, mode);
        else
            translation->markDelayed();
    }
    return fault;
}

vmid_t
MMU::CachedState::getVMID(ThreadContext *tc) const
{
    AA64MMFR1 mmfr1 = tc->readMiscReg(MISCREG_ID_AA64MMFR1_EL1);
    VTCR_t vtcr = tc->readMiscReg(MISCREG_VTCR_EL2);
    vmid_t vmid = 0;

    switch (mmfr1.vmidbits) {
      case 0b0000:
        // 8 bits
        vmid = bits(tc->readMiscReg(MISCREG_VTTBR_EL2), 55, 48);
        break;
      case 0b0010:
        if (vtcr.vs && ELIs64(tc, EL2)) {
            // 16 bits
            vmid = bits(tc->readMiscReg(MISCREG_VTTBR_EL2), 63, 48);
        } else {
            // 8 bits
            vmid = bits(tc->readMiscReg(MISCREG_VTTBR_EL2), 55, 48);
        }
        break;
      default:
        panic("Reserved ID_AA64MMFR1_EL1.VMIDBits value: %#x",
              mmfr1.vmidbits);
    }

    return vmid;
}

MMU::CachedState&
MMU::updateMiscReg(ThreadContext *tc,
    ArmTranslationType tran_type, bool stage2)
{
    // check if the regs have changed, or the translation mode is different.
    // NOTE: the tran type doesn't affect stage 2 TLB's as they only handle
    // one type of translation anyway

    auto& state = stage2 ? s2State : s1State;
    if (state.miscRegValid && miscRegContext == tc->contextId() &&
        ((tran_type == state.curTranType) || stage2)) {

    } else {
        DPRINTF(MMU, "MMU variables changed!\n");
        state.updateMiscReg(tc, tran_type);

        itbStage2->setVMID(state.vmid);
        dtbStage2->setVMID(state.vmid);

        for (auto tlb : instruction) {
            static_cast<TLB*>(tlb)->setVMID(state.vmid);
        }
        for (auto tlb : data) {
            static_cast<TLB*>(tlb)->setVMID(state.vmid);
        }
        for (auto tlb : unified) {
            static_cast<TLB*>(tlb)->setVMID(state.vmid);
        }

        miscRegContext = tc->contextId();
    }

    if (state.directToStage2) {
        s2State.updateMiscReg(tc, tran_type);
        return s2State;
    } else {
        return state;
    }
}

MMU::CachedState::CachedState(MMU *_mmu, bool stage2)
    : mmu(_mmu), isStage2(stage2), computeAddrTop(ArmISA::computeAddrTop)
{}

MMU::CachedState &
MMU::CachedState::operator=(const CachedState &rhs)
{
    isStage2 = rhs.isStage2;
    cpsr = rhs.cpsr;
    aarch64 = rhs.aarch64;
    exceptionLevel = rhs.exceptionLevel;
    currRegime = rhs.currRegime;
    sctlr = rhs.sctlr;
    scr = rhs.scr;
    isPriv = rhs.isPriv;
    securityState = rhs.securityState;
    ttbcr = rhs.ttbcr;
    tcr2 = rhs.tcr2;
    pir = rhs.pir;
    pire0 = rhs.pire0;
    pie = rhs.pie;
    asid = rhs.asid;
    vmid = rhs.vmid;
    prrr = rhs.prrr;
    nmrr = rhs.nmrr;
    hcr = rhs.hcr;
    dacr = rhs.dacr;
    miscRegValid = rhs.miscRegValid;
    curTranType = rhs.curTranType;
    stage2Req = rhs.stage2Req;
    stage2DescReq = rhs.stage2DescReq;
    directToStage2 = rhs.directToStage2;

    // When we copy we just flush the memoizer cache
    computeAddrTop.flush();

    return *this;
}

void
MMU::CachedState::updateMiscReg(ThreadContext *tc,
    ArmTranslationType tran_type)
{
    cpsr = tc->readMiscReg(MISCREG_CPSR);
    hcr = tc->readMiscReg(MISCREG_HCR_EL2);
    scr = tc->readMiscReg(MISCREG_SCR_EL3);

    // Dependencies: SCR/SCR_EL3, CPSR
    securityState = ArmISA::isSecure(tc) &&
        !(tran_type & HypMode) && !(tran_type & S1S2NsTran) ?
            SecurityState::Secure : SecurityState::NonSecure;

    exceptionLevel = tranTypeEL(cpsr, scr, tran_type);
    currRegime = translationRegime(tc, exceptionLevel);
    aarch64 = isStage2 ?
        ELIs64(tc, EL2) :
        ELIs64(tc, translationEl(currRegime));

    if (aarch64) {  // AArch64
        // determine EL we need to translate in
        switch (currRegime) {
          case TranslationRegime::EL10:
            {
                sctlr = tc->readMiscReg(MISCREG_SCTLR_EL1);
                ttbcr = tc->readMiscReg(MISCREG_TCR_EL1);
                tcr2 = tc->readMiscReg(MISCREG_TCR2_EL1);
                if (mmu->release()->has(ArmExtension::FEAT_S1PIE)) {
                    pir = tc->readMiscReg(MISCREG_PIR_EL1);
                    pire0 = tc->readMiscReg(MISCREG_PIRE0_EL1);
                    pie = tcr2.pie;
                }
                uint64_t ttbr_asid = ttbcr.a1 ?
                    tc->readMiscReg(MISCREG_TTBR1_EL1) :
                    tc->readMiscReg(MISCREG_TTBR0_EL1);
                asid = bits(ttbr_asid,
                            (mmu->haveLargeAsid64 && ttbcr.as) ? 63 : 55, 48);
            }
            break;
          case TranslationRegime::EL20:
            {
                // VHE code for EL2&0 regime
                sctlr = tc->readMiscReg(MISCREG_SCTLR_EL2);
                ttbcr = tc->readMiscReg(MISCREG_TCR_EL2);
                tcr2 = tc->readMiscReg(MISCREG_TCR2_EL2);
                if (mmu->release()->has(ArmExtension::FEAT_S1PIE)) {
                    pir = tc->readMiscReg(MISCREG_PIR_EL2);
                    pire0 = tc->readMiscReg(MISCREG_PIRE0_EL2);
                    pie = tcr2.pie;
                }
                uint64_t ttbr_asid = ttbcr.a1 ?
                    tc->readMiscReg(MISCREG_TTBR1_EL2) :
                    tc->readMiscReg(MISCREG_TTBR0_EL2);
                asid = bits(ttbr_asid,
                            (mmu->haveLargeAsid64 && ttbcr.as) ? 63 : 55, 48);
            }
            break;
          case TranslationRegime::EL2:
            sctlr = tc->readMiscReg(MISCREG_SCTLR_EL2);
            ttbcr = tc->readMiscReg(MISCREG_TCR_EL2);
            tcr2 = tc->readMiscReg(MISCREG_TCR2_EL2);
            if (mmu->release()->has(ArmExtension::FEAT_S1PIE)) {
                pir = tc->readMiscReg(MISCREG_PIR_EL2);
                pie = tcr2.pie;
            }
            asid = -1;
            break;
          case TranslationRegime::EL3:
            sctlr = tc->readMiscReg(MISCREG_SCTLR_EL3);
            ttbcr = tc->readMiscReg(MISCREG_TCR_EL3);
            if (mmu->release()->has(ArmExtension::FEAT_S1PIE)) {
                pir = tc->readMiscReg(MISCREG_PIR_EL3);
                pie = static_cast<TCR>(ttbcr).pie;
            }
            asid = -1;
            break;
        }

        isPriv = exceptionLevel != EL0;
        if (mmu->release()->has(ArmExtension::VIRTUALIZATION)) {
            vmid = getVMID(tc);
            bool vm = hcr.vm;
            if (HaveExt(tc, ArmExtension::FEAT_VHE) &&
                hcr.e2h == 1 && hcr.tge ==1) {
                vm = 0;
            }

            if (hcr.e2h == 1 && (exceptionLevel == EL2
                                  || (hcr.tge ==1 && exceptionLevel == EL0))) {
                directToStage2 = false;
                stage2Req      = false;
                stage2DescReq  = false;
            } else {
            // Work out if we should skip the first stage of translation and go
            // directly to stage 2. This value is cached so we don't have to
            // compute it for every translation.
                const bool el2_enabled = EL2Enabled(tc);
                stage2Req = isStage2 ||
                    (vm && exceptionLevel < EL2 && el2_enabled &&
                        !(tran_type & S1CTran) &&
                        !(tran_type & S1E1Tran)); // <--- FIX THIS HACK
                stage2DescReq = isStage2 ||
                    (vm && exceptionLevel < EL2 && el2_enabled);
                directToStage2 = !isStage2 && stage2Req && !sctlr.m;
            }
        } else {
            vmid           = 0;
            directToStage2 = false;
            stage2Req      = false;
            stage2DescReq  = false;
        }
    } else {  // AArch32
        sctlr  = tc->readMiscReg(snsBankedIndex(MISCREG_SCTLR, tc,
                                 securityState == SecurityState::NonSecure));
        ttbcr  = tc->readMiscReg(snsBankedIndex(MISCREG_TTBCR, tc,
                                 securityState == SecurityState::NonSecure));
        isPriv = cpsr.mode != MODE_USER;
        if (longDescFormatInUse(tc)) {
            uint64_t ttbr_asid = tc->readMiscReg(
                snsBankedIndex(ttbcr.a1 ? MISCREG_TTBR1 : MISCREG_TTBR0,
                               tc, securityState == SecurityState::NonSecure));
            asid = bits(ttbr_asid, 55, 48);
        } else { // Short-descriptor translation table format in use
            CONTEXTIDR context_id = tc->readMiscReg(snsBankedIndex(
                MISCREG_CONTEXTIDR, tc,
                securityState == SecurityState::NonSecure));
            asid = context_id.asid;
        }
        prrr = tc->readMiscReg(snsBankedIndex(MISCREG_PRRR, tc,
                               securityState == SecurityState::NonSecure));
        nmrr = tc->readMiscReg(snsBankedIndex(MISCREG_NMRR, tc,
                               securityState == SecurityState::NonSecure));
        dacr = tc->readMiscReg(snsBankedIndex(MISCREG_DACR, tc,
                               securityState == SecurityState::NonSecure));

        if (mmu->release()->has(ArmExtension::VIRTUALIZATION)) {
            vmid   = bits(tc->readMiscReg(MISCREG_VTTBR), 55, 48);
            if (exceptionLevel == EL2) {
                sctlr = tc->readMiscReg(MISCREG_HSCTLR);
            }
            // Work out if we should skip the first stage of translation and go
            // directly to stage 2. This value is cached so we don't have to
            // compute it for every translation.
            const bool el2_enabled = EL2Enabled(tc);
            stage2Req = isStage2 ||
                (hcr.vm && exceptionLevel < EL2 && el2_enabled &&
                    !(tran_type & S1CTran));
            stage2DescReq  = isStage2 ||
                (hcr.vm && exceptionLevel < EL2 && el2_enabled);
            directToStage2 = !isStage2 && stage2Req && !sctlr.m;
        } else {
            vmid           = 0;
            stage2Req      = false;
            directToStage2 = false;
            stage2DescReq  = false;
        }
    }
    miscRegValid = true;
    curTranType  = tran_type;
}

ExceptionLevel
MMU::tranTypeEL(CPSR cpsr, SCR scr, ArmTranslationType type)
{
    switch (type) {
      case S1E0Tran:
      case S12E0Tran:
        return EL0;

      case S1E1Tran:
      case S12E1Tran:
      case S1S2NsTran:
        return EL1;

      case S1E2Tran:
      case HypMode:
        return EL2;

      case S1E3Tran:
        return EL3;

      case S1CTran:
        return currEL(cpsr) == EL3 && scr.ns == 0 ?
           EL3 : EL1;

      case NormalTran:
        return currEL(cpsr);

      default:
        panic("Unknown translation mode!\n");
    }
}

Fault
MMU::getTE(TlbEntry **te, const RequestPtr &req, ThreadContext *tc, Mode mode,
        Translation *translation, bool timing, bool functional,
        SecurityState ss, PASpace ipaspace, ArmTranslationType tran_type,
        bool stage2)
{
    return getTE(te, req, tc, mode, translation, timing, functional,
        ss, ipaspace, tran_type, stage2 ? s2State : s1State);
}

TlbEntry*
MMU::lookup(Addr va, uint16_t asid, vmid_t vmid, SecurityState ss,
            bool functional, bool ignore_asn, TranslationRegime regime,
            bool stage2, BaseMMU::Mode mode)
{
    TLB *tlb = getTlb(mode, stage2);

    TlbEntry::KeyType lookup_data;

    lookup_data.va = va;
    lookup_data.asn = asid;
    lookup_data.ignoreAsn = ignore_asn;
    lookup_data.vmid = vmid;
    lookup_data.ss = ss;
    lookup_data.functional = functional;
    lookup_data.targetRegime = regime;
    lookup_data.mode = mode;

    return tlb->multiLookup(lookup_data);
}

void
MMU::insert(TlbEntry &entry, BaseMMU::Mode mode, bool stage2)
{
    TLB *tlb = getTlb(mode, stage2);
    tlb->multiInsert(TlbEntry::KeyType(entry), entry);
}

Fault
MMU::getTE(TlbEntry **te, const RequestPtr &req, ThreadContext *tc, Mode mode,
        Translation *translation, bool timing, bool functional,
        SecurityState ss, PASpace ipaspace, ArmTranslationType tran_type,
        CachedState& state)
{
    // In a 2-stage system, the IPA->PA translation can be started via this
    // call so make sure the miscRegs are correct.
    if (state.isStage2) {
        updateMiscReg(tc, tran_type, true);
    }

    Addr vaddr_tainted = req->getVaddr();
    Addr vaddr = 0;
    TranslationRegime regime = state.currRegime;

    if (state.aarch64) {
        vaddr = purifyTaggedAddr(vaddr_tainted, tc, state.exceptionLevel,
            static_cast<TCR>(state.ttbcr), mode==Execute, state);
    } else {
        vaddr = vaddr_tainted;
    }

    // [MDSPEC][R4-4] Publish this translation's Request identity to the
    // target TLB for the duration of the lookup so the CHAOSArmTLB hook
    // inside TLB::lookup can bind the fault chain to the request whose
    // translation consumed the corrupted entry (seq-PRIMARY correlation).
    // Cleared right after — every other TLB::lookup path (table walker's
    // mmu->lookup, MMU::translateFunctional) has no RequestPtr and must
    // honestly see 0. getTE is the only lookup caller that owns the req.
    // [MMU-TRACE v1] Trace only translations that actually miss the L1 TLB.
    // The miss-triggered transaction is created inside TLB::lookup (warm-hit
    // repetitions therefore emit nothing); its identity is read back here
    // and carried into the walk / result / LSU / commit chain.
    CHAOSPropagation *const mmu_prop = CHAOSPropagation::instance();
    uint64_t mmu_tid = 0;
    uint64_t mmu_uid = 0;

    TLB *const chaos_lookup_tlb = getTlb(mode, state.isStage2);
    // [MMU-TRACE v4] An Execute-mode fetch Request carries no dynamic-
    // instruction sequence. Mint ONE synthetic, reserved-namespace identity
    // for this translation so the miss-triggered trace transaction (and thus
    // the whole walk -> fill -> insert -> result chain) is joined. The id is
    // reused by the post-walk re-lookup below. It is pure observation:
    // mmuNewSyntheticSeq returns 0 when the trace is off or vaddr is outside
    // --prop_mmu_va_lo/hi, and it is published only through the dedicated
    // TLB trace field (chaosLookupSyntheticSeq), never through
    // chaosLookupReqSeq, so no fault-model gate or translation result can
    // observe it.
    uint64_t chaos_synthetic_seq = 0;
    if (!req->hasInstSeqNum() && mode == Execute && mmu_prop)
        chaos_synthetic_seq = mmu_prop->mmuNewSyntheticSeq(vaddr);
    if (chaos_lookup_tlb) {
        chaos_lookup_tlb->chaosLookupReqSeq =
            req->hasInstSeqNum() ? req->getReqInstSeqNum() : 0;
        chaos_lookup_tlb->chaosLookupReqSize = req->getSize();
        chaos_lookup_tlb->chaosLookupSyntheticSeq = chaos_synthetic_seq;
        chaos_lookup_tlb->chaosMmuTranslationId = mmu_tid;
        chaos_lookup_tlb->chaosMmuUniqueReqId = mmu_uid;
    }

    *te = lookup(vaddr, state.asid, state.vmid, ss, false,
                 false, regime, state.isStage2, mode);

    if (chaos_lookup_tlb) {
        mmu_tid = chaos_lookup_tlb->chaosMmuTranslationId;
        mmu_uid = chaos_lookup_tlb->chaosMmuUniqueReqId;
        chaos_lookup_tlb->chaosLookupReqSeq = 0;
        chaos_lookup_tlb->chaosLookupReqSize = 0;
        chaos_lookup_tlb->chaosLookupSyntheticSeq = 0;
        chaos_lookup_tlb->chaosMmuTranslationId = 0;
        chaos_lookup_tlb->chaosMmuUniqueReqId = 0;
    }
    (void)mmu_prop;

    if (!isCompleteTranslation(*te)) {
        if (req->isPrefetch()) {
            // if the request is a prefetch don't attempt to fill the TLB or go
            // any further with the memory access (here we can safely use the
            // fault status for the short desc. format in all cases)
           stats.prefetchFaults++;
           return std::make_shared<PrefetchAbort>(
               vaddr_tainted, ArmFault::PrefetchTLBMiss, state.isStage2);
        }

        // start translation table walk, pass variables rather than
        // re-retreaving in table walker for speed
        DPRINTF(MMU,
                "TLB Miss: Starting hardware table walker for %#x(%d:%d)\n",
                vaddr_tainted, state.asid, state.vmid);

        Fault fault;
        if (walker && mmu_tid)
            walker->setChaosMmuContext(mmu_tid, mmu_uid);
        fault =
            walker->walk(req, tc, state.asid, state.vmid, mode, translation,
                         timing, functional, ss, ipaspace, tran_type,
                         state.stage2DescReq, state.isStage2, *te);
        if (walker && mmu_tid)
            walker->setChaosMmuContext(0, 0);

        // for timing mode, return and wait for table walk,
        if (timing || fault != NoFault) {
            return fault;
        }

        // [MDSPEC][R4-4] same bracket for the post-walk re-lookup
        if (chaos_lookup_tlb) {
            chaos_lookup_tlb->chaosLookupReqSeq =
                req->hasInstSeqNum() ? req->getReqInstSeqNum() : 0;
            chaos_lookup_tlb->chaosLookupReqSize = req->getSize();
            // Reuse the SAME synthetic identity; the miss transaction (and
            // its completion) belongs to one fetch translation.
            chaos_lookup_tlb->chaosLookupSyntheticSeq = chaos_synthetic_seq;
            chaos_lookup_tlb->chaosMmuTranslationId = mmu_tid;
            chaos_lookup_tlb->chaosMmuUniqueReqId = mmu_uid;
        }
        *te = lookup(vaddr, state.asid, state.vmid, ss,
                     true, false, regime, state.isStage2, mode);
        if (chaos_lookup_tlb) {
            chaos_lookup_tlb->chaosLookupReqSeq = 0;
            chaos_lookup_tlb->chaosLookupReqSize = 0;
            chaos_lookup_tlb->chaosLookupSyntheticSeq = 0;
            chaos_lookup_tlb->chaosMmuTranslationId = 0;
            chaos_lookup_tlb->chaosMmuUniqueReqId = 0;
        }
        assert(*te);
    }
    return NoFault;
}

Fault
MMU::getResultTe(TlbEntry **te, const RequestPtr &req,
        ThreadContext *tc, Mode mode,
        Translation *translation, bool timing, bool functional,
        TlbEntry *mergeTe, CachedState &state)
{
    Fault fault;

    if (state.isStage2) {
        PASpace ipaspace = state.securityState == SecurityState::Secure ?
            PASpace::Secure : PASpace::NonSecure;

        // We are already in the stage 2 TLB. Grab the table entry for stage
        // 2 only. We are here because stage 1 translation is disabled.
        TlbEntry *s2_te = nullptr;
        // Get the stage 2 table entry
        fault = getTE(&s2_te, req, tc, mode, translation, timing, functional,
                      state.securityState, ipaspace,
                      state.curTranType, state);
        // Check permissions of stage 2
        if (isCompleteTranslation(s2_te) && (fault == NoFault)) {
            if (state.aarch64)
                fault = checkPermissions64(s2_te, req, mode, tc, state);
            else
                fault = checkPermissions(s2_te, req, mode, state);
        }
        *te = s2_te;
        return fault;
    }

    TlbEntry *s1_te = nullptr;

    Addr vaddr_tainted = req->getVaddr();

    // Get the stage 1 table entry
    fault = getTE(&s1_te, req, tc, mode, translation, timing, functional,
                  state.securityState, PASpace::NonSecure,
                  state.curTranType, state);
    // only proceed if we have a valid table entry
    if (isCompleteTranslation(s1_te) && (fault == NoFault)) {
        // Check stage 1 permissions before checking stage 2
        if (state.aarch64)
            fault = checkPermissions64(s1_te, req, mode, tc, state);
        else
            fault = checkPermissions(s1_te, req, mode, state);
        if (state.stage2Req & (fault == NoFault)) {
            Stage2LookUp *s2_lookup = new Stage2LookUp(this, *s1_te,
                req, translation, mode, timing, functional,
                state.securityState, state.curTranType);
            fault = s2_lookup->getTe(tc, mergeTe);
            if (s2_lookup->isComplete()) {
                *te = mergeTe;
                // We've finished with the lookup so delete it
                delete s2_lookup;
            } else {
                // The lookup hasn't completed, so we can't delete it now. We
                // get round this by asking the object to self delete when the
                // translation is complete.
                s2_lookup->setSelfDelete();
            }
        } else {
            // This case deals with an S1 hit (or bypass), followed by
            // an S2 hit-but-perms issue
            if (state.isStage2) {
                DPRINTF(MMU, "s2TLB: reqVa %#x, reqPa %#x, fault %p\n",
                        vaddr_tainted, req->hasPaddr() ? req->getPaddr() : ~0,
                        fault);
                if (fault != NoFault) {
                    auto arm_fault = reinterpret_cast<ArmFault*>(fault.get());
                    arm_fault->annotate(ArmFault::S1PTW, false);
                    arm_fault->annotate(ArmFault::OVA, vaddr_tainted);
                }
            }
            *te = s1_te;
        }
    }
    return fault;
}

bool
MMU::isCompleteTranslation(TlbEntry *entry) const
{
    return entry && !entry->partial;
}

void
MMU::takeOverFrom(BaseMMU *old_mmu)
{
    auto *ommu = dynamic_cast<MMU*>(old_mmu);
    assert(ommu);

    Port *old_tbw_port = ommu->getTableWalkerPort();
    Port *new_tbw_port = getTableWalkerPort();

    new_tbw_port->takeOverFrom(old_tbw_port);

    _attr = ommu->_attr;

    s1State = ommu->s1State;
    s2State = ommu->s2State;
}

Port *
MMU::getTableWalkerPort()
{
    return &walker->getTableWalkerPort();
}

void
MMU::setTestInterface(SimObject *_ti)
{
    if (!_ti) {
        test = nullptr;
    } else {
        TlbTestInterface *ti(dynamic_cast<TlbTestInterface *>(_ti));
        fatal_if(!ti, "%s is not a valid ARM TLB tester\n", _ti->name());
        test = ti;
        walker->setTestInterface(ti);
    }
}

Fault
MMU::testTranslation(const RequestPtr &req, Mode mode,
                     DomainType domain, CachedState &state) const
{
    if (!test || !req->hasSize() || req->getSize() == 0 ||
        req->isCacheMaintenance()) {
        return NoFault;
    } else {
        return test->translationCheck(req, state.isPriv, mode, domain);
    }
}

MMU::Stats::Stats(statistics::Group *parent)
  : statistics::Group(parent),
    ADD_STAT(alignFaults, statistics::units::Count::get(),
             "Number of MMU faults due to alignment restrictions"),
    ADD_STAT(prefetchFaults, statistics::units::Count::get(),
             "Number of MMU faults due to prefetch"),
    ADD_STAT(domainFaults, statistics::units::Count::get(),
             "Number of MMU faults due to domain restrictions"),
    ADD_STAT(permsFaults, statistics::units::Count::get(),
             "Number of MMU faults due to permissions restrictions")
{
}

} // namespace gem5
