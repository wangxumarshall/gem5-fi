/*
 * Copyright (c) 2010, 2012-2013, 2021, 2023-2024 Arm Limited
 * All rights reserved
 *
 * The license below extends only to copyright in the software and shall
 * not be construed as granting a license to any other intellectual
 * property including but not limited to intellectual property relating
 * to a hardware implementation of the functionality of the software
 * licensed hereunder.  You may use the software subject to the license
 * terms below provided that you ensure that this notice is replicated
 * unmodified and in its entirety in all distributions of the software,
 * modified or unmodified, in source code or in binary form.
 *
 * Copyright (c) 2002-2005 The Regents of The University of Michigan
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __ARCH_ARM_PAGETABLE_H__
#define __ARCH_ARM_PAGETABLE_H__

#include <cstdint>

#include "arch/arm/page_size.hh"
#include "arch/arm/types.hh"
#include "arch/arm/utility.hh"
#include "arch/generic/mmu.hh"
#include "enums/TypeTLB.hh"
#include "enums/ArmLookupLevel.hh"
#include "mem/cache/replacement_policies/replaceable_entry.hh"
#include "mem/cache/tags/indexing_policies/base.hh"
#include "params/TLBIndexingPolicy.hh"
#include "params/TLBSetAssociative.hh"
#include "sim/serialize.hh"

namespace gem5
{

namespace ArmISA
{

// Granule sizes
enum GrainSize
{
    Grain4KB  = 12,
    Grain16KB = 14,
    Grain64KB = 16,
    ReservedGrain = 0
};

extern const GrainSize GrainMap_tg0[];
extern const GrainSize GrainMap_tg1[];

// Max. physical address range in bits supported by the architecture
const unsigned MaxPhysAddrRange = 52;

// ITB/DTB page table entry
struct PTE
{
    void serialize(CheckpointOut &cp) const
    {
        panic("Need to implement PTE serialization\n");
    }

    void unserialize(CheckpointIn &cp)
    {
        panic("Need to implement PTE serialization\n");
    }

};

struct PageTableOps
{
    typedef enums::ArmLookupLevel LookupLevel;
    typedef int64_t pte_t;

    virtual ~PageTableOps() = default;

    virtual bool isValid(pte_t pte, unsigned level) const = 0;
    virtual bool isLeaf(pte_t pte, unsigned level) const = 0;
    virtual bool isWritable(pte_t pte, unsigned level, bool stage2) const = 0;
    virtual Addr nextLevelPointer(pte_t pte, unsigned level) const = 0;
    virtual Addr index(Addr va, unsigned level, int tsz) const = 0;
    virtual Addr pageMask(pte_t pte, unsigned level) const = 0;
    virtual unsigned walkBits(unsigned level) const = 0;
    virtual LookupLevel firstLevel(uint8_t tsz) const = 0;
    virtual LookupLevel firstS2Level(uint8_t sl0) const = 0;
    virtual LookupLevel lastLevel() const = 0;

    Addr walkMask(unsigned level) const;
};

struct V7LPageTableOps : public PageTableOps
{
    bool isValid(pte_t pte, unsigned level) const override;
    bool isLeaf(pte_t pte, unsigned level) const override;
    bool isWritable(pte_t pte, unsigned level, bool stage2) const override;
    Addr nextLevelPointer(pte_t pte, unsigned level) const override;
    Addr index(Addr va, unsigned level, int tsz) const override;
    Addr pageMask(pte_t pte, unsigned level) const override;
    unsigned walkBits(unsigned level) const override;
    LookupLevel firstLevel(uint8_t tsz) const override;
    LookupLevel lastLevel() const override;
};

struct V8PageTableOps4k : public PageTableOps
{
    bool isValid(pte_t pte, unsigned level) const override;
    bool isLeaf(pte_t pte, unsigned level) const override;
    bool isWritable(pte_t pte, unsigned level, bool stage2) const override;
    Addr nextLevelPointer(pte_t pte, unsigned level) const override;
    Addr index(Addr va, unsigned level, int tsz) const override;
    Addr pageMask(pte_t pte, unsigned level) const override;
    unsigned walkBits(unsigned level) const override;
    LookupLevel firstLevel(uint8_t tsz) const override;
    LookupLevel firstS2Level(uint8_t sl0) const override;
    LookupLevel lastLevel() const override;
};

struct V8PageTableOps16k : public PageTableOps
{
    bool isValid(pte_t pte, unsigned level) const override;
    bool isLeaf(pte_t pte, unsigned level) const override;
    bool isWritable(pte_t pte, unsigned level, bool stage2) const override;
    Addr nextLevelPointer(pte_t pte, unsigned level) const override;
    Addr index(Addr va, unsigned level, int tsz) const override;
    Addr pageMask(pte_t pte, unsigned level) const override;
    unsigned walkBits(unsigned level) const override;
    LookupLevel firstLevel(uint8_t tsz) const override;
    LookupLevel firstS2Level(uint8_t sl0) const override;
    LookupLevel lastLevel() const override;
};

struct V8PageTableOps64k : public PageTableOps
{
    bool isValid(pte_t pte, unsigned level) const override;
    bool isLeaf(pte_t pte, unsigned level) const override;
    bool isWritable(pte_t pte, unsigned level, bool stage2) const override;
    Addr nextLevelPointer(pte_t pte, unsigned level) const override;
    Addr index(Addr va, unsigned level, int tsz) const override;
    Addr pageMask(pte_t pte, unsigned level) const override;
    unsigned walkBits(unsigned level) const override;
    LookupLevel firstLevel(uint8_t tsz) const override;
    LookupLevel firstS2Level(uint8_t sl0) const override;
    LookupLevel lastLevel() const override;
};

struct TlbEntry;

class TLBTypes
{
  public:
    struct KeyType
    {
        KeyType() = default;
        explicit KeyType(const TlbEntry &entry);

        // virtual address
        Addr va = 0;
        // page size
        Addr pageSize = Grain4KB;
        // lookup size:
        // * != 0 -> this is a range based lookup.
        //           end_address = va + size
        // * == 0 -> This is a normal lookup. size should
        //           be ignored
        Addr size = 0;
        // context id/address space id to use
        uint16_t asn = 0;
        // if on lookup asn should be ignored
        bool ignoreAsn = false;
        // The virtual machine ID used for stage 2 translation
        vmid_t vmid = 0;
        // if the lookup is secure
        SecurityState ss = SecurityState::NonSecure;
        // if the lookup should modify state
        bool functional = false;
        // selecting the translation regime
        TranslationRegime targetRegime = TranslationRegime::EL10;
        // mode to differentiate between read/writes/fetches.
        BaseMMU::Mode mode = BaseMMU::Read;
    };

    using Params = TLBIndexingPolicyParams;
};
using TLBIndexingPolicy = IndexingPolicyTemplate<TLBTypes>;

class TLBSetAssociative : public TLBIndexingPolicy
{
  public:
    PARAMS(TLBSetAssociative);
    TLBSetAssociative(const Params &p)
      : TLBIndexingPolicy(p, p.num_entries, 0)
    {}

    std::vector<ReplaceableEntry*>
    getPossibleEntries(const KeyType &key) const override
    {
        Addr set_number = (key.va >> key.pageSize) & setMask;
        return sets[set_number];
    }

    Addr
    regenerateAddr(const KeyType &key,
                   const ReplaceableEntry *entry) const override
    {
        panic("Unimplemented\n");
    }
};

// ITB/DTB table entry
struct TlbEntry : public ReplaceableEntry, Serializable
{
  public:
    using LookupLevel = enums::ArmLookupLevel;
    using KeyType = TLBTypes::KeyType;
    using IndexingPolicy = TLBIndexingPolicy;

    enum class MemoryType : std::uint8_t
    {
        StronglyOrdered,
        Device,
        Normal
    };

    // Matching variables
    Addr pfn;
    Addr size;              // Size of this entry, == Type of TLB Rec
    Addr vpn;               // Virtual Page Number
    uint64_t attributes;    // Memory attributes formatted for PAR

    LookupLevel lookupLevel;    // Lookup level where the descriptor was fetched
                                // from.  Used to set the FSR for faults
                                // occurring while the long desc. format is in
                                // use (AArch32 w/ LPAE and AArch64)

    uint16_t asid;          // Address Space Identifier
    vmid_t vmid;            // Virtual machine Identifier
    GrainSize tg;           // Translation Granule Size
    uint8_t N;              // Number of bits in pagesize
    uint8_t innerAttrs;
    uint8_t outerAttrs;
    uint8_t ap;             // Access permissions bits
    uint8_t hap;            // Hyp access permissions bits
    uint8_t piindex;        // Indirect permission index.
    DomainType domain;         // Access Domain

    MemoryType mtype;

    // True if the long descriptor format is used for this entry (LPAE only)
    bool longDescFormat; // @todo use this in the update attribute bethod

    bool global;
    bool valid;

    // True if the entry targets the non-secure physical address space
    bool ns;
    // Security state of the translation regime
    SecurityState ss;
    // IPA Space (stage2 entries only)
    PASpace ipaSpace;
    // Translation regime on insert, AARCH64 EL0&1, AARCH32 -> el=1
    TranslationRegime regime;
    // This is used to distinguish between instruction and data entries
    // in unified TLBs
    TypeTLB type;
    // True if the entry is caching a partial translation (a table walk)
    bool partial;

    // Type of memory
    bool nonCacheable;     // Can we wrap this in mtype?

    // Memory Attributes
    bool shareable;
    bool outerShareable;

    // Access permissions
    bool xn;                // Execute Never
    bool pxn;               // Privileged Execute Never (LPAE only)

    bool xs;                // xs attribute from FEAT_XS

    // [MMU-TRACE v1] Stable, non-pointer TLB entry identity. Assigned by
    // TLB::insert (and lazily on lookup for checkpoint-restored entries).
    // NOT serialized: checkpoint compatibility is preserved; a restored
    // entry receives an id on its first observed lookup. Generation
    // increments on every invalidation and on every slot reuse.
    uint64_t chaosEntryId = 0;
    uint32_t chaosEntryGeneration = 0;

    // [MMU-PHASE3][M04] Fault-lineage carry for a PROMOTED copy. When an
    // already-substituted entry is copied into another TLB layer
    // (multiLookup -> insert), the new identity must inherit the same fault.
    // `chaosFaultOriginSeq` is the real dynamic instruction that performed
    // the original substitution; it travels with the entry payload (and the
    // swap/copy below) so the destination can register its own lineage
    // without guessing from VA/PA or tick order.
    // NOT serialized (same checkpoint-compatibility rule as the identity
    // fields above).
    uint64_t chaosFaultOriginSeq = 0;

    //Construct an entry that maps to physical address addr for SE mode
    TlbEntry(Addr _asn, Addr _vaddr, Addr _paddr,
             bool uncacheable, bool read_only) :
         pfn(_paddr >> PageShift), size(PageBytes - 1), vpn(_vaddr >> PageShift),
         attributes(0), lookupLevel(LookupLevel::L1),
         asid(_asn), vmid(0), tg(Grain4KB), N(0),
         innerAttrs(0), outerAttrs(0), ap(read_only ? 0x3 : 0), hap(0x3),
         piindex(0),
         domain(DomainType::Client),  mtype(MemoryType::StronglyOrdered),
         longDescFormat(false), global(false), valid(true),
         ns(true), ss(SecurityState::NonSecure),
         ipaSpace(PASpace::NonSecure),
         regime(TranslationRegime::EL10),
         type(TypeTLB::unified), partial(false),
         nonCacheable(uncacheable),
         shareable(false), outerShareable(false), xn(0), pxn(0),
         xs(true)
    {
        // no restrictions by default, hap = 0x3

        // @todo Check the memory type
        if (read_only)
            warn("ARM TlbEntry does not support read-only mappings\n");
    }

    TlbEntry() :
         pfn(0), size(0), vpn(0), attributes(0), lookupLevel(LookupLevel::L1),
         asid(0), vmid(0), tg(ReservedGrain), N(0),
         innerAttrs(0), outerAttrs(0), ap(0), hap(0x3), piindex(0),
         domain(DomainType::Client), mtype(MemoryType::StronglyOrdered),
         longDescFormat(false), global(false), valid(false),
         ns(true), ss(SecurityState::NonSecure),
         ipaSpace(PASpace::NonSecure),
         regime(TranslationRegime::EL10),
         type(TypeTLB::unified), partial(false), nonCacheable(false),
         shareable(false), outerShareable(false), xn(0), pxn(0),
         xs(true)
    {
        // no restrictions by default, hap = 0x3

        // @todo Check the memory type
    }
    TlbEntry(const TlbEntry &rhs) = default;
    TlbEntry& operator=(TlbEntry rhs)
    {
        swap(rhs);
        return *this;
    }

    void
    swap(TlbEntry &rhs)
    {
        std::swap(pfn, rhs.pfn);
        std::swap(size, rhs.size);
        std::swap(vpn, rhs.vpn);
        std::swap(attributes, rhs.attributes);
        std::swap(lookupLevel, rhs.lookupLevel);
        std::swap(asid, rhs.asid);
        std::swap(vmid, rhs.vmid);
        std::swap(tg, rhs.tg);
        std::swap(N, rhs.N);
        std::swap(innerAttrs, rhs.innerAttrs);
        std::swap(outerAttrs, rhs.outerAttrs);
        std::swap(ap, rhs.ap);
        std::swap(hap, rhs.hap);
        std::swap(piindex, rhs.piindex);
        std::swap(domain, rhs.domain);
        std::swap(mtype, rhs.mtype);
        std::swap(longDescFormat, rhs.longDescFormat);
        std::swap(global, rhs.global);
        std::swap(valid, rhs.valid);
        std::swap(ns, rhs.ns);
        std::swap(ss, rhs.ss);
        std::swap(regime, rhs.regime);
        std::swap(type, rhs.type);
        std::swap(partial, rhs.partial);
        std::swap(nonCacheable, rhs.nonCacheable);
        std::swap(shareable, rhs.shareable);
        std::swap(outerShareable, rhs.outerShareable);
        std::swap(xn, rhs.xn);
        std::swap(pxn, rhs.pxn);
        std::swap(xs, rhs.xs);
        std::swap(chaosEntryId, rhs.chaosEntryId);
        std::swap(chaosEntryGeneration, rhs.chaosEntryGeneration);
        std::swap(chaosFaultOriginSeq, rhs.chaosFaultOriginSeq);
    }

    /** Need for compliance with the AssociativeCache interface */
    void
    invalidate()
    {
        valid = false;
        // [MMU-TRACE v1] Every invalidation closes this entry lifetime. The
        // next insert into this slot increments the generation again.
        ++chaosEntryGeneration;
    }

    /** Need for compliance with the AssociativeCache interface */
    void insert(const KeyType &key) {}

    /** Need for compliance with the AssociativeCache interface */
    bool isValid() const { return valid; }

    void
    updateVaddr(Addr new_vaddr)
    {
        vpn = new_vaddr >> PageShift;
    }

    Addr
    pageStart() const
    {
        return pfn << PageShift;
    }

    bool
    matchAddress(const KeyType &key) const
    {
        Addr page_addr = vpn << N;
        if (key.size) {
            // This is a range based loookup
            return key.va <= page_addr + size &&
                   key.va + key.size > page_addr;
        } else {
            // This is a normal lookup
            return key.va >= page_addr && key.va <= page_addr + size;
        }
    }

    bool
    match(const KeyType &key) const
    {
        bool match = false;
        if (valid && matchAddress(key) && key.ss == ss)
        {
            match = checkRegime(key.targetRegime);

            if (match && !key.ignoreAsn) {
                match = global || (key.asn == asid);
            }
            if (match && useVMID(key.targetRegime)) {
                match = key.vmid == vmid;
            }
        }
        return match;
    }

    bool
    checkRegime(TranslationRegime target_regime) const
    {
        return regime == target_regime;
    }

    Addr
    pAddr(Addr va) const
    {
        return (pfn << N) | (va & size);
    }

    void
    updateAttributes()
    {
        uint64_t mask;
        uint64_t newBits;

        // chec bit 11 to determine if its currently LPAE or VMSA format.
        if ( attributes & (1 << 11) ) {
            newBits = ((outerShareable ? 0x2 :
                      shareable         ? 0x3 : 0) << 7);
            mask = 0x180;
        } else {
            /** Formatting for Physical Address Register (PAR)
             *  Only including lower bits (TLB info here)
             *  PAR (32-bit format):
             *  PA   [31:12]
             *  LPAE [11] (Large Physical Address Extension)
             *  TLB info [10:1]
             *      NOS  [10] (Not Outer Sharable)
             *      NS   [9]  (Non-Secure)
             *      --   [8]  (Implementation Defined)
             *      SH   [7]  (Sharable)
             *      Inner[6:4](Inner memory attributes)
             *      Outer[3:2](Outer memory attributes)
             *      SS   [1]  (SuperSection)
             *      F    [0]  (Fault, Fault Status in [6:1] if faulted)
            */
            newBits = ((outerShareable ? 0:1) << 10) |
                      ((shareable ? 1:0) << 7) |
                      (innerAttrs << 4) |
                      (outerAttrs << 2);
                      // TODO: Supersection bit
            mask = 0x4FC;
        }
        // common bits
        newBits |= ns << 9;  // NS bit
        mask    |= 1  << 9;
        // add in the new bits
        attributes &= ~mask;
        attributes |= newBits;
    }

    void
    setAttributes(bool lpae)
    {
        attributes = lpae ? (1 << 11) : 0;
        updateAttributes();
    }

    std::string
    print() const override
    {
        return csprintf("%#x, asn %d vmn %d ppn %#x size: %#x ap:%d "
                        "ns:%d ss:%s g:%d xs: %d regime:%s", vpn << N, asid, vmid,
                        pfn << N, size, ap, ns, ss, global,
                        xs, regimeToStr(regime));
    }

    void
    serialize(CheckpointOut &cp) const override
    {
        SERIALIZE_SCALAR(longDescFormat);
        SERIALIZE_SCALAR(pfn);
        SERIALIZE_SCALAR(size);
        SERIALIZE_SCALAR(vpn);
        SERIALIZE_SCALAR(asid);
        SERIALIZE_SCALAR(vmid);
        SERIALIZE_SCALAR(N);
        SERIALIZE_SCALAR(global);
        SERIALIZE_SCALAR(valid);
        SERIALIZE_SCALAR(ns);
        SERIALIZE_ENUM(ss);
        SERIALIZE_ENUM(type);
        SERIALIZE_SCALAR(nonCacheable);
        SERIALIZE_ENUM(lookupLevel);
        SERIALIZE_ENUM(mtype);
        SERIALIZE_SCALAR(innerAttrs);
        SERIALIZE_SCALAR(outerAttrs);
        SERIALIZE_SCALAR(shareable);
        SERIALIZE_SCALAR(outerShareable);
        SERIALIZE_SCALAR(attributes);
        SERIALIZE_SCALAR(xn);
        SERIALIZE_SCALAR(pxn);
        SERIALIZE_SCALAR(ap);
        SERIALIZE_SCALAR(hap);
        uint8_t domain_ = static_cast<uint8_t>(domain);
        paramOut(cp, "domain", domain_);
    }
    void
    unserialize(CheckpointIn &cp) override
    {
        UNSERIALIZE_SCALAR(longDescFormat);
        UNSERIALIZE_SCALAR(pfn);
        UNSERIALIZE_SCALAR(size);
        UNSERIALIZE_SCALAR(vpn);
        UNSERIALIZE_SCALAR(asid);
        UNSERIALIZE_SCALAR(vmid);
        UNSERIALIZE_SCALAR(N);
        UNSERIALIZE_SCALAR(global);
        UNSERIALIZE_SCALAR(valid);
        UNSERIALIZE_SCALAR(ns);
        UNSERIALIZE_ENUM(ss);
        UNSERIALIZE_ENUM(type);
        UNSERIALIZE_SCALAR(nonCacheable);
        UNSERIALIZE_ENUM(lookupLevel);
        UNSERIALIZE_ENUM(mtype);
        UNSERIALIZE_SCALAR(innerAttrs);
        UNSERIALIZE_SCALAR(outerAttrs);
        UNSERIALIZE_SCALAR(shareable);
        UNSERIALIZE_SCALAR(outerShareable);
        UNSERIALIZE_SCALAR(attributes);
        UNSERIALIZE_SCALAR(xn);
        UNSERIALIZE_SCALAR(pxn);
        UNSERIALIZE_SCALAR(ap);
        UNSERIALIZE_SCALAR(hap);
        uint8_t domain_;
        paramIn(cp, "domain", domain_);
        domain = static_cast<DomainType>(domain_);
    }

};

const PageTableOps *getPageTableOps(GrainSize trans_granule);

} // namespace ArmISA

template class IndexingPolicyTemplate<ArmISA::TLBTypes>;

} // namespace gem5

#endif // __ARCH_ARM_PAGETABLE_H__
