/*
 * Copyright (c) 2010-2016, 2019, 2021-2025 Arm Limited
 * All rights reserved
 *
 * The license below extends only to copyright in the software and shall
 * not be construed as granting a license to any other intellectual
 * property including but not limited to intellectual property relating
 * to a hardware implementation of the functionality of the software
 * licensed hereunder.  You may use the software subject to the license
 * terms below provided that you ensure that this notice is replicated
 * unmodified and in its entirety in all distributions of the software,
 * modified or unmodified, in source code or in binary form.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __ARCH_ARM_TABLE_WALKER_HH__
#define __ARCH_ARM_TABLE_WALKER_HH__

#include <list>

#include "arch/arm/faults.hh"
#include "arch/arm/mmu.hh"
#include "arch/arm/regs/misc.hh"
#include "arch/arm/system.hh"
#include "arch/arm/tlb.hh"
#include "arch/arm/types.hh"
#include "arch/generic/mmu.hh"
#include "enums/ArmLookupLevel.hh"
#include "mem/packet_queue.hh"
#include "mem/qport.hh"
#include "mem/request.hh"
#include "sim/clocked_object.hh"
#include "sim/eventq.hh"

namespace gem5
{

struct ArmTableWalkerParams;
struct ArmWalkUnitParams;

class ThreadContext;

// §2.10 CHAOSPTW: forward decl in top-level gem5 namespace (the injector
// class is gem5::CHAOSPTW, not ArmISA::). Used as a raw pointer member of
// ArmISA::WalkUnit below.
class CHAOSPTW;

namespace ArmISA {
class WalkUnit;
class Translation;
class TLB;

class TableWalker : public ClockedObject
{
  public:
    using LookupLevel = enums::ArmLookupLevel;

    class WalkerState;
    class DescriptorBase
    {
      public:
        DescriptorBase() : lookupLevel(LookupLevel::L0) {}
        virtual ~DescriptorBase() = default;

        /** Current lookup level for this descriptor */
        LookupLevel lookupLevel;

        virtual Addr pfn() const = 0;
        virtual DomainType domain() const = 0;
        virtual bool xn() const = 0;
        virtual uint8_t ap() const = 0;
        virtual bool global(WalkerState *currState) const = 0;
        virtual uint8_t offsetBits() const = 0;
        virtual bool secure(bool have_security, WalkerState *currState) const = 0;
        virtual std::string dbgHeader() const = 0;
        virtual uint8_t* getRawPtr() = 0;
        virtual uint64_t getRawData() const = 0;
        virtual uint8_t texcb() const
        {
            panic("texcb() not implemented for this class\n");
        }
        virtual bool shareable() const
        {
            panic("shareable() not implemented for this class\n");
        }
    };

    class L1Descriptor : public DescriptorBase
    {
      public:
        /** Type of page table entry ARM DDI 0406B: B3-8*/
        enum EntryType
        {
            Ignore,
            PageTable,
            Section,
            Reserved
        };

        /** The raw bits of the entry */
        uint32_t data;

        /** This entry has been modified (access flag set) and needs to be
         * written back to memory */
        bool _dirty;

        /** Default ctor */
        L1Descriptor() : data(0), _dirty(false)
        {
            lookupLevel = LookupLevel::L1;
        }
        virtual ~L1Descriptor() = default;

        uint8_t*
        getRawPtr() override
        {
            return reinterpret_cast<uint8_t*>(&data);
        }

        uint64_t
        getRawData() const override
        {
            return (data);
        }

        std::string
        dbgHeader() const override
        {
            return "Inserting Section Descriptor into TLB\n";
        }

        uint8_t
        offsetBits() const override
        {
            return 20;
        }

        EntryType
        type() const
        {
            return (EntryType)(data & 0x3);
        }

        /** Is the page a Supersection (16 MiB)?*/
        bool
        supersection() const
        {
            return bits(data, 18);
        }

        /** Return the physcal address of the entry, bits in position*/
        Addr
        paddr() const
        {
            if (supersection())
                panic("Super sections not implemented\n");
            return mbits(data, 31, 20);
        }

        /** Return the physcal address of the entry, bits in position*/
        Addr
        paddr(Addr va) const
        {
            if (supersection())
                panic("Super sections not implemented\n");
            return mbits(data, 31, 20) | mbits(va, 19, 0);
        }

        /** Return the physical frame, bits shifted right */
        Addr
        pfn() const override
        {
            if (supersection())
                panic("Super sections not implemented\n");
            return bits(data, 31, 20);
        }

        /** Is the translation global (no asid used)? */
        bool
        global(WalkerState *currState) const override
        {
            return !bits(data, 17);
        }

        /** Is the translation not allow execution? */
        bool
        xn() const override
        {
            return bits(data, 4);
        }

        /** Three bit access protection flags */
        uint8_t
        ap() const override
        {
            return (bits(data, 15) << 2) | bits(data, 11, 10);
        }

        /** Domain Client/Manager: ARM DDI 0406B: B3-31 */
        DomainType
        domain() const override
        {
            return static_cast<DomainType>(bits(data, 8, 5));
        }

        /** Address of L2 descriptor if it exists */
        Addr
        l2Addr() const
        {
            return mbits(data, 31, 10);
        }

        /** Memory region attributes: ARM DDI 0406B: B3-32.
         * These bits are largly ignored by M5 and only used to
         * provide the illusion that the memory system cares about
         * anything but cachable vs. uncachable.
         */
        uint8_t
        texcb() const override
        {
            return bits(data, 2) | bits(data, 3) << 1 | bits(data, 14, 12) << 2;
        }

        /** If the section is shareable. See texcb() comment. */
        bool
        shareable() const override
        {
            return bits(data, 16);
        }

        /** Set access flag that this entry has been touched. Mark
         * the entry as requiring a writeback, in the future.
         */
        void
        setAp0()
        {
            data |= 1 << 10;
            _dirty = true;
        }

        /** This entry needs to be written back to memory */
        bool
        dirty() const
        {
            return _dirty;
        }

        /**
         * Returns true if this entry targets the secure physical address
         * map.
         */
        bool
        secure(bool have_security, WalkerState *currState) const override
        {
            if (have_security && currState->secureLookup) {
                if (type() == PageTable)
                    return !bits(data, 3);
                else
                    return !bits(data, 19);
            }
            return false;
        }
    };

    /** Level 2 page table descriptor */
    class L2Descriptor : public DescriptorBase
    {
      public:
        /** The raw bits of the entry. */
        uint32_t     data;
        L1Descriptor *l1Parent;

        /** This entry has been modified (access flag set) and needs to be
         * written back to memory */
        bool _dirty;

        /** Default ctor */
        L2Descriptor() : data(0), l1Parent(nullptr), _dirty(false)
        {
            lookupLevel = LookupLevel::L2;
        }

        L2Descriptor(L1Descriptor &parent) : data(0), l1Parent(&parent),
                                             _dirty(false)
        {
            lookupLevel = LookupLevel::L2;
        }

        virtual ~L2Descriptor() = default;

        uint8_t*
        getRawPtr() override
        {
            return reinterpret_cast<uint8_t*>(&data);
        }

        uint64_t
        getRawData() const override
        {
            return (data);
        }

        std::string
        dbgHeader() const override
        {
            return "Inserting L2 Descriptor into TLB\n";
        }

        DomainType
        domain() const override
        {
            return l1Parent->domain();
        }

        bool
        secure(bool have_security, WalkerState *currState) const override
        {
            return l1Parent->secure(have_security, currState);
        }

        uint8_t
        offsetBits() const override
        {
            return large() ? 16 : 12;
        }

        /** Is the entry invalid */
        bool
        invalid() const
        {
            return bits(data, 1, 0) == 0;
        }

        /** What is the size of the mapping? */
        bool
        large() const
        {
            return bits(data, 1) == 0;
        }

        /** Is execution allowed on this mapping? */
        bool
        xn() const override
        {
            return large() ? bits(data, 15) : bits(data, 0);
        }

        /** Is the translation global (no asid used)? */
        bool
        global(WalkerState *currState) const override
        {
            return !bits(data, 11);
        }

        /** Three bit access protection flags */
        uint8_t
        ap() const override
        {
           return bits(data, 5, 4) | (bits(data, 9) << 2);
        }

        /** Memory region attributes: ARM DDI 0406B: B3-32 */
        uint8_t
        texcb() const override
        {
            return large() ?
                (bits(data, 2) | (bits(data, 3) << 1) | (bits(data, 14, 12) << 2)) :
                (bits(data, 2) | (bits(data, 3) << 1) | (bits(data, 8, 6) << 2));
        }

        /** Return the physical frame, bits shifted right */
        Addr
        pfn() const override
        {
            return large() ? bits(data, 31, 16) : bits(data, 31, 12);
        }

        /** Return complete physical address given a VA */
        Addr
        paddr(Addr va) const
        {
            if (large())
                return mbits(data, 31, 16) | mbits(va, 15, 0);
            else
                return mbits(data, 31, 12) | mbits(va, 11, 0);
        }

        /** If the section is shareable. See texcb() comment. */
        bool
        shareable() const override
        {
            return bits(data, 10);
        }

        /** Set access flag that this entry has been touched. Mark
         * the entry as requiring a writeback, in the future.
         */
        void
        setAp0()
        {
            data |= 1 << 4;
            _dirty = true;
        }

        /** This entry needs to be written back to memory */
        bool
        dirty() const
        {
            return _dirty;
        }

    };

    /** Long-descriptor format (LPAE) */
    class LongDescriptor : public DescriptorBase
    {
      public:
        /** Descriptor type */
        enum EntryType
        {
            Invalid,
            Table,
            Block,
            Page
        };

        LongDescriptor()
          : data(0), _dirty(false), aarch64(false), grainSize(Grain4KB),
            physAddrRange(0), isStage2(false)
        {}

        /** The raw bits of the entry */
        uint64_t data;

        /** This entry has been modified (access flag set) and needs to be
         * written back to memory */
        bool _dirty;

        /** True if the current lookup is performed in AArch64 state */
        bool aarch64;

        /** Width of the granule size in bits */
        GrainSize grainSize;

        uint8_t physAddrRange;

        bool isStage2;

        uint8_t*
        getRawPtr() override
        {
            return reinterpret_cast<uint8_t*>(&data);
        }

        uint64_t
        getRawData() const override
        {
            return (data);
        }

        std::string
        dbgHeader() const override
        {
            switch (type()) {
              case LongDescriptor::Page:
                assert(lookupLevel == LookupLevel::L3);
                return "Inserting Page descriptor into TLB\n";
              case LongDescriptor::Block:
                assert(lookupLevel < LookupLevel::L3);
                return "Inserting Block descriptor into TLB\n";
              case LongDescriptor::Table:
                return "Inserting Table descriptor into TLB\n";
              default:
                panic("Trying to insert and invalid descriptor\n");
            }
        }

        /**
         * Returns true if this entry targets the secure physical address
         * map.
         */
        bool
        secure(bool have_security, WalkerState *currState) const override
        {
            if (type() == Block || type() == Page) {
                if (isStage2) {
                    return have_security && currState->secureLookup &&
                        !currState->vtcr.nsa;
                } else {
                    return have_security &&
                        (currState->secureLookup && !bits(data, 5));
                }
            } else {
                return have_security && currState->secureLookup;
            }
        }

        /** Return the descriptor type */
        EntryType
        type() const
        {
            switch (bits(data, 1, 0)) {
              case 0x1:
                // In AArch64 blocks are not allowed at L0 for the
                // 4 KiB granule and at L1 for 16/64 KiB granules
                switch (grainSize) {
                  case Grain4KB:
                    if (lookupLevel == LookupLevel::L0 ||
                        lookupLevel == LookupLevel::L3)
                        return Invalid;
                    else
                        return Block;

                  case Grain16KB:
                    if (lookupLevel == LookupLevel::L2)
                        return Block;
                    else
                        return Invalid;

                  case Grain64KB:
                    // With Armv8.2-LPA (52bit PA) L1 Block descriptors
                    // are allowed for 64KiB granule
                    if ((lookupLevel == LookupLevel::L1 && physAddrRange == 52) ||
                        lookupLevel == LookupLevel::L2)
                        return Block;
                    else
                        return Invalid;

                  default:
                    return Invalid;
                }
              case 0x3:
                return lookupLevel == LookupLevel::L3 ? Page : Table;
              default:
                return Invalid;
            }
        }

        /** Return the bit width of the page/block offset */
        uint8_t
        offsetBits() const override
        {
            if (type() == Block) {
                switch (grainSize) {
                    case Grain4KB:
                        return lookupLevel == LookupLevel::L1 ?
                            30 /* 1 GiB */ : 21 /* 2 MiB */;
                    case Grain16KB:
                        return 25  /* 32 MiB */;
                    case Grain64KB:
                        return lookupLevel == LookupLevel::L1 ?
                            42 /* 4 TiB */ : 29 /* 512 MiB */;
                    default:
                        panic("Invalid AArch64 VM granule size\n");
                }
            } else if (type() == Page) {
                switch (grainSize) {
                    case Grain4KB:
                    case Grain16KB:
                    case Grain64KB:
                        return grainSize; /* enum -> uint okay */
                    default:
                        panic("Invalid AArch64 VM granule size\n");
                }
            } else if (type() == Table) {
                const auto* ptops = getPageTableOps(grainSize);
                return ptops->walkBits(lookupLevel);
            }
            panic("AArch64 page table entry must be block or page\n");
        }

        /** Return the physical frame, bits shifted right */
        Addr
        pfn() const override
        {
            return paddr() >> offsetBits();
        }

        /** Return the physical address of the entry */
        Addr
        paddr() const
        {
            Addr addr = 0;
            if (aarch64) {
                addr = mbits(data, 47, offsetBits());
                if (physAddrRange == 52 && grainSize == Grain64KB) {
                    addr |= bits(data, 15, 12) << 48;
                }
            } else {
                addr = mbits(data, 39, offsetBits());
            }
            return addr;
        }

        /** Return the address of the next page table */
        Addr
        nextTableAddr() const
        {
            assert(type() == Table);
            Addr table_address = 0;
            if (aarch64) {
                table_address = mbits(data, 47, grainSize);
                // Using 52bit if Armv8.2-LPA is implemented
                if (physAddrRange == 52 && grainSize == Grain64KB)
                    table_address |= bits(data, 15, 12) << 48;
            } else {
                table_address = mbits(data, 39, 12);
            }

            return table_address;
        }

        /** Return the address of the next descriptor */
        Addr
        nextDescAddr(Addr va) const
        {
            assert(type() == Table);
            Addr pa = 0;
            if (aarch64) {
                int stride = grainSize - 3;
                int va_lo = stride * (3 - (lookupLevel + 1)) + grainSize;
                int va_hi = va_lo + stride - 1;
                pa = nextTableAddr() | (bits(va, va_hi, va_lo) << 3);
            } else {
                if (lookupLevel == LookupLevel::L1)
                    pa = nextTableAddr() | (bits(va, 29, 21) << 3);
                else  // lookupLevel == L2
                    pa = nextTableAddr() | (bits(va, 20, 12) << 3);
            }
            return pa;
        }

        /** Is execution allowed on this mapping? */
        bool
        xn() const override
        {
            assert(type() == Block || type() == Page);
            return bits(data, 54);
        }

        /** Is privileged execution allowed on this mapping? (LPAE only) */
        bool
        pxn() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 53);
        }

        /** Contiguous hint bit. */
        bool
        contiguousHint() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 52);
        }

        /** Is the translation global (no asid used)? */
        bool
        global(WalkerState *currState) const override
        {
            assert(currState && (type() == Block || type() == Page));
            const bool secure_state = currState->ss == SecurityState::Secure;
            if (!currState->aarch64 && secure_state &&
                !currState->secureLookup) {
                return false;  // ARM ARM issue C B3.6.3
            } else if (currState->aarch64) {
                if (!MMU::hasUnprivRegime(currState->regime)) {
                    // By default translations are treated as global
                    // in AArch64 for regimes without an unpriviledged
                    // component
                    return true;
                } else if (secure_state && !currState->secureLookup) {
                    return false;
                }
            }
            return !bits(data, 11);
        }

        /** FNXS for FEAT_XS only */
        bool
        fnxs() const
        {
            assert((type() == Block || type() == Page));
            return bits(data, 11);
        }

        /** Returns true if the access flag (AF) is set. */
        bool
        af() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 10);
        }

        /** 2-bit shareability field */
        uint8_t
        sh() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 9, 8);
        }

        /** 2-bit access protection flags */
        uint8_t
        ap() const override
        {
            assert(type() == Block || type() == Page);
            // Long descriptors only support the AP[2:1] scheme
            return bits(data, 7, 6);
        }

        /** Stage 1 Indirect permissions  */
        uint8_t
        piindex() const
        {
            assert(type() == Block || type() == Page);
            return (bits(data, 54) << 3) +
                (bits(data, 53) << 2) +
                (bits(data, 51) << 1) +
                bits(data, 6);
        }

        /** Read/write access protection flag */
        bool
        rw() const
        {
            assert(type() == Block || type() == Page);
            return !bits(data, 7);
        }

        /** User/privileged level access protection flag */
        bool
        user() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 6);
        }

        /** Return the AP bits as compatible with the AP[2:0] format.  Utility
         * function used to simplify the code in the TLB for performing
         * permission checks. */
        static uint8_t
        ap(bool rw, bool user)
        {
            return ((!rw) << 2) | (user << 1);
        }

        DomainType
        domain() const override
        {
            // Long-desc. format only supports Client domain
            return DomainType::Client;
        }

        /** Attribute index */
        uint8_t
        attrIndx() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 4, 2);
        }

        /** Memory attributes, only used by stage 2 translations */
        uint8_t
        memAttr() const
        {
            assert(type() == Block || type() == Page);
            return bits(data, 5, 2);
        }

        /** Set access flag that this entry has been touched.  Mark the entry as
         * requiring a writeback, in the future. */
        void
        setAf()
        {
            data |= 1 << 10;
            _dirty = true;
        }

        /** This entry needs to be written back to memory */
        bool
        dirty() const
        {
            return _dirty;
        }

        /** Whether the subsequent levels of lookup are secure */
        bool
        secureTable() const
        {
            assert(type() == Table);
            return !bits(data, 63);
        }

        /** Two bit access protection flags for subsequent levels of lookup */
        uint8_t
        apTable() const
        {
            assert(type() == Table);
            return bits(data, 62, 61);
        }

        /** R/W protection flag for subsequent levels of lookup */
        uint8_t
        rwTable() const
        {
            assert(type() == Table);
            return !bits(data, 62);
        }

        /** User/privileged mode protection flag for subsequent levels of
         * lookup */
        uint8_t
        userTable() const
        {
            assert(type() == Table);
            return !bits(data, 61);
        }

        /** Is execution allowed on subsequent lookup levels? */
        bool
        xnTable() const
        {
            assert(type() == Table);
            return bits(data, 60);
        }

        /** Is privileged execution allowed on subsequent lookup levels? */
        bool
        pxnTable() const
        {
            assert(type() == Table);
            return bits(data, 59);
        }
    };

    class TableWalkerState : public Packet::SenderState
    {
      public:
        Tick delay = 0;
        Event *event = nullptr;
        // [MMU-TRACE v3] PTW request id carried from the fetch to the
        // response, so request/response correlating uses a real ID.
        uint64_t chaosPtwRequestId = 0;
    };

    class WalkerState
    {
      public:
        /** Thread context that we're doing the walk for */
        ThreadContext *tc;

        /** If the access is performed in AArch64 state */
        bool aarch64;

        /** Current exception level */
        ExceptionLevel el;

        /** Current translation regime */
        TranslationRegime regime;

        /** Current physical address range in bits */
        int physAddrRange;

        /** Request that is currently being serviced */
        RequestPtr req;

        /** Initial walk entry allowing to skip lookup levels */
        TlbEntry walkEntry;

        /** ASID that we're servicing the request under */
        uint16_t asid;
        vmid_t vmid;

        /** Translation state for delayed requests */
        BaseMMU::Translation *transState;

        /** The fault that we are going to return */
        Fault fault;

        /** The virtual address that is being translated with tagging removed.*/
        Addr vaddr;

        /** The virtual address that is being translated */
        Addr vaddr_tainted;

        /** Cached copy of the sctlr as it existed when translation began */
        SCTLR sctlr;

        /** Cached copy of the scr as it existed when translation began */
        SCR scr;

        /** Cached copy of the cpsr as it existed when translation began */
        CPSR cpsr;

        /** Cached copy of ttbcr/tcr as it existed when translation began */
        union
        {
            TTBCR ttbcr; // AArch32 translations
            TCR tcr;     // AArch64 translations
        };

        /** Cached copy of the htcr as it existed when translation began. */
        HTCR htcr;

        /** Cached copy of the htcr as it existed when translation began. */
        HCR  hcr;

        /** Cached copy of the vtcr as it existed when translation began. */
        VTCR_t vtcr;

        /** If the access is a write */
        bool isWrite;

        /** If the access is a fetch (for execution, and no-exec) must be checked?*/
        bool isFetch;

        /** Security State of the access */
        SecurityState ss;
        /** Whether lookups should be treated as using the secure state.
         * This is usually the same as isSecure, but can be set to false by the
         * long descriptor table attributes. */
        bool secureLookup = false;

        /** IPA space (Secure vs NonSecure); stage2 only.
         * This depends on whether the stage1 translation targeted
         * a secure or non-secure IPA space */
        PASpace ipaSpace;

        /** True if table walks are uncacheable (for table descriptors) */
        bool isUncacheable;

        /** Helper variables used to implement hierarchical access permissions
         * when the long-desc. format is used. */
        struct LongDescData
        {
            bool rwTable = false;
            bool userTable = false;
            bool xnTable = false;
            bool pxnTable = false;
        };
        std::optional<LongDescData> longDescData;

        /** Hierarchical access permission disable */
        bool hpd;

        uint8_t sh;
        uint8_t irgn;
        uint8_t orgn;

        /** Flag indicating if a second stage of lookup is required */
        bool stage2Req;

        /** Is the access is a stage2 access */
        bool isStage2;

        /** A pointer to the stage 2 translation that's in progress */
        BaseMMU::Translation *stage2Tran;

        /** If the mode is timing or atomic */
        bool timing;

        /** If the atomic mode should be functional */
        bool functional;

        /** Save mode for use in delayed response */
        BaseMMU::Mode mode;

        /** The translation type that has been requested */
        MMU::ArmTranslationType tranType;

        /** Short-format descriptors */
        L1Descriptor l1Desc;
        L2Descriptor l2Desc;

        /** Long-format descriptor (LPAE and AArch64) */
        LongDescriptor longDesc;

        /** Whether the response is delayed in timing mode due to additional
         * lookups */
        bool delayed;

        TableWalker *tableWalker;

        // [MDSPEC][R4-5.9] T08 walk/fill pairing: per-walk identity + the
        // tick the walk was ISSUED at. Assigned once in TableWalker::walk()
        // when this WalkerState is constructed; consumed by the CHAOSArmTLB
        // walk_pairing injector at the walk-issue decision point so the
        // emitted tlb_walk / tlb_refill node pair shares one walk_id and
        // carries the true issue/completion ticks (the pairing evidence).
        // Default 0 = walk never reached the injector (inert, zero effect).
        uint64_t chaosWalkId = 0;
        Tick chaosWalkStartTick = 0;

        // [MMU-TRACE v1] Translation identity of the request this walk
        // serves (copied at WalkerState construction) and the walk's own
        // explicit event cursor. These are observation-only.
        uint64_t chaosMmuTranslationId = 0;
        uint64_t chaosMmuUniqueReqId = 0;
        uint64_t chaosLastEvent = 0;
        uint64_t chaosPteReadEvent = 0;
        Addr chaosLastPteAddr = 0;
        // [MMU-TRACE v3] per-level PTW request identity (one fetchDescriptor).
        uint64_t chaosPtwRequestId = 0;
        // [MMU-PHASE3 / M06] Non-zero when a descriptor fault was injected
        // into THIS walk. generateLongDescFault uses it to emit the real
        // fault-result propagation witness only for the injected walk.
        uint64_t chaosMmuFaultPtag = 0;

        /** Timestamp for calculating elapsed time in service (for stats) */
        Tick startTime;

        /** Page entries walked during service (for stats) */
        unsigned levels;

        void doL1Descriptor();
        void doL2Descriptor();

        void doLongDescriptor();

        WalkerState();

        std::string name() const { return tableWalker->name(); }
    };

    class Port : public QueuedRequestPort
    {
      public:
        Port(TableWalker &_walker, RequestorID id);

        // [MMU-TRACE v3] Set immediately before a synchronous send; consumed
        // by createPacket and stored in TableWalkerState.
        void setChaosPtwRequestId(uint64_t id) { chaosPtwRequestId = id; }
        void sendFunctionalReq(const RequestPtr &req, uint8_t *data);
        void sendAtomicReq(const RequestPtr &req, uint8_t *data, Tick delay);
        void sendTimingReq(const RequestPtr &req, uint8_t *data, Tick delay,
            Event *event);

        bool recvTimingResp(PacketPtr pkt) override;

        RequestorID
        requestorId() const
        {
            return _requestorId;
        }

      private:
        void handleRespPacket(PacketPtr pkt, Tick delay=0);
        void handleResp(TableWalkerState *state, Addr addr,
                        Addr size, Tick delay=0);

        uint64_t chaosPtwRequestId = 0;
        PacketPtr createPacket(const RequestPtr &req, uint8_t *data,
                               Tick delay, Event *event);

      private:
        TableWalker &owner;

        /** Packet queue used to store outgoing requests. */
        ReqPacketQueue reqQueue;

        /** Packet queue used to store outgoing snoop responses. */
        SnoopRespPacketQueue snoopRespQueue;

        /** Cached requestorId of the table walker */
        RequestorID _requestorId;
    };

    PARAMS(ArmTableWalker);
    TableWalker(const Params &p);

    gem5::Port &getPort(const std::string &if_name,
                        PortID idx = InvalidPortID) override;

    void setMmu(MMU *_mmu);
    void setTestInterface(TlbTestInterface *ti);

    // [MDSPEC][R4-5.9] T08 walk/fill pairing injector attachment. Set from
    // CHAOSArmTLB's self-attach (same pattern as TLB::chaosTLB). nullptr =
    // no injector → TableWalker::walk emits nothing and drops no walk
    // (byte-equivalent to the pre-R4-5.9 tree).
    class ::gem5::CHAOSArmTLB *chaosTLB = nullptr;
    void setChaosTLB(class ::gem5::CHAOSArmTLB *p) { chaosTLB = p; }

    // Monotonic per-walk id source (pairing key). Incremented once per
    // WalkerState created in walk().
    uint64_t chaosNextWalkId = 0;

    // [MMU-TRACE v1] Translation identity in flight (set by MMU::getTE around
    // walk(); copied into the WalkerState synchronously, so a timing walk
    // keeps its identity after the setter is cleared).
    uint64_t chaosMmuTranslationId = 0;
    uint64_t chaosMmuUniqueReqId = 0;
    void setChaosMmuContext(uint64_t tid, uint64_t uid)
    {
        chaosMmuTranslationId = tid;
        chaosMmuUniqueReqId = uid;
    }

    WalkUnit *getAvailableWalk(BaseMMU::Mode mode, bool stage2,
                               bool functional) const;

    WalkUnit *busyOnSamePage(Addr iaddr, BaseMMU::Mode mode,
                             bool stage2) const;

    Port &getTableWalkerPort();

    Fault walk(const RequestPtr &req, ThreadContext *tc, uint16_t asid,
               vmid_t vmid, MMU::Mode mode, MMU::Translation *trans,
               bool timing, bool functional, SecurityState ss,
               PASpace ipaspace, MMU::ArmTranslationType tran_type,
               bool stage2_req, bool stage2, const TlbEntry *walk_entry);

    /**
     * A walk has finished. Schedule a look in
     * the pending queue to see if there is a pending walk awaiting
     * to be executed next
     *
     * @param wu WalkUnit calling the method. With this param the walk unit
     *           signals the Table Walker it is ready to accept a new walk
     *           request
     */
    void nextWalk(WalkUnit *wu);

    /**
     * Squash the walk passed as first argument. This would happen
     * in two cases
     * 1) The instruction generating the memory ref has been squashed
     * 2) No need to walk as the translation is now available in the TLB
     */
    void squashWalk(WalkerState *curr_state);

    void completeDrain();
    DrainState drain() override;

  public:
    TypeTLB modeToType(BaseMMU::Mode mode) const;

    bool
    haveLargeAsid64() const
    {
        return _haveLargeAsid64;
    }
    uint8_t
    physAddrRange() const
    {
        return _physAddrRange;
    }

  private:
    MMU *mmu;

    /** Pool of walking units */
    std::vector<WalkUnit *> walkUnits;

    /** walking unit for functional walks*/
    WalkUnit *walkUnitFunctionalS1;
    WalkUnit *walkUnitFunctionalS2;

    /** Requestor id assigned by the MMU. */
    RequestorID requestorId;

    /** Table Walker port */
    Port *port;

    /** Cached copies of system-level properties */
    const ArmRelease *release;
    uint8_t _physAddrRange;
    bool _haveLargeAsid64;

  private:
    /** Statistics */
    void pendingChange();

  public:
    /** Statistics */
    static const unsigned REQUESTED = 0;
    static const unsigned COMPLETED = 1;

    mutable unsigned pendingReqs;
    mutable Tick pendingChangeTick;

    struct TableWalkerStats : public statistics::Group
    {
        TableWalkerStats(statistics::Group *parent);
        statistics::Scalar instructionWalksS1;
        statistics::Scalar instructionWalksS2;
        statistics::Scalar dataWalksS1;
        statistics::Scalar dataWalksS2;
        statistics::Scalar walksShortDescriptor;
        statistics::Scalar walksLongDescriptor;
        statistics::Vector walksShortTerminatedAtLevel;
        statistics::Vector walksLongTerminatedAtLevel;
        statistics::Scalar squashedBefore;
        statistics::Scalar squashedAfter;
        statistics::Histogram walkWaitTime;
        statistics::Histogram walkServiceTime;
        // Essentially "L" of queueing theory
        statistics::Histogram pendingWalks;
        statistics::Vector pageSizes;
        statistics::Vector2d requestOrigin;

        statistics::Formula walks;
    } stats;

    /** Queue of requests that have passed are waiting because the walker is
     * currently busy. */
    std::list<WalkerState *> pendingQueue;
    std::vector<WalkerState *> inCompletionWalks;
};

class WalkUnit : public ClockedObject
{
  public:
    using LookupLevel = enums::ArmLookupLevel;
    using WalkerState = TableWalker::WalkerState;
    using DescriptorBase = TableWalker::DescriptorBase;
    using L1Descriptor = TableWalker::L1Descriptor;
    using L2Descriptor = TableWalker::L2Descriptor;
    using LongDescriptor = TableWalker::LongDescriptor;

    // §2.10 CHAOSPTW: raw pointer to the page-table-walker fault injector.
    // Set by the injector's startup() (Python config passes walker=this).
    // nullptr = no injection (zero regression). FS-only (SE走translateMmuOff,
    // doLongDescriptor never called in SE — doc §0.3). CHAOSPTW is in the
    // top-level gem5 namespace (forward-declared above table_walker.hh's
    // ArmISA block).
    CHAOSPTW *chaosPTW = nullptr;
    void setChaosPTW(CHAOSPTW *p);

    /** This translation class is used to trigger the data fetch once a timing
        translation returns the translated physical address */
    class Stage2Walk : public BaseMMU::Translation
    {
      private:
        uint8_t      *data;
        int          numBytes;
        RequestPtr   req;
        Event        *event;
        WalkUnit &parent;
        Addr         oVAddr;
        BaseMMU::Mode mode;
        MMU::ArmTranslationType tranType;

        TableWalker::Port *port;
        uint64_t chaosPtwRequestId;

      public:
        Fault fault;

        Stage2Walk(WalkUnit &_parent, uint8_t *_data, Event *_event,
                   Addr vaddr, BaseMMU::Mode mode,
                   MMU::ArmTranslationType tran_type,
                   TableWalker::Port *_port,
                   uint64_t ptw_request_id = 0);

        void markDelayed() {}

        void finish(const Fault &fault, const RequestPtr &req,
            ThreadContext *tc, BaseMMU::Mode mode);

        void
        setVirt(Addr vaddr, int size, Request::Flags flags,
                int requestorId)
        {
            numBytes = size;
            req->setVirt(vaddr, size, flags, requestorId, 0);
        }

        void translateTiming(ThreadContext *tc);
    };

    Fault readDataUntimed(ThreadContext *tc, Addr vaddr, Addr desc_addr,
                          uint8_t *data, int num_bytes, Request::Flags flags,
                          BaseMMU::Mode mode, MMU::ArmTranslationType tran_type,
                          bool functional, uint64_t ptw_request_id = 0);
    void readDataTimed(ThreadContext *tc, Addr desc_addr,
                       Stage2Walk *translation, int num_bytes,
                       Request::Flags flags, uint64_t ptw_request_id = 0);

    /** Timing mode: saves the currState into the stateQueues */
    void stashCurrState(WalkerState *state, int queue_idx);
    bool busyOnSamePage(Addr iaddr) const;

  protected:

    /** Queues of requests for all the different lookup levels */
    std::list<WalkerState *> stateQueues[LookupLevel::Num_ArmLookupLevel];

    /** The MMU to forward second stage look upts to */
    MMU *mmu;

    /** Pointer to the parent table walker */
    TableWalker *parent;

    TableWalker::Port *port;

    /** Indicates whether this table walker is part of the stage 2 mmu */
    const bool isStage2;

    /** TLB that is initiating these table walks */
    TLB *tlb;

    /** Walk type */
    const TypeTLB walkType;

    /** Functional */
    const bool isFunctional;

    /** Is the walk unit free? */
    bool available;

  public:
    PARAMS(ArmWalkUnit);
    WalkUnit(const Params &p);
    virtual ~WalkUnit();

    TypeTLB
    type() const
    {
        return walkType;
    }

    bool
    stage2() const
    {
        return isStage2;
    }

    bool
    functional() const
    {
        return isFunctional;
    }

    bool
    isAvailable() const
    {
        return available;
    }
    void
    isAvailable(bool _available)
    {
        available = _available;
    }

    /** Checks if all state is cleared and if so, completes drain */
    bool completeDrain();
    DrainState drain() override;

    Fault walk(WalkerState *state);

    void scheduleWalk(WalkerState *next_walk, Tick when);

    void setMmu(MMU *_mmu);
    void
    setPort(TableWalker::Port *_port)
    {
        port = _port;
    }
    TableWalker::Port &
    getTableWalkerPort() const
    {
        return *port;
    }
    void
    setTableWalker(TableWalker *_parent)
    {
        parent = _parent;
    }

    void memAttrs(WalkerState *state, TlbEntry &te, uint8_t texcb, bool s);
    void memAttrsLPAE(WalkerState *state, TlbEntry &te,
                      LongDescriptor &lDescriptor);
    void memAttrsAArch64(WalkerState *state, TlbEntry &te,
                         LongDescriptor &lDescriptor);
    void memAttrsWalkAArch64(WalkerState *state, TlbEntry &te);
    bool uncacheableFromAttrs(uint8_t attrs);

    static LookupLevel toLookupLevel(uint8_t lookup_level_as_int);

  private:
    class WalkEvent : public Event, public Named
    {
      public:
        WalkEvent(WalkUnit *_parent, const std::string &_name)
            : Event(), Named(_name), parent(_parent)
        {}

        void
        process() override
        {
            parent->processWalkWrapper(state);
        }

        void
        setState(WalkerState *next_state)
        {
            state = next_state;
        }

      private:
        WalkUnit *parent;
        WalkerState *state;
    } doProcessEvent;
    void processWalkWrapper(WalkerState *state);

    void doL1Descriptor(WalkerState *state);
    void doL1DescriptorWrapper();
    EventFunctionWrapper doL1DescEvent;

    void doL2Descriptor(WalkerState *state);
    void doL2DescriptorWrapper();
    EventFunctionWrapper doL2DescEvent;

    void doLongDescriptor(WalkerState *state);

    void doL0LongDescriptorWrapper();
    EventFunctionWrapper doL0LongDescEvent;
    void doL1LongDescriptorWrapper();
    EventFunctionWrapper doL1LongDescEvent;
    void doL2LongDescriptorWrapper();
    EventFunctionWrapper doL2LongDescEvent;
    void doL3LongDescriptorWrapper();
    EventFunctionWrapper doL3LongDescEvent;

    void doLongDescriptorWrapper(LookupLevel curr_lookup_level);
    Event* LongDescEventByLevel[4];

    void fetchDescriptor(Addr desc_addr, DescriptorBase &descriptor,
                         int num_bytes, Request::Flags flags,
                         LookupLevel lookup_lvl, Event *event,
                         void (WalkUnit::*doDescriptor)(WalkerState *state),
                         WalkerState *state);

    Fault generateLongDescFault(WalkerState *state, ArmFault::FaultSource src);

    void insertTableEntry(WalkerState *state, DescriptorBase &descriptor,
                          bool long_descriptor);
    void insertPartialTableEntry(WalkerState *state);

    /** Returns a tuple made of:
     * 1) The address of the first page table
     * 2) The address of the first descriptor within the table
     * 3) The page table level
     */
    std::tuple<Addr, Addr, LookupLevel> walkAddresses(WalkerState *state,
                                                      Addr ttbr, GrainSize tg,
                                                      int tsz, int pa_range);

    Fault processWalk(WalkerState *state);
    Fault processWalkLPAE(WalkerState *state);
    Fault processWalkAArch64(WalkerState *state);

    Addr maxTxSz(WalkerState *state, GrainSize tg) const;
    Addr s1MinTxSz(WalkerState *state, GrainSize tg) const;
    bool s1TxSzFault(WalkerState *state, GrainSize tg, int tsz) const;
    bool checkVAOutOfRange(WalkerState *state, int top_bit, int tsz,
                           bool low_range);

    /// Returns true if the address exceeds the range permitted by the
    /// system-wide setting or by the TCR_ELx IPS/PS setting
    bool checkAddrSizeFaultAArch64(Addr addr, int pa_range);

    /// Returns true if the table walk should be uncacheable
    bool uncacheableWalk(WalkerState *state) const;

    static uint8_t pageSizeNtoStatBin(uint8_t N);

    void mpamTagTableWalk(WalkerState *state, RequestPtr &req) const;

  public: /* Testing */
    TlbTestInterface *test;

    void setTestInterface(TlbTestInterface *ti);

    Fault testWalk(WalkerState *state, const RequestPtr &walk_req,
                   DomainType domain, LookupLevel lookup_level);
};

} // namespace ArmISA
} // namespace gem5

#endif //__ARCH_ARM_TABLE_WALKER_HH__
