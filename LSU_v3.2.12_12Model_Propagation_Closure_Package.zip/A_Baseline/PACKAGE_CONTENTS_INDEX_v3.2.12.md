# PACKAGE CONTENTS INDEX — LSU v3.2.12 12-Model Propagation Closure Package

Assembled 2026-11-11 (plan Task 20) and **rebuilt the same day** from worktree
`lsu-platform-v3.2.12` HEAD `278913ba3b00db8a64f960f75a6976b5ad6864f1`, final
binary `68c6ce737a95747e5f35be06fea160b4f461baead2c0b4d85cf900c4d047e4e8`
(both copies re-verified at rebuild). The first assembly (HEAD `87287cbd`)
shipped the then-current intermediate closure status MD; this rebuild carries
the FINAL committed files — regenerated `Closure_Matrix_Status_v3.2.12.md`
(32 rows / 173 records), updated `PACKAGE_MANIFEST_v3.2.12.md` (20/20 READY),
fresh git-state and validation captures — while every other file was verified
byte-identical to the first assembly (1456 of 1458 packaged files unchanged;
the finalization commits `1222daeb`/`b5e87eba`/`278913ba` committed exactly
the bytes the first assembly had staged for the report, blockers, workbook
and status matrix). This index maps the 20 required items of
`PACKAGE_MANIFEST_v3.2.12.md` to their locations inside this ZIP. No `build/`,
`.git/`, `.superpowers/`, scratch directories, or superseded packages are
included; no historical file was modified or repackaged — every artifact is a
verbatim copy, and the only new files are the ones generated at assembly
(marked DERIVED/NEW below).

| # | Manifest item | Location in this ZIP |
|---|---|---|
| 1 | Acceptance standard (frozen, E1–E7 + §12.5) | `B_Standard/LSU_Propagation_Acceptance_Standard_v3.2.12.md` |
| 2 | Pilot-record schema | `B_Standard/pilot_record.schema.md` |
| 3 | 12-model propagation closure matrix (FINAL, 32 rows / 173 records) | `C_Matrix_Audits/LSU_12Model_Propagation_Closure_Matrix_v3.2.12.csv` |
| 4 | Closure summary / matrix-status MD (FINAL regeneration) | `C_Matrix_Audits/Closure_Matrix_Status_v3.2.12.md` — regenerated 2026-11-11 from the FINAL matrix: 32 rows / 173 records, 12/12 models at COMPLETE_CAUSAL_CHAIN, E1–E7 + §12.5 frozen-import caveats, validation table with fresh pytest captures. |
| 5 | Diagnostic feature dataset (FINAL, 607 rows = 173 PILOT + 434 PATH_FRAGMENT) | `C_Matrix_Audits/LSU_12Model_Diagnostic_Feature_Dataset_v3.2.12.csv` |
| 6 | Missing-evidence matrix CSV (194 rows) | `C_Matrix_Audits/MissingEvidenceMatrix.csv` |
| 7 | Missing-evidence narrative | `C_Matrix_Audits/MissingEvidenceMatrix_v3.2.12.md` |
| 8 | LQ04 audit (E1) | `C_Matrix_Audits/LQ04_Propagation_Audit_v3.2.12.md` + `C_Matrix_Audits/records/LQ04_verdict_v3.2.12.json` |
| 9 | A01 audit + `68c6ce73` rerun evidence (E7) | `C_Matrix_Audits/A01_Propagation_Audit_v3.2.12.md` + `records/A01_verdict_v3.2.12{,_v3}.json` + `A01_A03_Rerun_Records_v3.2.12.csv` + `A01_A03_Rerun_NodePresence_DataDelta_v3.2.12.md` |
| 10 | A03 audit + `68c6ce73` rerun evidence (E6) | `C_Matrix_Audits/A03_Propagation_Audit_v3.2.12.md` + `records/A03_verdict_v3.2.12{,_v3}.json` + shared rerun CSV/MD |
| 11 | FW02 audit + control-fix pair | `C_Matrix_Audits/FW02_SQ01_SQ03_SP05_Evidence_Audit_v3.2.12.md` (§1) + `FW02_CONTROL_FIX_v3.2.12.md` + `FW02_CONTROL_FIX_VERIFIED_v3.2.12.md` + `records/FW02_verdict_v3.2.12.json` |
| 12 | SQ01 audit (E2, eligible-ordinal closure) | `C_Matrix_Audits/SQ_Ordinal_Eligibility_Preflight_v3.2.12.md` + `SQ01_SQ03_SP05_Eligible_Run_Records_v3.2.12.csv` + `records/SQ01_verdict{,_elig}_v3.2.12.json` |
| 13 | SQ03 audit (E3) | same preflight/records set + `records/SQ03_verdict{,_elig}_v3.2.12.json` |
| 14 | SP05 audit (E4) | same preflight/records set + `records/SP05_verdict{,_elig}_v3.2.12.json` |
| 15 | Frozen four (DA04/LP01/MD04/FW05) re-adjudication evidence | `C_Matrix_Audits/frozen_four/SUPPLEMENTARY_ORACLE_MANIFEST_v3.2.12.csv` + `FROZEN_PRIOR_PROPAGATION_VERDICTS_v3.2.12.json` + `{LP01,DA04,MD04,FW05}_frozen_records_v3.2.11.json` (22 imported records) + `MODEL_STATUS_MATRIX_v3.2.11_frozen.csv`; the SUPP pilot raw evidence is in `E_traces_pilots_v3_2_12/SUPP-{DA04,LP01,MD04,FW05}-*` |
| 16 | RP01 package (preflight + implementation evidence + verdict) | `D_RP01/RP01_CountOnly_Preflight_v3.2.12.{csv,md}` + `rp01_preflight_raw/` + `RP01_Task15_Runbook_v3.2.12.md` + `RP01_Task15_Evidence_v3.2.12.md` + `RP01_verdict_v3.2.12.json` + `RP01_records_v3.2.12.binary-68c6ce73.json`; pilots in `E_traces_pilots_v3_2_12/RP01-*` |
| 17 | W1–W8 baseline map + FINAL baselines (9/9 PASS on `68c6ce73…`) | `F_Workloads_Oracles/W1_W8_Baseline_Map_v3.2.12.csv` + `FINAL_BASELINE_SUMMARY.csv` + `FINAL_BASELINE_REPORT.md` (the superseded `720eb780` baseline pair stays out of the ZIP, on disk in the repo) |
| 18 | Excel workbook v3.2.7 (published) | `G_Config/gem5-fi-LSU-Final-Paper-Experiment-Plan-v3.2.7.xlsx` — committed in `b5e87eba` (21 sheets, sha256 `3b219ee0…`, builder tests green; carries the final matrix sha `064e28b4…` in its change record) |
| 19 | MODEL_STATUS_MATRIX.csv (derived rewrite, 12/12) + tooling | `G_Config/MODEL_STATUS_MATRIX.csv` (committed in `b5e87eba`; derived only, "PROPAGATION_VERIFIED=1 for 12 model(s); no cell hand-set"; frozen v3.2.11 copy also in item 15) + `G_Config/{update_lsu_v327_audit,build_lsu_v327_workbook,lsu_12model_closure,lsu_propagation_audit}.py` + `G_Config/test_*.py` |
| 20 | Final acceptance report + blockers + git/binary/SHA records | `A_Baseline/LSU_v3.2.12_Final_Acceptance_Report.md` (published in `278913ba`) + `LSU_v3.2.12_BLOCKERS.md` + `GIT_STATE_v3.2.12.txt` + `BINARY_SHA256_v3.2.12.txt` + `DELIVERABLES_SHA256_v3212.txt` (ZIP root; the worktree-root `.zip.sha256` sidecar records this ZIP itself) |

Extras carried per the assembly dispatch (all NEW files generated at
assembly/rebuild, except where noted):

- **Source diff**: `A_Baseline/GIT_DIFF_CODE_v3.2.12.txt` — `git diff
  c02976b2..HEAD` restricted to code paths (`CHAOS/gem5/src`, `configs`,
  `tools`, `tests`, `schemas`; 36 files, 9,741 insertions). The full-tree diff
  is dominated by committed evidence artifacts (pilots/traces/docs;
  1,369 files, ~1.94M insertions) and is summarized in
  `A_Baseline/GIT_COMMIT_LOG_v3.2.12.txt` (49 commits, one-line log).
- **Commit log**: `A_Baseline/GIT_COMMIT_LOG_v3.2.12.txt` (NEW).
- **Binary SHA**: `A_Baseline/BINARY_SHA256_v3.2.12.txt` (NEW; both copies
  `68c6ce73…`) + `A_Baseline/logs_v3_2_12/binary_v3212_final_candidate.sha256`
  + `binary_v3212_trace.sha256` (round records).
- **12 hook map**: `B_Standard/LSU_12Model_Hook_Map_v3.2.12.csv` (DERIVED —
  one row per model: SubUnit, hook/FaultDefinition, best binary group,
  complete contexts; generated verbatim from the closure matrix, no hand
  values; unchanged by the rebuild because the matrix sha is unchanged).
- **Traces (original + supplementary)**:
  `E_traces_pilots_v3_2_12/` — all 95 v3.2.12-round pilot directories
  verbatim (original Task 5/7–13 SUPP runs, supplementary `*B` eligible
  reruns, `C*` controls, A01/A03 `*C` reruns on the final binary, RP01 fault
  + control runs), each with its raw trace (`trace_v31.jsonl` or
  `prop_trace.csv.gz`), `pilot_meta.json`, `manifest.json`, `oracle.log`,
  `stdout.log`/`stderr.log`, injector sidecars. Historical-vintage traces
  (`pilots_v3_2_1`…`pilots_v3_2_10`, already delivered inside the
  v3.2.5–v3.2.10 packages) stay out; their per-record graded evidence is in
  `C_Matrix_Audits/records/*_records_v3.2.12.binary-*.json`. The frozen
  `FW05@8377c011` evidence paths recorded in the import refer to the
  v3.2.11-era `audit_v3_2_11/extracted_evidence/FW05_v3_2_7/` extraction
  (shipped in the v3.2.11 package), not restaged here.
- **Golden/Actual oracles**: golden files `F_Workloads_Oracles/workloads/*.golden`
  (+ `SHA256SUMS.txt`, `oracle_check.py`); actual per-pilot oracles are the
  `oracle.log`/`stdout.log` inside each pilot directory; the round-level
  golden/actual pairs are `F_Workloads_Oracles/FINAL_BASELINE_SUMMARY.csv`
  and `C_Matrix_Audits/frozen_four/SUPPLEMENTARY_ORACLE_MANIFEST_v3.2.12.csv`.
- **Workloads + SHA256**: `F_Workloads_Oracles/workloads/` (9 W-mapped
  binaries + sources + goldens + compile/run scripts, 6.7 MB) and
  `F_Workloads_Oracles/FW05_Workload_Archive/` (W8a provenance, 2.8 MB).
- **Five-context audits / per-model audits**: items 8–15 above; per-record
  evidence `C_Matrix_Audits/records/` (45 JSONs: per-binary record groups,
  verdicts, eligible-ordinal verdicts).
- **Test/build logs**: `A_Baseline/logs_v3_2_12/` (round build logs, baseline
  inventory, disk-reclaim record) + `A_Baseline/validation/` (NEW captures at
  rebuild: closure suite 36 passed, v327 audit+workbook 24 passed, status
  derivation dry run 12/12 — dry-run CSV byte-identical to the committed
  `MODEL_STATUS_MATRIX.csv` body, matrix sha + 32-row/173-record check).
- **Git state**: `A_Baseline/GIT_STATE_v3.2.12.txt` (NEW; branch, HEAD
  `278913ba`, porcelain status at rebuild, binary SHAs, disk free).
- **Blockers**: `A_Baseline/LSU_v3.2.12_BLOCKERS.md` (published, `278913ba`;
  its §5 "status MD intermediate" note is resolved by this rebuild — the ZIP
  now carries the FINAL status MD, so that blocker paragraph is historical).
