# LSU v3.3.2 — Formal Experiment Readiness Package

Date: 2026-11-11
Status: **PARTIALLY_READY** · `12_MODEL_FORMAL_READY = NO`
Final source HEAD: `fc60822408cbb3f5af4788bd99fc82c114917367`
Final binary SHA256: `070d68a688464fa737e6bf102f44a27e911dc29d15142d77c82ec2083115f5ca`
Scope: 12 models × R01–R05 = 60 contexts; 60 fault + 60 control runs.
Formal campaign: **NOT STARTED**.

## Headline

- 60/60 contexts mapped on one binary; 60/60 faults injected; 60/60
  controls zero-injection with real artifacts; 60/60 causal rows.
- Terminals: SDC 36, MASKED 12, SQUASHED 1, HANG 10 (A03 timeout/partial,
  RP01 in-simulator watchdog), UNRESOLVED 1 (A01-R03).
- P0 fixes landed: W4 load-preserving candidate, RP01 partial-overlap
  candidate, MD04 8-violation candidate, LP01 PC/VA identity, A03 PC +
  stuck lifecycle, DA04/MD04 control guards.
- Regressions: `pytest tests/ -q` 180 passed; platform tests 120 passed.

## Required deliverables in this package

| # | File |
|---|---|
| 1 | `report/LSU_v3.3.2_Final_Acceptance_Report.md` |
| 2 | `LSU_60Context_Final_Readiness_Matrix.csv` |
| 3 | `roi/LSU_60Context_ROI_Percentile_Mapping.csv` |
| 4 | `roi/LSU_60Context_Distinctness_Audit.csv` |
| 5 | `LSU_12Model_Source_Hook_Audit.csv` |
| 6 | `LSU_Workload_Oracle_Final_Audit.csv` |
| 7 | `controls/LSU_Fault_Control_Pair_Final.csv` |
| 8 | `propagation/LSU_60Context_Causal_Propagation_Final.csv` |
| 9 | `LSU_Diagnostic_Features_Final.csv` |
| 10 | `LSU_Formal_Experiment_Config.xlsx` |
| 11 | `report/LSU_Final_Blockers.md` |
| 12 | `subagent_reports/Agent_F_Independent_Acceptance_v332.md` |
| 13 | `sq_workload/LSU_SQ_Workload_Decision.md` + evidence |
| 14 | `report/SOURCE_DIFF.txt`, `report/BINARY_SHA256.txt` |
| 15 | `runs/` — 120 run dirs (summaries, commands, meta, logs) + curated traces |
| 16 | `report/DRY_RUN_RESULTS.txt` |

## Evidence policy

- `runs/<run>/summary.json` is the normalized per-run record; `command.txt`,
  `pilot_meta.json`, `oracle.log`, stdout/stderr and model injection logs are
  retained. Full `trace_v31.jsonl` is included for A01/FW02/SQ01/SQ03/SP05
  R01 faults and 2000-line excerpts for other R01 controls; 5000-line excerpts
  for the larger fault traces (FW05/DA04/LP01/MD04/LQ04). A03 has no full
  trace by design (persistent fault + 30 s bound); its capped log head is
  included. RP01 has partial prop traces + watchdog evidence.
- Candidate workloads are marked `CANDIDATE_PENDING_APPROVAL`; the frozen
  workbook is untouched (`git diff 8f7a1354 -- docs/.../excel` empty).
- No SampleRunID, seed, or frozen verdict was modified.

## Reproduce

```
python3 tools/lsu_v332_matrix.py --models all --roles fault,control
python3 tools/lsu_v332_report.py
python3 tools/lsu_v332_supplement.py
```

The final binary is not embedded (1.1 GB); its SHA256 and build provenance are
in `report/PROVENANCE.md` and `report/BINARY_SHA256.txt`.
