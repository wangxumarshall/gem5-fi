# Execute-load hook excerpt — CHAOS/gem5/src/cpu/o3/lsq_unit.cc lines 795-830 (Task 6 commit a6abe75d)
# Full file copied in 06_cpp_hook/lsq_unit.cc; this excerpt isolates the LQ04
# injection point at the end of a successful executeLoad round.


    // LQ04 (LSU v3.2.10): the injection point, at the end of a successful
    // executeLoad round. The entry is live and owns its just-issued request
    // (LSQRequest::install ran inside initiateAcc); the ordinal-selected
    // target moves valid/request into the LQEntry side channel — visibly
    // valid=0, request=nullptr — until its commit/squash boundary
    // (LSQUnit::lq04Restore). No pop, no early free/reuse; the returned
    // fault, the response binding (pkt->senderState) and the data are
    // untouched. The whole block is inert unless CHAOSLQ04 is mounted.
    if (cpu->chaosLQ04 && load_fault == NoFault && inst->isLoad()) {
        LQEntry &e = loadQueue[inst->lqIdx];
        if (chaos_lq04::isEligible(e.valid(), e.hasRequest(),
                                   inst->isSquashed(),
                                   inst->isExecuted())) {
            LSQRequest *req = e.request();
            const uint64_t rid = req->req(0)->getReqInstSeqNum();
            if (cpu->chaosLQ04->maybeSelect(
                    inst->seqNum, inst->pcState().instAddr(), inst->lqIdx,
                    inst->lqEntryGeneration, inst->executionAttemptId,
                    inst->effAddr, inst->effSize, rid,
                    inst->isDataPrefetch() || inst->isInstPrefetch())) {
                const uint64_t occ = loadQueue.size();
                e.corruptLifetime();
                if (cpu->chaosPropagation)
                    cpu->chaosPropagation->noteLQ04Injection(
                        inst.get(), inst->lqIdx, inst->lqEntryGeneration,
                        rid, inst->effAddr, inst->effSize, occ,
                        loadQueue.size(), cpu->chaosLQ04->eligibleCount(),
                        cpu->chaosLQ04->eventOrdinal(),
                        cpu->chaosLQ04->injectedCount(),
                        inst->executionAttemptId, inst->replayGeneration);
            }
        }
    }

    return load_fault;
