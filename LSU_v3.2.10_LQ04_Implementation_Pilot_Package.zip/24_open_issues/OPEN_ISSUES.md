# LSU v3.2.10 — Open issues (extracted from the final report §5)

Extracted verbatim from `LSU_v3.2.10_Final_Report.md` §5 (the full report is
packaged alongside as `FINAL_REPORT.md`). Extraction date: 2026-11-09.

---

## 5. Open issues

1. **Stale Excel oracle for LQ04** — Excel v3.2.4 carries `1624d44faff77183`
   (old `lq_lifetime` workload); the pilots used the D3 workload golden
   `checksum=0xb097eb83f71545cb` via the documented `--workload` override
   (`oracle_source=workload_golden`). To be corrected in the Excel v3.2.5
   transcription (Task 12), together with the workload path/SHA cells and the
   stale sheet-4 `G4` line ranges (freeze doc §1.1).
2. **Disk below guard threshold** — 14 GiB free at pilot time vs the 70.6 GiB
   red line; pilots ran without `lsu_guard`. The two v3.2.9 pytest failures
   (40 passed / 2 failed) are the same environmental disk guard.
3. **Control exit-1 signature** — `run_pilot.py` exits 1 for zero-injection
   controls (`accepted=false`: record validity requires ≥1 injection) while
   gem5 itself exits 0 and the oracle passes. By design; documented so the
   exit code is not misread as a failed control.
4. **Seed recorded as identity, not operative parameter** — the five seeds
   are frozen Excel identity cells carried in `pilot_meta.json`; LQ04 target
   selection is ordinal-gated and deterministic (`--lq04_event_ordinal`),
   so the seed does not drive selection in these pilots. Any future
   seeded-tier selection (D4 explicitly excludes it here) would need the seed
   wired as an operative RNG parameter.
5. **Stale-translation flush skips the corrupt entry** —
   `startStaleTranslationFlush()` / `checkStaleTranslations()`
   (`lsq_unit.cc:1566-1590`) guard `entry.valid() && entry.hasRequest()`, so
   an LQ04-corrupt entry's in-flight request is not marked stale during the
   corrupt window. Documented structural limitation (source audit answer B);
   not exercised by these pilots (no squash, no translation invalidation on a
   target entry).
6. **`/tmp` scratch not part of deliverables** — the Task 9 regression and
   no-fault-baseline outdirs (`/tmp/lq04_reg`, `/tmp/lq04_base_t9`) were
   scratch; their summarized results are committed in
   `logs_v3_2_10/regression_lq04.txt`, the raw outdirs are not deliverables.
7. **Tool-vs-audit coverage label** — the trace tool records the structural
   `propagation_coverage=COMPLETE` in `pilot_meta.json`/
   `LQ04_PILOT_SUMMARY.csv`; this audit and the controller ruling grade the
   research-question coverage as `LIFECYCLE_ONLY` / `PROPAGATION_VERIFIED=0`
   (§3). The artifacts were not rewritten; Task 12's Excel v3.2.5 must use
   the audit grading, not the tool label, for the LQ04 propagation cells.

---

Packaging note (2026-11-09): issue 1 was resolved by the Excel v3.2.5
transcription (commit `6b52ab6e`, packaged in `19_excel_v325/`); the v3.2.5
workbook carries the corrected workload path/SHA and the
`0xb097eb83f71545cb` oracle. The seven items above are otherwise unchanged
at packaging time.
