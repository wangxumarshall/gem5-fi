# LQ04 implementability verdict — location pointer

**Verdict: IMPLEMENTABLE_WITH_CONDITIONS.**

The verdict and its conditions are frozen in two places packaged with this
release (quoted verbatim from the gate documents, not re-derived here):

- `docs/superpowers/specs/2026-11-08-lsu-v3.2.10-lq04-design.md` **§3**
  (approved spec; researcher decisions D1–D6 are frozen verbatim from it into
  the freeze document).
- `02_lq04_original_definition/LQ04_Definition_Freeze_v3.2.10.md` **§4 "Gate
  verdict"**:

  > **IMPLEMENTABLE_WITH_CONDITIONS.**
  >
  > No UAF and no dangling request (source audit answers A–C); but the literal
  > definition (i) violates the commit invariant (`lsq_unit.cc:862`, `:890`,
  > `:343`) and (ii) does not produce the Excel's hypothesized response loss —
  > the honest expected outcome is a trace-visible invalid-entry interval plus
  > the load's normal correct writeback (answer D). The conditions are D1 and
  > D2 below; the negative propagation result is governed by D1 and D5.

- `03_source_audit/LQ04_Source_Audit_v3.2.10.md` **§4 "Gate verdict"** states
  the same verdict with the three conditions: (1) commit integrity — D2's
  side-channel restore at the commit/squash boundary is mandatory; (2)
  honesty — expected terminal MASKED, no manufactured SDC; (3) no leak —
  `_request` must be restorable so the normal `clear()` frees it.

The conditions were implemented (Tasks 4–6) and empirically confirmed by the
five pilots (see `13_five_pilots/`, `16_propagation_audit/` and
`24_open_issues/FINAL_REPORT.md` §4 question 1).
