# LQ04 watchdog / timeout test evidence — provenance note

The CHAOSLQ04 watchdog (`--lq04_watchdog_cycles`, `CHAOSLQ04.cc` watchdog()
at line 212 area, `exitSimLoop("lq04 watchdog expired", 1)`) was verified
functionally during Task 5. The evidence files in this section are **copies
of the original Task 5 run artifacts** (the run itself was executed on
2026-11-09 with the v3.2.10 binary `f3c2a442…`; the originals live in the
Task 5 scratch outdir `/tmp/lq04_t5_wd/`, which is not a deliverable, so the
copies here are the packaged record):

- `watchdog_stdout_lq04_t5_wd.out` — full gem5 stdout of the watchdog run
  (command: `--chaos_lq04 --lq04_event_ordinal 1 --lq04_max_faults 1
  --lq04_watchdog_cycles 1000`, inject-mode config). Line 23:
  `CHAOS_LQ04_WATCHDOG_EXPIRED: selected=0 injected=0 eligible=0 ordinal=1
  tick=385000` — fired at exactly `clockEdge(Cycles(1000))` = tick 385000
  (385 ticks/cycle), before any workload checksum was printed, and the
  process exited with code 1 (`WD_EXIT=1`, recorded in the Task 5 report).
- `lq04_injections_watchdog.log` — the injector's own log from the same run;
  it carries the identical `CHAOS_LQ04_WATCHDOG_EXPIRED` line (the watchdog
  prints to both stdout and `lq04_injections.log`).

The authoritative narrative record (Task 5 report §"Extra verifications"
item 1, including the `WD_EXIT=1` observation) is in the repository at
`.superpowers/sdd/2026-11-08-lsu-v3.2.10-lq04/task-5-report.md`; the exit
code and both output sinks are quoted above from the real run. Watchdog
safety properties: armed only when `watchdogCycles != 0`; descheduled by an
exit callback on normal completion; expiry is exit 1 — it can never be
classified MASKED and never hangs silently.

Related timeout behavior (Task 8, platform side): `run_pilot.py` wraps gem5
in `subprocess.run(..., timeout=...)`, writes partial logs on
`TimeoutExpired`, and sets `run_status=SIMULATOR_ERROR` / `terminal=TIMEOUT`
/ `accepted=False` — a pilot timeout is never MASKED. See
`09_git_diff/GIT_DIFF_CODE_v3210.txt` (platform/run_pilot.py hunk).
