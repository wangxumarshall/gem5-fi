# LQ04 safety analysis — location pointer

The LQ04 safety analysis is not duplicated in this section. It lives in the
source audit and gate documents packaged with this release:

- `03_source_audit/LQ04_Source_Audit_v3.2.10.md`
  - **§1.8 "Readers of `LQEntry::_request` and their guards (answer B
    evidence)"** — every LQ-side reader of `_request` and its null guard
    (`checkSnoop`, `checkViolations`, `startStaleTranslationFlush` /
    `checkStaleTranslations`): no dangling pointer, no use-after-free.
  - **§3 "Audit answers A–D"** — answer A (clearing `_valid`: commit-invariant
    abort sites `lsq_unit.cc:862/:890/:343`), answer B (clearing `_request`:
    memory-safe but leaks one `LSQRequest` without the D2 side channel),
    answer C (no pop / no reuse: occupancy and back-pressure unchanged),
    answer D (no response loss, no mis-binding, no replay, no data
    corruption under the literal definition).
  - **§4 "Gate verdict"** — `IMPLEMENTABLE_WITH_CONDITIONS` with the three
    safety conditions (commit integrity via the boundary restore; honesty —
    no manufactured SDC; no request leak).
- `02_lq04_original_definition/LQ04_Definition_Freeze_v3.2.10.md` **§5
  "Researcher decisions D1–D6"** — D2 (opaque side channel with exact
  boundary restore) is the safety-critical decision.

Runtime safety evidence (executed, not just argued):

- `11_watchdog_timeout_tests/` — the `CHAOS_LQ04_WATCHDOG_EXPIRED` functional
  test: the watchdog fires at `clockEdge(Cycles(1000))` = tick 385000, prints
  to both stdout and `lq04_injections.log`, and exits the simulation with
  code 1 (never a silent hang, never MASKED).
- `12_build_log/regression_lq04.txt` — the unaffected `reg_chain` regression
  (exit 0, checksum `f247ef3fe6f02cfd`, no SIGSEGV) and the no-fault anchor
  baseline (exit 0, `checksum=0xb097eb83f71545cb`).
- `13_five_pilots/` — five fault runs, gem5 exit 0 in 5/5, no crash evidence.
